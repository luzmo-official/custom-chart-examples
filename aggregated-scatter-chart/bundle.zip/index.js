function tr(t){let e=/(?:([^{])?([<>=^]))?([+\- \()])?([$#])?(0)?(\d+)?([,_])?(\.-?\d+)?([a-z%]{1,2})?/i.exec(t)??[];return{fill:e[1]||" ",align:e[2]||">",sign:e[3]||"-",symbol:e[4]||"",zfill:e[5],width:+e[6],comma:e[7],precision:e[8],typeFormat:e[9]}}function rt(t){return t==null}function er(t){return typeof t=="string"||t instanceof String}function Pt(t){return!Number.isNaN(t)&&Number.isFinite(t)}function Wi(t){return typeof t=="boolean"}function Qi(t){return t!==null&&typeof t=="object"&&!Array.isArray(t)}function Zi(t){return t!==null&&typeof t=="object"&&Object.keys(t).length===0}function rr(t,e,r){if(er(t)||Pt(t)||Wi(t))return t.toString();if(rt(t)||!Qi(t)||Zi(t))return"";let n="",o=Object.keys(t);return r!=null&&r.allowEmpty?(e&&t[e]!==void 0&&(n=t[e]),n===void 0&&(n="")):(e&&t[e]&&(n=t[e]),(rt(n)||n==="")&&o!=null&&o.length&&(n=t[o[0]])),n}function Ji(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function ge(t,e){if((r=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var r,n=t.slice(0,r);return[n.length>1?n[0]+n.slice(2):n,+t.slice(r+1)]}function Ki(t){return t=ge(Math.abs(t)),t?t[1]:NaN}function ji(t,e){return function(r,n){for(var o=r.length,i=[],a=0,s=t[0],l=0;o>0&&s>0&&(l+s+1>n&&(s=Math.max(1,n-l)),i.push(r.substring(o-=s,o+s)),!((l+=s+1)>n));)s=t[a=(a+1)%t.length];return i.reverse().join(e)}}function ta(t){return function(e){return e.replace(/[0-9]/g,function(r){return t[+r]})}}var ea=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function sr(t){if(!(e=ea.exec(t)))throw new Error("invalid format: "+t);var e;return new cr({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}sr.prototype=cr.prototype;function cr(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}cr.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function ra(t){t:for(var e=t.length,r=1,n=-1,o;r<e;++r)switch(t[r]){case".":n=o=r;break;case"0":n===0&&(n=r),o=r;break;default:if(!+t[r])break t;n>0&&(n=0);break}return n>0?t.slice(0,n)+t.slice(o+1):t}var xn;function na(t,e){var r=ge(t,e);if(!r)return t+"";var n=r[0],o=r[1],i=o-(xn=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,a=n.length;return i===a?n:i>a?n+new Array(i-a+1).join("0"):i>0?n.slice(0,i)+"."+n.slice(i):"0."+new Array(1-i).join("0")+ge(t,Math.max(0,e+i-1))[0]}function en(t,e){var r=ge(t,e);if(!r)return t+"";var n=r[0],o=r[1];return o<0?"0."+new Array(-o).join("0")+n:n.length>o+1?n.slice(0,o+1)+"."+n.slice(o+1):n+new Array(o-n.length+2).join("0")}var rn={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:Ji,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>en(t*100,e),r:en,s:na,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function nn(t){return t}var on=Array.prototype.map,an=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function oa(t){var e=t.grouping===void 0||t.thousands===void 0?nn:ji(on.call(t.grouping,Number),t.thousands+""),r=t.currency===void 0?"":t.currency[0]+"",n=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",i=t.numerals===void 0?nn:ta(on.call(t.numerals,String)),a=t.percent===void 0?"%":t.percent+"",s=t.minus===void 0?"\u2212":t.minus+"",l=t.nan===void 0?"NaN":t.nan+"";function u(c){c=sr(c);var p=c.fill,m=c.align,g=c.sign,y=c.symbol,_=c.zero,h=c.width,C=c.comma,w=c.precision,S=c.trim,b=c.type;b==="n"?(C=!0,b="g"):rn[b]||(w===void 0&&(w=12),S=!0,b="g"),(_||p==="0"&&m==="=")&&(_=!0,p="0",m="=");var M=y==="$"?r:y==="#"&&/[boxX]/.test(b)?"0"+b.toLowerCase():"",Y=y==="$"?n:/[%p]/.test(b)?a:"",z=rn[b],Q=/[defgprs%]/.test(b);w=w===void 0?6:/[gprs]/.test(b)?Math.max(1,Math.min(21,w)):Math.max(0,Math.min(20,w));function G(x){var F=M,A=Y,L,gt,J;if(b==="c")A=z(x)+A,x="";else{x=+x;var K=x<0||1/x<0;if(x=isNaN(x)?l:z(Math.abs(x),w),S&&(x=ra(x)),K&&+x==0&&g!=="+"&&(K=!1),F=(K?g==="("?g:s:g==="-"||g==="("?"":g)+F,A=(b==="s"?an[8+xn/3]:"")+A+(K&&g==="("?")":""),Q){for(L=-1,gt=x.length;++L<gt;)if(J=x.charCodeAt(L),48>J||J>57){A=(J===46?o+x.slice(L+1):x.slice(L))+A,x=x.slice(0,L);break}}}C&&!_&&(x=e(x,1/0));var j=F.length+x.length+A.length,I=j<h?new Array(h-j+1).join(p):"";switch(C&&_&&(x=e(I+x,I.length?h-A.length:1/0),I=""),m){case"<":x=F+x+A+I;break;case"=":x=F+I+x+A;break;case"^":x=I.slice(0,j=I.length>>1)+F+x+A+I.slice(j);break;default:x=I+F+x+A;break}return i(x)}return G.toString=function(){return c+""},G}function f(c,p){var m=u((c=sr(c),c.type="f",c)),g=Math.max(-8,Math.min(8,Math.floor(Ki(p)/3)))*3,y=Math.pow(10,-g),_=an[8+g/3];return function(h){return m(y*h)+_}}return{format:u,formatPrefix:f}}var nr=new Date,or=new Date;function q(t,e,r,n){function o(i){return t(i=arguments.length===0?new Date:new Date(+i)),i}return o.floor=i=>(t(i=new Date(+i)),i),o.ceil=i=>(t(i=new Date(i-1)),e(i,1),t(i),i),o.round=i=>{let a=o(i),s=o.ceil(i);return i-a<s-i?a:s},o.offset=(i,a)=>(e(i=new Date(+i),a==null?1:Math.floor(a)),i),o.range=(i,a,s)=>{let l=[];if(i=o.ceil(i),s=s==null?1:Math.floor(s),!(i<a)||!(s>0))return l;let u;do l.push(u=new Date(+i)),e(i,s),t(i);while(u<i&&i<a);return l},o.filter=i=>q(a=>{if(a>=a)for(;t(a),!i(a);)a.setTime(a-1)},(a,s)=>{if(a>=a)if(s<0)for(;++s<=0;)for(;e(a,-1),!i(a););else for(;--s>=0;)for(;e(a,1),!i(a););}),r&&(o.count=(i,a)=>(nr.setTime(+i),or.setTime(+a),t(nr),t(or),Math.floor(r(nr,or))),o.every=i=>(i=Math.floor(i),!isFinite(i)||!(i>0)?null:i>1?o.filter(n?a=>n(a)%i===0:a=>o.count(0,a)%i===0):o)),o}var Vt=1e3,ct=Vt*60,Ht=ct*60,Gt=Ht*24,yn=Gt*7,bn=q(t=>{t.setTime(t-t.getMilliseconds())},(t,e)=>{t.setTime(+t+e*Vt)},(t,e)=>(e-t)/Vt,t=>t.getUTCSeconds());bn.range;var vn=q(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*Vt)},(t,e)=>{t.setTime(+t+e*ct)},(t,e)=>(e-t)/ct,t=>t.getMinutes());vn.range;var ia=q(t=>{t.setUTCSeconds(0,0)},(t,e)=>{t.setTime(+t+e*ct)},(t,e)=>(e-t)/ct,t=>t.getUTCMinutes());ia.range;var wn=q(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*Vt-t.getMinutes()*ct)},(t,e)=>{t.setTime(+t+e*Ht)},(t,e)=>(e-t)/Ht,t=>t.getHours());wn.range;var aa=q(t=>{t.setUTCMinutes(0,0,0)},(t,e)=>{t.setTime(+t+e*Ht)},(t,e)=>(e-t)/Ht,t=>t.getUTCHours());aa.range;var be=q(t=>t.setHours(0,0,0,0),(t,e)=>t.setDate(t.getDate()+e),(t,e)=>(e-t-(e.getTimezoneOffset()-t.getTimezoneOffset())*ct)/Gt,t=>t.getDate()-1);be.range;var fr=q(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/Gt,t=>t.getUTCDate()-1);fr.range;var sa=q(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/Gt,t=>Math.floor(t/Gt));sa.range;function bt(t){return q(e=>{e.setDate(e.getDate()-(e.getDay()+7-t)%7),e.setHours(0,0,0,0)},(e,r)=>{e.setDate(e.getDate()+r*7)},(e,r)=>(r-e-(r.getTimezoneOffset()-e.getTimezoneOffset())*ct)/yn)}var mr=bt(0),xe=bt(1),la=bt(2),ua=bt(3),Ft=bt(4),ca=bt(5),fa=bt(6);mr.range;xe.range;la.range;ua.range;Ft.range;ca.range;fa.range;function vt(t){return q(e=>{e.setUTCDate(e.getUTCDate()-(e.getUTCDay()+7-t)%7),e.setUTCHours(0,0,0,0)},(e,r)=>{e.setUTCDate(e.getUTCDate()+r*7)},(e,r)=>(r-e)/yn)}var _n=vt(0),ye=vt(1),ma=vt(2),pa=vt(3),Et=vt(4),da=vt(5),ha=vt(6);_n.range;ye.range;ma.range;pa.range;Et.range;da.range;ha.range;var Cn=q(t=>{t.setDate(1),t.setHours(0,0,0,0)},(t,e)=>{t.setMonth(t.getMonth()+e)},(t,e)=>e.getMonth()-t.getMonth()+(e.getFullYear()-t.getFullYear())*12,t=>t.getMonth());Cn.range;var ga=q(t=>{t.setUTCDate(1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCMonth(t.getUTCMonth()+e)},(t,e)=>e.getUTCMonth()-t.getUTCMonth()+(e.getUTCFullYear()-t.getUTCFullYear())*12,t=>t.getUTCMonth());ga.range;var ft=q(t=>{t.setMonth(0,1),t.setHours(0,0,0,0)},(t,e)=>{t.setFullYear(t.getFullYear()+e)},(t,e)=>e.getFullYear()-t.getFullYear(),t=>t.getFullYear());ft.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:q(e=>{e.setFullYear(Math.floor(e.getFullYear()/t)*t),e.setMonth(0,1),e.setHours(0,0,0,0)},(e,r)=>{e.setFullYear(e.getFullYear()+r*t)});ft.range;var yt=q(t=>{t.setUTCMonth(0,1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCFullYear(t.getUTCFullYear()+e)},(t,e)=>e.getUTCFullYear()-t.getUTCFullYear(),t=>t.getUTCFullYear());yt.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:q(e=>{e.setUTCFullYear(Math.floor(e.getUTCFullYear()/t)*t),e.setUTCMonth(0,1),e.setUTCHours(0,0,0,0)},(e,r)=>{e.setUTCFullYear(e.getUTCFullYear()+r*t)});yt.range;function ir(t){if(0<=t.y&&t.y<100){var e=new Date(-1,t.m,t.d,t.H,t.M,t.S,t.L);return e.setFullYear(t.y),e}return new Date(t.y,t.m,t.d,t.H,t.M,t.S,t.L)}function ar(t){if(0<=t.y&&t.y<100){var e=new Date(Date.UTC(-1,t.m,t.d,t.H,t.M,t.S,t.L));return e.setUTCFullYear(t.y),e}return new Date(Date.UTC(t.y,t.m,t.d,t.H,t.M,t.S,t.L))}function $t(t,e,r){return{y:t,m:e,d:r,H:0,M:0,S:0,L:0}}function lr(t){var e=t.dateTime,r=t.date,n=t.time,o=t.periods,i=t.days,a=t.shortDays,s=t.months,l=t.shortMonths,u=Lt(o),f=Ut(o),c=Lt(i),p=Ut(i),m=Lt(a),g=Ut(a),y=Lt(s),_=Ut(s),h=Lt(l),C=Ut(l),w={a:K,A:j,b:I,B:qi,c:null,d:mn,e:mn,f:qa,g:Qa,G:Ja,H:za,I:Ba,j:Ra,L:Sn,m:Pa,M:$a,p:Pi,q:$i,Q:hn,s:gn,S:La,u:Ua,U:Va,V:Ha,w:Ga,W:Xa,x:null,X:null,y:Wa,Y:Za,Z:Ka,"%":dn},S={a:Li,A:Ui,b:Vi,B:Hi,c:null,d:pn,e:pn,f:rs,g:ms,G:ds,H:ja,I:ts,j:es,L:kn,m:ns,M:os,p:Gi,q:Xi,Q:hn,s:gn,S:is,u:as,U:ss,V:ls,w:us,W:cs,x:null,X:null,y:fs,Y:ps,Z:hs,"%":dn},b={a:G,A:x,b:F,B:A,c:L,d:cn,e:cn,f:Na,g:un,G:ln,H:fn,I:fn,j:Da,L:Ea,m:Aa,M:Ta,p:Q,q:ka,Q:Ya,s:Ia,S:Fa,u:wa,U:_a,V:Ca,w:va,W:Sa,x:gt,X:J,y:un,Y:ln,Z:Ma,"%":Oa};w.x=M(r,w),w.X=M(n,w),w.c=M(e,w),S.x=M(r,S),S.X=M(n,S),S.c=M(e,S);function M(v,k){return function(D){var d=[],V=-1,E=0,X=v.length,W,xt,tn;for(D instanceof Date||(D=new Date(+D));++V<X;)v.charCodeAt(V)===37&&(d.push(v.slice(E,V)),(xt=sn[W=v.charAt(++V)])!=null?W=v.charAt(++V):xt=W==="e"?" ":"0",(tn=k[W])&&(W=tn(D,xt)),d.push(W),E=V+1);return d.push(v.slice(E,V)),d.join("")}}function Y(v,k){return function(D){var d=$t(1900,void 0,1),V=z(d,v,D+="",0),E,X;if(V!=D.length)return null;if("Q"in d)return new Date(d.Q);if("s"in d)return new Date(d.s*1e3+("L"in d?d.L:0));if(k&&!("Z"in d)&&(d.Z=0),"p"in d&&(d.H=d.H%12+d.p*12),d.m===void 0&&(d.m="q"in d?d.q:0),"V"in d){if(d.V<1||d.V>53)return null;"w"in d||(d.w=1),"Z"in d?(E=ar($t(d.y,0,1)),X=E.getUTCDay(),E=X>4||X===0?ye.ceil(E):ye(E),E=fr.offset(E,(d.V-1)*7),d.y=E.getUTCFullYear(),d.m=E.getUTCMonth(),d.d=E.getUTCDate()+(d.w+6)%7):(E=ir($t(d.y,0,1)),X=E.getDay(),E=X>4||X===0?xe.ceil(E):xe(E),E=be.offset(E,(d.V-1)*7),d.y=E.getFullYear(),d.m=E.getMonth(),d.d=E.getDate()+(d.w+6)%7)}else("W"in d||"U"in d)&&("w"in d||(d.w="u"in d?d.u%7:"W"in d?1:0),X="Z"in d?ar($t(d.y,0,1)).getUTCDay():ir($t(d.y,0,1)).getDay(),d.m=0,d.d="W"in d?(d.w+6)%7+d.W*7-(X+5)%7:d.w+d.U*7-(X+6)%7);return"Z"in d?(d.H+=d.Z/100|0,d.M+=d.Z%100,ar(d)):ir(d)}}function z(v,k,D,d){for(var V=0,E=k.length,X=D.length,W,xt;V<E;){if(d>=X)return-1;if(W=k.charCodeAt(V++),W===37){if(W=k.charAt(V++),xt=b[W in sn?k.charAt(V++):W],!xt||(d=xt(v,D,d))<0)return-1}else if(W!=D.charCodeAt(d++))return-1}return d}function Q(v,k,D){var d=u.exec(k.slice(D));return d?(v.p=f.get(d[0].toLowerCase()),D+d[0].length):-1}function G(v,k,D){var d=m.exec(k.slice(D));return d?(v.w=g.get(d[0].toLowerCase()),D+d[0].length):-1}function x(v,k,D){var d=c.exec(k.slice(D));return d?(v.w=p.get(d[0].toLowerCase()),D+d[0].length):-1}function F(v,k,D){var d=h.exec(k.slice(D));return d?(v.m=C.get(d[0].toLowerCase()),D+d[0].length):-1}function A(v,k,D){var d=y.exec(k.slice(D));return d?(v.m=_.get(d[0].toLowerCase()),D+d[0].length):-1}function L(v,k,D){return z(v,e,k,D)}function gt(v,k,D){return z(v,r,k,D)}function J(v,k,D){return z(v,n,k,D)}function K(v){return a[v.getDay()]}function j(v){return i[v.getDay()]}function I(v){return l[v.getMonth()]}function qi(v){return s[v.getMonth()]}function Pi(v){return o[+(v.getHours()>=12)]}function $i(v){return 1+~~(v.getMonth()/3)}function Li(v){return a[v.getUTCDay()]}function Ui(v){return i[v.getUTCDay()]}function Vi(v){return l[v.getUTCMonth()]}function Hi(v){return s[v.getUTCMonth()]}function Gi(v){return o[+(v.getUTCHours()>=12)]}function Xi(v){return 1+~~(v.getUTCMonth()/3)}return{format:function(v){var k=M(v+="",w);return k.toString=function(){return v},k},parse:function(v){var k=Y(v+="",!1);return k.toString=function(){return v},k},utcFormat:function(v){var k=M(v+="",S);return k.toString=function(){return v},k},utcParse:function(v){var k=Y(v+="",!0);return k.toString=function(){return v},k}}}var sn={"-":"",_:" ",0:"0"},R=/^\s*\d+/,xa=/^%/,ya=/[\\^$*+?|[\]().{}]/g;function T(t,e,r){var n=t<0?"-":"",o=(n?-t:t)+"",i=o.length;return n+(i<r?new Array(r-i+1).join(e)+o:o)}function ba(t){return t.replace(ya,"\\$&")}function Lt(t){return new RegExp("^(?:"+t.map(ba).join("|")+")","i")}function Ut(t){return new Map(t.map((e,r)=>[e.toLowerCase(),r]))}function va(t,e,r){var n=R.exec(e.slice(r,r+1));return n?(t.w=+n[0],r+n[0].length):-1}function wa(t,e,r){var n=R.exec(e.slice(r,r+1));return n?(t.u=+n[0],r+n[0].length):-1}function _a(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.U=+n[0],r+n[0].length):-1}function Ca(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.V=+n[0],r+n[0].length):-1}function Sa(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.W=+n[0],r+n[0].length):-1}function ln(t,e,r){var n=R.exec(e.slice(r,r+4));return n?(t.y=+n[0],r+n[0].length):-1}function un(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.y=+n[0]+(+n[0]>68?1900:2e3),r+n[0].length):-1}function Ma(t,e,r){var n=/^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(r,r+6));return n?(t.Z=n[1]?0:-(n[2]+(n[3]||"00")),r+n[0].length):-1}function ka(t,e,r){var n=R.exec(e.slice(r,r+1));return n?(t.q=n[0]*3-3,r+n[0].length):-1}function Aa(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.m=n[0]-1,r+n[0].length):-1}function cn(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.d=+n[0],r+n[0].length):-1}function Da(t,e,r){var n=R.exec(e.slice(r,r+3));return n?(t.m=0,t.d=+n[0],r+n[0].length):-1}function fn(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.H=+n[0],r+n[0].length):-1}function Ta(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.M=+n[0],r+n[0].length):-1}function Fa(t,e,r){var n=R.exec(e.slice(r,r+2));return n?(t.S=+n[0],r+n[0].length):-1}function Ea(t,e,r){var n=R.exec(e.slice(r,r+3));return n?(t.L=+n[0],r+n[0].length):-1}function Na(t,e,r){var n=R.exec(e.slice(r,r+6));return n?(t.L=Math.floor(n[0]/1e3),r+n[0].length):-1}function Oa(t,e,r){var n=xa.exec(e.slice(r,r+1));return n?r+n[0].length:-1}function Ya(t,e,r){var n=R.exec(e.slice(r));return n?(t.Q=+n[0],r+n[0].length):-1}function Ia(t,e,r){var n=R.exec(e.slice(r));return n?(t.s=+n[0],r+n[0].length):-1}function mn(t,e){return T(t.getDate(),e,2)}function za(t,e){return T(t.getHours(),e,2)}function Ba(t,e){return T(t.getHours()%12||12,e,2)}function Ra(t,e){return T(1+be.count(ft(t),t),e,3)}function Sn(t,e){return T(t.getMilliseconds(),e,3)}function qa(t,e){return Sn(t,e)+"000"}function Pa(t,e){return T(t.getMonth()+1,e,2)}function $a(t,e){return T(t.getMinutes(),e,2)}function La(t,e){return T(t.getSeconds(),e,2)}function Ua(t){var e=t.getDay();return e===0?7:e}function Va(t,e){return T(mr.count(ft(t)-1,t),e,2)}function Mn(t){var e=t.getDay();return e>=4||e===0?Ft(t):Ft.ceil(t)}function Ha(t,e){return t=Mn(t),T(Ft.count(ft(t),t)+(ft(t).getDay()===4),e,2)}function Ga(t){return t.getDay()}function Xa(t,e){return T(xe.count(ft(t)-1,t),e,2)}function Wa(t,e){return T(t.getFullYear()%100,e,2)}function Qa(t,e){return t=Mn(t),T(t.getFullYear()%100,e,2)}function Za(t,e){return T(t.getFullYear()%1e4,e,4)}function Ja(t,e){var r=t.getDay();return t=r>=4||r===0?Ft(t):Ft.ceil(t),T(t.getFullYear()%1e4,e,4)}function Ka(t){var e=t.getTimezoneOffset();return(e>0?"-":(e*=-1,"+"))+T(e/60|0,"0",2)+T(e%60,"0",2)}function pn(t,e){return T(t.getUTCDate(),e,2)}function ja(t,e){return T(t.getUTCHours(),e,2)}function ts(t,e){return T(t.getUTCHours()%12||12,e,2)}function es(t,e){return T(1+fr.count(yt(t),t),e,3)}function kn(t,e){return T(t.getUTCMilliseconds(),e,3)}function rs(t,e){return kn(t,e)+"000"}function ns(t,e){return T(t.getUTCMonth()+1,e,2)}function os(t,e){return T(t.getUTCMinutes(),e,2)}function is(t,e){return T(t.getUTCSeconds(),e,2)}function as(t){var e=t.getUTCDay();return e===0?7:e}function ss(t,e){return T(_n.count(yt(t)-1,t),e,2)}function An(t){var e=t.getUTCDay();return e>=4||e===0?Et(t):Et.ceil(t)}function ls(t,e){return t=An(t),T(Et.count(yt(t),t)+(yt(t).getUTCDay()===4),e,2)}function us(t){return t.getUTCDay()}function cs(t,e){return T(ye.count(yt(t)-1,t),e,2)}function fs(t,e){return T(t.getUTCFullYear()%100,e,2)}function ms(t,e){return t=An(t),T(t.getUTCFullYear()%100,e,2)}function ps(t,e){return T(t.getUTCFullYear()%1e4,e,4)}function ds(t,e){var r=t.getUTCDay();return t=r>=4||r===0?Et(t):Et.ceil(t),T(t.getUTCFullYear()%1e4,e,4)}function hs(){return"+0000"}function dn(){return"%"}function hn(t){return+t}function gn(t){return Math.floor(+t/1e3)}var Tt,it;gs({dateTime:"%x, %X",date:"%-m/%-d/%Y",time:"%-I:%M:%S %p",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]});function gs(t){return Tt=lr(t),it=Tt.format,Tt.parse,Tt.utcFormat,Tt.utcParse,Tt}var ur=[[1,4,12,52,365,365*24,365*24*60,365*24*60*60,365*24*60*60*1e3],[1/4,1,3,13,91,91*24,91*24*60,91*24*60*60,91*24*60*60*1e3],[1/12,1/3,1,4,30,30*24,30*24*60,30*24*60*60,30*24*60*60*1e3],[1/52,1/13,1/4,1,7,7*24,7*24*60,7*24*60*60,7*24*60*60*1e3],[1/365,1/91,1/30,1/7,1,24,24*60,24*60*60,24*60*60*1e3],[1/(365*24),1/(91*24),1/(30*24),1/(7*24),1/24,1,60,60*60,60*60*1e3],[1/(365*24*60),1/(91*24*60),1/(30*24*60),1/(7*24*60),1/(24*60),1/60,1,60,60*1e3],[1/(365*24*60*60),1/(91*24*60*60),1/(30*24*60*60),1/(7*24*60*60),1/(24*60*60),1/(60*60),1/60,1,1e3],[1/(365*24*60*60*1e3),1/(91*24*60*60*1e3),1/(30*24*60*60*1e3),1/(7*24*60*60*1e3),1/(24*60*60*1e3),1/(60*60*1e3),1/(60*1e3),1/1e3,1]];function xs(t,e,r){if(rt(t))return;if(!e||!r||e===r)return t;let n=ur[e-1][r-1];if(n)return t*n}function ys(t,e,r,n){if(rt(t)||!e.lowestLevel||r.length===0)return"";let o=[],i=0,a=Math.round(t*ur[e.lowestLevel-1][8]),s=9;for(let[,u]of r.entries())if(t){a=a-i;let f=ur[u-1][s-1],c=Math.floor(a/f);i=c*f,o.push({level:u,value:c})}else o.push({level:u,value:0});let l="";for(let[u,f]of o.entries())if(e.duration.format==="time"){let c=f.value;[6,7,8].includes(f.level)&&f.value<10?c="0"+f.value.toString():f.level===9&&f.value<10?c="00"+f.value.toString():f.level===9&&f.value<100&&(c="0"+f.value.toString()),l+=(u===0?"":f.level===9?".":":")+c}else if(e.duration.format==="long"){let c=n.durationLongSuffix;l+=f.value+" "+c[f.level]+(u===o.length-1?"":" ")}else{let c=n.durationShortSuffix;l+=f.value+""+c[f.level]+(u===o.length-1?"":" ")}return l}var bs={decimal:".",thousands:",",grouping:[3],currency:["$",""],dateTime:"%a %b %e %X %Y",date:"%m/%d/%Y",dateSeparator:"/",time:"%H:%M:%S",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],levels:["All","Year","Quarter","Month","Week","Date","Hour","Minute","Second","Millisecond"],shortLevels:["All","Yr","Qtr","Mth","Wk","Date","Hr","Min","Sec","Msec"],durationLongSuffix:["","years","quarters","months","weeks","days","hours","minutes","seconds","milliseconds"],durationShortSuffix:["","y","q","mo","w","d","h","m","s","ms"],multi:[".%L",":%S","%I:%M","%I %p","%a %d","W%G","%b %d","%B","%Y"]},vs="%d-%m-%Y",ws=[{key:"%a %e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%a %e %b %Y",monthType:"name",longText:!1,weekday:!0},{key:"%e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%e %b %Y",monthType:"name",longText:!1,weekday:!1},{key:"%a %e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%a %e %B %Y",monthType:"name",longText:!0,weekday:!0},{key:"%e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%e %B %Y",monthType:"name",longText:!0,weekday:!1},{key:"%d/%m/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"W%V/%G",lev5:"%d/%m/%Y",monthType:"number",mmdd:!1,separator:"/"},{key:"%d-%m-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"W%V-%G",lev5:"%d-%m-%Y",monthType:"number",mmdd:!1,separator:"-"},{key:"%d.%m.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"W%V.%G",lev5:"%d.%m.%Y",monthType:"number",mmdd:!1,separator:"."},{key:"%d~%m~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"W%V~%G",lev5:"%d~%m~%Y",monthType:"number",mmdd:!1,separator:"~"},{key:"%m/%d/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%m/%d/%Y",monthType:"number",mmdd:!0,separator:"/"},{key:"%m-%d-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%m-%d-%Y",monthType:"number",mmdd:!0,separator:"-"},{key:"%m.%d.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%m.%d.%Y",monthType:"number",mmdd:!0,separator:"."},{key:"%m~%d~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%m~%d~%Y",monthType:"number",mmdd:!0,separator:"~"},{key:"%amd/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%amd/%Y",monthType:"number",mmdd:null,separator:"/"},{key:"%amd-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%amd-%Y",monthType:"number",mmdd:null,separator:"-"},{key:"%amd.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%amd.%Y",monthType:"number",mmdd:null,separator:"."},{key:"%amd~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%amd~%Y",monthType:"number",mmdd:null,separator:"~"}],_s=[{key:"%H:%M:%S.%L",lev6:"%H:00",lev7:"%H:%M",lev8:"%H:%M:%S",lev9:"%H:%M:%S.%L",ampm:!1},{key:"%I:%M:%S.%L %p",lev6:"%I:00 %p",lev7:"%I:%M %p",lev8:"%I:%M:%S %p",lev9:"%I:%M:%S.%L %p",ampm:!0}];function Xt(t,e){var r,n;e=e||{};let o=e.localFormats||bs,i,a,s,l=[],u=[],f="datetime",c;e&&e.multi&&(f="datetime"),(!t||!t.format)&&(f="hierarchy"),t&&t.type&&(f=t.type),t&&t.format?c=t.format:f==="numeric"?c=",.0f":f==="datetime"?c=vs:c="";let p=tr(c);switch(p.precision&&p.typeFormat&&(f="numeric"),f){case"numeric":{if(t.subtype==="duration"&&t.duration&&t.duration.levels&&t.duration.levels.length>1&&!e.hideDuration)i=m=>rt(m)?"":ys(m,t,t.duration.levels,o);else{let m={...o},g=p.typeFormat,y=!1;switch(g.length===2&&g.startsWith("a")&&(y=!0,g=g.slice(1,2),c=c.replace(/a/,"")),y?(m.decimal=o.decimal,m.thousands=o.thousands):["z","y","w"].includes(g)?(m.decimal=",",m.thousands="."):(m.decimal=".",m.thousands=","),g){case"z":{c=c.replace("z","f");break}case"y":{c=c.replace("y","%");break}case"w":{c=c.replace("w","s");break}}if(t?.subtype==="currency"&&t.currency){let h="\xA0",C=m.currency.findIndex(M=>M.length>0),w=m.currency[C].startsWith(h),S=m.currency[C].endsWith(h),b=`${w?h:""}${t.currency}${S?h:""}`;m.currency[C]=b}let _=oa(m);g!=="%"&&t?.subtype==="currency"&&t.currency&&m.currency&&!(e!=null&&e.hideCurrency)&&!["count","distinctcount"].includes(t.aggregationFunc)&&!(t.aggregationFunc==="rate"&&((r=t.aggregationWeight)==null?void 0:r.columnSubType)==="currency")&&((n=t.periodOverPeriod)==null?void 0:n.type)!=="percentageChange"&&(c="$"+c),e!=null&&e.trimZero&&["y","%"].includes(g)&&m.decimal===","?a=h=>_.format(c)(h).replace(/(,\d*?)0+%$/,"$1%").replace(/,%$/,"%"):e!=null&&e.trimZero&&["y","%"].includes(g)&&m.decimal==="."?a=h=>_.format(c)(h).replace(/(\.\d*?)0+%$/,"$1%").replace(/\.%$/,"%"):e!=null&&e.trimZero&&["z","f"].includes(g)&&m.decimal===","?a=h=>_.format(c)(h).replace(/(,\d*?)0+$/,"$1").replace(/,$/,""):e!=null&&e.trimZero&&["z","f"].includes(g)&&m.decimal==="."?a=h=>_.format(c)(h).replace(/(\.\d*?)0+$/,"$1").replace(/\.$/,""):t?.subtype==="currency"&&t.currency&&m.currency&&g==="s"?a=h=>_.format(c)(h).replace(/G/,"B"):a=rt(p.precision)?_.format(",.0f"):_.format(c),i=h=>{var C;if(rt(h))return"";if(t.subtype==="duration"&&t.duration&&!e.hideDuration){let w=t.duration.levels?t.duration.levels[0]:t.lowestLevel;return w!==t.lowestLevel&&(h=xs(h,t.lowestLevel,w)),a(h)+((C=o?.durationShortSuffix)==null?void 0:C[w])}return a(h)}}break}case"datetime":{if(l=o?.smartDateFormats??ws,u=o?.smartTimeFormats??_s,rt(t.datetimeDisplayMode)){if(e!=null&&e.level){let m=e.level,g=l.find(S=>c.includes(S.key)),y=u.find(S=>c.includes(S.key)),_=g?g["lev"+Math.min(m,5)]:l[0]["lev"+Math.min(m,5)],h=m>5?y?y["lev"+m]:u[0]["lev"+m]:"";c=m>5?_+", "+h:_;let C=c.includes("%amd")&&e.level>=5,w=g?e.level>=2&&g.separator==="~":!1;C?c=w?c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8)):c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8).replaceAll(new RegExp(/[.~\/-]/g),g.separator)):c=w?c.replaceAll(new RegExp(/[~]/g),o.dateSeparator):c}if(e!=null&&e.multi){let m=it(o.multi[0]),g=it(o.multi[1]),y=it(o.multi[2]),_=it(o.multi[3]),h=it(o.multi[4]),C=it(o.multi[6]),w=it(o.multi[7]),S=it(o.multi[8]);s=b=>{let M;return bn(b)<b?M=m:vn(b)<b?M=g:wn(b)<b?M=y:be(b)<b?M=_:Cn(b)<b?M=mr(b)<b?h:C:ft(b)<b?M=w:M=S,M(b)}}else s=lr(o).format(c)}else{let m={quarter_number:{min:1,max:4},month_name:{min:1,max:12},month_number:{min:1,max:12},week_number:{min:1,max:53},day_in_month:{min:1,max:31},day_in_year:{min:1,max:366},weekday_name:{min:0,max:7},weekday_number:{min:0,max:7},hour_in_day:{min:0,max:23},minute_in_hour:{min:0,max:59},second_in_minute:{min:0,max:59}},g=(y,_,h)=>{var C,w,S,b,M;return _==="letter"?((C=y.shortNames)==null?void 0:C.length)>0&&((w=y.shortNames[h])==null?void 0:w.length)>0?(S=y.shortNames[h])==null?void 0:S.charAt(0):"N/A":_==="short"?((b=y.shortNames)==null?void 0:b.length)>0&&y.shortNames[h]?y.shortNames[h]:"N/A":((M=y.longNames)==null?void 0:M.length)>0&&y.longNames[h]?y.longNames[h]:"N/A"};["quarter_number","month_number","week_number","day_in_month","day_in_year","weekday_number","hour_in_day","minute_in_hour","second_in_minute"].includes(t.datetimeDisplayMode)?s=y=>Pt(y)&&y>=m[t.datetimeDisplayMode].min&&y<=m[t.datetimeDisplayMode].max?y:"N/A":t.datetimeDisplayMode==="month_name"?s=y=>{let _=[...o.shortMonths],h=[...o.months];return Pt(y)&&y>=m[t.datetimeDisplayMode].min&&y<=m[t.datetimeDisplayMode].max?g({shortNames:_,longNames:h},t.monthNameFormat,y-1):"N/A"}:t.datetimeDisplayMode==="weekday_name"?s=y=>{let _=[...o.shortDays],h=[...o.days];return t.weekStart==="monday"&&(_.push(_.shift()??""),h.push(h.shift()??"")),Pt(y)&&y>=m[t.datetimeDisplayMode].min&&y<=m[t.datetimeDisplayMode].max?g({shortNames:_,longNames:h},t.weekDayNameFormat,y-1):"N/A"}:s=lr(o).format(c)}i=m=>{if(rt(m))return"";let g=s(m);return er(g)?g.trim():g};break}case"hierarchy":{i=m=>rr(m,e?e.locale:void 0);break}default:{i=m=>m;break}}return i}var Z={type:"platform",background:"rgb(245,245,245)",itemsBackground:"rgb(255,255,255)",boxShadow:{size:"none",color:"rgb(0, 0, 0)"},title:{align:"left",bold:!1,italic:!1,underline:!1,border:!1},font:{fontFamily:"Lato","font-style":"normal","font-weight":400,fontSize:15},colors:["rgb(68,52,255)","rgb(143,133,255)","rgb(218,214,255)","rgb(191,5,184)","rgb(217,105,212)","rgb(242,205,241)","rgb(248,194,12)","rgb(251,218,109)","rgb(254,243,206)","rgb(9,203,120)","rgb(107,224,174)","rgb(206,245,228)","rgb(122,112,112)","rgb(175,169,169)","rgb(228,226,226)"],borders:{"border-color":"rgba(216,216,216,1)","border-style":"none","border-radius":"12px","border-top-width":"0px","border-left-width":"0px","border-right-width":"0px","border-bottom-width":"0px"},margins:[16,16],mainColor:"rgb(68,52,255)",axis:{},legend:{type:"circle"},tooltip:{background:"rgb(38,38,38)"},itemSpecific:{rounding:8,padding:4}},Nt=(t,e)=>({"border-color":t,"border-style":"none","border-radius":e,"border-top-width":"1px","border-left-width":"1px","border-right-width":"1px","border-bottom-width":"1px"}),Ym={default:{...Z,name:"Default (light)"},default_dark:{...Z,name:"Default (dark)",background:"rgb(61,61,61)",itemsBackground:"rgb(38,38,38)",colors:["rgb(48,36,179)","rgb(105,93,255)","rgb(199,194,255)","rgb(134,4,129)","rgb(204,55,198)","rgb(236,180,234)","rgb(220,141,0)","rgb(249,206,61)","rgb(253,237,182)","rgb(6,142,84)","rgb(58,213,147)","rgb(181,239,215)","rgb(85,78,78)","rgb(149,141,141)","rgb(215,212,212)"],mainColor:"rgb(123,144,255)",tooltip:{background:"rgb(248,248,248)"}},vivid:{...Z,name:"Vivid",background:"#eef3f6",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[12,12],mainColor:"#5867C3",legend:{type:"normal"},tooltip:{},colors:["#5867C3","#00C5DC","#FF525E","#FFAA00","#FFDB03","#86de40","#59b339","#cc27bc","#ff4aed","#bfbfbf","#737373"],font:{fontFamily:"Open Sans",fontSize:13}},seasonal:{...Z,name:"Seasonal",background:"#ffffff",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:Nt("rgba(0,0,0,.1)","8px"),margins:[10,10],mainColor:"#009788",tooltip:{},colors:["#009788","#60cc64","#CDDC39","#FFEB3C","#FEC107","#FF9700","#FE5722","#EA1E63","#9C28B1","#673BB7","#3F51B5","#2196F3","#03A9F5","#00BCD5"],font:{fontFamily:"Open Sans",fontSize:13}},orion:{...Z,name:"Orion's Belt",background:"#00062d",itemsBackground:"#00062d",boxShadow:{size:"L",color:"#64046f"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:Nt("rgba(0, 0, 0, .1)","8px"),mainColor:"#d62750",legend:{type:"normal"},colors:["#880065","#b3005e","#d62750","#ef513e","#fd7b27","#ffa600","#fdae6b"],font:{fontFamily:"Electrolize",fontSize:15}},royale:{...Z,name:"Royale",background:"#0A2747",itemsBackground:"#111e2f",boxShadow:{size:"S",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{"border-radius":"3px"},margins:[10,10],mainColor:"#f4a92c",legend:{type:"circle"},tooltip:{},colors:["#feeaa1","#e6cc85","#ceaf6a","#b79350","#9f7738","#885d20","#704308"],font:{fontFamily:"Exo",fontSize:13}},urban:{...Z,name:"Urban",background:"#42403c",itemsBackground:"#e4dbcd",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[5,5],mainColor:"#33b59e",legend:{type:"circle"},colors:["#33b59e","#453d30","#ffffff","#237869","#165e4e","#b89f76","#7a6138","#543c13","#8a9c98","#44524f"],font:{fontFamily:"Open Sans",fontSize:13}},pinky:{...Z,name:"Pinky Brains",background:"#0F1E43",itemsBackground:"#1B2A4D",title:{align:"center",bold:!0,italic:!1,underline:!1,border:!0},borders:Nt("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#e84281",legend:{type:"normal"},tooltip:{},colors:["#e84281","#d464c2","#a089f2","#46a8ff","#00c0ff","#00d0e8","#49dcc9"],font:{fontFamily:"Capriola",fontSize:15}},bliss:{...Z,name:"Bliss",background:"#ffffff",itemsBackground:"#ffffff",boxShadow:{size:"none",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:Nt("rgba(0, 0, 0, .1)","8px"),margins:[10,10],mainColor:"#0578ff",axis:{},legend:{type:"normal"},tooltip:{},colors:["#b8d8ff","#3ba0ff","#0044f2","#1b00ca","#9114de","#ce42ff","#ff19f6","#ed2bab","#d8175c","#ff303d","#ff6130","#ff9f30","#15BF49","#95E88C"],font:{fontFamily:"Open Sans",fontSize:13}},radiant:{...Z,name:"Radiant",background:"rgba(43,43,56,1)",itemsBackground:"rgba(52,52,69,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:Nt("rgba(255, 255, 255, .08)","8px"),margins:[14,14],mainColor:"#00a4eb",legend:{type:"line"},tooltip:{},colors:["#a6e1ff","#00a4eb","#3f3af0","#9300c7","#f72f5f","#f29b50","#f2d566","#3ae086","#c9c9c9","#7a7a7a"],font:{fontFamily:"Open Sans",fontSize:13}},classic:{...Z,name:"Classic (light)",background:"#F2F2F2",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#ececec",borders:Nt("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#009dff",legend:{type:"normal"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}},classic_dark:{...Z,name:"Classic (dark)",background:"rgb(38,39,50)",itemsBackground:"rgba(52,53,68,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{},margins:[10,10],mainColor:"#0E89E0",legend:{type:"line"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}}};function wt(t,e){return t==null||e==null?NaN:t<e?-1:t>e?1:t>=e?0:NaN}function pr(t,e){return t==null||e==null?NaN:e<t?-1:e>t?1:e>=t?0:NaN}function ve(t){let e,r,n;t.length!==2?(e=wt,r=(s,l)=>wt(t(s),l),n=(s,l)=>t(s)-l):(e=t===wt||t===pr?t:Cs,r=t,n=t);function o(s,l,u=0,f=s.length){if(u<f){if(e(l,l)!==0)return f;do{let c=u+f>>>1;r(s[c],l)<0?u=c+1:f=c}while(u<f)}return u}function i(s,l,u=0,f=s.length){if(u<f){if(e(l,l)!==0)return f;do{let c=u+f>>>1;r(s[c],l)<=0?u=c+1:f=c}while(u<f)}return u}function a(s,l,u=0,f=s.length){let c=o(s,l,u,f-1);return c>u&&n(s[c-1],l)>-n(s[c],l)?c-1:c}return{left:o,center:a,right:i}}function Cs(){return 0}function dr(t){return t===null?NaN:+t}var Dn=ve(wt),Tn=Dn.right,Ss=Dn.left,Ms=ve(dr).center,hr=Tn;function Wt(t,e){let r,n;if(e===void 0)for(let o of t)o!=null&&(r===void 0?o>=o&&(r=n=o):(r>o&&(r=o),n<o&&(n=o)));else{let o=-1;for(let i of t)(i=e(i,++o,t))!=null&&(r===void 0?i>=i&&(r=n=i):(r>i&&(r=i),n<i&&(n=i)))}return[r,n]}var Ot=class extends Map{constructor(e,r=Ds){if(super(),Object.defineProperties(this,{_intern:{value:new Map},_key:{value:r}}),e!=null)for(let[n,o]of e)this.set(n,o)}get(e){return super.get(Fn(this,e))}has(e){return super.has(Fn(this,e))}set(e,r){return super.set(ks(this,e),r)}delete(e){return super.delete(As(this,e))}};function Fn({_intern:t,_key:e},r){let n=e(r);return t.has(n)?t.get(n):r}function ks({_intern:t,_key:e},r){let n=e(r);return t.has(n)?t.get(n):(t.set(n,r),r)}function As({_intern:t,_key:e},r){let n=e(r);return t.has(n)&&(r=t.get(n),t.delete(n)),r}function Ds(t){return t!==null&&typeof t=="object"?t.valueOf():t}var Ts=Math.sqrt(50),Fs=Math.sqrt(10),Es=Math.sqrt(2);function we(t,e,r){let n=(e-t)/Math.max(0,r),o=Math.floor(Math.log10(n)),i=n/Math.pow(10,o),a=i>=Ts?10:i>=Fs?5:i>=Es?2:1,s,l,u;return o<0?(u=Math.pow(10,-o)/a,s=Math.round(t*u),l=Math.round(e*u),s/u<t&&++s,l/u>e&&--l,u=-u):(u=Math.pow(10,o)*a,s=Math.round(t/u),l=Math.round(e/u),s*u<t&&++s,l*u>e&&--l),l<s&&.5<=r&&r<2?we(t,e,r*2):[s,l,u]}function _e(t,e,r){if(e=+e,t=+t,r=+r,!(r>0))return[];if(t===e)return[t];let n=e<t,[o,i,a]=n?we(e,t,r):we(t,e,r);if(!(i>=o))return[];let s=i-o+1,l=new Array(s);if(n)if(a<0)for(let u=0;u<s;++u)l[u]=(i-u)/-a;else for(let u=0;u<s;++u)l[u]=(i-u)*a;else if(a<0)for(let u=0;u<s;++u)l[u]=(o+u)/-a;else for(let u=0;u<s;++u)l[u]=(o+u)*a;return l}function Qt(t,e,r){return e=+e,t=+t,r=+r,we(t,e,r)[2]}function gr(t,e,r){e=+e,t=+t,r=+r;let n=e<t,o=n?Qt(e,t,r):Qt(t,e,r);return(n?-1:1)*(o<0?1/-o:o)}function En(t){return t}var xr=1,yr=2,br=3,Zt=4,Nn=1e-6;function Ns(t){return"translate("+t+",0)"}function Os(t){return"translate(0,"+t+")"}function Ys(t){return e=>+t(e)}function Is(t,e){return e=Math.max(0,t.bandwidth()-e*2)/2,t.round()&&(e=Math.round(e)),r=>+t(r)+e}function zs(){return!this.__axis}function On(t,e){var r=[],n=null,o=null,i=6,a=6,s=3,l=typeof window<"u"&&window.devicePixelRatio>1?0:.5,u=t===xr||t===Zt?-1:1,f=t===Zt||t===yr?"x":"y",c=t===xr||t===br?Ns:Os;function p(m){var g=n??(e.ticks?e.ticks.apply(e,r):e.domain()),y=o??(e.tickFormat?e.tickFormat.apply(e,r):En),_=Math.max(i,0)+s,h=e.range(),C=+h[0]+l,w=+h[h.length-1]+l,S=(e.bandwidth?Is:Ys)(e.copy(),l),b=m.selection?m.selection():m,M=b.selectAll(".domain").data([null]),Y=b.selectAll(".tick").data(g,e).order(),z=Y.exit(),Q=Y.enter().append("g").attr("class","tick"),G=Y.select("line"),x=Y.select("text");M=M.merge(M.enter().insert("path",".tick").attr("class","domain").attr("stroke","currentColor")),Y=Y.merge(Q),G=G.merge(Q.append("line").attr("stroke","currentColor").attr(f+"2",u*i)),x=x.merge(Q.append("text").attr("fill","currentColor").attr(f,u*_).attr("dy",t===xr?"0em":t===br?"0.71em":"0.32em")),m!==b&&(M=M.transition(m),Y=Y.transition(m),G=G.transition(m),x=x.transition(m),z=z.transition(m).attr("opacity",Nn).attr("transform",function(F){return isFinite(F=S(F))?c(F+l):this.getAttribute("transform")}),Q.attr("opacity",Nn).attr("transform",function(F){var A=this.parentNode.__axis;return c((A&&isFinite(A=A(F))?A:S(F))+l)})),z.remove(),M.attr("d",t===Zt||t===yr?a?"M"+u*a+","+C+"H"+l+"V"+w+"H"+u*a:"M"+l+","+C+"V"+w:a?"M"+C+","+u*a+"V"+l+"H"+w+"V"+u*a:"M"+C+","+l+"H"+w),Y.attr("opacity",1).attr("transform",function(F){return c(S(F)+l)}),G.attr(f+"2",u*i),x.attr(f,u*_).text(y),b.filter(zs).attr("fill","none").attr("font-size",10).attr("font-family","sans-serif").attr("text-anchor",t===yr?"start":t===Zt?"end":"middle"),b.each(function(){this.__axis=S})}return p.scale=function(m){return arguments.length?(e=m,p):e},p.ticks=function(){return r=Array.from(arguments),p},p.tickArguments=function(m){return arguments.length?(r=m==null?[]:Array.from(m),p):r.slice()},p.tickValues=function(m){return arguments.length?(n=m==null?null:Array.from(m),p):n&&n.slice()},p.tickFormat=function(m){return arguments.length?(o=m,p):o},p.tickSize=function(m){return arguments.length?(i=a=+m,p):i},p.tickSizeInner=function(m){return arguments.length?(i=+m,p):i},p.tickSizeOuter=function(m){return arguments.length?(a=+m,p):a},p.tickPadding=function(m){return arguments.length?(s=+m,p):s},p.offset=function(m){return arguments.length?(l=+m,p):l},p}function vr(t){return On(br,t)}function wr(t){return On(Zt,t)}var Bs={value:()=>{}};function In(){for(var t=0,e=arguments.length,r={},n;t<e;++t){if(!(n=arguments[t]+"")||n in r||/[\s.]/.test(n))throw new Error("illegal type: "+n);r[n]=[]}return new Ce(r)}function Ce(t){this._=t}function Rs(t,e){return t.trim().split(/^|\s+/).map(function(r){var n="",o=r.indexOf(".");if(o>=0&&(n=r.slice(o+1),r=r.slice(0,o)),r&&!e.hasOwnProperty(r))throw new Error("unknown type: "+r);return{type:r,name:n}})}Ce.prototype=In.prototype={constructor:Ce,on:function(t,e){var r=this._,n=Rs(t+"",r),o,i=-1,a=n.length;if(arguments.length<2){for(;++i<a;)if((o=(t=n[i]).type)&&(o=qs(r[o],t.name)))return o;return}if(e!=null&&typeof e!="function")throw new Error("invalid callback: "+e);for(;++i<a;)if(o=(t=n[i]).type)r[o]=Yn(r[o],t.name,e);else if(e==null)for(o in r)r[o]=Yn(r[o],t.name,null);return this},copy:function(){var t={},e=this._;for(var r in e)t[r]=e[r].slice();return new Ce(t)},call:function(t,e){if((o=arguments.length-2)>0)for(var r=new Array(o),n=0,o,i;n<o;++n)r[n]=arguments[n+2];if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(i=this._[t],n=0,o=i.length;n<o;++n)i[n].value.apply(e,r)},apply:function(t,e,r){if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(var n=this._[t],o=0,i=n.length;o<i;++o)n[o].value.apply(e,r)}};function qs(t,e){for(var r=0,n=t.length,o;r<n;++r)if((o=t[r]).name===e)return o.value}function Yn(t,e,r){for(var n=0,o=t.length;n<o;++n)if(t[n].name===e){t[n]=Bs,t=t.slice(0,n).concat(t.slice(n+1));break}return r!=null&&t.push({name:e,value:r}),t}var _r=In;var Se="http://www.w3.org/1999/xhtml",Cr={svg:"http://www.w3.org/2000/svg",xhtml:Se,xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace",xmlns:"http://www.w3.org/2000/xmlns/"};function at(t){var e=t+="",r=e.indexOf(":");return r>=0&&(e=t.slice(0,r))!=="xmlns"&&(t=t.slice(r+1)),Cr.hasOwnProperty(e)?{space:Cr[e],local:t}:t}function Ps(t){return function(){var e=this.ownerDocument,r=this.namespaceURI;return r===Se&&e.documentElement.namespaceURI===Se?e.createElement(t):e.createElementNS(r,t)}}function $s(t){return function(){return this.ownerDocument.createElementNS(t.space,t.local)}}function Me(t){var e=at(t);return(e.local?$s:Ps)(e)}function Ls(){}function _t(t){return t==null?Ls:function(){return this.querySelector(t)}}function zn(t){typeof t!="function"&&(t=_t(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,s=n[o]=new Array(a),l,u,f=0;f<a;++f)(l=i[f])&&(u=t.call(l,l.__data__,f,i))&&("__data__"in l&&(u.__data__=l.__data__),s[f]=u);return new N(n,this._parents)}function Jt(t){return t==null?[]:Array.isArray(t)?t:Array.from(t)}function Us(){return[]}function Kt(t){return t==null?Us:function(){return this.querySelectorAll(t)}}function Vs(t){return function(){return Jt(t.apply(this,arguments))}}function Bn(t){typeof t=="function"?t=Vs(t):t=Kt(t);for(var e=this._groups,r=e.length,n=[],o=[],i=0;i<r;++i)for(var a=e[i],s=a.length,l,u=0;u<s;++u)(l=a[u])&&(n.push(t.call(l,l.__data__,u,a)),o.push(l));return new N(n,o)}function jt(t){return function(){return this.matches(t)}}function ke(t){return function(e){return e.matches(t)}}var Hs=Array.prototype.find;function Gs(t){return function(){return Hs.call(this.children,t)}}function Xs(){return this.firstElementChild}function Rn(t){return this.select(t==null?Xs:Gs(typeof t=="function"?t:ke(t)))}var Ws=Array.prototype.filter;function Qs(){return Array.from(this.children)}function Zs(t){return function(){return Ws.call(this.children,t)}}function qn(t){return this.selectAll(t==null?Qs:Zs(typeof t=="function"?t:ke(t)))}function Pn(t){typeof t!="function"&&(t=jt(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,s=n[o]=[],l,u=0;u<a;++u)(l=i[u])&&t.call(l,l.__data__,u,i)&&s.push(l);return new N(n,this._parents)}function Ae(t){return new Array(t.length)}function $n(){return new N(this._enter||this._groups.map(Ae),this._parents)}function te(t,e){this.ownerDocument=t.ownerDocument,this.namespaceURI=t.namespaceURI,this._next=null,this._parent=t,this.__data__=e}te.prototype={constructor:te,appendChild:function(t){return this._parent.insertBefore(t,this._next)},insertBefore:function(t,e){return this._parent.insertBefore(t,e)},querySelector:function(t){return this._parent.querySelector(t)},querySelectorAll:function(t){return this._parent.querySelectorAll(t)}};function Ln(t){return function(){return t}}function Js(t,e,r,n,o,i){for(var a=0,s,l=e.length,u=i.length;a<u;++a)(s=e[a])?(s.__data__=i[a],n[a]=s):r[a]=new te(t,i[a]);for(;a<l;++a)(s=e[a])&&(o[a]=s)}function Ks(t,e,r,n,o,i,a){var s,l,u=new Map,f=e.length,c=i.length,p=new Array(f),m;for(s=0;s<f;++s)(l=e[s])&&(p[s]=m=a.call(l,l.__data__,s,e)+"",u.has(m)?o[s]=l:u.set(m,l));for(s=0;s<c;++s)m=a.call(t,i[s],s,i)+"",(l=u.get(m))?(n[s]=l,l.__data__=i[s],u.delete(m)):r[s]=new te(t,i[s]);for(s=0;s<f;++s)(l=e[s])&&u.get(p[s])===l&&(o[s]=l)}function js(t){return t.__data__}function Un(t,e){if(!arguments.length)return Array.from(this,js);var r=e?Ks:Js,n=this._parents,o=this._groups;typeof t!="function"&&(t=Ln(t));for(var i=o.length,a=new Array(i),s=new Array(i),l=new Array(i),u=0;u<i;++u){var f=n[u],c=o[u],p=c.length,m=tl(t.call(f,f&&f.__data__,u,n)),g=m.length,y=s[u]=new Array(g),_=a[u]=new Array(g),h=l[u]=new Array(p);r(f,c,y,_,h,m,e);for(var C=0,w=0,S,b;C<g;++C)if(S=y[C]){for(C>=w&&(w=C+1);!(b=_[w])&&++w<g;);S._next=b||null}}return a=new N(a,n),a._enter=s,a._exit=l,a}function tl(t){return typeof t=="object"&&"length"in t?t:Array.from(t)}function Vn(){return new N(this._exit||this._groups.map(Ae),this._parents)}function Hn(t,e,r){var n=this.enter(),o=this,i=this.exit();return typeof t=="function"?(n=t(n),n&&(n=n.selection())):n=n.append(t+""),e!=null&&(o=e(o),o&&(o=o.selection())),r==null?i.remove():r(i),n&&o?n.merge(o).order():o}function Gn(t){for(var e=t.selection?t.selection():t,r=this._groups,n=e._groups,o=r.length,i=n.length,a=Math.min(o,i),s=new Array(o),l=0;l<a;++l)for(var u=r[l],f=n[l],c=u.length,p=s[l]=new Array(c),m,g=0;g<c;++g)(m=u[g]||f[g])&&(p[g]=m);for(;l<o;++l)s[l]=r[l];return new N(s,this._parents)}function Xn(){for(var t=this._groups,e=-1,r=t.length;++e<r;)for(var n=t[e],o=n.length-1,i=n[o],a;--o>=0;)(a=n[o])&&(i&&a.compareDocumentPosition(i)^4&&i.parentNode.insertBefore(a,i),i=a);return this}function Wn(t){t||(t=el);function e(c,p){return c&&p?t(c.__data__,p.__data__):!c-!p}for(var r=this._groups,n=r.length,o=new Array(n),i=0;i<n;++i){for(var a=r[i],s=a.length,l=o[i]=new Array(s),u,f=0;f<s;++f)(u=a[f])&&(l[f]=u);l.sort(e)}return new N(o,this._parents).order()}function el(t,e){return t<e?-1:t>e?1:t>=e?0:NaN}function Qn(){var t=arguments[0];return arguments[0]=this,t.apply(null,arguments),this}function Zn(){return Array.from(this)}function Jn(){for(var t=this._groups,e=0,r=t.length;e<r;++e)for(var n=t[e],o=0,i=n.length;o<i;++o){var a=n[o];if(a)return a}return null}function Kn(){let t=0;for(let e of this)++t;return t}function jn(){return!this.node()}function to(t){for(var e=this._groups,r=0,n=e.length;r<n;++r)for(var o=e[r],i=0,a=o.length,s;i<a;++i)(s=o[i])&&t.call(s,s.__data__,i,o);return this}function rl(t){return function(){this.removeAttribute(t)}}function nl(t){return function(){this.removeAttributeNS(t.space,t.local)}}function ol(t,e){return function(){this.setAttribute(t,e)}}function il(t,e){return function(){this.setAttributeNS(t.space,t.local,e)}}function al(t,e){return function(){var r=e.apply(this,arguments);r==null?this.removeAttribute(t):this.setAttribute(t,r)}}function sl(t,e){return function(){var r=e.apply(this,arguments);r==null?this.removeAttributeNS(t.space,t.local):this.setAttributeNS(t.space,t.local,r)}}function eo(t,e){var r=at(t);if(arguments.length<2){var n=this.node();return r.local?n.getAttributeNS(r.space,r.local):n.getAttribute(r)}return this.each((e==null?r.local?nl:rl:typeof e=="function"?r.local?sl:al:r.local?il:ol)(r,e))}function De(t){return t.ownerDocument&&t.ownerDocument.defaultView||t.document&&t||t.defaultView}function ll(t){return function(){this.style.removeProperty(t)}}function ul(t,e,r){return function(){this.style.setProperty(t,e,r)}}function cl(t,e,r){return function(){var n=e.apply(this,arguments);n==null?this.style.removeProperty(t):this.style.setProperty(t,n,r)}}function ro(t,e,r){return arguments.length>1?this.each((e==null?ll:typeof e=="function"?cl:ul)(t,e,r??"")):mt(this.node(),t)}function mt(t,e){return t.style.getPropertyValue(e)||De(t).getComputedStyle(t,null).getPropertyValue(e)}function fl(t){return function(){delete this[t]}}function ml(t,e){return function(){this[t]=e}}function pl(t,e){return function(){var r=e.apply(this,arguments);r==null?delete this[t]:this[t]=r}}function no(t,e){return arguments.length>1?this.each((e==null?fl:typeof e=="function"?pl:ml)(t,e)):this.node()[t]}function oo(t){return t.trim().split(/^|\s+/)}function Sr(t){return t.classList||new io(t)}function io(t){this._node=t,this._names=oo(t.getAttribute("class")||"")}io.prototype={add:function(t){var e=this._names.indexOf(t);e<0&&(this._names.push(t),this._node.setAttribute("class",this._names.join(" ")))},remove:function(t){var e=this._names.indexOf(t);e>=0&&(this._names.splice(e,1),this._node.setAttribute("class",this._names.join(" ")))},contains:function(t){return this._names.indexOf(t)>=0}};function ao(t,e){for(var r=Sr(t),n=-1,o=e.length;++n<o;)r.add(e[n])}function so(t,e){for(var r=Sr(t),n=-1,o=e.length;++n<o;)r.remove(e[n])}function dl(t){return function(){ao(this,t)}}function hl(t){return function(){so(this,t)}}function gl(t,e){return function(){(e.apply(this,arguments)?ao:so)(this,t)}}function lo(t,e){var r=oo(t+"");if(arguments.length<2){for(var n=Sr(this.node()),o=-1,i=r.length;++o<i;)if(!n.contains(r[o]))return!1;return!0}return this.each((typeof e=="function"?gl:e?dl:hl)(r,e))}function xl(){this.textContent=""}function yl(t){return function(){this.textContent=t}}function bl(t){return function(){var e=t.apply(this,arguments);this.textContent=e??""}}function uo(t){return arguments.length?this.each(t==null?xl:(typeof t=="function"?bl:yl)(t)):this.node().textContent}function vl(){this.innerHTML=""}function wl(t){return function(){this.innerHTML=t}}function _l(t){return function(){var e=t.apply(this,arguments);this.innerHTML=e??""}}function co(t){return arguments.length?this.each(t==null?vl:(typeof t=="function"?_l:wl)(t)):this.node().innerHTML}function Cl(){this.nextSibling&&this.parentNode.appendChild(this)}function fo(){return this.each(Cl)}function Sl(){this.previousSibling&&this.parentNode.insertBefore(this,this.parentNode.firstChild)}function mo(){return this.each(Sl)}function po(t){var e=typeof t=="function"?t:Me(t);return this.select(function(){return this.appendChild(e.apply(this,arguments))})}function Ml(){return null}function ho(t,e){var r=typeof t=="function"?t:Me(t),n=e==null?Ml:typeof e=="function"?e:_t(e);return this.select(function(){return this.insertBefore(r.apply(this,arguments),n.apply(this,arguments)||null)})}function kl(){var t=this.parentNode;t&&t.removeChild(this)}function go(){return this.each(kl)}function Al(){var t=this.cloneNode(!1),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function Dl(){var t=this.cloneNode(!0),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function xo(t){return this.select(t?Dl:Al)}function yo(t){return arguments.length?this.property("__data__",t):this.node().__data__}function Tl(t){return function(e){t.call(this,e,this.__data__)}}function Fl(t){return t.trim().split(/^|\s+/).map(function(e){var r="",n=e.indexOf(".");return n>=0&&(r=e.slice(n+1),e=e.slice(0,n)),{type:e,name:r}})}function El(t){return function(){var e=this.__on;if(e){for(var r=0,n=-1,o=e.length,i;r<o;++r)i=e[r],(!t.type||i.type===t.type)&&i.name===t.name?this.removeEventListener(i.type,i.listener,i.options):e[++n]=i;++n?e.length=n:delete this.__on}}}function Nl(t,e,r){return function(){var n=this.__on,o,i=Tl(e);if(n){for(var a=0,s=n.length;a<s;++a)if((o=n[a]).type===t.type&&o.name===t.name){this.removeEventListener(o.type,o.listener,o.options),this.addEventListener(o.type,o.listener=i,o.options=r),o.value=e;return}}this.addEventListener(t.type,i,r),o={type:t.type,name:t.name,value:e,listener:i,options:r},n?n.push(o):this.__on=[o]}}function bo(t,e,r){var n=Fl(t+""),o,i=n.length,a;if(arguments.length<2){var s=this.node().__on;if(s){for(var l=0,u=s.length,f;l<u;++l)for(o=0,f=s[l];o<i;++o)if((a=n[o]).type===f.type&&a.name===f.name)return f.value}return}for(s=e?Nl:El,o=0;o<i;++o)this.each(s(n[o],e,r));return this}function vo(t,e,r){var n=De(t),o=n.CustomEvent;typeof o=="function"?o=new o(e,r):(o=n.document.createEvent("Event"),r?(o.initEvent(e,r.bubbles,r.cancelable),o.detail=r.detail):o.initEvent(e,!1,!1)),t.dispatchEvent(o)}function Ol(t,e){return function(){return vo(this,t,e)}}function Yl(t,e){return function(){return vo(this,t,e.apply(this,arguments))}}function wo(t,e){return this.each((typeof e=="function"?Yl:Ol)(t,e))}function*_o(){for(var t=this._groups,e=0,r=t.length;e<r;++e)for(var n=t[e],o=0,i=n.length,a;o<i;++o)(a=n[o])&&(yield a)}var ee=[null];function N(t,e){this._groups=t,this._parents=e}function Co(){return new N([[document.documentElement]],ee)}function Il(){return this}N.prototype=Co.prototype={constructor:N,select:zn,selectAll:Bn,selectChild:Rn,selectChildren:qn,filter:Pn,data:Un,enter:$n,exit:Vn,join:Hn,merge:Gn,selection:Il,order:Xn,sort:Wn,call:Qn,nodes:Zn,node:Jn,size:Kn,empty:jn,each:to,attr:eo,style:ro,property:no,classed:lo,text:uo,html:co,raise:fo,lower:mo,append:po,insert:ho,remove:go,clone:xo,datum:yo,on:bo,dispatch:wo,[Symbol.iterator]:_o};var st=Co;function lt(t){return typeof t=="string"?new N([[document.querySelector(t)]],[document.documentElement]):new N([[t]],ee)}function Mr(t){return typeof t=="string"?new N([document.querySelectorAll(t)],[document.documentElement]):new N([Jt(t)],ee)}function Te(t,e,r){t.prototype=e.prototype=r,r.constructor=t}function kr(t,e){var r=Object.create(t.prototype);for(var n in e)r[n]=e[n];return r}function oe(){}var re=.7,Ne=1/re,Yt="\\s*([+-]?\\d+)\\s*",ne="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*",nt="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*",zl=/^#([0-9a-f]{3,8})$/,Bl=new RegExp(`^rgb\\(${Yt},${Yt},${Yt}\\)$`),Rl=new RegExp(`^rgb\\(${nt},${nt},${nt}\\)$`),ql=new RegExp(`^rgba\\(${Yt},${Yt},${Yt},${ne}\\)$`),Pl=new RegExp(`^rgba\\(${nt},${nt},${nt},${ne}\\)$`),$l=new RegExp(`^hsl\\(${ne},${nt},${nt}\\)$`),Ll=new RegExp(`^hsla\\(${ne},${nt},${nt},${ne}\\)$`),So={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074};Te(oe,et,{copy(t){return Object.assign(new this.constructor,this,t)},displayable(){return this.rgb().displayable()},hex:Mo,formatHex:Mo,formatHex8:Ul,formatHsl:Vl,formatRgb:ko,toString:ko});function Mo(){return this.rgb().formatHex()}function Ul(){return this.rgb().formatHex8()}function Vl(){return No(this).formatHsl()}function ko(){return this.rgb().formatRgb()}function et(t){var e,r;return t=(t+"").trim().toLowerCase(),(e=zl.exec(t))?(r=e[1].length,e=parseInt(e[1],16),r===6?Ao(e):r===3?new H(e>>8&15|e>>4&240,e>>4&15|e&240,(e&15)<<4|e&15,1):r===8?Fe(e>>24&255,e>>16&255,e>>8&255,(e&255)/255):r===4?Fe(e>>12&15|e>>8&240,e>>8&15|e>>4&240,e>>4&15|e&240,((e&15)<<4|e&15)/255):null):(e=Bl.exec(t))?new H(e[1],e[2],e[3],1):(e=Rl.exec(t))?new H(e[1]*255/100,e[2]*255/100,e[3]*255/100,1):(e=ql.exec(t))?Fe(e[1],e[2],e[3],e[4]):(e=Pl.exec(t))?Fe(e[1]*255/100,e[2]*255/100,e[3]*255/100,e[4]):(e=$l.exec(t))?Fo(e[1],e[2]/100,e[3]/100,1):(e=Ll.exec(t))?Fo(e[1],e[2]/100,e[3]/100,e[4]):So.hasOwnProperty(t)?Ao(So[t]):t==="transparent"?new H(NaN,NaN,NaN,0):null}function Ao(t){return new H(t>>16&255,t>>8&255,t&255,1)}function Fe(t,e,r,n){return n<=0&&(t=e=r=NaN),new H(t,e,r,n)}function Hl(t){return t instanceof oe||(t=et(t)),t?(t=t.rgb(),new H(t.r,t.g,t.b,t.opacity)):new H}function It(t,e,r,n){return arguments.length===1?Hl(t):new H(t,e,r,n??1)}function H(t,e,r,n){this.r=+t,this.g=+e,this.b=+r,this.opacity=+n}Te(H,It,kr(oe,{brighter(t){return t=t==null?Ne:Math.pow(Ne,t),new H(this.r*t,this.g*t,this.b*t,this.opacity)},darker(t){return t=t==null?re:Math.pow(re,t),new H(this.r*t,this.g*t,this.b*t,this.opacity)},rgb(){return this},clamp(){return new H(St(this.r),St(this.g),St(this.b),Oe(this.opacity))},displayable(){return-.5<=this.r&&this.r<255.5&&-.5<=this.g&&this.g<255.5&&-.5<=this.b&&this.b<255.5&&0<=this.opacity&&this.opacity<=1},hex:Do,formatHex:Do,formatHex8:Gl,formatRgb:To,toString:To}));function Do(){return`#${Ct(this.r)}${Ct(this.g)}${Ct(this.b)}`}function Gl(){return`#${Ct(this.r)}${Ct(this.g)}${Ct(this.b)}${Ct((isNaN(this.opacity)?1:this.opacity)*255)}`}function To(){let t=Oe(this.opacity);return`${t===1?"rgb(":"rgba("}${St(this.r)}, ${St(this.g)}, ${St(this.b)}${t===1?")":`, ${t})`}`}function Oe(t){return isNaN(t)?1:Math.max(0,Math.min(1,t))}function St(t){return Math.max(0,Math.min(255,Math.round(t)||0))}function Ct(t){return t=St(t),(t<16?"0":"")+t.toString(16)}function Fo(t,e,r,n){return n<=0?t=e=r=NaN:r<=0||r>=1?t=e=NaN:e<=0&&(t=NaN),new tt(t,e,r,n)}function No(t){if(t instanceof tt)return new tt(t.h,t.s,t.l,t.opacity);if(t instanceof oe||(t=et(t)),!t)return new tt;if(t instanceof tt)return t;t=t.rgb();var e=t.r/255,r=t.g/255,n=t.b/255,o=Math.min(e,r,n),i=Math.max(e,r,n),a=NaN,s=i-o,l=(i+o)/2;return s?(e===i?a=(r-n)/s+(r<n)*6:r===i?a=(n-e)/s+2:a=(e-r)/s+4,s/=l<.5?i+o:2-i-o,a*=60):s=l>0&&l<1?0:a,new tt(a,s,l,t.opacity)}function Oo(t,e,r,n){return arguments.length===1?No(t):new tt(t,e,r,n??1)}function tt(t,e,r,n){this.h=+t,this.s=+e,this.l=+r,this.opacity=+n}Te(tt,Oo,kr(oe,{brighter(t){return t=t==null?Ne:Math.pow(Ne,t),new tt(this.h,this.s,this.l*t,this.opacity)},darker(t){return t=t==null?re:Math.pow(re,t),new tt(this.h,this.s,this.l*t,this.opacity)},rgb(){var t=this.h%360+(this.h<0)*360,e=isNaN(t)||isNaN(this.s)?0:this.s,r=this.l,n=r+(r<.5?r:1-r)*e,o=2*r-n;return new H(Ar(t>=240?t-240:t+120,o,n),Ar(t,o,n),Ar(t<120?t+240:t-120,o,n),this.opacity)},clamp(){return new tt(Eo(this.h),Ee(this.s),Ee(this.l),Oe(this.opacity))},displayable(){return(0<=this.s&&this.s<=1||isNaN(this.s))&&0<=this.l&&this.l<=1&&0<=this.opacity&&this.opacity<=1},formatHsl(){let t=Oe(this.opacity);return`${t===1?"hsl(":"hsla("}${Eo(this.h)}, ${Ee(this.s)*100}%, ${Ee(this.l)*100}%${t===1?")":`, ${t})`}`}}));function Eo(t){return t=(t||0)%360,t<0?t+360:t}function Ee(t){return Math.max(0,Math.min(1,t||0))}function Ar(t,e,r){return(t<60?e+(r-e)*t/60:t<180?r:t<240?e+(r-e)*(240-t)/60:e)*255}function Dr(t,e,r,n,o){var i=t*t,a=i*t;return((1-3*t+3*i-a)*e+(4-6*i+3*a)*r+(1+3*t+3*i-3*a)*n+a*o)/6}function Yo(t){var e=t.length-1;return function(r){var n=r<=0?r=0:r>=1?(r=1,e-1):Math.floor(r*e),o=t[n],i=t[n+1],a=n>0?t[n-1]:2*o-i,s=n<e-1?t[n+2]:2*i-o;return Dr((r-n/e)*e,a,o,i,s)}}function Io(t){var e=t.length;return function(r){var n=Math.floor(((r%=1)<0?++r:r)*e),o=t[(n+e-1)%e],i=t[n%e],a=t[(n+1)%e],s=t[(n+2)%e];return Dr((r-n/e)*e,o,i,a,s)}}var ie=t=>()=>t;function Xl(t,e){return function(r){return t+r*e}}function Wl(t,e,r){return t=Math.pow(t,r),e=Math.pow(e,r)-t,r=1/r,function(n){return Math.pow(t+n*e,r)}}function zo(t){return(t=+t)==1?Ye:function(e,r){return r-e?Wl(e,r,t):ie(isNaN(e)?r:e)}}function Ye(t,e){var r=e-t;return r?Xl(t,r):ie(isNaN(t)?e:t)}var Mt=function t(e){var r=zo(e);function n(o,i){var a=r((o=It(o)).r,(i=It(i)).r),s=r(o.g,i.g),l=r(o.b,i.b),u=Ye(o.opacity,i.opacity);return function(f){return o.r=a(f),o.g=s(f),o.b=l(f),o.opacity=u(f),o+""}}return n.gamma=t,n}(1);function Bo(t){return function(e){var r=e.length,n=new Array(r),o=new Array(r),i=new Array(r),a,s;for(a=0;a<r;++a)s=It(e[a]),n[a]=s.r||0,o[a]=s.g||0,i[a]=s.b||0;return n=t(n),o=t(o),i=t(i),s.opacity=1,function(l){return s.r=n(l),s.g=o(l),s.b=i(l),s+""}}}var Ql=Bo(Yo),Zl=Bo(Io);function Ro(t,e){e||(e=[]);var r=t?Math.min(e.length,t.length):0,n=e.slice(),o;return function(i){for(o=0;o<r;++o)n[o]=t[o]*(1-i)+e[o]*i;return n}}function qo(t){return ArrayBuffer.isView(t)&&!(t instanceof DataView)}function Po(t,e){var r=e?e.length:0,n=t?Math.min(r,t.length):0,o=new Array(n),i=new Array(r),a;for(a=0;a<n;++a)o[a]=kt(t[a],e[a]);for(;a<r;++a)i[a]=e[a];return function(s){for(a=0;a<n;++a)i[a]=o[a](s);return i}}function $o(t,e){var r=new Date;return t=+t,e=+e,function(n){return r.setTime(t*(1-n)+e*n),r}}function P(t,e){return t=+t,e=+e,function(r){return t*(1-r)+e*r}}function Lo(t,e){var r={},n={},o;(t===null||typeof t!="object")&&(t={}),(e===null||typeof e!="object")&&(e={});for(o in e)o in t?r[o]=kt(t[o],e[o]):n[o]=e[o];return function(i){for(o in r)n[o]=r[o](i);return n}}var Fr=/[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,Tr=new RegExp(Fr.source,"g");function Jl(t){return function(){return t}}function Kl(t){return function(e){return t(e)+""}}function ae(t,e){var r=Fr.lastIndex=Tr.lastIndex=0,n,o,i,a=-1,s=[],l=[];for(t=t+"",e=e+"";(n=Fr.exec(t))&&(o=Tr.exec(e));)(i=o.index)>r&&(i=e.slice(r,i),s[a]?s[a]+=i:s[++a]=i),(n=n[0])===(o=o[0])?s[a]?s[a]+=o:s[++a]=o:(s[++a]=null,l.push({i:a,x:P(n,o)})),r=Tr.lastIndex;return r<e.length&&(i=e.slice(r),s[a]?s[a]+=i:s[++a]=i),s.length<2?l[0]?Kl(l[0].x):Jl(e):(e=l.length,function(u){for(var f=0,c;f<e;++f)s[(c=l[f]).i]=c.x(u);return s.join("")})}function kt(t,e){var r=typeof e,n;return e==null||r==="boolean"?ie(e):(r==="number"?P:r==="string"?(n=et(e))?(e=n,Mt):ae:e instanceof et?Mt:e instanceof Date?$o:qo(e)?Ro:Array.isArray(e)?Po:typeof e.valueOf!="function"&&typeof e.toString!="function"||isNaN(e)?Lo:P)(t,e)}function Er(t,e){return t=+t,e=+e,function(r){return Math.round(t*(1-r)+e*r)}}var Uo=180/Math.PI,Ie={translateX:0,translateY:0,rotate:0,skewX:0,scaleX:1,scaleY:1};function Nr(t,e,r,n,o,i){var a,s,l;return(a=Math.sqrt(t*t+e*e))&&(t/=a,e/=a),(l=t*r+e*n)&&(r-=t*l,n-=e*l),(s=Math.sqrt(r*r+n*n))&&(r/=s,n/=s,l/=s),t*n<e*r&&(t=-t,e=-e,l=-l,a=-a),{translateX:o,translateY:i,rotate:Math.atan2(e,t)*Uo,skewX:Math.atan(l)*Uo,scaleX:a,scaleY:s}}var ze;function Vo(t){let e=new(typeof DOMMatrix=="function"?DOMMatrix:WebKitCSSMatrix)(t+"");return e.isIdentity?Ie:Nr(e.a,e.b,e.c,e.d,e.e,e.f)}function Ho(t){return t==null?Ie:(ze||(ze=document.createElementNS("http://www.w3.org/2000/svg","g")),ze.setAttribute("transform",t),(t=ze.transform.baseVal.consolidate())?(t=t.matrix,Nr(t.a,t.b,t.c,t.d,t.e,t.f)):Ie)}function Go(t,e,r,n){function o(u){return u.length?u.pop()+" ":""}function i(u,f,c,p,m,g){if(u!==c||f!==p){var y=m.push("translate(",null,e,null,r);g.push({i:y-4,x:P(u,c)},{i:y-2,x:P(f,p)})}else(c||p)&&m.push("translate("+c+e+p+r)}function a(u,f,c,p){u!==f?(u-f>180?f+=360:f-u>180&&(u+=360),p.push({i:c.push(o(c)+"rotate(",null,n)-2,x:P(u,f)})):f&&c.push(o(c)+"rotate("+f+n)}function s(u,f,c,p){u!==f?p.push({i:c.push(o(c)+"skewX(",null,n)-2,x:P(u,f)}):f&&c.push(o(c)+"skewX("+f+n)}function l(u,f,c,p,m,g){if(u!==c||f!==p){var y=m.push(o(m)+"scale(",null,",",null,")");g.push({i:y-4,x:P(u,c)},{i:y-2,x:P(f,p)})}else(c!==1||p!==1)&&m.push(o(m)+"scale("+c+","+p+")")}return function(u,f){var c=[],p=[];return u=t(u),f=t(f),i(u.translateX,u.translateY,f.translateX,f.translateY,c,p),a(u.rotate,f.rotate,c,p),s(u.skewX,f.skewX,c,p),l(u.scaleX,u.scaleY,f.scaleX,f.scaleY,c,p),u=f=null,function(m){for(var g=-1,y=p.length,_;++g<y;)c[(_=p[g]).i]=_.x(m);return c.join("")}}}var Or=Go(Vo,"px, ","px)","deg)"),Yr=Go(Ho,", ",")",")");var zt=0,le=0,se=0,Wo=1e3,Be,ue,Re=0,At=0,qe=0,ce=typeof performance=="object"&&performance.now?performance:Date,Qo=typeof window=="object"&&window.requestAnimationFrame?window.requestAnimationFrame.bind(window):function(t){setTimeout(t,17)};function me(){return At||(Qo(jl),At=ce.now()+qe)}function jl(){At=0}function fe(){this._call=this._time=this._next=null}fe.prototype=Pe.prototype={constructor:fe,restart:function(t,e,r){if(typeof t!="function")throw new TypeError("callback is not a function");r=(r==null?me():+r)+(e==null?0:+e),!this._next&&ue!==this&&(ue?ue._next=this:Be=this,ue=this),this._call=t,this._time=r,Ir()},stop:function(){this._call&&(this._call=null,this._time=1/0,Ir())}};function Pe(t,e,r){var n=new fe;return n.restart(t,e,r),n}function Zo(){me(),++zt;for(var t=Be,e;t;)(e=At-t._time)>=0&&t._call.call(void 0,e),t=t._next;--zt}function Xo(){At=(Re=ce.now())+qe,zt=le=0;try{Zo()}finally{zt=0,eu(),At=0}}function tu(){var t=ce.now(),e=t-Re;e>Wo&&(qe-=e,Re=t)}function eu(){for(var t,e=Be,r,n=1/0;e;)e._call?(n>e._time&&(n=e._time),t=e,e=e._next):(r=e._next,e._next=null,e=t?t._next=r:Be=r);ue=t,Ir(n)}function Ir(t){if(!zt){le&&(le=clearTimeout(le));var e=t-At;e>24?(t<1/0&&(le=setTimeout(Xo,t-ce.now()-qe)),se&&(se=clearInterval(se))):(se||(Re=ce.now(),se=setInterval(tu,Wo)),zt=1,Qo(Xo))}}function $e(t,e,r){var n=new fe;return e=e==null?0:+e,n.restart(o=>{n.stop(),t(o+e)},e,r),n}var ru=_r("start","end","cancel","interrupt"),nu=[],jo=0,Jo=1,Ue=2,Le=3,Ko=4,Ve=5,pe=6;function pt(t,e,r,n,o,i){var a=t.__transition;if(!a)t.__transition={};else if(r in a)return;ou(t,r,{name:e,index:n,group:o,on:ru,tween:nu,time:i.time,delay:i.delay,duration:i.duration,ease:i.ease,timer:null,state:jo})}function de(t,e){var r=B(t,e);if(r.state>jo)throw new Error("too late; already scheduled");return r}function $(t,e){var r=B(t,e);if(r.state>Le)throw new Error("too late; already running");return r}function B(t,e){var r=t.__transition;if(!r||!(r=r[e]))throw new Error("transition not found");return r}function ou(t,e,r){var n=t.__transition,o;n[e]=r,r.timer=Pe(i,0,r.time);function i(u){r.state=Jo,r.timer.restart(a,r.delay,r.time),r.delay<=u&&a(u-r.delay)}function a(u){var f,c,p,m;if(r.state!==Jo)return l();for(f in n)if(m=n[f],m.name===r.name){if(m.state===Le)return $e(a);m.state===Ko?(m.state=pe,m.timer.stop(),m.on.call("interrupt",t,t.__data__,m.index,m.group),delete n[f]):+f<e&&(m.state=pe,m.timer.stop(),m.on.call("cancel",t,t.__data__,m.index,m.group),delete n[f])}if($e(function(){r.state===Le&&(r.state=Ko,r.timer.restart(s,r.delay,r.time),s(u))}),r.state=Ue,r.on.call("start",t,t.__data__,r.index,r.group),r.state===Ue){for(r.state=Le,o=new Array(p=r.tween.length),f=0,c=-1;f<p;++f)(m=r.tween[f].value.call(t,t.__data__,r.index,r.group))&&(o[++c]=m);o.length=c+1}}function s(u){for(var f=u<r.duration?r.ease.call(null,u/r.duration):(r.timer.restart(l),r.state=Ve,1),c=-1,p=o.length;++c<p;)o[c].call(t,f);r.state===Ve&&(r.on.call("end",t,t.__data__,r.index,r.group),l())}function l(){r.state=pe,r.timer.stop(),delete n[e];for(var u in n)return;delete t.__transition}}function He(t,e){var r=t.__transition,n,o,i=!0,a;if(r){e=e==null?null:e+"";for(a in r){if((n=r[a]).name!==e){i=!1;continue}o=n.state>Ue&&n.state<Ve,n.state=pe,n.timer.stop(),n.on.call(o?"interrupt":"cancel",t,t.__data__,n.index,n.group),delete r[a]}i&&delete t.__transition}}function ti(t){return this.each(function(){He(this,t)})}function iu(t,e){var r,n;return function(){var o=$(this,t),i=o.tween;if(i!==r){n=r=i;for(var a=0,s=n.length;a<s;++a)if(n[a].name===e){n=n.slice(),n.splice(a,1);break}}o.tween=n}}function au(t,e,r){var n,o;if(typeof r!="function")throw new Error;return function(){var i=$(this,t),a=i.tween;if(a!==n){o=(n=a).slice();for(var s={name:e,value:r},l=0,u=o.length;l<u;++l)if(o[l].name===e){o[l]=s;break}l===u&&o.push(s)}i.tween=o}}function ei(t,e){var r=this._id;if(t+="",arguments.length<2){for(var n=B(this.node(),r).tween,o=0,i=n.length,a;o<i;++o)if((a=n[o]).name===t)return a.value;return null}return this.each((e==null?iu:au)(r,t,e))}function Bt(t,e,r){var n=t._id;return t.each(function(){var o=$(this,n);(o.value||(o.value={}))[e]=r.apply(this,arguments)}),function(o){return B(o,n).value[e]}}function Ge(t,e){var r;return(typeof e=="number"?P:e instanceof et?Mt:(r=et(e))?(e=r,Mt):ae)(t,e)}function su(t){return function(){this.removeAttribute(t)}}function lu(t){return function(){this.removeAttributeNS(t.space,t.local)}}function uu(t,e,r){var n,o=r+"",i;return function(){var a=this.getAttribute(t);return a===o?null:a===n?i:i=e(n=a,r)}}function cu(t,e,r){var n,o=r+"",i;return function(){var a=this.getAttributeNS(t.space,t.local);return a===o?null:a===n?i:i=e(n=a,r)}}function fu(t,e,r){var n,o,i;return function(){var a,s=r(this),l;return s==null?void this.removeAttribute(t):(a=this.getAttribute(t),l=s+"",a===l?null:a===n&&l===o?i:(o=l,i=e(n=a,s)))}}function mu(t,e,r){var n,o,i;return function(){var a,s=r(this),l;return s==null?void this.removeAttributeNS(t.space,t.local):(a=this.getAttributeNS(t.space,t.local),l=s+"",a===l?null:a===n&&l===o?i:(o=l,i=e(n=a,s)))}}function ri(t,e){var r=at(t),n=r==="transform"?Yr:Ge;return this.attrTween(t,typeof e=="function"?(r.local?mu:fu)(r,n,Bt(this,"attr."+t,e)):e==null?(r.local?lu:su)(r):(r.local?cu:uu)(r,n,e))}function pu(t,e){return function(r){this.setAttribute(t,e.call(this,r))}}function du(t,e){return function(r){this.setAttributeNS(t.space,t.local,e.call(this,r))}}function hu(t,e){var r,n;function o(){var i=e.apply(this,arguments);return i!==n&&(r=(n=i)&&du(t,i)),r}return o._value=e,o}function gu(t,e){var r,n;function o(){var i=e.apply(this,arguments);return i!==n&&(r=(n=i)&&pu(t,i)),r}return o._value=e,o}function ni(t,e){var r="attr."+t;if(arguments.length<2)return(r=this.tween(r))&&r._value;if(e==null)return this.tween(r,null);if(typeof e!="function")throw new Error;var n=at(t);return this.tween(r,(n.local?hu:gu)(n,e))}function xu(t,e){return function(){de(this,t).delay=+e.apply(this,arguments)}}function yu(t,e){return e=+e,function(){de(this,t).delay=e}}function oi(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?xu:yu)(e,t)):B(this.node(),e).delay}function bu(t,e){return function(){$(this,t).duration=+e.apply(this,arguments)}}function vu(t,e){return e=+e,function(){$(this,t).duration=e}}function ii(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?bu:vu)(e,t)):B(this.node(),e).duration}function wu(t,e){if(typeof e!="function")throw new Error;return function(){$(this,t).ease=e}}function ai(t){var e=this._id;return arguments.length?this.each(wu(e,t)):B(this.node(),e).ease}function _u(t,e){return function(){var r=e.apply(this,arguments);if(typeof r!="function")throw new Error;$(this,t).ease=r}}function si(t){if(typeof t!="function")throw new Error;return this.each(_u(this._id,t))}function li(t){typeof t!="function"&&(t=jt(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,s=n[o]=[],l,u=0;u<a;++u)(l=i[u])&&t.call(l,l.__data__,u,i)&&s.push(l);return new U(n,this._parents,this._name,this._id)}function ui(t){if(t._id!==this._id)throw new Error;for(var e=this._groups,r=t._groups,n=e.length,o=r.length,i=Math.min(n,o),a=new Array(n),s=0;s<i;++s)for(var l=e[s],u=r[s],f=l.length,c=a[s]=new Array(f),p,m=0;m<f;++m)(p=l[m]||u[m])&&(c[m]=p);for(;s<n;++s)a[s]=e[s];return new U(a,this._parents,this._name,this._id)}function Cu(t){return(t+"").trim().split(/^|\s+/).every(function(e){var r=e.indexOf(".");return r>=0&&(e=e.slice(0,r)),!e||e==="start"})}function Su(t,e,r){var n,o,i=Cu(e)?de:$;return function(){var a=i(this,t),s=a.on;s!==n&&(o=(n=s).copy()).on(e,r),a.on=o}}function ci(t,e){var r=this._id;return arguments.length<2?B(this.node(),r).on.on(t):this.each(Su(r,t,e))}function Mu(t){return function(){var e=this.parentNode;for(var r in this.__transition)if(+r!==t)return;e&&e.removeChild(this)}}function fi(){return this.on("end.remove",Mu(this._id))}function mi(t){var e=this._name,r=this._id;typeof t!="function"&&(t=_t(t));for(var n=this._groups,o=n.length,i=new Array(o),a=0;a<o;++a)for(var s=n[a],l=s.length,u=i[a]=new Array(l),f,c,p=0;p<l;++p)(f=s[p])&&(c=t.call(f,f.__data__,p,s))&&("__data__"in f&&(c.__data__=f.__data__),u[p]=c,pt(u[p],e,r,p,u,B(f,r)));return new U(i,this._parents,e,r)}function pi(t){var e=this._name,r=this._id;typeof t!="function"&&(t=Kt(t));for(var n=this._groups,o=n.length,i=[],a=[],s=0;s<o;++s)for(var l=n[s],u=l.length,f,c=0;c<u;++c)if(f=l[c]){for(var p=t.call(f,f.__data__,c,l),m,g=B(f,r),y=0,_=p.length;y<_;++y)(m=p[y])&&pt(m,e,r,y,p,g);i.push(p),a.push(f)}return new U(i,a,e,r)}var ku=st.prototype.constructor;function di(){return new ku(this._groups,this._parents)}function Au(t,e){var r,n,o;return function(){var i=mt(this,t),a=(this.style.removeProperty(t),mt(this,t));return i===a?null:i===r&&a===n?o:o=e(r=i,n=a)}}function hi(t){return function(){this.style.removeProperty(t)}}function Du(t,e,r){var n,o=r+"",i;return function(){var a=mt(this,t);return a===o?null:a===n?i:i=e(n=a,r)}}function Tu(t,e,r){var n,o,i;return function(){var a=mt(this,t),s=r(this),l=s+"";return s==null&&(l=s=(this.style.removeProperty(t),mt(this,t))),a===l?null:a===n&&l===o?i:(o=l,i=e(n=a,s))}}function Fu(t,e){var r,n,o,i="style."+e,a="end."+i,s;return function(){var l=$(this,t),u=l.on,f=l.value[i]==null?s||(s=hi(e)):void 0;(u!==r||o!==f)&&(n=(r=u).copy()).on(a,o=f),l.on=n}}function gi(t,e,r){var n=(t+="")=="transform"?Or:Ge;return e==null?this.styleTween(t,Au(t,n)).on("end.style."+t,hi(t)):typeof e=="function"?this.styleTween(t,Tu(t,n,Bt(this,"style."+t,e))).each(Fu(this._id,t)):this.styleTween(t,Du(t,n,e),r).on("end.style."+t,null)}function Eu(t,e,r){return function(n){this.style.setProperty(t,e.call(this,n),r)}}function Nu(t,e,r){var n,o;function i(){var a=e.apply(this,arguments);return a!==o&&(n=(o=a)&&Eu(t,a,r)),n}return i._value=e,i}function xi(t,e,r){var n="style."+(t+="");if(arguments.length<2)return(n=this.tween(n))&&n._value;if(e==null)return this.tween(n,null);if(typeof e!="function")throw new Error;return this.tween(n,Nu(t,e,r??""))}function Ou(t){return function(){this.textContent=t}}function Yu(t){return function(){var e=t(this);this.textContent=e??""}}function yi(t){return this.tween("text",typeof t=="function"?Yu(Bt(this,"text",t)):Ou(t==null?"":t+""))}function Iu(t){return function(e){this.textContent=t.call(this,e)}}function zu(t){var e,r;function n(){var o=t.apply(this,arguments);return o!==r&&(e=(r=o)&&Iu(o)),e}return n._value=t,n}function bi(t){var e="text";if(arguments.length<1)return(e=this.tween(e))&&e._value;if(t==null)return this.tween(e,null);if(typeof t!="function")throw new Error;return this.tween(e,zu(t))}function vi(){for(var t=this._name,e=this._id,r=Xe(),n=this._groups,o=n.length,i=0;i<o;++i)for(var a=n[i],s=a.length,l,u=0;u<s;++u)if(l=a[u]){var f=B(l,e);pt(l,t,r,u,a,{time:f.time+f.delay+f.duration,delay:0,duration:f.duration,ease:f.ease})}return new U(n,this._parents,t,r)}function wi(){var t,e,r=this,n=r._id,o=r.size();return new Promise(function(i,a){var s={value:a},l={value:function(){--o===0&&i()}};r.each(function(){var u=$(this,n),f=u.on;f!==t&&(e=(t=f).copy(),e._.cancel.push(s),e._.interrupt.push(s),e._.end.push(l)),u.on=e}),o===0&&i()})}var Bu=0;function U(t,e,r,n){this._groups=t,this._parents=e,this._name=r,this._id=n}function _i(t){return st().transition(t)}function Xe(){return++Bu}var ut=st.prototype;U.prototype=_i.prototype={constructor:U,select:mi,selectAll:pi,selectChild:ut.selectChild,selectChildren:ut.selectChildren,filter:li,merge:ui,selection:di,transition:vi,call:ut.call,nodes:ut.nodes,node:ut.node,size:ut.size,empty:ut.empty,each:ut.each,on:ci,attr:ri,attrTween:ni,style:gi,styleTween:xi,text:yi,textTween:bi,remove:fi,tween:ei,delay:oi,duration:ii,ease:ai,easeVarying:si,end:wi,[Symbol.iterator]:ut[Symbol.iterator]};function We(t){return((t*=2)<=1?t*t*t:(t-=2)*t*t+2)/2}var Ru={time:null,delay:0,duration:250,ease:We};function qu(t,e){for(var r;!(r=t.__transition)||!(r=r[e]);)if(!(t=t.parentNode))throw new Error(`transition ${e} not found`);return r}function Ci(t){var e,r;t instanceof U?(e=t._id,t=t._name):(e=Xe(),(r=Ru).time=me(),t=t==null?null:t+"");for(var n=this._groups,o=n.length,i=0;i<o;++i)for(var a=n[i],s=a.length,l,u=0;u<s;++u)(l=a[u])&&pt(l,t,e,u,a,r||qu(l,e));return new U(n,this._parents,t,e)}st.prototype.interrupt=ti;st.prototype.transition=Ci;var{abs:Sx,max:Mx,min:kx}=Math;function Si(t){return[+t[0],+t[1]]}function Pu(t){return[Si(t[0]),Si(t[1])]}var Ax={name:"x",handles:["w","e"].map(zr),input:function(t,e){return t==null?null:[[+t[0],e[0][1]],[+t[1],e[1][1]]]},output:function(t){return t&&[t[0][0],t[1][0]]}},Dx={name:"y",handles:["n","s"].map(zr),input:function(t,e){return t==null?null:[[e[0][0],+t[0]],[e[1][0],+t[1]]]},output:function(t){return t&&[t[0][1],t[1][1]]}},Tx={name:"xy",handles:["n","w","e","s","nw","ne","sw","se"].map(zr),input:function(t){return t==null?null:Pu(t)},output:function(t){return t}};function zr(t){return{type:t}}function Mi(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function Dt(t,e){if((r=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var r,n=t.slice(0,r);return[n.length>1?n[0]+n.slice(2):n,+t.slice(r+1)]}function ot(t){return t=Dt(Math.abs(t)),t?t[1]:NaN}function ki(t,e){return function(r,n){for(var o=r.length,i=[],a=0,s=t[0],l=0;o>0&&s>0&&(l+s+1>n&&(s=Math.max(1,n-l)),i.push(r.substring(o-=s,o+s)),!((l+=s+1)>n));)s=t[a=(a+1)%t.length];return i.reverse().join(e)}}function Ai(t){return function(e){return e.replace(/[0-9]/g,function(r){return t[+r]})}}var $u=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function dt(t){if(!(e=$u.exec(t)))throw new Error("invalid format: "+t);var e;return new Qe({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}dt.prototype=Qe.prototype;function Qe(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}Qe.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function Di(t){t:for(var e=t.length,r=1,n=-1,o;r<e;++r)switch(t[r]){case".":n=o=r;break;case"0":n===0&&(n=r),o=r;break;default:if(!+t[r])break t;n>0&&(n=0);break}return n>0?t.slice(0,n)+t.slice(o+1):t}var Br;function Ti(t,e){var r=Dt(t,e);if(!r)return t+"";var n=r[0],o=r[1],i=o-(Br=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,a=n.length;return i===a?n:i>a?n+new Array(i-a+1).join("0"):i>0?n.slice(0,i)+"."+n.slice(i):"0."+new Array(1-i).join("0")+Dt(t,Math.max(0,e+i-1))[0]}function Rr(t,e){var r=Dt(t,e);if(!r)return t+"";var n=r[0],o=r[1];return o<0?"0."+new Array(-o).join("0")+n:n.length>o+1?n.slice(0,o+1)+"."+n.slice(o+1):n+new Array(o-n.length+2).join("0")}var qr={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:Mi,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>Rr(t*100,e),r:Rr,s:Ti,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function Pr(t){return t}var Fi=Array.prototype.map,Ei=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function Ni(t){var e=t.grouping===void 0||t.thousands===void 0?Pr:ki(Fi.call(t.grouping,Number),t.thousands+""),r=t.currency===void 0?"":t.currency[0]+"",n=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",i=t.numerals===void 0?Pr:Ai(Fi.call(t.numerals,String)),a=t.percent===void 0?"%":t.percent+"",s=t.minus===void 0?"\u2212":t.minus+"",l=t.nan===void 0?"NaN":t.nan+"";function u(c){c=dt(c);var p=c.fill,m=c.align,g=c.sign,y=c.symbol,_=c.zero,h=c.width,C=c.comma,w=c.precision,S=c.trim,b=c.type;b==="n"?(C=!0,b="g"):qr[b]||(w===void 0&&(w=12),S=!0,b="g"),(_||p==="0"&&m==="=")&&(_=!0,p="0",m="=");var M=y==="$"?r:y==="#"&&/[boxX]/.test(b)?"0"+b.toLowerCase():"",Y=y==="$"?n:/[%p]/.test(b)?a:"",z=qr[b],Q=/[defgprs%]/.test(b);w=w===void 0?6:/[gprs]/.test(b)?Math.max(1,Math.min(21,w)):Math.max(0,Math.min(20,w));function G(x){var F=M,A=Y,L,gt,J;if(b==="c")A=z(x)+A,x="";else{x=+x;var K=x<0||1/x<0;if(x=isNaN(x)?l:z(Math.abs(x),w),S&&(x=Di(x)),K&&+x==0&&g!=="+"&&(K=!1),F=(K?g==="("?g:s:g==="-"||g==="("?"":g)+F,A=(b==="s"?Ei[8+Br/3]:"")+A+(K&&g==="("?")":""),Q){for(L=-1,gt=x.length;++L<gt;)if(J=x.charCodeAt(L),48>J||J>57){A=(J===46?o+x.slice(L+1):x.slice(L))+A,x=x.slice(0,L);break}}}C&&!_&&(x=e(x,1/0));var j=F.length+x.length+A.length,I=j<h?new Array(h-j+1).join(p):"";switch(C&&_&&(x=e(I+x,I.length?h-A.length:1/0),I=""),m){case"<":x=F+x+A+I;break;case"=":x=F+I+x+A;break;case"^":x=I.slice(0,j=I.length>>1)+F+x+A+I.slice(j);break;default:x=I+F+x+A;break}return i(x)}return G.toString=function(){return c+""},G}function f(c,p){var m=u((c=dt(c),c.type="f",c)),g=Math.max(-8,Math.min(8,Math.floor(ot(p)/3)))*3,y=Math.pow(10,-g),_=Ei[8+g/3];return function(h){return m(y*h)+_}}return{format:u,formatPrefix:f}}var Ze,Je,Ke;$r({thousands:",",grouping:[3],currency:["$",""]});function $r(t){return Ze=Ni(t),Je=Ze.format,Ke=Ze.formatPrefix,Ze}function Lr(t){return Math.max(0,-ot(Math.abs(t)))}function Ur(t,e){return Math.max(0,Math.max(-8,Math.min(8,Math.floor(ot(e)/3)))*3-ot(Math.abs(t)))}function Vr(t,e){return t=Math.abs(t),e=Math.abs(e)-t,Math.max(0,ot(e)-ot(t))+1}function je(t,e){switch(arguments.length){case 0:break;case 1:this.range(t);break;default:this.range(e).domain(t);break}return this}var Hr=Symbol("implicit");function he(){var t=new Ot,e=[],r=[],n=Hr;function o(i){let a=t.get(i);if(a===void 0){if(n!==Hr)return n;t.set(i,a=e.push(i)-1)}return r[a%r.length]}return o.domain=function(i){if(!arguments.length)return e.slice();e=[],t=new Ot;for(let a of i)t.has(a)||t.set(a,e.push(a)-1);return o},o.range=function(i){return arguments.length?(r=Array.from(i),o):r.slice()},o.unknown=function(i){return arguments.length?(n=i,o):n},o.copy=function(){return he(e,r).unknown(n)},je.apply(o,arguments),o}function Gr(t){return function(){return t}}function Xr(t){return+t}var Oi=[0,1];function Rt(t){return t}function Wr(t,e){return(e-=t=+t)?function(r){return(r-t)/e}:Gr(isNaN(e)?NaN:.5)}function Lu(t,e){var r;return t>e&&(r=t,t=e,e=r),function(n){return Math.max(t,Math.min(e,n))}}function Uu(t,e,r){var n=t[0],o=t[1],i=e[0],a=e[1];return o<n?(n=Wr(o,n),i=r(a,i)):(n=Wr(n,o),i=r(i,a)),function(s){return i(n(s))}}function Vu(t,e,r){var n=Math.min(t.length,e.length)-1,o=new Array(n),i=new Array(n),a=-1;for(t[n]<t[0]&&(t=t.slice().reverse(),e=e.slice().reverse());++a<n;)o[a]=Wr(t[a],t[a+1]),i[a]=r(e[a],e[a+1]);return function(s){var l=hr(t,s,1,n)-1;return i[l](o[l](s))}}function Yi(t,e){return e.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown())}function Hu(){var t=Oi,e=Oi,r=kt,n,o,i,a=Rt,s,l,u;function f(){var p=Math.min(t.length,e.length);return a!==Rt&&(a=Lu(t[0],t[p-1])),s=p>2?Vu:Uu,l=u=null,c}function c(p){return p==null||isNaN(p=+p)?i:(l||(l=s(t.map(n),e,r)))(n(a(p)))}return c.invert=function(p){return a(o((u||(u=s(e,t.map(n),P)))(p)))},c.domain=function(p){return arguments.length?(t=Array.from(p,Xr),f()):t.slice()},c.range=function(p){return arguments.length?(e=Array.from(p),f()):e.slice()},c.rangeRound=function(p){return e=Array.from(p),r=Er,f()},c.clamp=function(p){return arguments.length?(a=p?!0:Rt,f()):a!==Rt},c.interpolate=function(p){return arguments.length?(r=p,f()):r},c.unknown=function(p){return arguments.length?(i=p,c):i},function(p,m){return n=p,o=m,f()}}function Qr(){return Hu()(Rt,Rt)}function Zr(t,e,r,n){var o=gr(t,e,r),i;switch(n=dt(n??",f"),n.type){case"s":{var a=Math.max(Math.abs(t),Math.abs(e));return n.precision==null&&!isNaN(i=Ur(o,a))&&(n.precision=i),Ke(n,a)}case"":case"e":case"g":case"p":case"r":{n.precision==null&&!isNaN(i=Vr(o,Math.max(Math.abs(t),Math.abs(e))))&&(n.precision=i-(n.type==="e"));break}case"f":case"%":{n.precision==null&&!isNaN(i=Lr(o))&&(n.precision=i-(n.type==="%")*2);break}}return Je(n)}function Gu(t){var e=t.domain;return t.ticks=function(r){var n=e();return _e(n[0],n[n.length-1],r??10)},t.tickFormat=function(r,n){var o=e();return Zr(o[0],o[o.length-1],r??10,n)},t.nice=function(r){r==null&&(r=10);var n=e(),o=0,i=n.length-1,a=n[o],s=n[i],l,u,f=10;for(s<a&&(u=a,a=s,s=u,u=o,o=i,i=u);f-- >0;){if(u=Qt(a,s,r),u===l)return n[o]=a,n[i]=s,e(n);if(u>0)a=Math.floor(a/u)*u,s=Math.ceil(s/u)*u;else if(u<0)a=Math.ceil(a*u)/u,s=Math.floor(s*u)/u;else break;l=u}return t},t}function qt(){var t=Qr();return t.copy=function(){return Yi(t,qt())},je.apply(t,arguments),Gu(t)}function Ii(t){for(var e=t.length/6|0,r=new Array(e),n=0;n<e;)r[n]="#"+t.slice(n*6,++n*6);return r}var Jr=Ii("1f77b4ff7f0e2ca02cd627289467bd8c564be377c27f7f7fbcbd2217becf");function ht(t,e,r){this.k=t,this.x=e,this.y=r}ht.prototype={constructor:ht,scale:function(t){return t===1?this:new ht(this.k*t,this.x,this.y)},translate:function(t,e){return t===0&e===0?this:new ht(this.k,this.x+this.k*t,this.y+this.k*e)},apply:function(t){return[t[0]*this.k+this.x,t[1]*this.k+this.y]},applyX:function(t){return t*this.k+this.x},applyY:function(t){return t*this.k+this.y},invert:function(t){return[(t[0]-this.x)/this.k,(t[1]-this.y)/this.k]},invertX:function(t){return(t-this.x)/this.k},invertY:function(t){return(t-this.y)/this.k},rescaleX:function(t){return t.copy().domain(t.range().map(this.invertX,this).map(t.invert,t))},rescaleY:function(t){return t.copy().domain(t.range().map(this.invertY,this).map(t.invert,t))},toString:function(){return"translate("+this.x+","+this.y+") scale("+this.k+")"}};var Kr=new ht(1,0,0);jr.prototype=ht.prototype;function jr(t){for(;!t.__zoom;)if(!(t=t.parentNode))return Kr;return t.__zoom}var O={selectedPoints:new Set};function Wu(t){let e={type:"customEvent",data:t};window.parent.postMessage(e,"*")}function zi(t){let e={type:"setFilter",filters:t};window.parent.postMessage(e,"*")}var Qu=({container:t,data:e=[],slots:r=[],slotConfigurations:n=[],options:o={},language:i="en",dimensions:{width:a,height:s}={width:0,height:0}})=>{let l=Ri(t);O.xAxisSlot=r.find(_=>_.name==="x-axis"),O.yAxisSlot=r.find(_=>_.name==="y-axis"),O.categorySlot=r.find(_=>_.name==="category"),O.language=i;let u=O.xAxisSlot?.content?.length>0,f=O.yAxisSlot?.content?.length>0,c=O.categorySlot?.content?.length>0,p=[];if(!e.length||!u||!f){let _=["Category A","Category B","Category C","Category D","Category E"],h=[];for(let C=0;C<_.length;C++){let w=Math.random()*100,S=Math.random()*1e3+100;h.push({x:w,y:S,category:_[C],value:S.toString(),rawValue:S,columnId:`column_${C}`,datasetId:`dataset_${C}`})}p=h}else p=Ju(e,O.xAxisSlot,O.yAxisSlot,O.categorySlot);let m={top:40,right:30,bottom:60,left:60},g=a-m.left-m.right,y=s-m.top-m.bottom;Bi(l,p,a,s,m,g,y),t.__chartData=p},Zu=({container:t,slots:e=[],slotConfigurations:r=[],options:n={},language:o="en",dimensions:{width:i,height:a}={width:0,height:0}})=>{let s=t.__chartData||[],l=Ri(t),u={top:40,right:30,bottom:60,left:60},f=i-u.left-u.right,c=a-u.top-u.bottom;Bi(l,s,i,a,u,f,c),t.__chartData=s};function Bi(t,e,r,n,o,i,a){let s=lt(t).append("svg").attr("width",r).attr("height",n),l=s.append("g").attr("transform",`translate(${o.left},${o.top})`),u=Array.from(new Set(e.map(h=>h.category))).sort(),f=he().domain(u).range(Jr),c=Wt(e,h=>h.x),p=qt().domain([Math.min(0,c[0]),c[1]]).range([0,i]).nice(),m=Wt(e,h=>h.y),g=qt().domain([Math.min(0,m[0]),m[1]]).range([a,0]).nice();l.append("g").attr("class","axis x-axis").attr("transform",`translate(0,${a})`).call(vr(p).ticks(Math.ceil(i/80))).style("color","black"),l.append("g").attr("class","axis y-axis").call(wr(g).ticks(5)).style("color","black");let y=lt(t).append("div").attr("class","tooltip").style("opacity",0);l.selectAll(".point").data(e).enter().append("circle").attr("class","point").attr("cx",h=>p(h.x)).attr("cy",h=>g(h.y)).attr("r",6).attr("fill",h=>f(h.category)).attr("stroke","#fff").attr("stroke-width",2).on("mouseover",function(h,C){lt(this).transition().duration(200).attr("r",8),y.transition().duration(200).style("opacity",.9);let w=O.language||"en",S=O.xAxisSlot?.content?.[0]?.label?.[w]||O.xAxisSlot?.content?.[0]?.label?.en||"X-axis",b=O.yAxisSlot?.content?.[0]?.label?.[w]||O.yAxisSlot?.content?.[0]?.label?.en||"Y-axis",M=O.categorySlot?.content?.[0]?.label?.[w]||O.categorySlot?.content?.[0]?.label?.en||"Category";y.html(`<strong>${S}:</strong> ${C.x.toFixed(2)}<br><strong>${b}:</strong> ${C.y.toFixed(2)}<br><strong>${M}:</strong> ${C.category}`).style("left",h.offsetX+10+"px").style("top",h.offsetY-28+"px")}).on("mouseout",function(){lt(this).transition().duration(200).attr("r",6),y.transition().duration(500).style("opacity",0)}).on("click",function(h,C){let w=`${C.x}-${C.y}-${C.category}`;O.selectedPoints.has(w)?(O.selectedPoints.delete(w),lt(this).classed("point-selected",!1)):(O.selectedPoints.add(w),lt(this).classed("point-selected",!0)),lt(t).select(".clear-filter-btn").classed("visible",O.selectedPoints.size>0);let b=[],M=new Set;if(Array.from(O.selectedPoints).forEach(Y=>{let Q=Y.split("-").slice(2).join("-");M.add(Q)}),M.size>0&&O.categorySlot?.content?.[0]){let Y=O.categorySlot.content[0],z=Array.from(M);b.push({expression:z.length>1?"? in ?":"? = ?",parameters:[{column_id:Y.columnId||Y.column,dataset_id:Y.datasetId||Y.set,level:Y.level||void 0},z.length>1?z:z[0]],properties:{origin:"filterFromVizItem",type:"where"}})}zi(b),Wu({x:C.x,y:C.y,category:C.category,value:C.value,rawValue:C.rawValue})});let _=s.append("g").attr("class","legend").attr("transform",`translate(${o.left}, ${n-25})`);u.forEach((h,C)=>{let w=_.append("g").attr("class","legend-item").attr("transform",`translate(${C*100}, 0)`);w.append("circle").attr("class","legend-color").attr("cx",6).attr("cy",6).attr("r",6).attr("fill",f(h)),w.append("text").attr("x",18).attr("y",10).text(h).style("font-size","12px")})}function Ri(t){t.innerHTML="";let e=document.createElement("div");e.className="scatter-plot-container",t.appendChild(e);let r=document.createElement("button");return r.className="clear-filter-btn",r.textContent="Clear Filters",r.onclick=()=>{O.selectedPoints.clear(),Mr(".point").classed("point-selected",!1),r.classList.remove("visible"),zi([])},e.appendChild(r),e}function Ju(t,e,r,n){let o={xAxis:e?.content[0]?Xt(e.content[0]):l=>Number(l)||0,yAxis:r?.content[0]?Xt(r.content[0]):l=>Number(l)||0,category:n?.content[0]?Xt(n.content[0],{level:n.content[0].level||9}):l=>String(l)},i=n?.content?.length>0,a={xAxis:1,yAxis:2,category:0},s=new Map;return(t??[]).forEach(l=>{let u=Number(l[a.xAxis])||0,f=Number(l[a.yAxis])||0,c=i?l[a.category]?.name?.en||l[a.category]||"Unknown":"Default",p=i?o.category(n.content[0].type==="datetime"?new Date(c):c):"Default";s.has(p)||s.set(p,{xValues:[],yValues:[],row:l});let m=s.get(p);m.xValues.push(u),m.yValues.push(f)}),Array.from(s.entries()).map(([l,u])=>{let f=u.xValues.reduce((p,m)=>p+m,0)/u.xValues.length,c=u.yValues.reduce((p,m)=>p+m,0);return{x:f,y:c,category:String(l),value:o.yAxis(c),rawValue:c,columnId:u.row[a.yAxis]?.columnId,datasetId:u.row[a.yAxis]?.datasetId}})}export{Qu as render,Zu as resize};
/*! Bundled license information:

@luzmo/analytics-components-kit/components/decompose-numeric-format-BuZcjH2k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/localize-BX7q0S0M.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/formatter-CQDms6fU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/area-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bar-chart-slots.config-MQAjNXqV.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/box-plot-slots.config-BRhnF2FE.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bubble-chart-slots.config-Bbh94VgZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bullet-chart-slots.config-BlWTleBt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/choropleth-map-slots.config-B-uJTj4q.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circle-pack-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circular-gauge-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/column-chart-slots.config-DAdAk17k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/combination-chart-slots.config-CqKLFKCZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/conditional-number-slots.config-L3t5pb1-.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/date-filter-slots.config-CxB8IF5B.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/donut-chart-slots.config-BEwhfq27.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/dropdown-filter-slots.config-B8J6ftCh.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/evolution-number-slots.config-CW21b2ua.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/funnel-chart-slots.config-BBhMS2qi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-table-slots.config-DJkP72oT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/hexbin-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/image-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/line-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/marker-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/ohlc-chart-slots.config-Cvy5n1xv.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/parallel-coordinates-plot-slots.config-CQW2CJW6.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pivot-table-slots.config-BH5fOJre.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pyramid-chart-slots.config-Cm9bQsXT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/radar-chart-slots.config-Dpmytmc3.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/regular-table-slots.config-EUS-V9lL.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/route-map-slots.config-DYCcaQZi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sankey-diagram-slots.config-BSTBEZDe.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/scatter-plot-slots.config-BuWYqDWK.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/search-filter-slots.config-DmiVXOva.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slicer-filter-slots.config-CHQ0ZXga.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slider-filter-slots.config-BN3K1rnl.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/speedometer-chart-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/spike-map-slots.config-CuqpgkvN.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/strip-plot-slots.config-Co8ghEv8.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sunburst-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/symbol-map-slots.config-C5CKaVED.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/text-slots.config-Hy5yNIAX.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/treemap-chart-slots.config-xLD22K9V.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/venn-diagram-slots.config-DPmj71cR.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/video-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/wordcloud-chart-slots.config-BS4sOOHt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/index-BEAYzHcY.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/utils.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)
*/
