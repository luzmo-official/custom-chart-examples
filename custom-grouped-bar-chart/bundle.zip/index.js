function or(t){let e=/(?:([^{])?([<>=^]))?([+\- \()])?([$#])?(0)?(\d+)?([,_])?(\.-?\d+)?([a-z%]{1,2})?/i.exec(t)??[];return{fill:e[1]||" ",align:e[2]||">",sign:e[3]||"-",symbol:e[4]||"",zfill:e[5],width:+e[6],comma:e[7],precision:e[8],typeFormat:e[9]}}function nt(t){return t==null}function ir(t){return typeof t=="string"||t instanceof String}function Lt(t){return!Number.isNaN(t)&&Number.isFinite(t)}function Ki(t){return typeof t=="boolean"}function ji(t){return t!==null&&typeof t=="object"&&!Array.isArray(t)}function ta(t){return t!==null&&typeof t=="object"&&Object.keys(t).length===0}function ar(t,e,r){if(ir(t)||Lt(t)||Ki(t))return t.toString();if(nt(t)||!ji(t)||ta(t))return"";let n="",o=Object.keys(t);return r!=null&&r.allowEmpty?(e&&t[e]!==void 0&&(n=t[e]),n===void 0&&(n="")):(e&&t[e]&&(n=t[e]),(nt(n)||n==="")&&o!=null&&o.length&&(n=t[o[0]])),n}function ea(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function ye(t,e){if((r=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var r,n=t.slice(0,r);return[n.length>1?n[0]+n.slice(2):n,+t.slice(r+1)]}function ra(t){return t=ye(Math.abs(t)),t?t[1]:NaN}function na(t,e){return function(r,n){for(var o=r.length,i=[],a=0,s=t[0],l=0;o>0&&s>0&&(l+s+1>n&&(s=Math.max(1,n-l)),i.push(r.substring(o-=s,o+s)),!((l+=s+1)>n));)s=t[a=(a+1)%t.length];return i.reverse().join(e)}}function oa(t){return function(e){return e.replace(/[0-9]/g,function(r){return t[+r]})}}var ia=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function fr(t){if(!(e=ia.exec(t)))throw new Error("invalid format: "+t);var e;return new dr({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}fr.prototype=dr.prototype;function dr(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}dr.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function aa(t){t:for(var e=t.length,r=1,n=-1,o;r<e;++r)switch(t[r]){case".":n=o=r;break;case"0":n===0&&(n=r),o=r;break;default:if(!+t[r])break t;n>0&&(n=0);break}return n>0?t.slice(0,n)+t.slice(o+1):t}var wn;function sa(t,e){var r=ye(t,e);if(!r)return t+"";var n=r[0],o=r[1],i=o-(wn=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,a=n.length;return i===a?n:i>a?n+new Array(i-a+1).join("0"):i>0?n.slice(0,i)+"."+n.slice(i):"0."+new Array(1-i).join("0")+ye(t,Math.max(0,e+i-1))[0]}function an(t,e){var r=ye(t,e);if(!r)return t+"";var n=r[0],o=r[1];return o<0?"0."+new Array(-o).join("0")+n:n.length>o+1?n.slice(0,o+1)+"."+n.slice(o+1):n+new Array(o-n.length+2).join("0")}var sn={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:ea,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>an(t*100,e),r:an,s:sa,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function ln(t){return t}var un=Array.prototype.map,cn=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function la(t){var e=t.grouping===void 0||t.thousands===void 0?ln:na(un.call(t.grouping,Number),t.thousands+""),r=t.currency===void 0?"":t.currency[0]+"",n=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",i=t.numerals===void 0?ln:oa(un.call(t.numerals,String)),a=t.percent===void 0?"%":t.percent+"",s=t.minus===void 0?"\u2212":t.minus+"",l=t.nan===void 0?"NaN":t.nan+"";function u(c){c=fr(c);var m=c.fill,p=c.align,h=c.sign,g=c.symbol,_=c.zero,v=c.width,C=c.comma,b=c.precision,M=c.trim,x=c.type;x==="n"?(C=!0,x="g"):sn[x]||(b===void 0&&(b=12),M=!0,x="g"),(_||m==="0"&&p==="=")&&(_=!0,m="0",p="=");var S=g==="$"?r:g==="#"&&/[boxX]/.test(x)?"0"+x.toLowerCase():"",N=g==="$"?n:/[%p]/.test(x)?a:"",R=sn[x],K=/[defgprs%]/.test(x);b=b===void 0?6:/[gprs]/.test(x)?Math.max(1,Math.min(21,b)):Math.max(0,Math.min(20,b));function U(y){var F=S,k=N,z,G,I;if(x==="c")k=R(y)+k,y="";else{y=+y;var j=y<0||1/y<0;if(y=isNaN(y)?l:R(Math.abs(y),b),M&&(y=aa(y)),j&&+y==0&&h!=="+"&&(j=!1),F=(j?h==="("?h:s:h==="-"||h==="("?"":h)+F,k=(x==="s"?cn[8+wn/3]:"")+k+(j&&h==="("?")":""),K){for(z=-1,G=y.length;++z<G;)if(I=y.charCodeAt(z),48>I||I>57){k=(I===46?o+y.slice(z+1):y.slice(z))+k,y=y.slice(0,z);break}}}C&&!_&&(y=e(y,1/0));var tt=F.length+y.length+k.length,Y=tt<v?new Array(v-tt+1).join(m):"";switch(C&&_&&(y=e(Y+y,Y.length?v-k.length:1/0),Y=""),p){case"<":y=F+y+k+Y;break;case"=":y=F+Y+y+k;break;case"^":y=Y.slice(0,tt=Y.length>>1)+F+y+k+Y.slice(tt);break;default:y=Y+F+y+k;break}return i(y)}return U.toString=function(){return c+""},U}function f(c,m){var p=u((c=fr(c),c.type="f",c)),h=Math.max(-8,Math.min(8,Math.floor(ra(m)/3)))*3,g=Math.pow(10,-h),_=cn[8+h/3];return function(v){return p(g*v)+_}}return{format:u,formatPrefix:f}}var sr=new Date,lr=new Date;function P(t,e,r,n){function o(i){return t(i=arguments.length===0?new Date:new Date(+i)),i}return o.floor=i=>(t(i=new Date(+i)),i),o.ceil=i=>(t(i=new Date(i-1)),e(i,1),t(i),i),o.round=i=>{let a=o(i),s=o.ceil(i);return i-a<s-i?a:s},o.offset=(i,a)=>(e(i=new Date(+i),a==null?1:Math.floor(a)),i),o.range=(i,a,s)=>{let l=[];if(i=o.ceil(i),s=s==null?1:Math.floor(s),!(i<a)||!(s>0))return l;let u;do l.push(u=new Date(+i)),e(i,s),t(i);while(u<i&&i<a);return l},o.filter=i=>P(a=>{if(a>=a)for(;t(a),!i(a);)a.setTime(a-1)},(a,s)=>{if(a>=a)if(s<0)for(;++s<=0;)for(;e(a,-1),!i(a););else for(;--s>=0;)for(;e(a,1),!i(a););}),r&&(o.count=(i,a)=>(sr.setTime(+i),lr.setTime(+a),t(sr),t(lr),Math.floor(r(sr,lr))),o.every=i=>(i=Math.floor(i),!isFinite(i)||!(i>0)?null:i>1?o.filter(n?a=>n(a)%i===0:a=>o.count(0,a)%i===0):o)),o}var Gt=1e3,ft=Gt*60,Xt=ft*60,Wt=Xt*24,_n=Wt*7,Cn=P(t=>{t.setTime(t-t.getMilliseconds())},(t,e)=>{t.setTime(+t+e*Gt)},(t,e)=>(e-t)/Gt,t=>t.getUTCSeconds());Cn.range;var Sn=P(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*Gt)},(t,e)=>{t.setTime(+t+e*ft)},(t,e)=>(e-t)/ft,t=>t.getMinutes());Sn.range;var ua=P(t=>{t.setUTCSeconds(0,0)},(t,e)=>{t.setTime(+t+e*ft)},(t,e)=>(e-t)/ft,t=>t.getUTCMinutes());ua.range;var Mn=P(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*Gt-t.getMinutes()*ft)},(t,e)=>{t.setTime(+t+e*Xt)},(t,e)=>(e-t)/Xt,t=>t.getHours());Mn.range;var ca=P(t=>{t.setUTCMinutes(0,0,0)},(t,e)=>{t.setTime(+t+e*Xt)},(t,e)=>(e-t)/Xt,t=>t.getUTCHours());ca.range;var ve=P(t=>t.setHours(0,0,0,0),(t,e)=>t.setDate(t.getDate()+e),(t,e)=>(e-t-(e.getTimezoneOffset()-t.getTimezoneOffset())*ft)/Wt,t=>t.getDate()-1);ve.range;var hr=P(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/Wt,t=>t.getUTCDate()-1);hr.range;var fa=P(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/Wt,t=>Math.floor(t/Wt));fa.range;function vt(t){return P(e=>{e.setDate(e.getDate()-(e.getDay()+7-t)%7),e.setHours(0,0,0,0)},(e,r)=>{e.setDate(e.getDate()+r*7)},(e,r)=>(r-e-(r.getTimezoneOffset()-e.getTimezoneOffset())*ft)/_n)}var gr=vt(0),xe=vt(1),ma=vt(2),pa=vt(3),Ot=vt(4),da=vt(5),ha=vt(6);gr.range;xe.range;ma.range;pa.range;Ot.range;da.range;ha.range;function wt(t){return P(e=>{e.setUTCDate(e.getUTCDate()-(e.getUTCDay()+7-t)%7),e.setUTCHours(0,0,0,0)},(e,r)=>{e.setUTCDate(e.getUTCDate()+r*7)},(e,r)=>(r-e)/_n)}var kn=wt(0),be=wt(1),ga=wt(2),ya=wt(3),Nt=wt(4),xa=wt(5),ba=wt(6);kn.range;be.range;ga.range;ya.range;Nt.range;xa.range;ba.range;var Dn=P(t=>{t.setDate(1),t.setHours(0,0,0,0)},(t,e)=>{t.setMonth(t.getMonth()+e)},(t,e)=>e.getMonth()-t.getMonth()+(e.getFullYear()-t.getFullYear())*12,t=>t.getMonth());Dn.range;var va=P(t=>{t.setUTCDate(1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCMonth(t.getUTCMonth()+e)},(t,e)=>e.getUTCMonth()-t.getUTCMonth()+(e.getUTCFullYear()-t.getUTCFullYear())*12,t=>t.getUTCMonth());va.range;var mt=P(t=>{t.setMonth(0,1),t.setHours(0,0,0,0)},(t,e)=>{t.setFullYear(t.getFullYear()+e)},(t,e)=>e.getFullYear()-t.getFullYear(),t=>t.getFullYear());mt.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:P(e=>{e.setFullYear(Math.floor(e.getFullYear()/t)*t),e.setMonth(0,1),e.setHours(0,0,0,0)},(e,r)=>{e.setFullYear(e.getFullYear()+r*t)});mt.range;var bt=P(t=>{t.setUTCMonth(0,1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCFullYear(t.getUTCFullYear()+e)},(t,e)=>e.getUTCFullYear()-t.getUTCFullYear(),t=>t.getUTCFullYear());bt.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:P(e=>{e.setUTCFullYear(Math.floor(e.getUTCFullYear()/t)*t),e.setUTCMonth(0,1),e.setUTCHours(0,0,0,0)},(e,r)=>{e.setUTCFullYear(e.getUTCFullYear()+r*t)});bt.range;function ur(t){if(0<=t.y&&t.y<100){var e=new Date(-1,t.m,t.d,t.H,t.M,t.S,t.L);return e.setFullYear(t.y),e}return new Date(t.y,t.m,t.d,t.H,t.M,t.S,t.L)}function cr(t){if(0<=t.y&&t.y<100){var e=new Date(Date.UTC(-1,t.m,t.d,t.H,t.M,t.S,t.L));return e.setUTCFullYear(t.y),e}return new Date(Date.UTC(t.y,t.m,t.d,t.H,t.M,t.S,t.L))}function Ut(t,e,r){return{y:t,m:e,d:r,H:0,M:0,S:0,L:0}}function mr(t){var e=t.dateTime,r=t.date,n=t.time,o=t.periods,i=t.days,a=t.shortDays,s=t.months,l=t.shortMonths,u=Ht(o),f=Vt(o),c=Ht(i),m=Vt(i),p=Ht(a),h=Vt(a),g=Ht(s),_=Vt(s),v=Ht(l),C=Vt(l),b={a:j,A:tt,b:Y,B:Ui,c:null,d:gn,e:gn,f:Ua,g:ja,G:es,H:Pa,I:$a,j:La,L:An,m:Ha,M:Va,p:Hi,q:Vi,Q:bn,s:vn,S:Ga,u:Xa,U:Wa,V:Qa,w:Za,W:Ja,x:null,X:null,y:Ka,Y:ts,Z:rs,"%":xn},M={a:Gi,A:Xi,b:Wi,B:Qi,c:null,d:yn,e:yn,f:as,g:gs,G:xs,H:ns,I:os,j:is,L:Fn,m:ss,M:ls,p:Zi,q:Ji,Q:bn,s:vn,S:us,u:cs,U:fs,V:ms,w:ps,W:ds,x:null,X:null,y:hs,Y:ys,Z:bs,"%":xn},x={a:U,A:y,b:F,B:k,c:z,d:dn,e:dn,f:Ba,g:pn,G:mn,H:hn,I:hn,j:Oa,L:Ia,m:Ea,M:Na,p:K,q:Fa,Q:za,s:qa,S:Ya,u:Ma,U:ka,V:Da,w:Sa,W:Aa,x:G,X:I,y:pn,Y:mn,Z:Ta,"%":Ra};b.x=S(r,b),b.X=S(n,b),b.c=S(e,b),M.x=S(r,M),M.X=S(n,M),M.c=S(e,M);function S(w,D){return function(A){var d=[],X=-1,E=0,Q=w.length,Z,xt,on;for(A instanceof Date||(A=new Date(+A));++X<Q;)w.charCodeAt(X)===37&&(d.push(w.slice(E,X)),(xt=fn[Z=w.charAt(++X)])!=null?Z=w.charAt(++X):xt=Z==="e"?" ":"0",(on=D[Z])&&(Z=on(A,xt)),d.push(Z),E=X+1);return d.push(w.slice(E,X)),d.join("")}}function N(w,D){return function(A){var d=Ut(1900,void 0,1),X=R(d,w,A+="",0),E,Q;if(X!=A.length)return null;if("Q"in d)return new Date(d.Q);if("s"in d)return new Date(d.s*1e3+("L"in d?d.L:0));if(D&&!("Z"in d)&&(d.Z=0),"p"in d&&(d.H=d.H%12+d.p*12),d.m===void 0&&(d.m="q"in d?d.q:0),"V"in d){if(d.V<1||d.V>53)return null;"w"in d||(d.w=1),"Z"in d?(E=cr(Ut(d.y,0,1)),Q=E.getUTCDay(),E=Q>4||Q===0?be.ceil(E):be(E),E=hr.offset(E,(d.V-1)*7),d.y=E.getUTCFullYear(),d.m=E.getUTCMonth(),d.d=E.getUTCDate()+(d.w+6)%7):(E=ur(Ut(d.y,0,1)),Q=E.getDay(),E=Q>4||Q===0?xe.ceil(E):xe(E),E=ve.offset(E,(d.V-1)*7),d.y=E.getFullYear(),d.m=E.getMonth(),d.d=E.getDate()+(d.w+6)%7)}else("W"in d||"U"in d)&&("w"in d||(d.w="u"in d?d.u%7:"W"in d?1:0),Q="Z"in d?cr(Ut(d.y,0,1)).getUTCDay():ur(Ut(d.y,0,1)).getDay(),d.m=0,d.d="W"in d?(d.w+6)%7+d.W*7-(Q+5)%7:d.w+d.U*7-(Q+6)%7);return"Z"in d?(d.H+=d.Z/100|0,d.M+=d.Z%100,cr(d)):ur(d)}}function R(w,D,A,d){for(var X=0,E=D.length,Q=A.length,Z,xt;X<E;){if(d>=Q)return-1;if(Z=D.charCodeAt(X++),Z===37){if(Z=D.charAt(X++),xt=x[Z in fn?D.charAt(X++):Z],!xt||(d=xt(w,A,d))<0)return-1}else if(Z!=A.charCodeAt(d++))return-1}return d}function K(w,D,A){var d=u.exec(D.slice(A));return d?(w.p=f.get(d[0].toLowerCase()),A+d[0].length):-1}function U(w,D,A){var d=p.exec(D.slice(A));return d?(w.w=h.get(d[0].toLowerCase()),A+d[0].length):-1}function y(w,D,A){var d=c.exec(D.slice(A));return d?(w.w=m.get(d[0].toLowerCase()),A+d[0].length):-1}function F(w,D,A){var d=v.exec(D.slice(A));return d?(w.m=C.get(d[0].toLowerCase()),A+d[0].length):-1}function k(w,D,A){var d=g.exec(D.slice(A));return d?(w.m=_.get(d[0].toLowerCase()),A+d[0].length):-1}function z(w,D,A){return R(w,e,D,A)}function G(w,D,A){return R(w,r,D,A)}function I(w,D,A){return R(w,n,D,A)}function j(w){return a[w.getDay()]}function tt(w){return i[w.getDay()]}function Y(w){return l[w.getMonth()]}function Ui(w){return s[w.getMonth()]}function Hi(w){return o[+(w.getHours()>=12)]}function Vi(w){return 1+~~(w.getMonth()/3)}function Gi(w){return a[w.getUTCDay()]}function Xi(w){return i[w.getUTCDay()]}function Wi(w){return l[w.getUTCMonth()]}function Qi(w){return s[w.getUTCMonth()]}function Zi(w){return o[+(w.getUTCHours()>=12)]}function Ji(w){return 1+~~(w.getUTCMonth()/3)}return{format:function(w){var D=S(w+="",b);return D.toString=function(){return w},D},parse:function(w){var D=N(w+="",!1);return D.toString=function(){return w},D},utcFormat:function(w){var D=S(w+="",M);return D.toString=function(){return w},D},utcParse:function(w){var D=N(w+="",!0);return D.toString=function(){return w},D}}}var fn={"-":"",_:" ",0:"0"},q=/^\s*\d+/,wa=/^%/,_a=/[\\^$*+?|[\]().{}]/g;function T(t,e,r){var n=t<0?"-":"",o=(n?-t:t)+"",i=o.length;return n+(i<r?new Array(r-i+1).join(e)+o:o)}function Ca(t){return t.replace(_a,"\\$&")}function Ht(t){return new RegExp("^(?:"+t.map(Ca).join("|")+")","i")}function Vt(t){return new Map(t.map((e,r)=>[e.toLowerCase(),r]))}function Sa(t,e,r){var n=q.exec(e.slice(r,r+1));return n?(t.w=+n[0],r+n[0].length):-1}function Ma(t,e,r){var n=q.exec(e.slice(r,r+1));return n?(t.u=+n[0],r+n[0].length):-1}function ka(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.U=+n[0],r+n[0].length):-1}function Da(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.V=+n[0],r+n[0].length):-1}function Aa(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.W=+n[0],r+n[0].length):-1}function mn(t,e,r){var n=q.exec(e.slice(r,r+4));return n?(t.y=+n[0],r+n[0].length):-1}function pn(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.y=+n[0]+(+n[0]>68?1900:2e3),r+n[0].length):-1}function Ta(t,e,r){var n=/^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(r,r+6));return n?(t.Z=n[1]?0:-(n[2]+(n[3]||"00")),r+n[0].length):-1}function Fa(t,e,r){var n=q.exec(e.slice(r,r+1));return n?(t.q=n[0]*3-3,r+n[0].length):-1}function Ea(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.m=n[0]-1,r+n[0].length):-1}function dn(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.d=+n[0],r+n[0].length):-1}function Oa(t,e,r){var n=q.exec(e.slice(r,r+3));return n?(t.m=0,t.d=+n[0],r+n[0].length):-1}function hn(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.H=+n[0],r+n[0].length):-1}function Na(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.M=+n[0],r+n[0].length):-1}function Ya(t,e,r){var n=q.exec(e.slice(r,r+2));return n?(t.S=+n[0],r+n[0].length):-1}function Ia(t,e,r){var n=q.exec(e.slice(r,r+3));return n?(t.L=+n[0],r+n[0].length):-1}function Ba(t,e,r){var n=q.exec(e.slice(r,r+6));return n?(t.L=Math.floor(n[0]/1e3),r+n[0].length):-1}function Ra(t,e,r){var n=wa.exec(e.slice(r,r+1));return n?r+n[0].length:-1}function za(t,e,r){var n=q.exec(e.slice(r));return n?(t.Q=+n[0],r+n[0].length):-1}function qa(t,e,r){var n=q.exec(e.slice(r));return n?(t.s=+n[0],r+n[0].length):-1}function gn(t,e){return T(t.getDate(),e,2)}function Pa(t,e){return T(t.getHours(),e,2)}function $a(t,e){return T(t.getHours()%12||12,e,2)}function La(t,e){return T(1+ve.count(mt(t),t),e,3)}function An(t,e){return T(t.getMilliseconds(),e,3)}function Ua(t,e){return An(t,e)+"000"}function Ha(t,e){return T(t.getMonth()+1,e,2)}function Va(t,e){return T(t.getMinutes(),e,2)}function Ga(t,e){return T(t.getSeconds(),e,2)}function Xa(t){var e=t.getDay();return e===0?7:e}function Wa(t,e){return T(gr.count(mt(t)-1,t),e,2)}function Tn(t){var e=t.getDay();return e>=4||e===0?Ot(t):Ot.ceil(t)}function Qa(t,e){return t=Tn(t),T(Ot.count(mt(t),t)+(mt(t).getDay()===4),e,2)}function Za(t){return t.getDay()}function Ja(t,e){return T(xe.count(mt(t)-1,t),e,2)}function Ka(t,e){return T(t.getFullYear()%100,e,2)}function ja(t,e){return t=Tn(t),T(t.getFullYear()%100,e,2)}function ts(t,e){return T(t.getFullYear()%1e4,e,4)}function es(t,e){var r=t.getDay();return t=r>=4||r===0?Ot(t):Ot.ceil(t),T(t.getFullYear()%1e4,e,4)}function rs(t){var e=t.getTimezoneOffset();return(e>0?"-":(e*=-1,"+"))+T(e/60|0,"0",2)+T(e%60,"0",2)}function yn(t,e){return T(t.getUTCDate(),e,2)}function ns(t,e){return T(t.getUTCHours(),e,2)}function os(t,e){return T(t.getUTCHours()%12||12,e,2)}function is(t,e){return T(1+hr.count(bt(t),t),e,3)}function Fn(t,e){return T(t.getUTCMilliseconds(),e,3)}function as(t,e){return Fn(t,e)+"000"}function ss(t,e){return T(t.getUTCMonth()+1,e,2)}function ls(t,e){return T(t.getUTCMinutes(),e,2)}function us(t,e){return T(t.getUTCSeconds(),e,2)}function cs(t){var e=t.getUTCDay();return e===0?7:e}function fs(t,e){return T(kn.count(bt(t)-1,t),e,2)}function En(t){var e=t.getUTCDay();return e>=4||e===0?Nt(t):Nt.ceil(t)}function ms(t,e){return t=En(t),T(Nt.count(bt(t),t)+(bt(t).getUTCDay()===4),e,2)}function ps(t){return t.getUTCDay()}function ds(t,e){return T(be.count(bt(t)-1,t),e,2)}function hs(t,e){return T(t.getUTCFullYear()%100,e,2)}function gs(t,e){return t=En(t),T(t.getUTCFullYear()%100,e,2)}function ys(t,e){return T(t.getUTCFullYear()%1e4,e,4)}function xs(t,e){var r=t.getUTCDay();return t=r>=4||r===0?Nt(t):Nt.ceil(t),T(t.getUTCFullYear()%1e4,e,4)}function bs(){return"+0000"}function xn(){return"%"}function bn(t){return+t}function vn(t){return Math.floor(+t/1e3)}var Et,at;vs({dateTime:"%x, %X",date:"%-m/%-d/%Y",time:"%-I:%M:%S %p",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]});function vs(t){return Et=mr(t),at=Et.format,Et.parse,Et.utcFormat,Et.utcParse,Et}var pr=[[1,4,12,52,365,365*24,365*24*60,365*24*60*60,365*24*60*60*1e3],[1/4,1,3,13,91,91*24,91*24*60,91*24*60*60,91*24*60*60*1e3],[1/12,1/3,1,4,30,30*24,30*24*60,30*24*60*60,30*24*60*60*1e3],[1/52,1/13,1/4,1,7,7*24,7*24*60,7*24*60*60,7*24*60*60*1e3],[1/365,1/91,1/30,1/7,1,24,24*60,24*60*60,24*60*60*1e3],[1/(365*24),1/(91*24),1/(30*24),1/(7*24),1/24,1,60,60*60,60*60*1e3],[1/(365*24*60),1/(91*24*60),1/(30*24*60),1/(7*24*60),1/(24*60),1/60,1,60,60*1e3],[1/(365*24*60*60),1/(91*24*60*60),1/(30*24*60*60),1/(7*24*60*60),1/(24*60*60),1/(60*60),1/60,1,1e3],[1/(365*24*60*60*1e3),1/(91*24*60*60*1e3),1/(30*24*60*60*1e3),1/(7*24*60*60*1e3),1/(24*60*60*1e3),1/(60*60*1e3),1/(60*1e3),1/1e3,1]];function ws(t,e,r){if(nt(t))return;if(!e||!r||e===r)return t;let n=pr[e-1][r-1];if(n)return t*n}function _s(t,e,r,n){if(nt(t)||!e.lowestLevel||r.length===0)return"";let o=[],i=0,a=Math.round(t*pr[e.lowestLevel-1][8]),s=9;for(let[,u]of r.entries())if(t){a=a-i;let f=pr[u-1][s-1],c=Math.floor(a/f);i=c*f,o.push({level:u,value:c})}else o.push({level:u,value:0});let l="";for(let[u,f]of o.entries())if(e.duration.format==="time"){let c=f.value;[6,7,8].includes(f.level)&&f.value<10?c="0"+f.value.toString():f.level===9&&f.value<10?c="00"+f.value.toString():f.level===9&&f.value<100&&(c="0"+f.value.toString()),l+=(u===0?"":f.level===9?".":":")+c}else if(e.duration.format==="long"){let c=n.durationLongSuffix;l+=f.value+" "+c[f.level]+(u===o.length-1?"":" ")}else{let c=n.durationShortSuffix;l+=f.value+""+c[f.level]+(u===o.length-1?"":" ")}return l}var Cs={decimal:".",thousands:",",grouping:[3],currency:["$",""],dateTime:"%a %b %e %X %Y",date:"%m/%d/%Y",dateSeparator:"/",time:"%H:%M:%S",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],levels:["All","Year","Quarter","Month","Week","Date","Hour","Minute","Second","Millisecond"],shortLevels:["All","Yr","Qtr","Mth","Wk","Date","Hr","Min","Sec","Msec"],durationLongSuffix:["","years","quarters","months","weeks","days","hours","minutes","seconds","milliseconds"],durationShortSuffix:["","y","q","mo","w","d","h","m","s","ms"],multi:[".%L",":%S","%I:%M","%I %p","%a %d","W%G","%b %d","%B","%Y"]},Ss="%d-%m-%Y",Ms=[{key:"%a %e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%a %e %b %Y",monthType:"name",longText:!1,weekday:!0},{key:"%e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%e %b %Y",monthType:"name",longText:!1,weekday:!1},{key:"%a %e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%a %e %B %Y",monthType:"name",longText:!0,weekday:!0},{key:"%e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%e %B %Y",monthType:"name",longText:!0,weekday:!1},{key:"%d/%m/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"W%V/%G",lev5:"%d/%m/%Y",monthType:"number",mmdd:!1,separator:"/"},{key:"%d-%m-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"W%V-%G",lev5:"%d-%m-%Y",monthType:"number",mmdd:!1,separator:"-"},{key:"%d.%m.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"W%V.%G",lev5:"%d.%m.%Y",monthType:"number",mmdd:!1,separator:"."},{key:"%d~%m~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"W%V~%G",lev5:"%d~%m~%Y",monthType:"number",mmdd:!1,separator:"~"},{key:"%m/%d/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%m/%d/%Y",monthType:"number",mmdd:!0,separator:"/"},{key:"%m-%d-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%m-%d-%Y",monthType:"number",mmdd:!0,separator:"-"},{key:"%m.%d.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%m.%d.%Y",monthType:"number",mmdd:!0,separator:"."},{key:"%m~%d~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%m~%d~%Y",monthType:"number",mmdd:!0,separator:"~"},{key:"%amd/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%amd/%Y",monthType:"number",mmdd:null,separator:"/"},{key:"%amd-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%amd-%Y",monthType:"number",mmdd:null,separator:"-"},{key:"%amd.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%amd.%Y",monthType:"number",mmdd:null,separator:"."},{key:"%amd~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%amd~%Y",monthType:"number",mmdd:null,separator:"~"}],ks=[{key:"%H:%M:%S.%L",lev6:"%H:00",lev7:"%H:%M",lev8:"%H:%M:%S",lev9:"%H:%M:%S.%L",ampm:!1},{key:"%I:%M:%S.%L %p",lev6:"%I:00 %p",lev7:"%I:%M %p",lev8:"%I:%M:%S %p",lev9:"%I:%M:%S.%L %p",ampm:!0}];function Qt(t,e){var r,n;e=e||{};let o=e.localFormats||Cs,i,a,s,l=[],u=[],f="datetime",c;e&&e.multi&&(f="datetime"),(!t||!t.format)&&(f="hierarchy"),t&&t.type&&(f=t.type),t&&t.format?c=t.format:f==="numeric"?c=",.0f":f==="datetime"?c=Ss:c="";let m=or(c);switch(m.precision&&m.typeFormat&&(f="numeric"),f){case"numeric":{if(t.subtype==="duration"&&t.duration&&t.duration.levels&&t.duration.levels.length>1&&!e.hideDuration)i=p=>nt(p)?"":_s(p,t,t.duration.levels,o);else{let p={...o},h=m.typeFormat,g=!1;switch(h.length===2&&h.startsWith("a")&&(g=!0,h=h.slice(1,2),c=c.replace(/a/,"")),g?(p.decimal=o.decimal,p.thousands=o.thousands):["z","y","w"].includes(h)?(p.decimal=",",p.thousands="."):(p.decimal=".",p.thousands=","),h){case"z":{c=c.replace("z","f");break}case"y":{c=c.replace("y","%");break}case"w":{c=c.replace("w","s");break}}if(t?.subtype==="currency"&&t.currency){let v="\xA0",C=p.currency.findIndex(S=>S.length>0),b=p.currency[C].startsWith(v),M=p.currency[C].endsWith(v),x=`${b?v:""}${t.currency}${M?v:""}`;p.currency[C]=x}let _=la(p);h!=="%"&&t?.subtype==="currency"&&t.currency&&p.currency&&!(e!=null&&e.hideCurrency)&&!["count","distinctcount"].includes(t.aggregationFunc)&&!(t.aggregationFunc==="rate"&&((r=t.aggregationWeight)==null?void 0:r.columnSubType)==="currency")&&((n=t.periodOverPeriod)==null?void 0:n.type)!=="percentageChange"&&(c="$"+c),e!=null&&e.trimZero&&["y","%"].includes(h)&&p.decimal===","?a=v=>_.format(c)(v).replace(/(,\d*?)0+%$/,"$1%").replace(/,%$/,"%"):e!=null&&e.trimZero&&["y","%"].includes(h)&&p.decimal==="."?a=v=>_.format(c)(v).replace(/(\.\d*?)0+%$/,"$1%").replace(/\.%$/,"%"):e!=null&&e.trimZero&&["z","f"].includes(h)&&p.decimal===","?a=v=>_.format(c)(v).replace(/(,\d*?)0+$/,"$1").replace(/,$/,""):e!=null&&e.trimZero&&["z","f"].includes(h)&&p.decimal==="."?a=v=>_.format(c)(v).replace(/(\.\d*?)0+$/,"$1").replace(/\.$/,""):t?.subtype==="currency"&&t.currency&&p.currency&&h==="s"?a=v=>_.format(c)(v).replace(/G/,"B"):a=nt(m.precision)?_.format(",.0f"):_.format(c),i=v=>{var C;if(nt(v))return"";if(t.subtype==="duration"&&t.duration&&!e.hideDuration){let b=t.duration.levels?t.duration.levels[0]:t.lowestLevel;return b!==t.lowestLevel&&(v=ws(v,t.lowestLevel,b)),a(v)+((C=o?.durationShortSuffix)==null?void 0:C[b])}return a(v)}}break}case"datetime":{if(l=o?.smartDateFormats??Ms,u=o?.smartTimeFormats??ks,nt(t.datetimeDisplayMode)){if(e!=null&&e.level){let p=e.level,h=l.find(M=>c.includes(M.key)),g=u.find(M=>c.includes(M.key)),_=h?h["lev"+Math.min(p,5)]:l[0]["lev"+Math.min(p,5)],v=p>5?g?g["lev"+p]:u[0]["lev"+p]:"";c=p>5?_+", "+v:_;let C=c.includes("%amd")&&e.level>=5,b=h?e.level>=2&&h.separator==="~":!1;C?c=b?c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8)):c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8).replaceAll(new RegExp(/[.~\/-]/g),h.separator)):c=b?c.replaceAll(new RegExp(/[~]/g),o.dateSeparator):c}if(e!=null&&e.multi){let p=at(o.multi[0]),h=at(o.multi[1]),g=at(o.multi[2]),_=at(o.multi[3]),v=at(o.multi[4]),C=at(o.multi[6]),b=at(o.multi[7]),M=at(o.multi[8]);s=x=>{let S;return Cn(x)<x?S=p:Sn(x)<x?S=h:Mn(x)<x?S=g:ve(x)<x?S=_:Dn(x)<x?S=gr(x)<x?v:C:mt(x)<x?S=b:S=M,S(x)}}else s=mr(o).format(c)}else{let p={quarter_number:{min:1,max:4},month_name:{min:1,max:12},month_number:{min:1,max:12},week_number:{min:1,max:53},day_in_month:{min:1,max:31},day_in_year:{min:1,max:366},weekday_name:{min:0,max:7},weekday_number:{min:0,max:7},hour_in_day:{min:0,max:23},minute_in_hour:{min:0,max:59},second_in_minute:{min:0,max:59}},h=(g,_,v)=>{var C,b,M,x,S;return _==="letter"?((C=g.shortNames)==null?void 0:C.length)>0&&((b=g.shortNames[v])==null?void 0:b.length)>0?(M=g.shortNames[v])==null?void 0:M.charAt(0):"N/A":_==="short"?((x=g.shortNames)==null?void 0:x.length)>0&&g.shortNames[v]?g.shortNames[v]:"N/A":((S=g.longNames)==null?void 0:S.length)>0&&g.longNames[v]?g.longNames[v]:"N/A"};["quarter_number","month_number","week_number","day_in_month","day_in_year","weekday_number","hour_in_day","minute_in_hour","second_in_minute"].includes(t.datetimeDisplayMode)?s=g=>Lt(g)&&g>=p[t.datetimeDisplayMode].min&&g<=p[t.datetimeDisplayMode].max?g:"N/A":t.datetimeDisplayMode==="month_name"?s=g=>{let _=[...o.shortMonths],v=[...o.months];return Lt(g)&&g>=p[t.datetimeDisplayMode].min&&g<=p[t.datetimeDisplayMode].max?h({shortNames:_,longNames:v},t.monthNameFormat,g-1):"N/A"}:t.datetimeDisplayMode==="weekday_name"?s=g=>{let _=[...o.shortDays],v=[...o.days];return t.weekStart==="monday"&&(_.push(_.shift()??""),v.push(v.shift()??"")),Lt(g)&&g>=p[t.datetimeDisplayMode].min&&g<=p[t.datetimeDisplayMode].max?h({shortNames:_,longNames:v},t.weekDayNameFormat,g-1):"N/A"}:s=mr(o).format(c)}i=p=>{if(nt(p))return"";let h=s(p);return ir(h)?h.trim():h};break}case"hierarchy":{i=p=>ar(p,e?e.locale:void 0);break}default:{i=p=>p;break}}return i}var J={type:"platform",background:"rgb(245,245,245)",itemsBackground:"rgb(255,255,255)",boxShadow:{size:"none",color:"rgb(0, 0, 0)"},title:{align:"left",bold:!1,italic:!1,underline:!1,border:!1},font:{fontFamily:"Lato","font-style":"normal","font-weight":400,fontSize:15},colors:["rgb(68,52,255)","rgb(143,133,255)","rgb(218,214,255)","rgb(191,5,184)","rgb(217,105,212)","rgb(242,205,241)","rgb(248,194,12)","rgb(251,218,109)","rgb(254,243,206)","rgb(9,203,120)","rgb(107,224,174)","rgb(206,245,228)","rgb(122,112,112)","rgb(175,169,169)","rgb(228,226,226)"],borders:{"border-color":"rgba(216,216,216,1)","border-style":"none","border-radius":"12px","border-top-width":"0px","border-left-width":"0px","border-right-width":"0px","border-bottom-width":"0px"},margins:[16,16],mainColor:"rgb(68,52,255)",axis:{},legend:{type:"circle"},tooltip:{background:"rgb(38,38,38)"},itemSpecific:{rounding:8,padding:4}},Yt=(t,e)=>({"border-color":t,"border-style":"none","border-radius":e,"border-top-width":"1px","border-left-width":"1px","border-right-width":"1px","border-bottom-width":"1px"}),qm={default:{...J,name:"Default (light)"},default_dark:{...J,name:"Default (dark)",background:"rgb(61,61,61)",itemsBackground:"rgb(38,38,38)",colors:["rgb(48,36,179)","rgb(105,93,255)","rgb(199,194,255)","rgb(134,4,129)","rgb(204,55,198)","rgb(236,180,234)","rgb(220,141,0)","rgb(249,206,61)","rgb(253,237,182)","rgb(6,142,84)","rgb(58,213,147)","rgb(181,239,215)","rgb(85,78,78)","rgb(149,141,141)","rgb(215,212,212)"],mainColor:"rgb(123,144,255)",tooltip:{background:"rgb(248,248,248)"}},vivid:{...J,name:"Vivid",background:"#eef3f6",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[12,12],mainColor:"#5867C3",legend:{type:"normal"},tooltip:{},colors:["#5867C3","#00C5DC","#FF525E","#FFAA00","#FFDB03","#86de40","#59b339","#cc27bc","#ff4aed","#bfbfbf","#737373"],font:{fontFamily:"Open Sans",fontSize:13}},seasonal:{...J,name:"Seasonal",background:"#ffffff",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:Yt("rgba(0,0,0,.1)","8px"),margins:[10,10],mainColor:"#009788",tooltip:{},colors:["#009788","#60cc64","#CDDC39","#FFEB3C","#FEC107","#FF9700","#FE5722","#EA1E63","#9C28B1","#673BB7","#3F51B5","#2196F3","#03A9F5","#00BCD5"],font:{fontFamily:"Open Sans",fontSize:13}},orion:{...J,name:"Orion's Belt",background:"#00062d",itemsBackground:"#00062d",boxShadow:{size:"L",color:"#64046f"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:Yt("rgba(0, 0, 0, .1)","8px"),mainColor:"#d62750",legend:{type:"normal"},colors:["#880065","#b3005e","#d62750","#ef513e","#fd7b27","#ffa600","#fdae6b"],font:{fontFamily:"Electrolize",fontSize:15}},royale:{...J,name:"Royale",background:"#0A2747",itemsBackground:"#111e2f",boxShadow:{size:"S",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{"border-radius":"3px"},margins:[10,10],mainColor:"#f4a92c",legend:{type:"circle"},tooltip:{},colors:["#feeaa1","#e6cc85","#ceaf6a","#b79350","#9f7738","#885d20","#704308"],font:{fontFamily:"Exo",fontSize:13}},urban:{...J,name:"Urban",background:"#42403c",itemsBackground:"#e4dbcd",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[5,5],mainColor:"#33b59e",legend:{type:"circle"},colors:["#33b59e","#453d30","#ffffff","#237869","#165e4e","#b89f76","#7a6138","#543c13","#8a9c98","#44524f"],font:{fontFamily:"Open Sans",fontSize:13}},pinky:{...J,name:"Pinky Brains",background:"#0F1E43",itemsBackground:"#1B2A4D",title:{align:"center",bold:!0,italic:!1,underline:!1,border:!0},borders:Yt("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#e84281",legend:{type:"normal"},tooltip:{},colors:["#e84281","#d464c2","#a089f2","#46a8ff","#00c0ff","#00d0e8","#49dcc9"],font:{fontFamily:"Capriola",fontSize:15}},bliss:{...J,name:"Bliss",background:"#ffffff",itemsBackground:"#ffffff",boxShadow:{size:"none",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:Yt("rgba(0, 0, 0, .1)","8px"),margins:[10,10],mainColor:"#0578ff",axis:{},legend:{type:"normal"},tooltip:{},colors:["#b8d8ff","#3ba0ff","#0044f2","#1b00ca","#9114de","#ce42ff","#ff19f6","#ed2bab","#d8175c","#ff303d","#ff6130","#ff9f30","#15BF49","#95E88C"],font:{fontFamily:"Open Sans",fontSize:13}},radiant:{...J,name:"Radiant",background:"rgba(43,43,56,1)",itemsBackground:"rgba(52,52,69,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:Yt("rgba(255, 255, 255, .08)","8px"),margins:[14,14],mainColor:"#00a4eb",legend:{type:"line"},tooltip:{},colors:["#a6e1ff","#00a4eb","#3f3af0","#9300c7","#f72f5f","#f29b50","#f2d566","#3ae086","#c9c9c9","#7a7a7a"],font:{fontFamily:"Open Sans",fontSize:13}},classic:{...J,name:"Classic (light)",background:"#F2F2F2",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#ececec",borders:Yt("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#009dff",legend:{type:"normal"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}},classic_dark:{...J,name:"Classic (dark)",background:"rgb(38,39,50)",itemsBackground:"rgba(52,53,68,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{},margins:[10,10],mainColor:"#0E89E0",legend:{type:"line"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}}};function _t(t,e){return t==null||e==null?NaN:t<e?-1:t>e?1:t>=e?0:NaN}function yr(t,e){return t==null||e==null?NaN:e<t?-1:e>t?1:e>=t?0:NaN}function we(t){let e,r,n;t.length!==2?(e=_t,r=(s,l)=>_t(t(s),l),n=(s,l)=>t(s)-l):(e=t===_t||t===yr?t:Ds,r=t,n=t);function o(s,l,u=0,f=s.length){if(u<f){if(e(l,l)!==0)return f;do{let c=u+f>>>1;r(s[c],l)<0?u=c+1:f=c}while(u<f)}return u}function i(s,l,u=0,f=s.length){if(u<f){if(e(l,l)!==0)return f;do{let c=u+f>>>1;r(s[c],l)<=0?u=c+1:f=c}while(u<f)}return u}function a(s,l,u=0,f=s.length){let c=o(s,l,u,f-1);return c>u&&n(s[c-1],l)>-n(s[c],l)?c-1:c}return{left:o,center:a,right:i}}function Ds(){return 0}function xr(t){return t===null?NaN:+t}var On=we(_t),Nn=On.right,As=On.left,Ts=we(xr).center,br=Nn;var pt=class extends Map{constructor(e,r=Os){if(super(),Object.defineProperties(this,{_intern:{value:new Map},_key:{value:r}}),e!=null)for(let[n,o]of e)this.set(n,o)}get(e){return super.get(Yn(this,e))}has(e){return super.has(Yn(this,e))}set(e,r){return super.set(Fs(this,e),r)}delete(e){return super.delete(Es(this,e))}};function Yn({_intern:t,_key:e},r){let n=e(r);return t.has(n)?t.get(n):r}function Fs({_intern:t,_key:e},r){let n=e(r);return t.has(n)?t.get(n):(t.set(n,r),r)}function Es({_intern:t,_key:e},r){let n=e(r);return t.has(n)&&(r=t.get(n),t.delete(n)),r}function Os(t){return t!==null&&typeof t=="object"?t.valueOf():t}function _e(t){return t}function Ce(t,...e){return Ns(t,_e,_e,e)}function Ns(t,e,r,n){return function o(i,a){if(a>=n.length)return r(i);let s=new pt,l=n[a++],u=-1;for(let f of i){let c=l(f,++u,i),m=s.get(c);m?m.push(f):s.set(c,[f])}for(let[f,c]of s)s.set(f,o(c,a));return e(s)}(t,0)}var Ys=Math.sqrt(50),Is=Math.sqrt(10),Bs=Math.sqrt(2);function Se(t,e,r){let n=(e-t)/Math.max(0,r),o=Math.floor(Math.log10(n)),i=n/Math.pow(10,o),a=i>=Ys?10:i>=Is?5:i>=Bs?2:1,s,l,u;return o<0?(u=Math.pow(10,-o)/a,s=Math.round(t*u),l=Math.round(e*u),s/u<t&&++s,l/u>e&&--l,u=-u):(u=Math.pow(10,o)*a,s=Math.round(t/u),l=Math.round(e/u),s*u<t&&++s,l*u>e&&--l),l<s&&.5<=r&&r<2?Se(t,e,r*2):[s,l,u]}function Me(t,e,r){if(e=+e,t=+t,r=+r,!(r>0))return[];if(t===e)return[t];let n=e<t,[o,i,a]=n?Se(e,t,r):Se(t,e,r);if(!(i>=o))return[];let s=i-o+1,l=new Array(s);if(n)if(a<0)for(let u=0;u<s;++u)l[u]=(i-u)/-a;else for(let u=0;u<s;++u)l[u]=(i-u)*a;else if(a<0)for(let u=0;u<s;++u)l[u]=(o+u)/-a;else for(let u=0;u<s;++u)l[u]=(o+u)*a;return l}function Zt(t,e,r){return e=+e,t=+t,r=+r,Se(t,e,r)[2]}function vr(t,e,r){e=+e,t=+t,r=+r;let n=e<t,o=n?Zt(e,t,r):Zt(t,e,r);return(n?-1:1)*(o<0?1/-o:o)}function ke(t,e){let r;if(e===void 0)for(let n of t)n!=null&&(r<n||r===void 0&&n>=n)&&(r=n);else{let n=-1;for(let o of t)(o=e(o,++n,t))!=null&&(r<o||r===void 0&&o>=o)&&(r=o)}return r}function De(t,e,r){t=+t,e=+e,r=(o=arguments.length)<2?(e=t,t=0,1):o<3?1:+r;for(var n=-1,o=Math.max(0,Math.ceil((e-t)/r))|0,i=new Array(o);++n<o;)i[n]=t+n*r;return i}function In(t){return t}var wr=1,_r=2,Cr=3,Jt=4,Bn=1e-6;function Rs(t){return"translate("+t+",0)"}function zs(t){return"translate(0,"+t+")"}function qs(t){return e=>+t(e)}function Ps(t,e){return e=Math.max(0,t.bandwidth()-e*2)/2,t.round()&&(e=Math.round(e)),r=>+t(r)+e}function $s(){return!this.__axis}function Rn(t,e){var r=[],n=null,o=null,i=6,a=6,s=3,l=typeof window<"u"&&window.devicePixelRatio>1?0:.5,u=t===wr||t===Jt?-1:1,f=t===Jt||t===_r?"x":"y",c=t===wr||t===Cr?Rs:zs;function m(p){var h=n??(e.ticks?e.ticks.apply(e,r):e.domain()),g=o??(e.tickFormat?e.tickFormat.apply(e,r):In),_=Math.max(i,0)+s,v=e.range(),C=+v[0]+l,b=+v[v.length-1]+l,M=(e.bandwidth?Ps:qs)(e.copy(),l),x=p.selection?p.selection():p,S=x.selectAll(".domain").data([null]),N=x.selectAll(".tick").data(h,e).order(),R=N.exit(),K=N.enter().append("g").attr("class","tick"),U=N.select("line"),y=N.select("text");S=S.merge(S.enter().insert("path",".tick").attr("class","domain").attr("stroke","currentColor")),N=N.merge(K),U=U.merge(K.append("line").attr("stroke","currentColor").attr(f+"2",u*i)),y=y.merge(K.append("text").attr("fill","currentColor").attr(f,u*_).attr("dy",t===wr?"0em":t===Cr?"0.71em":"0.32em")),p!==x&&(S=S.transition(p),N=N.transition(p),U=U.transition(p),y=y.transition(p),R=R.transition(p).attr("opacity",Bn).attr("transform",function(F){return isFinite(F=M(F))?c(F+l):this.getAttribute("transform")}),K.attr("opacity",Bn).attr("transform",function(F){var k=this.parentNode.__axis;return c((k&&isFinite(k=k(F))?k:M(F))+l)})),R.remove(),S.attr("d",t===Jt||t===_r?a?"M"+u*a+","+C+"H"+l+"V"+b+"H"+u*a:"M"+l+","+C+"V"+b:a?"M"+C+","+u*a+"V"+l+"H"+b+"V"+u*a:"M"+C+","+l+"H"+b),N.attr("opacity",1).attr("transform",function(F){return c(M(F)+l)}),U.attr(f+"2",u*i),y.attr(f,u*_).text(g),x.filter($s).attr("fill","none").attr("font-size",10).attr("font-family","sans-serif").attr("text-anchor",t===_r?"start":t===Jt?"end":"middle"),x.each(function(){this.__axis=M})}return m.scale=function(p){return arguments.length?(e=p,m):e},m.ticks=function(){return r=Array.from(arguments),m},m.tickArguments=function(p){return arguments.length?(r=p==null?[]:Array.from(p),m):r.slice()},m.tickValues=function(p){return arguments.length?(n=p==null?null:Array.from(p),m):n&&n.slice()},m.tickFormat=function(p){return arguments.length?(o=p,m):o},m.tickSize=function(p){return arguments.length?(i=a=+p,m):i},m.tickSizeInner=function(p){return arguments.length?(i=+p,m):i},m.tickSizeOuter=function(p){return arguments.length?(a=+p,m):a},m.tickPadding=function(p){return arguments.length?(s=+p,m):s},m.offset=function(p){return arguments.length?(l=+p,m):l},m}function Sr(t){return Rn(Cr,t)}function Mr(t){return Rn(Jt,t)}var Ls={value:()=>{}};function qn(){for(var t=0,e=arguments.length,r={},n;t<e;++t){if(!(n=arguments[t]+"")||n in r||/[\s.]/.test(n))throw new Error("illegal type: "+n);r[n]=[]}return new Ae(r)}function Ae(t){this._=t}function Us(t,e){return t.trim().split(/^|\s+/).map(function(r){var n="",o=r.indexOf(".");if(o>=0&&(n=r.slice(o+1),r=r.slice(0,o)),r&&!e.hasOwnProperty(r))throw new Error("unknown type: "+r);return{type:r,name:n}})}Ae.prototype=qn.prototype={constructor:Ae,on:function(t,e){var r=this._,n=Us(t+"",r),o,i=-1,a=n.length;if(arguments.length<2){for(;++i<a;)if((o=(t=n[i]).type)&&(o=Hs(r[o],t.name)))return o;return}if(e!=null&&typeof e!="function")throw new Error("invalid callback: "+e);for(;++i<a;)if(o=(t=n[i]).type)r[o]=zn(r[o],t.name,e);else if(e==null)for(o in r)r[o]=zn(r[o],t.name,null);return this},copy:function(){var t={},e=this._;for(var r in e)t[r]=e[r].slice();return new Ae(t)},call:function(t,e){if((o=arguments.length-2)>0)for(var r=new Array(o),n=0,o,i;n<o;++n)r[n]=arguments[n+2];if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(i=this._[t],n=0,o=i.length;n<o;++n)i[n].value.apply(e,r)},apply:function(t,e,r){if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(var n=this._[t],o=0,i=n.length;o<i;++o)n[o].value.apply(e,r)}};function Hs(t,e){for(var r=0,n=t.length,o;r<n;++r)if((o=t[r]).name===e)return o.value}function zn(t,e,r){for(var n=0,o=t.length;n<o;++n)if(t[n].name===e){t[n]=Ls,t=t.slice(0,n).concat(t.slice(n+1));break}return r!=null&&t.push({name:e,value:r}),t}var kr=qn;var Te="http://www.w3.org/1999/xhtml",Dr={svg:"http://www.w3.org/2000/svg",xhtml:Te,xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace",xmlns:"http://www.w3.org/2000/xmlns/"};function st(t){var e=t+="",r=e.indexOf(":");return r>=0&&(e=t.slice(0,r))!=="xmlns"&&(t=t.slice(r+1)),Dr.hasOwnProperty(e)?{space:Dr[e],local:t}:t}function Vs(t){return function(){var e=this.ownerDocument,r=this.namespaceURI;return r===Te&&e.documentElement.namespaceURI===Te?e.createElement(t):e.createElementNS(r,t)}}function Gs(t){return function(){return this.ownerDocument.createElementNS(t.space,t.local)}}function Fe(t){var e=st(t);return(e.local?Gs:Vs)(e)}function Xs(){}function Ct(t){return t==null?Xs:function(){return this.querySelector(t)}}function Pn(t){typeof t!="function"&&(t=Ct(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,s=n[o]=new Array(a),l,u,f=0;f<a;++f)(l=i[f])&&(u=t.call(l,l.__data__,f,i))&&("__data__"in l&&(u.__data__=l.__data__),s[f]=u);return new O(n,this._parents)}function Kt(t){return t==null?[]:Array.isArray(t)?t:Array.from(t)}function Ws(){return[]}function jt(t){return t==null?Ws:function(){return this.querySelectorAll(t)}}function Qs(t){return function(){return Kt(t.apply(this,arguments))}}function $n(t){typeof t=="function"?t=Qs(t):t=jt(t);for(var e=this._groups,r=e.length,n=[],o=[],i=0;i<r;++i)for(var a=e[i],s=a.length,l,u=0;u<s;++u)(l=a[u])&&(n.push(t.call(l,l.__data__,u,a)),o.push(l));return new O(n,o)}function te(t){return function(){return this.matches(t)}}function Ee(t){return function(e){return e.matches(t)}}var Zs=Array.prototype.find;function Js(t){return function(){return Zs.call(this.children,t)}}function Ks(){return this.firstElementChild}function Ln(t){return this.select(t==null?Ks:Js(typeof t=="function"?t:Ee(t)))}var js=Array.prototype.filter;function tl(){return Array.from(this.children)}function el(t){return function(){return js.call(this.children,t)}}function Un(t){return this.selectAll(t==null?tl:el(typeof t=="function"?t:Ee(t)))}function Hn(t){typeof t!="function"&&(t=te(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,s=n[o]=[],l,u=0;u<a;++u)(l=i[u])&&t.call(l,l.__data__,u,i)&&s.push(l);return new O(n,this._parents)}function Oe(t){return new Array(t.length)}function Vn(){return new O(this._enter||this._groups.map(Oe),this._parents)}function ee(t,e){this.ownerDocument=t.ownerDocument,this.namespaceURI=t.namespaceURI,this._next=null,this._parent=t,this.__data__=e}ee.prototype={constructor:ee,appendChild:function(t){return this._parent.insertBefore(t,this._next)},insertBefore:function(t,e){return this._parent.insertBefore(t,e)},querySelector:function(t){return this._parent.querySelector(t)},querySelectorAll:function(t){return this._parent.querySelectorAll(t)}};function Gn(t){return function(){return t}}function rl(t,e,r,n,o,i){for(var a=0,s,l=e.length,u=i.length;a<u;++a)(s=e[a])?(s.__data__=i[a],n[a]=s):r[a]=new ee(t,i[a]);for(;a<l;++a)(s=e[a])&&(o[a]=s)}function nl(t,e,r,n,o,i,a){var s,l,u=new Map,f=e.length,c=i.length,m=new Array(f),p;for(s=0;s<f;++s)(l=e[s])&&(m[s]=p=a.call(l,l.__data__,s,e)+"",u.has(p)?o[s]=l:u.set(p,l));for(s=0;s<c;++s)p=a.call(t,i[s],s,i)+"",(l=u.get(p))?(n[s]=l,l.__data__=i[s],u.delete(p)):r[s]=new ee(t,i[s]);for(s=0;s<f;++s)(l=e[s])&&u.get(m[s])===l&&(o[s]=l)}function ol(t){return t.__data__}function Xn(t,e){if(!arguments.length)return Array.from(this,ol);var r=e?nl:rl,n=this._parents,o=this._groups;typeof t!="function"&&(t=Gn(t));for(var i=o.length,a=new Array(i),s=new Array(i),l=new Array(i),u=0;u<i;++u){var f=n[u],c=o[u],m=c.length,p=il(t.call(f,f&&f.__data__,u,n)),h=p.length,g=s[u]=new Array(h),_=a[u]=new Array(h),v=l[u]=new Array(m);r(f,c,g,_,v,p,e);for(var C=0,b=0,M,x;C<h;++C)if(M=g[C]){for(C>=b&&(b=C+1);!(x=_[b])&&++b<h;);M._next=x||null}}return a=new O(a,n),a._enter=s,a._exit=l,a}function il(t){return typeof t=="object"&&"length"in t?t:Array.from(t)}function Wn(){return new O(this._exit||this._groups.map(Oe),this._parents)}function Qn(t,e,r){var n=this.enter(),o=this,i=this.exit();return typeof t=="function"?(n=t(n),n&&(n=n.selection())):n=n.append(t+""),e!=null&&(o=e(o),o&&(o=o.selection())),r==null?i.remove():r(i),n&&o?n.merge(o).order():o}function Zn(t){for(var e=t.selection?t.selection():t,r=this._groups,n=e._groups,o=r.length,i=n.length,a=Math.min(o,i),s=new Array(o),l=0;l<a;++l)for(var u=r[l],f=n[l],c=u.length,m=s[l]=new Array(c),p,h=0;h<c;++h)(p=u[h]||f[h])&&(m[h]=p);for(;l<o;++l)s[l]=r[l];return new O(s,this._parents)}function Jn(){for(var t=this._groups,e=-1,r=t.length;++e<r;)for(var n=t[e],o=n.length-1,i=n[o],a;--o>=0;)(a=n[o])&&(i&&a.compareDocumentPosition(i)^4&&i.parentNode.insertBefore(a,i),i=a);return this}function Kn(t){t||(t=al);function e(c,m){return c&&m?t(c.__data__,m.__data__):!c-!m}for(var r=this._groups,n=r.length,o=new Array(n),i=0;i<n;++i){for(var a=r[i],s=a.length,l=o[i]=new Array(s),u,f=0;f<s;++f)(u=a[f])&&(l[f]=u);l.sort(e)}return new O(o,this._parents).order()}function al(t,e){return t<e?-1:t>e?1:t>=e?0:NaN}function jn(){var t=arguments[0];return arguments[0]=this,t.apply(null,arguments),this}function to(){return Array.from(this)}function eo(){for(var t=this._groups,e=0,r=t.length;e<r;++e)for(var n=t[e],o=0,i=n.length;o<i;++o){var a=n[o];if(a)return a}return null}function ro(){let t=0;for(let e of this)++t;return t}function no(){return!this.node()}function oo(t){for(var e=this._groups,r=0,n=e.length;r<n;++r)for(var o=e[r],i=0,a=o.length,s;i<a;++i)(s=o[i])&&t.call(s,s.__data__,i,o);return this}function sl(t){return function(){this.removeAttribute(t)}}function ll(t){return function(){this.removeAttributeNS(t.space,t.local)}}function ul(t,e){return function(){this.setAttribute(t,e)}}function cl(t,e){return function(){this.setAttributeNS(t.space,t.local,e)}}function fl(t,e){return function(){var r=e.apply(this,arguments);r==null?this.removeAttribute(t):this.setAttribute(t,r)}}function ml(t,e){return function(){var r=e.apply(this,arguments);r==null?this.removeAttributeNS(t.space,t.local):this.setAttributeNS(t.space,t.local,r)}}function io(t,e){var r=st(t);if(arguments.length<2){var n=this.node();return r.local?n.getAttributeNS(r.space,r.local):n.getAttribute(r)}return this.each((e==null?r.local?ll:sl:typeof e=="function"?r.local?ml:fl:r.local?cl:ul)(r,e))}function Ne(t){return t.ownerDocument&&t.ownerDocument.defaultView||t.document&&t||t.defaultView}function pl(t){return function(){this.style.removeProperty(t)}}function dl(t,e,r){return function(){this.style.setProperty(t,e,r)}}function hl(t,e,r){return function(){var n=e.apply(this,arguments);n==null?this.style.removeProperty(t):this.style.setProperty(t,n,r)}}function ao(t,e,r){return arguments.length>1?this.each((e==null?pl:typeof e=="function"?hl:dl)(t,e,r??"")):dt(this.node(),t)}function dt(t,e){return t.style.getPropertyValue(e)||Ne(t).getComputedStyle(t,null).getPropertyValue(e)}function gl(t){return function(){delete this[t]}}function yl(t,e){return function(){this[t]=e}}function xl(t,e){return function(){var r=e.apply(this,arguments);r==null?delete this[t]:this[t]=r}}function so(t,e){return arguments.length>1?this.each((e==null?gl:typeof e=="function"?xl:yl)(t,e)):this.node()[t]}function lo(t){return t.trim().split(/^|\s+/)}function Ar(t){return t.classList||new uo(t)}function uo(t){this._node=t,this._names=lo(t.getAttribute("class")||"")}uo.prototype={add:function(t){var e=this._names.indexOf(t);e<0&&(this._names.push(t),this._node.setAttribute("class",this._names.join(" ")))},remove:function(t){var e=this._names.indexOf(t);e>=0&&(this._names.splice(e,1),this._node.setAttribute("class",this._names.join(" ")))},contains:function(t){return this._names.indexOf(t)>=0}};function co(t,e){for(var r=Ar(t),n=-1,o=e.length;++n<o;)r.add(e[n])}function fo(t,e){for(var r=Ar(t),n=-1,o=e.length;++n<o;)r.remove(e[n])}function bl(t){return function(){co(this,t)}}function vl(t){return function(){fo(this,t)}}function wl(t,e){return function(){(e.apply(this,arguments)?co:fo)(this,t)}}function mo(t,e){var r=lo(t+"");if(arguments.length<2){for(var n=Ar(this.node()),o=-1,i=r.length;++o<i;)if(!n.contains(r[o]))return!1;return!0}return this.each((typeof e=="function"?wl:e?bl:vl)(r,e))}function _l(){this.textContent=""}function Cl(t){return function(){this.textContent=t}}function Sl(t){return function(){var e=t.apply(this,arguments);this.textContent=e??""}}function po(t){return arguments.length?this.each(t==null?_l:(typeof t=="function"?Sl:Cl)(t)):this.node().textContent}function Ml(){this.innerHTML=""}function kl(t){return function(){this.innerHTML=t}}function Dl(t){return function(){var e=t.apply(this,arguments);this.innerHTML=e??""}}function ho(t){return arguments.length?this.each(t==null?Ml:(typeof t=="function"?Dl:kl)(t)):this.node().innerHTML}function Al(){this.nextSibling&&this.parentNode.appendChild(this)}function go(){return this.each(Al)}function Tl(){this.previousSibling&&this.parentNode.insertBefore(this,this.parentNode.firstChild)}function yo(){return this.each(Tl)}function xo(t){var e=typeof t=="function"?t:Fe(t);return this.select(function(){return this.appendChild(e.apply(this,arguments))})}function Fl(){return null}function bo(t,e){var r=typeof t=="function"?t:Fe(t),n=e==null?Fl:typeof e=="function"?e:Ct(e);return this.select(function(){return this.insertBefore(r.apply(this,arguments),n.apply(this,arguments)||null)})}function El(){var t=this.parentNode;t&&t.removeChild(this)}function vo(){return this.each(El)}function Ol(){var t=this.cloneNode(!1),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function Nl(){var t=this.cloneNode(!0),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function wo(t){return this.select(t?Nl:Ol)}function _o(t){return arguments.length?this.property("__data__",t):this.node().__data__}function Yl(t){return function(e){t.call(this,e,this.__data__)}}function Il(t){return t.trim().split(/^|\s+/).map(function(e){var r="",n=e.indexOf(".");return n>=0&&(r=e.slice(n+1),e=e.slice(0,n)),{type:e,name:r}})}function Bl(t){return function(){var e=this.__on;if(e){for(var r=0,n=-1,o=e.length,i;r<o;++r)i=e[r],(!t.type||i.type===t.type)&&i.name===t.name?this.removeEventListener(i.type,i.listener,i.options):e[++n]=i;++n?e.length=n:delete this.__on}}}function Rl(t,e,r){return function(){var n=this.__on,o,i=Yl(e);if(n){for(var a=0,s=n.length;a<s;++a)if((o=n[a]).type===t.type&&o.name===t.name){this.removeEventListener(o.type,o.listener,o.options),this.addEventListener(o.type,o.listener=i,o.options=r),o.value=e;return}}this.addEventListener(t.type,i,r),o={type:t.type,name:t.name,value:e,listener:i,options:r},n?n.push(o):this.__on=[o]}}function Co(t,e,r){var n=Il(t+""),o,i=n.length,a;if(arguments.length<2){var s=this.node().__on;if(s){for(var l=0,u=s.length,f;l<u;++l)for(o=0,f=s[l];o<i;++o)if((a=n[o]).type===f.type&&a.name===f.name)return f.value}return}for(s=e?Rl:Bl,o=0;o<i;++o)this.each(s(n[o],e,r));return this}function So(t,e,r){var n=Ne(t),o=n.CustomEvent;typeof o=="function"?o=new o(e,r):(o=n.document.createEvent("Event"),r?(o.initEvent(e,r.bubbles,r.cancelable),o.detail=r.detail):o.initEvent(e,!1,!1)),t.dispatchEvent(o)}function zl(t,e){return function(){return So(this,t,e)}}function ql(t,e){return function(){return So(this,t,e.apply(this,arguments))}}function Mo(t,e){return this.each((typeof e=="function"?ql:zl)(t,e))}function*ko(){for(var t=this._groups,e=0,r=t.length;e<r;++e)for(var n=t[e],o=0,i=n.length,a;o<i;++o)(a=n[o])&&(yield a)}var re=[null];function O(t,e){this._groups=t,this._parents=e}function Do(){return new O([[document.documentElement]],re)}function Pl(){return this}O.prototype=Do.prototype={constructor:O,select:Pn,selectAll:$n,selectChild:Ln,selectChildren:Un,filter:Hn,data:Xn,enter:Vn,exit:Wn,join:Qn,merge:Zn,selection:Pl,order:Jn,sort:Kn,call:jn,nodes:to,node:eo,size:ro,empty:no,each:oo,attr:io,style:ao,property:so,classed:mo,text:po,html:ho,raise:go,lower:yo,append:xo,insert:bo,remove:vo,clone:wo,datum:_o,on:Co,dispatch:Mo,[Symbol.iterator]:ko};var lt=Do;function ut(t){return typeof t=="string"?new O([[document.querySelector(t)]],[document.documentElement]):new O([[t]],re)}function Tr(t){return typeof t=="string"?new O([document.querySelectorAll(t)],[document.documentElement]):new O([Kt(t)],re)}function Ye(t,e,r){t.prototype=e.prototype=r,r.constructor=t}function Fr(t,e){var r=Object.create(t.prototype);for(var n in e)r[n]=e[n];return r}function ie(){}var ne=.7,Re=1/ne,It="\\s*([+-]?\\d+)\\s*",oe="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*",ot="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*",$l=/^#([0-9a-f]{3,8})$/,Ll=new RegExp(`^rgb\\(${It},${It},${It}\\)$`),Ul=new RegExp(`^rgb\\(${ot},${ot},${ot}\\)$`),Hl=new RegExp(`^rgba\\(${It},${It},${It},${oe}\\)$`),Vl=new RegExp(`^rgba\\(${ot},${ot},${ot},${oe}\\)$`),Gl=new RegExp(`^hsl\\(${oe},${ot},${ot}\\)$`),Xl=new RegExp(`^hsla\\(${oe},${ot},${ot},${oe}\\)$`),Ao={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074};Ye(ie,rt,{copy(t){return Object.assign(new this.constructor,this,t)},displayable(){return this.rgb().displayable()},hex:To,formatHex:To,formatHex8:Wl,formatHsl:Ql,formatRgb:Fo,toString:Fo});function To(){return this.rgb().formatHex()}function Wl(){return this.rgb().formatHex8()}function Ql(){return Bo(this).formatHsl()}function Fo(){return this.rgb().formatRgb()}function rt(t){var e,r;return t=(t+"").trim().toLowerCase(),(e=$l.exec(t))?(r=e[1].length,e=parseInt(e[1],16),r===6?Eo(e):r===3?new W(e>>8&15|e>>4&240,e>>4&15|e&240,(e&15)<<4|e&15,1):r===8?Ie(e>>24&255,e>>16&255,e>>8&255,(e&255)/255):r===4?Ie(e>>12&15|e>>8&240,e>>8&15|e>>4&240,e>>4&15|e&240,((e&15)<<4|e&15)/255):null):(e=Ll.exec(t))?new W(e[1],e[2],e[3],1):(e=Ul.exec(t))?new W(e[1]*255/100,e[2]*255/100,e[3]*255/100,1):(e=Hl.exec(t))?Ie(e[1],e[2],e[3],e[4]):(e=Vl.exec(t))?Ie(e[1]*255/100,e[2]*255/100,e[3]*255/100,e[4]):(e=Gl.exec(t))?Yo(e[1],e[2]/100,e[3]/100,1):(e=Xl.exec(t))?Yo(e[1],e[2]/100,e[3]/100,e[4]):Ao.hasOwnProperty(t)?Eo(Ao[t]):t==="transparent"?new W(NaN,NaN,NaN,0):null}function Eo(t){return new W(t>>16&255,t>>8&255,t&255,1)}function Ie(t,e,r,n){return n<=0&&(t=e=r=NaN),new W(t,e,r,n)}function Zl(t){return t instanceof ie||(t=rt(t)),t?(t=t.rgb(),new W(t.r,t.g,t.b,t.opacity)):new W}function Bt(t,e,r,n){return arguments.length===1?Zl(t):new W(t,e,r,n??1)}function W(t,e,r,n){this.r=+t,this.g=+e,this.b=+r,this.opacity=+n}Ye(W,Bt,Fr(ie,{brighter(t){return t=t==null?Re:Math.pow(Re,t),new W(this.r*t,this.g*t,this.b*t,this.opacity)},darker(t){return t=t==null?ne:Math.pow(ne,t),new W(this.r*t,this.g*t,this.b*t,this.opacity)},rgb(){return this},clamp(){return new W(Mt(this.r),Mt(this.g),Mt(this.b),ze(this.opacity))},displayable(){return-.5<=this.r&&this.r<255.5&&-.5<=this.g&&this.g<255.5&&-.5<=this.b&&this.b<255.5&&0<=this.opacity&&this.opacity<=1},hex:Oo,formatHex:Oo,formatHex8:Jl,formatRgb:No,toString:No}));function Oo(){return`#${St(this.r)}${St(this.g)}${St(this.b)}`}function Jl(){return`#${St(this.r)}${St(this.g)}${St(this.b)}${St((isNaN(this.opacity)?1:this.opacity)*255)}`}function No(){let t=ze(this.opacity);return`${t===1?"rgb(":"rgba("}${Mt(this.r)}, ${Mt(this.g)}, ${Mt(this.b)}${t===1?")":`, ${t})`}`}function ze(t){return isNaN(t)?1:Math.max(0,Math.min(1,t))}function Mt(t){return Math.max(0,Math.min(255,Math.round(t)||0))}function St(t){return t=Mt(t),(t<16?"0":"")+t.toString(16)}function Yo(t,e,r,n){return n<=0?t=e=r=NaN:r<=0||r>=1?t=e=NaN:e<=0&&(t=NaN),new et(t,e,r,n)}function Bo(t){if(t instanceof et)return new et(t.h,t.s,t.l,t.opacity);if(t instanceof ie||(t=rt(t)),!t)return new et;if(t instanceof et)return t;t=t.rgb();var e=t.r/255,r=t.g/255,n=t.b/255,o=Math.min(e,r,n),i=Math.max(e,r,n),a=NaN,s=i-o,l=(i+o)/2;return s?(e===i?a=(r-n)/s+(r<n)*6:r===i?a=(n-e)/s+2:a=(e-r)/s+4,s/=l<.5?i+o:2-i-o,a*=60):s=l>0&&l<1?0:a,new et(a,s,l,t.opacity)}function Ro(t,e,r,n){return arguments.length===1?Bo(t):new et(t,e,r,n??1)}function et(t,e,r,n){this.h=+t,this.s=+e,this.l=+r,this.opacity=+n}Ye(et,Ro,Fr(ie,{brighter(t){return t=t==null?Re:Math.pow(Re,t),new et(this.h,this.s,this.l*t,this.opacity)},darker(t){return t=t==null?ne:Math.pow(ne,t),new et(this.h,this.s,this.l*t,this.opacity)},rgb(){var t=this.h%360+(this.h<0)*360,e=isNaN(t)||isNaN(this.s)?0:this.s,r=this.l,n=r+(r<.5?r:1-r)*e,o=2*r-n;return new W(Er(t>=240?t-240:t+120,o,n),Er(t,o,n),Er(t<120?t+240:t-120,o,n),this.opacity)},clamp(){return new et(Io(this.h),Be(this.s),Be(this.l),ze(this.opacity))},displayable(){return(0<=this.s&&this.s<=1||isNaN(this.s))&&0<=this.l&&this.l<=1&&0<=this.opacity&&this.opacity<=1},formatHsl(){let t=ze(this.opacity);return`${t===1?"hsl(":"hsla("}${Io(this.h)}, ${Be(this.s)*100}%, ${Be(this.l)*100}%${t===1?")":`, ${t})`}`}}));function Io(t){return t=(t||0)%360,t<0?t+360:t}function Be(t){return Math.max(0,Math.min(1,t||0))}function Er(t,e,r){return(t<60?e+(r-e)*t/60:t<180?r:t<240?e+(r-e)*(240-t)/60:e)*255}function Or(t,e,r,n,o){var i=t*t,a=i*t;return((1-3*t+3*i-a)*e+(4-6*i+3*a)*r+(1+3*t+3*i-3*a)*n+a*o)/6}function zo(t){var e=t.length-1;return function(r){var n=r<=0?r=0:r>=1?(r=1,e-1):Math.floor(r*e),o=t[n],i=t[n+1],a=n>0?t[n-1]:2*o-i,s=n<e-1?t[n+2]:2*i-o;return Or((r-n/e)*e,a,o,i,s)}}function qo(t){var e=t.length;return function(r){var n=Math.floor(((r%=1)<0?++r:r)*e),o=t[(n+e-1)%e],i=t[n%e],a=t[(n+1)%e],s=t[(n+2)%e];return Or((r-n/e)*e,o,i,a,s)}}var ae=t=>()=>t;function Kl(t,e){return function(r){return t+r*e}}function jl(t,e,r){return t=Math.pow(t,r),e=Math.pow(e,r)-t,r=1/r,function(n){return Math.pow(t+n*e,r)}}function Po(t){return(t=+t)==1?qe:function(e,r){return r-e?jl(e,r,t):ae(isNaN(e)?r:e)}}function qe(t,e){var r=e-t;return r?Kl(t,r):ae(isNaN(t)?e:t)}var kt=function t(e){var r=Po(e);function n(o,i){var a=r((o=Bt(o)).r,(i=Bt(i)).r),s=r(o.g,i.g),l=r(o.b,i.b),u=qe(o.opacity,i.opacity);return function(f){return o.r=a(f),o.g=s(f),o.b=l(f),o.opacity=u(f),o+""}}return n.gamma=t,n}(1);function $o(t){return function(e){var r=e.length,n=new Array(r),o=new Array(r),i=new Array(r),a,s;for(a=0;a<r;++a)s=Bt(e[a]),n[a]=s.r||0,o[a]=s.g||0,i[a]=s.b||0;return n=t(n),o=t(o),i=t(i),s.opacity=1,function(l){return s.r=n(l),s.g=o(l),s.b=i(l),s+""}}}var tu=$o(zo),eu=$o(qo);function Lo(t,e){e||(e=[]);var r=t?Math.min(e.length,t.length):0,n=e.slice(),o;return function(i){for(o=0;o<r;++o)n[o]=t[o]*(1-i)+e[o]*i;return n}}function Uo(t){return ArrayBuffer.isView(t)&&!(t instanceof DataView)}function Ho(t,e){var r=e?e.length:0,n=t?Math.min(r,t.length):0,o=new Array(n),i=new Array(r),a;for(a=0;a<n;++a)o[a]=Dt(t[a],e[a]);for(;a<r;++a)i[a]=e[a];return function(s){for(a=0;a<n;++a)i[a]=o[a](s);return i}}function Vo(t,e){var r=new Date;return t=+t,e=+e,function(n){return r.setTime(t*(1-n)+e*n),r}}function $(t,e){return t=+t,e=+e,function(r){return t*(1-r)+e*r}}function Go(t,e){var r={},n={},o;(t===null||typeof t!="object")&&(t={}),(e===null||typeof e!="object")&&(e={});for(o in e)o in t?r[o]=Dt(t[o],e[o]):n[o]=e[o];return function(i){for(o in r)n[o]=r[o](i);return n}}var Yr=/[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,Nr=new RegExp(Yr.source,"g");function ru(t){return function(){return t}}function nu(t){return function(e){return t(e)+""}}function se(t,e){var r=Yr.lastIndex=Nr.lastIndex=0,n,o,i,a=-1,s=[],l=[];for(t=t+"",e=e+"";(n=Yr.exec(t))&&(o=Nr.exec(e));)(i=o.index)>r&&(i=e.slice(r,i),s[a]?s[a]+=i:s[++a]=i),(n=n[0])===(o=o[0])?s[a]?s[a]+=o:s[++a]=o:(s[++a]=null,l.push({i:a,x:$(n,o)})),r=Nr.lastIndex;return r<e.length&&(i=e.slice(r),s[a]?s[a]+=i:s[++a]=i),s.length<2?l[0]?nu(l[0].x):ru(e):(e=l.length,function(u){for(var f=0,c;f<e;++f)s[(c=l[f]).i]=c.x(u);return s.join("")})}function Dt(t,e){var r=typeof e,n;return e==null||r==="boolean"?ae(e):(r==="number"?$:r==="string"?(n=rt(e))?(e=n,kt):se:e instanceof rt?kt:e instanceof Date?Vo:Uo(e)?Lo:Array.isArray(e)?Ho:typeof e.valueOf!="function"&&typeof e.toString!="function"||isNaN(e)?Go:$)(t,e)}function Ir(t,e){return t=+t,e=+e,function(r){return Math.round(t*(1-r)+e*r)}}var Xo=180/Math.PI,Pe={translateX:0,translateY:0,rotate:0,skewX:0,scaleX:1,scaleY:1};function Br(t,e,r,n,o,i){var a,s,l;return(a=Math.sqrt(t*t+e*e))&&(t/=a,e/=a),(l=t*r+e*n)&&(r-=t*l,n-=e*l),(s=Math.sqrt(r*r+n*n))&&(r/=s,n/=s,l/=s),t*n<e*r&&(t=-t,e=-e,l=-l,a=-a),{translateX:o,translateY:i,rotate:Math.atan2(e,t)*Xo,skewX:Math.atan(l)*Xo,scaleX:a,scaleY:s}}var $e;function Wo(t){let e=new(typeof DOMMatrix=="function"?DOMMatrix:WebKitCSSMatrix)(t+"");return e.isIdentity?Pe:Br(e.a,e.b,e.c,e.d,e.e,e.f)}function Qo(t){return t==null?Pe:($e||($e=document.createElementNS("http://www.w3.org/2000/svg","g")),$e.setAttribute("transform",t),(t=$e.transform.baseVal.consolidate())?(t=t.matrix,Br(t.a,t.b,t.c,t.d,t.e,t.f)):Pe)}function Zo(t,e,r,n){function o(u){return u.length?u.pop()+" ":""}function i(u,f,c,m,p,h){if(u!==c||f!==m){var g=p.push("translate(",null,e,null,r);h.push({i:g-4,x:$(u,c)},{i:g-2,x:$(f,m)})}else(c||m)&&p.push("translate("+c+e+m+r)}function a(u,f,c,m){u!==f?(u-f>180?f+=360:f-u>180&&(u+=360),m.push({i:c.push(o(c)+"rotate(",null,n)-2,x:$(u,f)})):f&&c.push(o(c)+"rotate("+f+n)}function s(u,f,c,m){u!==f?m.push({i:c.push(o(c)+"skewX(",null,n)-2,x:$(u,f)}):f&&c.push(o(c)+"skewX("+f+n)}function l(u,f,c,m,p,h){if(u!==c||f!==m){var g=p.push(o(p)+"scale(",null,",",null,")");h.push({i:g-4,x:$(u,c)},{i:g-2,x:$(f,m)})}else(c!==1||m!==1)&&p.push(o(p)+"scale("+c+","+m+")")}return function(u,f){var c=[],m=[];return u=t(u),f=t(f),i(u.translateX,u.translateY,f.translateX,f.translateY,c,m),a(u.rotate,f.rotate,c,m),s(u.skewX,f.skewX,c,m),l(u.scaleX,u.scaleY,f.scaleX,f.scaleY,c,m),u=f=null,function(p){for(var h=-1,g=m.length,_;++h<g;)c[(_=m[h]).i]=_.x(p);return c.join("")}}}var Rr=Zo(Wo,"px, ","px)","deg)"),zr=Zo(Qo,", ",")",")");var Rt=0,ue=0,le=0,Ko=1e3,Le,ce,Ue=0,At=0,He=0,fe=typeof performance=="object"&&performance.now?performance:Date,jo=typeof window=="object"&&window.requestAnimationFrame?window.requestAnimationFrame.bind(window):function(t){setTimeout(t,17)};function pe(){return At||(jo(ou),At=fe.now()+He)}function ou(){At=0}function me(){this._call=this._time=this._next=null}me.prototype=Ve.prototype={constructor:me,restart:function(t,e,r){if(typeof t!="function")throw new TypeError("callback is not a function");r=(r==null?pe():+r)+(e==null?0:+e),!this._next&&ce!==this&&(ce?ce._next=this:Le=this,ce=this),this._call=t,this._time=r,qr()},stop:function(){this._call&&(this._call=null,this._time=1/0,qr())}};function Ve(t,e,r){var n=new me;return n.restart(t,e,r),n}function ti(){pe(),++Rt;for(var t=Le,e;t;)(e=At-t._time)>=0&&t._call.call(void 0,e),t=t._next;--Rt}function Jo(){At=(Ue=fe.now())+He,Rt=ue=0;try{ti()}finally{Rt=0,au(),At=0}}function iu(){var t=fe.now(),e=t-Ue;e>Ko&&(He-=e,Ue=t)}function au(){for(var t,e=Le,r,n=1/0;e;)e._call?(n>e._time&&(n=e._time),t=e,e=e._next):(r=e._next,e._next=null,e=t?t._next=r:Le=r);ce=t,qr(n)}function qr(t){if(!Rt){ue&&(ue=clearTimeout(ue));var e=t-At;e>24?(t<1/0&&(ue=setTimeout(Jo,t-fe.now()-He)),le&&(le=clearInterval(le))):(le||(Ue=fe.now(),le=setInterval(iu,Ko)),Rt=1,jo(Jo))}}function Ge(t,e,r){var n=new me;return e=e==null?0:+e,n.restart(o=>{n.stop(),t(o+e)},e,r),n}var su=kr("start","end","cancel","interrupt"),lu=[],ni=0,ei=1,We=2,Xe=3,ri=4,Qe=5,de=6;function ht(t,e,r,n,o,i){var a=t.__transition;if(!a)t.__transition={};else if(r in a)return;uu(t,r,{name:e,index:n,group:o,on:su,tween:lu,time:i.time,delay:i.delay,duration:i.duration,ease:i.ease,timer:null,state:ni})}function he(t,e){var r=B(t,e);if(r.state>ni)throw new Error("too late; already scheduled");return r}function L(t,e){var r=B(t,e);if(r.state>Xe)throw new Error("too late; already running");return r}function B(t,e){var r=t.__transition;if(!r||!(r=r[e]))throw new Error("transition not found");return r}function uu(t,e,r){var n=t.__transition,o;n[e]=r,r.timer=Ve(i,0,r.time);function i(u){r.state=ei,r.timer.restart(a,r.delay,r.time),r.delay<=u&&a(u-r.delay)}function a(u){var f,c,m,p;if(r.state!==ei)return l();for(f in n)if(p=n[f],p.name===r.name){if(p.state===Xe)return Ge(a);p.state===ri?(p.state=de,p.timer.stop(),p.on.call("interrupt",t,t.__data__,p.index,p.group),delete n[f]):+f<e&&(p.state=de,p.timer.stop(),p.on.call("cancel",t,t.__data__,p.index,p.group),delete n[f])}if(Ge(function(){r.state===Xe&&(r.state=ri,r.timer.restart(s,r.delay,r.time),s(u))}),r.state=We,r.on.call("start",t,t.__data__,r.index,r.group),r.state===We){for(r.state=Xe,o=new Array(m=r.tween.length),f=0,c=-1;f<m;++f)(p=r.tween[f].value.call(t,t.__data__,r.index,r.group))&&(o[++c]=p);o.length=c+1}}function s(u){for(var f=u<r.duration?r.ease.call(null,u/r.duration):(r.timer.restart(l),r.state=Qe,1),c=-1,m=o.length;++c<m;)o[c].call(t,f);r.state===Qe&&(r.on.call("end",t,t.__data__,r.index,r.group),l())}function l(){r.state=de,r.timer.stop(),delete n[e];for(var u in n)return;delete t.__transition}}function Ze(t,e){var r=t.__transition,n,o,i=!0,a;if(r){e=e==null?null:e+"";for(a in r){if((n=r[a]).name!==e){i=!1;continue}o=n.state>We&&n.state<Qe,n.state=de,n.timer.stop(),n.on.call(o?"interrupt":"cancel",t,t.__data__,n.index,n.group),delete r[a]}i&&delete t.__transition}}function oi(t){return this.each(function(){Ze(this,t)})}function cu(t,e){var r,n;return function(){var o=L(this,t),i=o.tween;if(i!==r){n=r=i;for(var a=0,s=n.length;a<s;++a)if(n[a].name===e){n=n.slice(),n.splice(a,1);break}}o.tween=n}}function fu(t,e,r){var n,o;if(typeof r!="function")throw new Error;return function(){var i=L(this,t),a=i.tween;if(a!==n){o=(n=a).slice();for(var s={name:e,value:r},l=0,u=o.length;l<u;++l)if(o[l].name===e){o[l]=s;break}l===u&&o.push(s)}i.tween=o}}function ii(t,e){var r=this._id;if(t+="",arguments.length<2){for(var n=B(this.node(),r).tween,o=0,i=n.length,a;o<i;++o)if((a=n[o]).name===t)return a.value;return null}return this.each((e==null?cu:fu)(r,t,e))}function zt(t,e,r){var n=t._id;return t.each(function(){var o=L(this,n);(o.value||(o.value={}))[e]=r.apply(this,arguments)}),function(o){return B(o,n).value[e]}}function Je(t,e){var r;return(typeof e=="number"?$:e instanceof rt?kt:(r=rt(e))?(e=r,kt):se)(t,e)}function mu(t){return function(){this.removeAttribute(t)}}function pu(t){return function(){this.removeAttributeNS(t.space,t.local)}}function du(t,e,r){var n,o=r+"",i;return function(){var a=this.getAttribute(t);return a===o?null:a===n?i:i=e(n=a,r)}}function hu(t,e,r){var n,o=r+"",i;return function(){var a=this.getAttributeNS(t.space,t.local);return a===o?null:a===n?i:i=e(n=a,r)}}function gu(t,e,r){var n,o,i;return function(){var a,s=r(this),l;return s==null?void this.removeAttribute(t):(a=this.getAttribute(t),l=s+"",a===l?null:a===n&&l===o?i:(o=l,i=e(n=a,s)))}}function yu(t,e,r){var n,o,i;return function(){var a,s=r(this),l;return s==null?void this.removeAttributeNS(t.space,t.local):(a=this.getAttributeNS(t.space,t.local),l=s+"",a===l?null:a===n&&l===o?i:(o=l,i=e(n=a,s)))}}function ai(t,e){var r=st(t),n=r==="transform"?zr:Je;return this.attrTween(t,typeof e=="function"?(r.local?yu:gu)(r,n,zt(this,"attr."+t,e)):e==null?(r.local?pu:mu)(r):(r.local?hu:du)(r,n,e))}function xu(t,e){return function(r){this.setAttribute(t,e.call(this,r))}}function bu(t,e){return function(r){this.setAttributeNS(t.space,t.local,e.call(this,r))}}function vu(t,e){var r,n;function o(){var i=e.apply(this,arguments);return i!==n&&(r=(n=i)&&bu(t,i)),r}return o._value=e,o}function wu(t,e){var r,n;function o(){var i=e.apply(this,arguments);return i!==n&&(r=(n=i)&&xu(t,i)),r}return o._value=e,o}function si(t,e){var r="attr."+t;if(arguments.length<2)return(r=this.tween(r))&&r._value;if(e==null)return this.tween(r,null);if(typeof e!="function")throw new Error;var n=st(t);return this.tween(r,(n.local?vu:wu)(n,e))}function _u(t,e){return function(){he(this,t).delay=+e.apply(this,arguments)}}function Cu(t,e){return e=+e,function(){he(this,t).delay=e}}function li(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?_u:Cu)(e,t)):B(this.node(),e).delay}function Su(t,e){return function(){L(this,t).duration=+e.apply(this,arguments)}}function Mu(t,e){return e=+e,function(){L(this,t).duration=e}}function ui(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?Su:Mu)(e,t)):B(this.node(),e).duration}function ku(t,e){if(typeof e!="function")throw new Error;return function(){L(this,t).ease=e}}function ci(t){var e=this._id;return arguments.length?this.each(ku(e,t)):B(this.node(),e).ease}function Du(t,e){return function(){var r=e.apply(this,arguments);if(typeof r!="function")throw new Error;L(this,t).ease=r}}function fi(t){if(typeof t!="function")throw new Error;return this.each(Du(this._id,t))}function mi(t){typeof t!="function"&&(t=te(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,s=n[o]=[],l,u=0;u<a;++u)(l=i[u])&&t.call(l,l.__data__,u,i)&&s.push(l);return new V(n,this._parents,this._name,this._id)}function pi(t){if(t._id!==this._id)throw new Error;for(var e=this._groups,r=t._groups,n=e.length,o=r.length,i=Math.min(n,o),a=new Array(n),s=0;s<i;++s)for(var l=e[s],u=r[s],f=l.length,c=a[s]=new Array(f),m,p=0;p<f;++p)(m=l[p]||u[p])&&(c[p]=m);for(;s<n;++s)a[s]=e[s];return new V(a,this._parents,this._name,this._id)}function Au(t){return(t+"").trim().split(/^|\s+/).every(function(e){var r=e.indexOf(".");return r>=0&&(e=e.slice(0,r)),!e||e==="start"})}function Tu(t,e,r){var n,o,i=Au(e)?he:L;return function(){var a=i(this,t),s=a.on;s!==n&&(o=(n=s).copy()).on(e,r),a.on=o}}function di(t,e){var r=this._id;return arguments.length<2?B(this.node(),r).on.on(t):this.each(Tu(r,t,e))}function Fu(t){return function(){var e=this.parentNode;for(var r in this.__transition)if(+r!==t)return;e&&e.removeChild(this)}}function hi(){return this.on("end.remove",Fu(this._id))}function gi(t){var e=this._name,r=this._id;typeof t!="function"&&(t=Ct(t));for(var n=this._groups,o=n.length,i=new Array(o),a=0;a<o;++a)for(var s=n[a],l=s.length,u=i[a]=new Array(l),f,c,m=0;m<l;++m)(f=s[m])&&(c=t.call(f,f.__data__,m,s))&&("__data__"in f&&(c.__data__=f.__data__),u[m]=c,ht(u[m],e,r,m,u,B(f,r)));return new V(i,this._parents,e,r)}function yi(t){var e=this._name,r=this._id;typeof t!="function"&&(t=jt(t));for(var n=this._groups,o=n.length,i=[],a=[],s=0;s<o;++s)for(var l=n[s],u=l.length,f,c=0;c<u;++c)if(f=l[c]){for(var m=t.call(f,f.__data__,c,l),p,h=B(f,r),g=0,_=m.length;g<_;++g)(p=m[g])&&ht(p,e,r,g,m,h);i.push(m),a.push(f)}return new V(i,a,e,r)}var Eu=lt.prototype.constructor;function xi(){return new Eu(this._groups,this._parents)}function Ou(t,e){var r,n,o;return function(){var i=dt(this,t),a=(this.style.removeProperty(t),dt(this,t));return i===a?null:i===r&&a===n?o:o=e(r=i,n=a)}}function bi(t){return function(){this.style.removeProperty(t)}}function Nu(t,e,r){var n,o=r+"",i;return function(){var a=dt(this,t);return a===o?null:a===n?i:i=e(n=a,r)}}function Yu(t,e,r){var n,o,i;return function(){var a=dt(this,t),s=r(this),l=s+"";return s==null&&(l=s=(this.style.removeProperty(t),dt(this,t))),a===l?null:a===n&&l===o?i:(o=l,i=e(n=a,s))}}function Iu(t,e){var r,n,o,i="style."+e,a="end."+i,s;return function(){var l=L(this,t),u=l.on,f=l.value[i]==null?s||(s=bi(e)):void 0;(u!==r||o!==f)&&(n=(r=u).copy()).on(a,o=f),l.on=n}}function vi(t,e,r){var n=(t+="")=="transform"?Rr:Je;return e==null?this.styleTween(t,Ou(t,n)).on("end.style."+t,bi(t)):typeof e=="function"?this.styleTween(t,Yu(t,n,zt(this,"style."+t,e))).each(Iu(this._id,t)):this.styleTween(t,Nu(t,n,e),r).on("end.style."+t,null)}function Bu(t,e,r){return function(n){this.style.setProperty(t,e.call(this,n),r)}}function Ru(t,e,r){var n,o;function i(){var a=e.apply(this,arguments);return a!==o&&(n=(o=a)&&Bu(t,a,r)),n}return i._value=e,i}function wi(t,e,r){var n="style."+(t+="");if(arguments.length<2)return(n=this.tween(n))&&n._value;if(e==null)return this.tween(n,null);if(typeof e!="function")throw new Error;return this.tween(n,Ru(t,e,r??""))}function zu(t){return function(){this.textContent=t}}function qu(t){return function(){var e=t(this);this.textContent=e??""}}function _i(t){return this.tween("text",typeof t=="function"?qu(zt(this,"text",t)):zu(t==null?"":t+""))}function Pu(t){return function(e){this.textContent=t.call(this,e)}}function $u(t){var e,r;function n(){var o=t.apply(this,arguments);return o!==r&&(e=(r=o)&&Pu(o)),e}return n._value=t,n}function Ci(t){var e="text";if(arguments.length<1)return(e=this.tween(e))&&e._value;if(t==null)return this.tween(e,null);if(typeof t!="function")throw new Error;return this.tween(e,$u(t))}function Si(){for(var t=this._name,e=this._id,r=Ke(),n=this._groups,o=n.length,i=0;i<o;++i)for(var a=n[i],s=a.length,l,u=0;u<s;++u)if(l=a[u]){var f=B(l,e);ht(l,t,r,u,a,{time:f.time+f.delay+f.duration,delay:0,duration:f.duration,ease:f.ease})}return new V(n,this._parents,t,r)}function Mi(){var t,e,r=this,n=r._id,o=r.size();return new Promise(function(i,a){var s={value:a},l={value:function(){--o===0&&i()}};r.each(function(){var u=L(this,n),f=u.on;f!==t&&(e=(t=f).copy(),e._.cancel.push(s),e._.interrupt.push(s),e._.end.push(l)),u.on=e}),o===0&&i()})}var Lu=0;function V(t,e,r,n){this._groups=t,this._parents=e,this._name=r,this._id=n}function ki(t){return lt().transition(t)}function Ke(){return++Lu}var ct=lt.prototype;V.prototype=ki.prototype={constructor:V,select:gi,selectAll:yi,selectChild:ct.selectChild,selectChildren:ct.selectChildren,filter:mi,merge:pi,selection:xi,transition:Si,call:ct.call,nodes:ct.nodes,node:ct.node,size:ct.size,empty:ct.empty,each:ct.each,on:di,attr:ai,attrTween:si,style:vi,styleTween:wi,text:_i,textTween:Ci,remove:hi,tween:ii,delay:li,duration:ui,ease:ci,easeVarying:fi,end:Mi,[Symbol.iterator]:ct[Symbol.iterator]};function je(t){return((t*=2)<=1?t*t*t:(t-=2)*t*t+2)/2}var Uu={time:null,delay:0,duration:250,ease:je};function Hu(t,e){for(var r;!(r=t.__transition)||!(r=r[e]);)if(!(t=t.parentNode))throw new Error(`transition ${e} not found`);return r}function Di(t){var e,r;t instanceof V?(e=t._id,t=t._name):(e=Ke(),(r=Uu).time=pe(),t=t==null?null:t+"");for(var n=this._groups,o=n.length,i=0;i<o;++i)for(var a=n[i],s=a.length,l,u=0;u<s;++u)(l=a[u])&&ht(l,t,e,u,a,r||Hu(l,e));return new V(n,this._parents,t,e)}lt.prototype.interrupt=oi;lt.prototype.transition=Di;var{abs:Uy,max:Hy,min:Vy}=Math;function Ai(t){return[+t[0],+t[1]]}function Vu(t){return[Ai(t[0]),Ai(t[1])]}var Gy={name:"x",handles:["w","e"].map(Pr),input:function(t,e){return t==null?null:[[+t[0],e[0][1]],[+t[1],e[1][1]]]},output:function(t){return t&&[t[0][0],t[1][0]]}},Xy={name:"y",handles:["n","s"].map(Pr),input:function(t,e){return t==null?null:[[e[0][0],+t[0]],[e[1][0],+t[1]]]},output:function(t){return t&&[t[0][1],t[1][1]]}},Wy={name:"xy",handles:["n","w","e","s","nw","ne","sw","se"].map(Pr),input:function(t){return t==null?null:Vu(t)},output:function(t){return t}};function Pr(t){return{type:t}}function Ti(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function Tt(t,e){if((r=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var r,n=t.slice(0,r);return[n.length>1?n[0]+n.slice(2):n,+t.slice(r+1)]}function it(t){return t=Tt(Math.abs(t)),t?t[1]:NaN}function Fi(t,e){return function(r,n){for(var o=r.length,i=[],a=0,s=t[0],l=0;o>0&&s>0&&(l+s+1>n&&(s=Math.max(1,n-l)),i.push(r.substring(o-=s,o+s)),!((l+=s+1)>n));)s=t[a=(a+1)%t.length];return i.reverse().join(e)}}function Ei(t){return function(e){return e.replace(/[0-9]/g,function(r){return t[+r]})}}var Gu=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function gt(t){if(!(e=Gu.exec(t)))throw new Error("invalid format: "+t);var e;return new tr({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}gt.prototype=tr.prototype;function tr(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}tr.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function Oi(t){t:for(var e=t.length,r=1,n=-1,o;r<e;++r)switch(t[r]){case".":n=o=r;break;case"0":n===0&&(n=r),o=r;break;default:if(!+t[r])break t;n>0&&(n=0);break}return n>0?t.slice(0,n)+t.slice(o+1):t}var $r;function Ni(t,e){var r=Tt(t,e);if(!r)return t+"";var n=r[0],o=r[1],i=o-($r=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,a=n.length;return i===a?n:i>a?n+new Array(i-a+1).join("0"):i>0?n.slice(0,i)+"."+n.slice(i):"0."+new Array(1-i).join("0")+Tt(t,Math.max(0,e+i-1))[0]}function Lr(t,e){var r=Tt(t,e);if(!r)return t+"";var n=r[0],o=r[1];return o<0?"0."+new Array(-o).join("0")+n:n.length>o+1?n.slice(0,o+1)+"."+n.slice(o+1):n+new Array(o-n.length+2).join("0")}var Ur={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:Ti,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>Lr(t*100,e),r:Lr,s:Ni,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function Hr(t){return t}var Yi=Array.prototype.map,Ii=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function Bi(t){var e=t.grouping===void 0||t.thousands===void 0?Hr:Fi(Yi.call(t.grouping,Number),t.thousands+""),r=t.currency===void 0?"":t.currency[0]+"",n=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",i=t.numerals===void 0?Hr:Ei(Yi.call(t.numerals,String)),a=t.percent===void 0?"%":t.percent+"",s=t.minus===void 0?"\u2212":t.minus+"",l=t.nan===void 0?"NaN":t.nan+"";function u(c){c=gt(c);var m=c.fill,p=c.align,h=c.sign,g=c.symbol,_=c.zero,v=c.width,C=c.comma,b=c.precision,M=c.trim,x=c.type;x==="n"?(C=!0,x="g"):Ur[x]||(b===void 0&&(b=12),M=!0,x="g"),(_||m==="0"&&p==="=")&&(_=!0,m="0",p="=");var S=g==="$"?r:g==="#"&&/[boxX]/.test(x)?"0"+x.toLowerCase():"",N=g==="$"?n:/[%p]/.test(x)?a:"",R=Ur[x],K=/[defgprs%]/.test(x);b=b===void 0?6:/[gprs]/.test(x)?Math.max(1,Math.min(21,b)):Math.max(0,Math.min(20,b));function U(y){var F=S,k=N,z,G,I;if(x==="c")k=R(y)+k,y="";else{y=+y;var j=y<0||1/y<0;if(y=isNaN(y)?l:R(Math.abs(y),b),M&&(y=Oi(y)),j&&+y==0&&h!=="+"&&(j=!1),F=(j?h==="("?h:s:h==="-"||h==="("?"":h)+F,k=(x==="s"?Ii[8+$r/3]:"")+k+(j&&h==="("?")":""),K){for(z=-1,G=y.length;++z<G;)if(I=y.charCodeAt(z),48>I||I>57){k=(I===46?o+y.slice(z+1):y.slice(z))+k,y=y.slice(0,z);break}}}C&&!_&&(y=e(y,1/0));var tt=F.length+y.length+k.length,Y=tt<v?new Array(v-tt+1).join(m):"";switch(C&&_&&(y=e(Y+y,Y.length?v-k.length:1/0),Y=""),p){case"<":y=F+y+k+Y;break;case"=":y=F+Y+y+k;break;case"^":y=Y.slice(0,tt=Y.length>>1)+F+y+k+Y.slice(tt);break;default:y=Y+F+y+k;break}return i(y)}return U.toString=function(){return c+""},U}function f(c,m){var p=u((c=gt(c),c.type="f",c)),h=Math.max(-8,Math.min(8,Math.floor(it(m)/3)))*3,g=Math.pow(10,-h),_=Ii[8+h/3];return function(v){return p(g*v)+_}}return{format:u,formatPrefix:f}}var er,rr,nr;Vr({thousands:",",grouping:[3],currency:["$",""]});function Vr(t){return er=Bi(t),rr=er.format,nr=er.formatPrefix,er}function Gr(t){return Math.max(0,-it(Math.abs(t)))}function Xr(t,e){return Math.max(0,Math.max(-8,Math.min(8,Math.floor(it(e)/3)))*3-it(Math.abs(t)))}function Wr(t,e){return t=Math.abs(t),e=Math.abs(e)-t,Math.max(0,it(e)-it(t))+1}function qt(t,e){switch(arguments.length){case 0:break;case 1:this.range(t);break;default:this.range(e).domain(t);break}return this}var Qr=Symbol("implicit");function Ft(){var t=new pt,e=[],r=[],n=Qr;function o(i){let a=t.get(i);if(a===void 0){if(n!==Qr)return n;t.set(i,a=e.push(i)-1)}return r[a%r.length]}return o.domain=function(i){if(!arguments.length)return e.slice();e=[],t=new pt;for(let a of i)t.has(a)||t.set(a,e.push(a)-1);return o},o.range=function(i){return arguments.length?(r=Array.from(i),o):r.slice()},o.unknown=function(i){return arguments.length?(n=i,o):n},o.copy=function(){return Ft(e,r).unknown(n)},qt.apply(o,arguments),o}function Pt(){var t=Ft().unknown(void 0),e=t.domain,r=t.range,n=0,o=1,i,a,s=!1,l=0,u=0,f=.5;delete t.unknown;function c(){var m=e().length,p=o<n,h=p?o:n,g=p?n:o;i=(g-h)/Math.max(1,m-l+u*2),s&&(i=Math.floor(i)),h+=(g-h-i*(m-l))*f,a=i*(1-l),s&&(h=Math.round(h),a=Math.round(a));var _=De(m).map(function(v){return h+i*v});return r(p?_.reverse():_)}return t.domain=function(m){return arguments.length?(e(m),c()):e()},t.range=function(m){return arguments.length?([n,o]=m,n=+n,o=+o,c()):[n,o]},t.rangeRound=function(m){return[n,o]=m,n=+n,o=+o,s=!0,c()},t.bandwidth=function(){return a},t.step=function(){return i},t.round=function(m){return arguments.length?(s=!!m,c()):s},t.padding=function(m){return arguments.length?(l=Math.min(1,u=+m),c()):l},t.paddingInner=function(m){return arguments.length?(l=Math.min(1,m),c()):l},t.paddingOuter=function(m){return arguments.length?(u=+m,c()):u},t.align=function(m){return arguments.length?(f=Math.max(0,Math.min(1,m)),c()):f},t.copy=function(){return Pt(e(),[n,o]).round(s).paddingInner(l).paddingOuter(u).align(f)},qt.apply(c(),arguments)}function Zr(t){return function(){return t}}function Jr(t){return+t}var Ri=[0,1];function $t(t){return t}function Kr(t,e){return(e-=t=+t)?function(r){return(r-t)/e}:Zr(isNaN(e)?NaN:.5)}function Xu(t,e){var r;return t>e&&(r=t,t=e,e=r),function(n){return Math.max(t,Math.min(e,n))}}function Wu(t,e,r){var n=t[0],o=t[1],i=e[0],a=e[1];return o<n?(n=Kr(o,n),i=r(a,i)):(n=Kr(n,o),i=r(i,a)),function(s){return i(n(s))}}function Qu(t,e,r){var n=Math.min(t.length,e.length)-1,o=new Array(n),i=new Array(n),a=-1;for(t[n]<t[0]&&(t=t.slice().reverse(),e=e.slice().reverse());++a<n;)o[a]=Kr(t[a],t[a+1]),i[a]=r(e[a],e[a+1]);return function(s){var l=br(t,s,1,n)-1;return i[l](o[l](s))}}function zi(t,e){return e.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown())}function Zu(){var t=Ri,e=Ri,r=Dt,n,o,i,a=$t,s,l,u;function f(){var m=Math.min(t.length,e.length);return a!==$t&&(a=Xu(t[0],t[m-1])),s=m>2?Qu:Wu,l=u=null,c}function c(m){return m==null||isNaN(m=+m)?i:(l||(l=s(t.map(n),e,r)))(n(a(m)))}return c.invert=function(m){return a(o((u||(u=s(e,t.map(n),$)))(m)))},c.domain=function(m){return arguments.length?(t=Array.from(m,Jr),f()):t.slice()},c.range=function(m){return arguments.length?(e=Array.from(m),f()):e.slice()},c.rangeRound=function(m){return e=Array.from(m),r=Ir,f()},c.clamp=function(m){return arguments.length?(a=m?!0:$t,f()):a!==$t},c.interpolate=function(m){return arguments.length?(r=m,f()):r},c.unknown=function(m){return arguments.length?(i=m,c):i},function(m,p){return n=m,o=p,f()}}function jr(){return Zu()($t,$t)}function tn(t,e,r,n){var o=vr(t,e,r),i;switch(n=gt(n??",f"),n.type){case"s":{var a=Math.max(Math.abs(t),Math.abs(e));return n.precision==null&&!isNaN(i=Xr(o,a))&&(n.precision=i),nr(n,a)}case"":case"e":case"g":case"p":case"r":{n.precision==null&&!isNaN(i=Wr(o,Math.max(Math.abs(t),Math.abs(e))))&&(n.precision=i-(n.type==="e"));break}case"f":case"%":{n.precision==null&&!isNaN(i=Gr(o))&&(n.precision=i-(n.type==="%")*2);break}}return rr(n)}function Ju(t){var e=t.domain;return t.ticks=function(r){var n=e();return Me(n[0],n[n.length-1],r??10)},t.tickFormat=function(r,n){var o=e();return tn(o[0],o[o.length-1],r??10,n)},t.nice=function(r){r==null&&(r=10);var n=e(),o=0,i=n.length-1,a=n[o],s=n[i],l,u,f=10;for(s<a&&(u=a,a=s,s=u,u=o,o=i,i=u);f-- >0;){if(u=Zt(a,s,r),u===l)return n[o]=a,n[i]=s,e(n);if(u>0)a=Math.floor(a/u)*u,s=Math.ceil(s/u)*u;else if(u<0)a=Math.ceil(a*u)/u,s=Math.floor(s*u)/u;else break;l=u}return t},t}function ge(){var t=jr();return t.copy=function(){return zi(t,ge())},qt.apply(t,arguments),Ju(t)}function qi(t){for(var e=t.length/6|0,r=new Array(e),n=0;n<e;)r[n]="#"+t.slice(n*6,++n*6);return r}var en=qi("1f77b4ff7f0e2ca02cd627289467bd8c564be377c27f7f7fbcbd2217becf");function yt(t,e,r){this.k=t,this.x=e,this.y=r}yt.prototype={constructor:yt,scale:function(t){return t===1?this:new yt(this.k*t,this.x,this.y)},translate:function(t,e){return t===0&e===0?this:new yt(this.k,this.x+this.k*t,this.y+this.k*e)},apply:function(t){return[t[0]*this.k+this.x,t[1]*this.k+this.y]},applyX:function(t){return t*this.k+this.x},applyY:function(t){return t*this.k+this.y},invert:function(t){return[(t[0]-this.x)/this.k,(t[1]-this.y)/this.k]},invertX:function(t){return(t-this.x)/this.k},invertY:function(t){return(t-this.y)/this.k},rescaleX:function(t){return t.copy().domain(t.range().map(this.invertX,this).map(t.invert,t))},rescaleY:function(t){return t.copy().domain(t.range().map(this.invertY,this).map(t.invert,t))},toString:function(){return"translate("+this.x+","+this.y+") scale("+this.k+")"}};var rn=new yt(1,0,0);nn.prototype=yt.prototype;function nn(t){for(;!t.__zoom;)if(!(t=t.parentNode))return rn;return t.__zoom}var H={selectedBars:new Set};function ju(t){let e={type:"customEvent",data:t};window.parent.postMessage(e,"*")}function Pi(t){let e={type:"setFilter",filters:t};window.parent.postMessage(e,"*")}var tc=({container:t,data:e=[],slots:r=[],slotConfigurations:n=[],options:o={},language:i="en",dimensions:{width:a,height:s}={width:0,height:0}})=>{let l=Li(t);H.categorySlot=r.find(g=>g.name==="category"),H.measureSlot=r.find(g=>g.name==="measure"),H.groupSlot=r.find(g=>g.name==="legend");let u=H.categorySlot?.content?.length>0,f=H.measureSlot?.content?.length>0,c=[];if(!e.length||!u||!f){let g=["Product A","Product B","Product C","Product D","Product E"],_=["Region 1","Region 2","Region 3"],v=[];for(let C=0;C<g.length;C++)for(let b=0;b<_.length;b++){let M=Math.floor(Math.random()*800)+200;v.push({category:g[C],group:_[b],value:M.toString(),rawValue:M,columnId:`column_${C}_${b}`,datasetId:`dataset_${C}_${b}`})}c=v}else c=rc(e,H.measureSlot,H.categorySlot,H.groupSlot);let m={top:40,right:30,bottom:60,left:60},p=a-m.left-m.right,h=s-m.top-m.bottom;$i(l,c,a,s,m,p,h),t.__chartData=c},ec=({container:t,slots:e=[],slotConfigurations:r=[],options:n={},language:o="en",dimensions:{width:i,height:a}={width:0,height:0}})=>{let s=t.__chartData||[],l=Li(t),u={top:40,right:30,bottom:60,left:60},f=i-u.left-u.right,c=a-u.top-u.bottom;$i(l,s,i,a,u,f,c),t.__chartData=s};function $i(t,e,r,n,o,i,a){let s=ut(t).append("svg").attr("width",r).attr("height",n),l=s.append("g").attr("transform",`translate(${o.left},${o.top})`),u=Ce(e,b=>b.category),f=Array.from(u.keys()),c=Array.from(new Set(e.map(b=>b.group))),m=Ft().domain(c).range(en),p=Pt().domain(f).range([0,i]).padding(.2),h=Pt().domain(c).range([0,p.bandwidth()]).padding(.05),g=ke(e,b=>b.rawValue)||0,_=ge().domain([0,g*1.1]).range([a,0]);l.append("g").attr("class","axis x-axis").attr("transform",`translate(0,${a})`).call(Sr(p)).selectAll("text").attr("transform","rotate(-45)").style("text-anchor","end").attr("dx","-.8em").attr("dy",".15em"),l.append("g").attr("class","axis y-axis").call(Mr(_));let v=ut(t).append("div").attr("class","tooltip").style("opacity",0);f.forEach(b=>{let M=e.filter(x=>x.category===b);c.forEach(x=>{let S=M.filter(N=>N.group===x);S.length&&l.append("rect").attr("class","bar").attr("x",p(b)+h(x)).attr("y",_(S[0].rawValue)).attr("width",h.bandwidth()).attr("height",a-_(S[0].rawValue)).attr("fill",m(x)).on("mouseover",function(N){ut(this).transition().duration(200).attr("opacity",.8),v.transition().duration(200).style("opacity",.9),v.html(`${b}<br>${x}<br>Value: ${S[0].value}`).style("left",N.offsetX+10+"px").style("top",N.offsetY-28+"px")}).on("mouseout",function(){ut(this).transition().duration(200).attr("opacity",1),v.transition().duration(500).style("opacity",0)}).on("click",function(N){let R=`${b}-${x}`;H.selectedBars.has(R)?(H.selectedBars.delete(R),ut(this).classed("bar-selected",!1)):(H.selectedBars.add(R),ut(this).classed("bar-selected",!0)),ut(t).select(".clear-filter-btn").classed("visible",H.selectedBars.size>0);let U=[],y=new Map;Array.from(H.selectedBars).forEach(F=>{let[k,z]=F.split("-"),G=H.categorySlot?.content[0],I=`${G?.columnId||G?.column}:${G?.datasetId||G?.set}`;y.has(I)||y.set(I,new Set),y.get(I)?.add(k)}),y.forEach((F,k)=>{let[z,G]=k.split(":"),I=Array.from(F);U.push({expression:I.length>1?"? in ?":"? = ?",parameters:[{column_id:z,dataset_id:G,level:H.categorySlot?.content[0]?.level||void 0},I.length>1?I:I[0]],properties:{origin:"filterFromVizItem",type:"where"}})}),Pi(U),ju({category:b,group:x,value:S[0].value,rawValue:S[0].rawValue})})})});let C=s.append("g").attr("class","legend").attr("transform",`translate(${o.left}, ${n-25})`);c.forEach((b,M)=>{let x=C.append("g").attr("class","legend-item").attr("transform",`translate(${M*100}, 0)`);x.append("rect").attr("class","legend-color").attr("x",0).attr("y",0).attr("width",12).attr("height",12).attr("fill",m(b)),x.append("text").attr("x",18).attr("y",10).text(b).style("font-size","12px")})}function Li(t){t.innerHTML="";let e=document.createElement("div");e.className="bar-chart-container",t.appendChild(e);let r=document.createElement("button");return r.className="clear-filter-btn",r.textContent="Clear Filters",r.onclick=()=>{H.selectedBars.clear(),Tr(".bar").classed("bar-selected",!1),r.classList.remove("visible"),Pi([])},e.appendChild(r),e}function rc(t,e,r,n){let o={category:r?.content[0]?Qt(r.content[0],{level:r.content[0].level||9}):s=>String(s),group:n?.content[0]?Qt(n.content[0],{level:n.content[0].level||9}):s=>String(s),measure:e?.content[0]?Qt(e.content[0]):s=>String(s)},i=n?.content?.length>0,a={category:0,group:i?1:-1,measure:i?2:1};return(t??[]).map(s=>{let l=s[a.category]?.name?.en||s[a.category]||"Unknown",u=o.category(r.content[0].type==="datetime"?new Date(l):l),f=s[a.group]?.name?.en||s[a.group]||"Default",c=i?o.group(n.content[0].type==="datetime"?new Date(f):f):"Default",m=Number(s[a.measure])||0,p=o.measure(m);return{category:String(u),group:String(c),value:p,rawValue:m,columnId:s[a.measure]?.columnId,datasetId:s[a.measure]?.datasetId}})}export{tc as render,ec as resize};
/*! Bundled license information:

@luzmo/analytics-components-kit/components/decompose-numeric-format-BuZcjH2k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/localize-BX7q0S0M.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/formatter-CQDms6fU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/area-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bar-chart-slots.config-MQAjNXqV.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/box-plot-slots.config-BRhnF2FE.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bubble-chart-slots.config-Bbh94VgZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bullet-chart-slots.config-BlWTleBt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/choropleth-map-slots.config-B-uJTj4q.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circle-pack-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circular-gauge-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/column-chart-slots.config-DAdAk17k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/combination-chart-slots.config-CqKLFKCZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/conditional-number-slots.config-L3t5pb1-.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/date-filter-slots.config-CxB8IF5B.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/donut-chart-slots.config-BEwhfq27.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/dropdown-filter-slots.config-B8J6ftCh.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/evolution-number-slots.config-CW21b2ua.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/funnel-chart-slots.config-BBhMS2qi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-table-slots.config-DJkP72oT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/hexbin-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/image-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/line-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/marker-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/ohlc-chart-slots.config-Cvy5n1xv.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/parallel-coordinates-plot-slots.config-CQW2CJW6.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pivot-table-slots.config-BH5fOJre.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pyramid-chart-slots.config-Cm9bQsXT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/radar-chart-slots.config-Dpmytmc3.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/regular-table-slots.config-EUS-V9lL.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/route-map-slots.config-DYCcaQZi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sankey-diagram-slots.config-BSTBEZDe.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/scatter-plot-slots.config-BuWYqDWK.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/search-filter-slots.config-DmiVXOva.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slicer-filter-slots.config-CHQ0ZXga.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slider-filter-slots.config-BN3K1rnl.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/speedometer-chart-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/spike-map-slots.config-CuqpgkvN.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/strip-plot-slots.config-Co8ghEv8.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sunburst-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/symbol-map-slots.config-C5CKaVED.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/text-slots.config-Hy5yNIAX.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/treemap-chart-slots.config-xLD22K9V.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/venn-diagram-slots.config-DPmj71cR.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/video-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/wordcloud-chart-slots.config-BS4sOOHt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/index-BEAYzHcY.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/utils.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)
*/
