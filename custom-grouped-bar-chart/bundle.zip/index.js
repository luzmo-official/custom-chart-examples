function hr(t){let e=/(?:([^{])?([<>=^]))?([+\- \()])?([$#])?(0)?(\d+)?([,_])?(\.-?\d+)?([a-z%]{1,2})?/i.exec(t)??[];return{fill:e[1]||" ",align:e[2]||">",sign:e[3]||"-",symbol:e[4]||"",zfill:e[5],width:+e[6],comma:e[7],precision:e[8],typeFormat:e[9]}}function it(t){return t==null}function gr(t){return typeof t=="string"||t instanceof String}function jt(t){return!Number.isNaN(t)&&Number.isFinite(t)}function ea(t){return typeof t=="boolean"}function ra(t){return t!==null&&typeof t=="object"&&!Array.isArray(t)}function na(t){return t!==null&&typeof t=="object"&&Object.keys(t).length===0}function yr(t,e,r){if(gr(t)||jt(t)||ea(t))return t.toString();if(it(t)||!ra(t)||na(t))return"";let n="",o=Object.keys(t);return r!=null&&r.allowEmpty?(e&&t[e]!==void 0&&(n=t[e]),n===void 0&&(n="")):(e&&t[e]&&(n=t[e]),(it(n)||n==="")&&o!=null&&o.length&&(n=t[o[0]])),n}function oa(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function De(t,e){if((r=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var r,n=t.slice(0,r);return[n.length>1?n[0]+n.slice(2):n,+t.slice(r+1)]}function ia(t){return t=De(Math.abs(t)),t?t[1]:NaN}function aa(t,e){return function(r,n){for(var o=r.length,i=[],a=0,l=t[0],s=0;o>0&&l>0&&(s+l+1>n&&(l=Math.max(1,n-s)),i.push(r.substring(o-=l,o+l)),!((s+=l+1)>n));)l=t[a=(a+1)%t.length];return i.reverse().join(e)}}function la(t){return function(e){return e.replace(/[0-9]/g,function(r){return t[+r]})}}var sa=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function _r(t){if(!(e=sa.exec(t)))throw new Error("invalid format: "+t);var e;return new Mr({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}_r.prototype=Mr.prototype;function Mr(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}Mr.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function ua(t){t:for(var e=t.length,r=1,n=-1,o;r<e;++r)switch(t[r]){case".":n=o=r;break;case"0":n===0&&(n=r),o=r;break;default:if(!+t[r])break t;n>0&&(n=0);break}return n>0?t.slice(0,n)+t.slice(o+1):t}var Nn;function ca(t,e){var r=De(t,e);if(!r)return t+"";var n=r[0],o=r[1],i=o-(Nn=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,a=n.length;return i===a?n:i>a?n+new Array(i-a+1).join("0"):i>0?n.slice(0,i)+"."+n.slice(i):"0."+new Array(1-i).join("0")+De(t,Math.max(0,e+i-1))[0]}function yn(t,e){var r=De(t,e);if(!r)return t+"";var n=r[0],o=r[1];return o<0?"0."+new Array(-o).join("0")+n:n.length>o+1?n.slice(0,o+1)+"."+n.slice(o+1):n+new Array(o-n.length+2).join("0")}var xn={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:oa,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>yn(t*100,e),r:yn,s:ca,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function bn(t){return t}var vn=Array.prototype.map,wn=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function fa(t){var e=t.grouping===void 0||t.thousands===void 0?bn:aa(vn.call(t.grouping,Number),t.thousands+""),r=t.currency===void 0?"":t.currency[0]+"",n=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",i=t.numerals===void 0?bn:la(vn.call(t.numerals,String)),a=t.percent===void 0?"%":t.percent+"",l=t.minus===void 0?"\u2212":t.minus+"",s=t.nan===void 0?"NaN":t.nan+"";function u(c){c=_r(c);var p=c.fill,m=c.align,h=c.sign,g=c.symbol,w=c.zero,y=c.width,S=c.comma,_=c.precision,C=c.trim,b=c.type;b==="n"?(S=!0,b="g"):xn[b]||(_===void 0&&(_=12),C=!0,b="g"),(w||p==="0"&&m==="=")&&(w=!0,p="0",m="=");var M=g==="$"?r:g==="#"&&/[boxX]/.test(b)?"0"+b.toLowerCase():"",E=g==="$"?n:/[%p]/.test(b)?a:"",B=xn[b],q=/[defgprs%]/.test(b);_=_===void 0?6:/[gprs]/.test(b)?Math.max(1,Math.min(21,_)):Math.max(0,Math.min(20,_));function Q(x){var A=M,T=E,O,U,$;if(b==="c")T=B(x)+T,x="";else{x=+x;var z=x<0||1/x<0;if(x=isNaN(x)?s:B(Math.abs(x),_),C&&(x=ua(x)),z&&+x==0&&h!=="+"&&(z=!1),A=(z?h==="("?h:l:h==="-"||h==="("?"":h)+A,T=(b==="s"?wn[8+Nn/3]:"")+T+(z&&h==="("?")":""),q){for(O=-1,U=x.length;++O<U;)if($=x.charCodeAt(O),48>$||$>57){T=($===46?o+x.slice(O+1):x.slice(O))+T,x=x.slice(0,O);break}}}S&&!w&&(x=e(x,1/0));var Z=A.length+x.length+T.length,I=Z<y?new Array(y-Z+1).join(p):"";switch(S&&w&&(x=e(I+x,I.length?y-T.length:1/0),I=""),m){case"<":x=A+x+T+I;break;case"=":x=A+I+x+T;break;case"^":x=I.slice(0,Z=I.length>>1)+A+x+T+I.slice(Z);break;default:x=I+A+x+T;break}return i(x)}return Q.toString=function(){return c+""},Q}function f(c,p){var m=u((c=_r(c),c.type="f",c)),h=Math.max(-8,Math.min(8,Math.floor(ia(p)/3)))*3,g=Math.pow(10,-h),w=wn[8+h/3];return function(y){return m(g*y)+w}}return{format:u,formatPrefix:f}}var xr=new Date,br=new Date;function G(t,e,r,n){function o(i){return t(i=arguments.length===0?new Date:new Date(+i)),i}return o.floor=i=>(t(i=new Date(+i)),i),o.ceil=i=>(t(i=new Date(i-1)),e(i,1),t(i),i),o.round=i=>{let a=o(i),l=o.ceil(i);return i-a<l-i?a:l},o.offset=(i,a)=>(e(i=new Date(+i),a==null?1:Math.floor(a)),i),o.range=(i,a,l)=>{let s=[];if(i=o.ceil(i),l=l==null?1:Math.floor(l),!(i<a)||!(l>0))return s;let u;do s.push(u=new Date(+i)),e(i,l),t(i);while(u<i&&i<a);return s},o.filter=i=>G(a=>{if(a>=a)for(;t(a),!i(a);)a.setTime(a-1)},(a,l)=>{if(a>=a)if(l<0)for(;++l<=0;)for(;e(a,-1),!i(a););else for(;--l>=0;)for(;e(a,1),!i(a););}),r&&(o.count=(i,a)=>(xr.setTime(+i),br.setTime(+a),t(xr),t(br),Math.floor(r(xr,br))),o.every=i=>(i=Math.floor(i),!isFinite(i)||!(i>0)?null:i>1?o.filter(n?a=>n(a)%i===0:a=>o.count(0,a)%i===0):o)),o}var ne=1e3,yt=ne*60,oe=yt*60,ie=oe*24,On=ie*7,In=G(t=>{t.setTime(t-t.getMilliseconds())},(t,e)=>{t.setTime(+t+e*ne)},(t,e)=>(e-t)/ne,t=>t.getUTCSeconds());In.range;var Yn=G(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*ne)},(t,e)=>{t.setTime(+t+e*yt)},(t,e)=>(e-t)/yt,t=>t.getMinutes());Yn.range;var ma=G(t=>{t.setUTCSeconds(0,0)},(t,e)=>{t.setTime(+t+e*yt)},(t,e)=>(e-t)/yt,t=>t.getUTCMinutes());ma.range;var Bn=G(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*ne-t.getMinutes()*yt)},(t,e)=>{t.setTime(+t+e*oe)},(t,e)=>(e-t)/oe,t=>t.getHours());Bn.range;var pa=G(t=>{t.setUTCMinutes(0,0,0)},(t,e)=>{t.setTime(+t+e*oe)},(t,e)=>(e-t)/oe,t=>t.getUTCHours());pa.range;var Ee=G(t=>t.setHours(0,0,0,0),(t,e)=>t.setDate(t.getDate()+e),(t,e)=>(e-t-(e.getTimezoneOffset()-t.getTimezoneOffset())*yt)/ie,t=>t.getDate()-1);Ee.range;var kr=G(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/ie,t=>t.getUTCDate()-1);kr.range;var da=G(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/ie,t=>Math.floor(t/ie));da.range;function Dt(t){return G(e=>{e.setDate(e.getDate()-(e.getDay()+7-t)%7),e.setHours(0,0,0,0)},(e,r)=>{e.setDate(e.getDate()+r*7)},(e,r)=>(r-e-(r.getTimezoneOffset()-e.getTimezoneOffset())*yt)/On)}var Ar=Dt(0),Te=Dt(1),ha=Dt(2),ga=Dt(3),$t=Dt(4),ya=Dt(5),xa=Dt(6);Ar.range;Te.range;ha.range;ga.range;$t.range;ya.range;xa.range;function Tt(t){return G(e=>{e.setUTCDate(e.getUTCDate()-(e.getUTCDay()+7-t)%7),e.setUTCHours(0,0,0,0)},(e,r)=>{e.setUTCDate(e.getUTCDate()+r*7)},(e,r)=>(r-e)/On)}var Rn=Tt(0),Fe=Tt(1),ba=Tt(2),va=Tt(3),Pt=Tt(4),wa=Tt(5),_a=Tt(6);Rn.range;Fe.range;ba.range;va.range;Pt.range;wa.range;_a.range;var zn=G(t=>{t.setDate(1),t.setHours(0,0,0,0)},(t,e)=>{t.setMonth(t.getMonth()+e)},(t,e)=>e.getMonth()-t.getMonth()+(e.getFullYear()-t.getFullYear())*12,t=>t.getMonth());zn.range;var Ca=G(t=>{t.setUTCDate(1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCMonth(t.getUTCMonth()+e)},(t,e)=>e.getUTCMonth()-t.getUTCMonth()+(e.getUTCFullYear()-t.getUTCFullYear())*12,t=>t.getUTCMonth());Ca.range;var xt=G(t=>{t.setMonth(0,1),t.setHours(0,0,0,0)},(t,e)=>{t.setFullYear(t.getFullYear()+e)},(t,e)=>e.getFullYear()-t.getFullYear(),t=>t.getFullYear());xt.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:G(e=>{e.setFullYear(Math.floor(e.getFullYear()/t)*t),e.setMonth(0,1),e.setHours(0,0,0,0)},(e,r)=>{e.setFullYear(e.getFullYear()+r*t)});xt.range;var At=G(t=>{t.setUTCMonth(0,1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCFullYear(t.getUTCFullYear()+e)},(t,e)=>e.getUTCFullYear()-t.getUTCFullYear(),t=>t.getUTCFullYear());At.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:G(e=>{e.setUTCFullYear(Math.floor(e.getUTCFullYear()/t)*t),e.setUTCMonth(0,1),e.setUTCHours(0,0,0,0)},(e,r)=>{e.setUTCFullYear(e.getUTCFullYear()+r*t)});At.range;function vr(t){if(0<=t.y&&t.y<100){var e=new Date(-1,t.m,t.d,t.H,t.M,t.S,t.L);return e.setFullYear(t.y),e}return new Date(t.y,t.m,t.d,t.H,t.M,t.S,t.L)}function wr(t){if(0<=t.y&&t.y<100){var e=new Date(Date.UTC(-1,t.m,t.d,t.H,t.M,t.S,t.L));return e.setUTCFullYear(t.y),e}return new Date(Date.UTC(t.y,t.m,t.d,t.H,t.M,t.S,t.L))}function te(t,e,r){return{y:t,m:e,d:r,H:0,M:0,S:0,L:0}}function Cr(t){var e=t.dateTime,r=t.date,n=t.time,o=t.periods,i=t.days,a=t.shortDays,l=t.months,s=t.shortMonths,u=ee(o),f=re(o),c=ee(i),p=re(i),m=ee(a),h=re(a),g=ee(l),w=re(l),y=ee(s),S=re(s),_={a:z,A:Z,b:I,B:Zt,c:null,d:An,e:An,f:Ga,g:rl,G:ol,H:Ha,I:Va,j:Ua,L:qn,m:Xa,M:Wa,p:Jt,q:J,Q:Fn,s:En,S:Qa,u:Za,U:Ja,V:Ka,w:ja,W:tl,x:null,X:null,y:el,Y:nl,Z:il,"%":Tn},C={a:nt,A:ct,b:Kt,B:Ae,c:null,d:Dn,e:Dn,f:ul,g:bl,G:wl,H:al,I:ll,j:sl,L:Pn,m:cl,M:fl,p:St,q:Mt,Q:Fn,s:En,S:ml,u:pl,U:dl,V:hl,w:gl,W:yl,x:null,X:null,y:xl,Y:vl,Z:_l,"%":Tn},b={a:Q,A:x,b:A,B:T,c:O,d:Mn,e:Mn,f:qa,g:Sn,G:Cn,H:kn,I:kn,j:Ya,L:za,m:Ia,M:Ba,p:q,q:Oa,Q:Pa,s:La,S:Ra,u:Da,U:Ta,V:Fa,w:Aa,W:Ea,x:U,X:$,y:Sn,Y:Cn,Z:Na,"%":$a};_.x=M(r,_),_.X=M(n,_),_.c=M(e,_),C.x=M(r,C),C.X=M(n,C),C.c=M(e,C);function M(v,k){return function(D){var d=[],P=-1,N=0,tt=v.length,et,kt,gn;for(D instanceof Date||(D=new Date(+D));++P<tt;)v.charCodeAt(P)===37&&(d.push(v.slice(N,P)),(kt=_n[et=v.charAt(++P)])!=null?et=v.charAt(++P):kt=et==="e"?" ":"0",(gn=k[et])&&(et=gn(D,kt)),d.push(et),N=P+1);return d.push(v.slice(N,P)),d.join("")}}function E(v,k){return function(D){var d=te(1900,void 0,1),P=B(d,v,D+="",0),N,tt;if(P!=D.length)return null;if("Q"in d)return new Date(d.Q);if("s"in d)return new Date(d.s*1e3+("L"in d?d.L:0));if(k&&!("Z"in d)&&(d.Z=0),"p"in d&&(d.H=d.H%12+d.p*12),d.m===void 0&&(d.m="q"in d?d.q:0),"V"in d){if(d.V<1||d.V>53)return null;"w"in d||(d.w=1),"Z"in d?(N=wr(te(d.y,0,1)),tt=N.getUTCDay(),N=tt>4||tt===0?Fe.ceil(N):Fe(N),N=kr.offset(N,(d.V-1)*7),d.y=N.getUTCFullYear(),d.m=N.getUTCMonth(),d.d=N.getUTCDate()+(d.w+6)%7):(N=vr(te(d.y,0,1)),tt=N.getDay(),N=tt>4||tt===0?Te.ceil(N):Te(N),N=Ee.offset(N,(d.V-1)*7),d.y=N.getFullYear(),d.m=N.getMonth(),d.d=N.getDate()+(d.w+6)%7)}else("W"in d||"U"in d)&&("w"in d||(d.w="u"in d?d.u%7:"W"in d?1:0),tt="Z"in d?wr(te(d.y,0,1)).getUTCDay():vr(te(d.y,0,1)).getDay(),d.m=0,d.d="W"in d?(d.w+6)%7+d.W*7-(tt+5)%7:d.w+d.U*7-(tt+6)%7);return"Z"in d?(d.H+=d.Z/100|0,d.M+=d.Z%100,wr(d)):vr(d)}}function B(v,k,D,d){for(var P=0,N=k.length,tt=D.length,et,kt;P<N;){if(d>=tt)return-1;if(et=k.charCodeAt(P++),et===37){if(et=k.charAt(P++),kt=b[et in _n?k.charAt(P++):et],!kt||(d=kt(v,D,d))<0)return-1}else if(et!=D.charCodeAt(d++))return-1}return d}function q(v,k,D){var d=u.exec(k.slice(D));return d?(v.p=f.get(d[0].toLowerCase()),D+d[0].length):-1}function Q(v,k,D){var d=m.exec(k.slice(D));return d?(v.w=h.get(d[0].toLowerCase()),D+d[0].length):-1}function x(v,k,D){var d=c.exec(k.slice(D));return d?(v.w=p.get(d[0].toLowerCase()),D+d[0].length):-1}function A(v,k,D){var d=y.exec(k.slice(D));return d?(v.m=S.get(d[0].toLowerCase()),D+d[0].length):-1}function T(v,k,D){var d=g.exec(k.slice(D));return d?(v.m=w.get(d[0].toLowerCase()),D+d[0].length):-1}function O(v,k,D){return B(v,e,k,D)}function U(v,k,D){return B(v,r,k,D)}function $(v,k,D){return B(v,n,k,D)}function z(v){return a[v.getDay()]}function Z(v){return i[v.getDay()]}function I(v){return s[v.getMonth()]}function Zt(v){return l[v.getMonth()]}function Jt(v){return o[+(v.getHours()>=12)]}function J(v){return 1+~~(v.getMonth()/3)}function nt(v){return a[v.getUTCDay()]}function ct(v){return i[v.getUTCDay()]}function Kt(v){return s[v.getUTCMonth()]}function Ae(v){return l[v.getUTCMonth()]}function St(v){return o[+(v.getUTCHours()>=12)]}function Mt(v){return 1+~~(v.getUTCMonth()/3)}return{format:function(v){var k=M(v+="",_);return k.toString=function(){return v},k},parse:function(v){var k=E(v+="",!1);return k.toString=function(){return v},k},utcFormat:function(v){var k=M(v+="",C);return k.toString=function(){return v},k},utcParse:function(v){var k=E(v+="",!0);return k.toString=function(){return v},k}}}var _n={"-":"",_:" ",0:"0"},V=/^\s*\d+/,Sa=/^%/,Ma=/[\\^$*+?|[\]().{}]/g;function F(t,e,r){var n=t<0?"-":"",o=(n?-t:t)+"",i=o.length;return n+(i<r?new Array(r-i+1).join(e)+o:o)}function ka(t){return t.replace(Ma,"\\$&")}function ee(t){return new RegExp("^(?:"+t.map(ka).join("|")+")","i")}function re(t){return new Map(t.map((e,r)=>[e.toLowerCase(),r]))}function Aa(t,e,r){var n=V.exec(e.slice(r,r+1));return n?(t.w=+n[0],r+n[0].length):-1}function Da(t,e,r){var n=V.exec(e.slice(r,r+1));return n?(t.u=+n[0],r+n[0].length):-1}function Ta(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.U=+n[0],r+n[0].length):-1}function Fa(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.V=+n[0],r+n[0].length):-1}function Ea(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.W=+n[0],r+n[0].length):-1}function Cn(t,e,r){var n=V.exec(e.slice(r,r+4));return n?(t.y=+n[0],r+n[0].length):-1}function Sn(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.y=+n[0]+(+n[0]>68?1900:2e3),r+n[0].length):-1}function Na(t,e,r){var n=/^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(r,r+6));return n?(t.Z=n[1]?0:-(n[2]+(n[3]||"00")),r+n[0].length):-1}function Oa(t,e,r){var n=V.exec(e.slice(r,r+1));return n?(t.q=n[0]*3-3,r+n[0].length):-1}function Ia(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.m=n[0]-1,r+n[0].length):-1}function Mn(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.d=+n[0],r+n[0].length):-1}function Ya(t,e,r){var n=V.exec(e.slice(r,r+3));return n?(t.m=0,t.d=+n[0],r+n[0].length):-1}function kn(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.H=+n[0],r+n[0].length):-1}function Ba(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.M=+n[0],r+n[0].length):-1}function Ra(t,e,r){var n=V.exec(e.slice(r,r+2));return n?(t.S=+n[0],r+n[0].length):-1}function za(t,e,r){var n=V.exec(e.slice(r,r+3));return n?(t.L=+n[0],r+n[0].length):-1}function qa(t,e,r){var n=V.exec(e.slice(r,r+6));return n?(t.L=Math.floor(n[0]/1e3),r+n[0].length):-1}function $a(t,e,r){var n=Sa.exec(e.slice(r,r+1));return n?r+n[0].length:-1}function Pa(t,e,r){var n=V.exec(e.slice(r));return n?(t.Q=+n[0],r+n[0].length):-1}function La(t,e,r){var n=V.exec(e.slice(r));return n?(t.s=+n[0],r+n[0].length):-1}function An(t,e){return F(t.getDate(),e,2)}function Ha(t,e){return F(t.getHours(),e,2)}function Va(t,e){return F(t.getHours()%12||12,e,2)}function Ua(t,e){return F(1+Ee.count(xt(t),t),e,3)}function qn(t,e){return F(t.getMilliseconds(),e,3)}function Ga(t,e){return qn(t,e)+"000"}function Xa(t,e){return F(t.getMonth()+1,e,2)}function Wa(t,e){return F(t.getMinutes(),e,2)}function Qa(t,e){return F(t.getSeconds(),e,2)}function Za(t){var e=t.getDay();return e===0?7:e}function Ja(t,e){return F(Ar.count(xt(t)-1,t),e,2)}function $n(t){var e=t.getDay();return e>=4||e===0?$t(t):$t.ceil(t)}function Ka(t,e){return t=$n(t),F($t.count(xt(t),t)+(xt(t).getDay()===4),e,2)}function ja(t){return t.getDay()}function tl(t,e){return F(Te.count(xt(t)-1,t),e,2)}function el(t,e){return F(t.getFullYear()%100,e,2)}function rl(t,e){return t=$n(t),F(t.getFullYear()%100,e,2)}function nl(t,e){return F(t.getFullYear()%1e4,e,4)}function ol(t,e){var r=t.getDay();return t=r>=4||r===0?$t(t):$t.ceil(t),F(t.getFullYear()%1e4,e,4)}function il(t){var e=t.getTimezoneOffset();return(e>0?"-":(e*=-1,"+"))+F(e/60|0,"0",2)+F(e%60,"0",2)}function Dn(t,e){return F(t.getUTCDate(),e,2)}function al(t,e){return F(t.getUTCHours(),e,2)}function ll(t,e){return F(t.getUTCHours()%12||12,e,2)}function sl(t,e){return F(1+kr.count(At(t),t),e,3)}function Pn(t,e){return F(t.getUTCMilliseconds(),e,3)}function ul(t,e){return Pn(t,e)+"000"}function cl(t,e){return F(t.getUTCMonth()+1,e,2)}function fl(t,e){return F(t.getUTCMinutes(),e,2)}function ml(t,e){return F(t.getUTCSeconds(),e,2)}function pl(t){var e=t.getUTCDay();return e===0?7:e}function dl(t,e){return F(Rn.count(At(t)-1,t),e,2)}function Ln(t){var e=t.getUTCDay();return e>=4||e===0?Pt(t):Pt.ceil(t)}function hl(t,e){return t=Ln(t),F(Pt.count(At(t),t)+(At(t).getUTCDay()===4),e,2)}function gl(t){return t.getUTCDay()}function yl(t,e){return F(Fe.count(At(t)-1,t),e,2)}function xl(t,e){return F(t.getUTCFullYear()%100,e,2)}function bl(t,e){return t=Ln(t),F(t.getUTCFullYear()%100,e,2)}function vl(t,e){return F(t.getUTCFullYear()%1e4,e,4)}function wl(t,e){var r=t.getUTCDay();return t=r>=4||r===0?Pt(t):Pt.ceil(t),F(t.getUTCFullYear()%1e4,e,4)}function _l(){return"+0000"}function Tn(){return"%"}function Fn(t){return+t}function En(t){return Math.floor(+t/1e3)}var qt,ft;Cl({dateTime:"%x, %X",date:"%-m/%-d/%Y",time:"%-I:%M:%S %p",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]});function Cl(t){return qt=Cr(t),ft=qt.format,qt.parse,qt.utcFormat,qt.utcParse,qt}var Sr=[[1,4,12,52,365,365*24,365*24*60,365*24*60*60,365*24*60*60*1e3],[1/4,1,3,13,91,91*24,91*24*60,91*24*60*60,91*24*60*60*1e3],[1/12,1/3,1,4,30,30*24,30*24*60,30*24*60*60,30*24*60*60*1e3],[1/52,1/13,1/4,1,7,7*24,7*24*60,7*24*60*60,7*24*60*60*1e3],[1/365,1/91,1/30,1/7,1,24,24*60,24*60*60,24*60*60*1e3],[1/(365*24),1/(91*24),1/(30*24),1/(7*24),1/24,1,60,60*60,60*60*1e3],[1/(365*24*60),1/(91*24*60),1/(30*24*60),1/(7*24*60),1/(24*60),1/60,1,60,60*1e3],[1/(365*24*60*60),1/(91*24*60*60),1/(30*24*60*60),1/(7*24*60*60),1/(24*60*60),1/(60*60),1/60,1,1e3],[1/(365*24*60*60*1e3),1/(91*24*60*60*1e3),1/(30*24*60*60*1e3),1/(7*24*60*60*1e3),1/(24*60*60*1e3),1/(60*60*1e3),1/(60*1e3),1/1e3,1]];function Sl(t,e,r){if(it(t))return;if(!e||!r||e===r)return t;let n=Sr[e-1][r-1];if(n)return t*n}function Ml(t,e,r,n){if(it(t)||!e.lowestLevel||r.length===0)return"";let o=[],i=0,a=Math.round(t*Sr[e.lowestLevel-1][8]),l=9;for(let[,u]of r.entries())if(t){a=a-i;let f=Sr[u-1][l-1],c=Math.floor(a/f);i=c*f,o.push({level:u,value:c})}else o.push({level:u,value:0});let s="";for(let[u,f]of o.entries())if(e.duration.format==="time"){let c=f.value;[6,7,8].includes(f.level)&&f.value<10?c="0"+f.value.toString():f.level===9&&f.value<10?c="00"+f.value.toString():f.level===9&&f.value<100&&(c="0"+f.value.toString()),s+=(u===0?"":f.level===9?".":":")+c}else if(e.duration.format==="long"){let c=n.durationLongSuffix;s+=f.value+" "+c[f.level]+(u===o.length-1?"":" ")}else{let c=n.durationShortSuffix;s+=f.value+""+c[f.level]+(u===o.length-1?"":" ")}return s}var kl={decimal:".",thousands:",",grouping:[3],currency:["$",""],dateTime:"%a %b %e %X %Y",date:"%m/%d/%Y",dateSeparator:"/",time:"%H:%M:%S",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],levels:["All","Year","Quarter","Month","Week","Date","Hour","Minute","Second","Millisecond"],shortLevels:["All","Yr","Qtr","Mth","Wk","Date","Hr","Min","Sec","Msec"],durationLongSuffix:["","years","quarters","months","weeks","days","hours","minutes","seconds","milliseconds"],durationShortSuffix:["","y","q","mo","w","d","h","m","s","ms"],multi:[".%L",":%S","%I:%M","%I %p","%a %d","W%G","%b %d","%B","%Y"]},Al="%d-%m-%Y",Dl=[{key:"%a %e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%a %e %b %Y",monthType:"name",longText:!1,weekday:!0},{key:"%e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%e %b %Y",monthType:"name",longText:!1,weekday:!1},{key:"%a %e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%a %e %B %Y",monthType:"name",longText:!0,weekday:!0},{key:"%e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%e %B %Y",monthType:"name",longText:!0,weekday:!1},{key:"%d/%m/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"W%V/%G",lev5:"%d/%m/%Y",monthType:"number",mmdd:!1,separator:"/"},{key:"%d-%m-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"W%V-%G",lev5:"%d-%m-%Y",monthType:"number",mmdd:!1,separator:"-"},{key:"%d.%m.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"W%V.%G",lev5:"%d.%m.%Y",monthType:"number",mmdd:!1,separator:"."},{key:"%d~%m~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"W%V~%G",lev5:"%d~%m~%Y",monthType:"number",mmdd:!1,separator:"~"},{key:"%m/%d/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%m/%d/%Y",monthType:"number",mmdd:!0,separator:"/"},{key:"%m-%d-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%m-%d-%Y",monthType:"number",mmdd:!0,separator:"-"},{key:"%m.%d.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%m.%d.%Y",monthType:"number",mmdd:!0,separator:"."},{key:"%m~%d~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%m~%d~%Y",monthType:"number",mmdd:!0,separator:"~"},{key:"%amd/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%amd/%Y",monthType:"number",mmdd:null,separator:"/"},{key:"%amd-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%amd-%Y",monthType:"number",mmdd:null,separator:"-"},{key:"%amd.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%amd.%Y",monthType:"number",mmdd:null,separator:"."},{key:"%amd~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%amd~%Y",monthType:"number",mmdd:null,separator:"~"}],Tl=[{key:"%H:%M:%S.%L",lev6:"%H:00",lev7:"%H:%M",lev8:"%H:%M:%S",lev9:"%H:%M:%S.%L",ampm:!1},{key:"%I:%M:%S.%L %p",lev6:"%I:00 %p",lev7:"%I:%M %p",lev8:"%I:%M:%S %p",lev9:"%I:%M:%S.%L %p",ampm:!0}];function Lt(t,e){var r,n;e=e||{};let o=e.localFormats||kl,i,a,l,s=[],u=[],f="datetime",c;e&&e.multi&&(f="datetime"),(!t||!t.format)&&(f="hierarchy"),t&&t.type&&(f=t.type),t&&t.format?c=t.format:f==="numeric"?c=",.0f":f==="datetime"?c=Al:c="";let p=hr(c);switch(p.precision&&p.typeFormat&&(f="numeric"),f){case"numeric":{if(t.subtype==="duration"&&t.duration&&t.duration.levels&&t.duration.levels.length>1&&!e.hideDuration)i=m=>it(m)?"":Ml(m,t,t.duration.levels,o);else{let m={...o},h=p.typeFormat,g=!1;switch(h.length===2&&h.startsWith("a")&&(g=!0,h=h.slice(1,2),c=c.replace(/a/,"")),g?(m.decimal=o.decimal,m.thousands=o.thousands):["z","y","w"].includes(h)?(m.decimal=",",m.thousands="."):(m.decimal=".",m.thousands=","),h){case"z":{c=c.replace("z","f");break}case"y":{c=c.replace("y","%");break}case"w":{c=c.replace("w","s");break}}if(t?.subtype==="currency"&&t.currency){let y="\xA0",S=m.currency.findIndex(M=>M.length>0),_=m.currency[S].startsWith(y),C=m.currency[S].endsWith(y),b=`${_?y:""}${t.currency}${C?y:""}`;m.currency[S]=b}let w=fa(m);h!=="%"&&t?.subtype==="currency"&&t.currency&&m.currency&&!(e!=null&&e.hideCurrency)&&!["count","distinctcount"].includes(t.aggregationFunc)&&!(t.aggregationFunc==="rate"&&((r=t.aggregationWeight)==null?void 0:r.columnSubType)==="currency")&&((n=t.periodOverPeriod)==null?void 0:n.type)!=="percentageChange"&&(c="$"+c),e!=null&&e.trimZero&&["y","%"].includes(h)&&m.decimal===","?a=y=>w.format(c)(y).replace(/(,\d*?)0+%$/,"$1%").replace(/,%$/,"%"):e!=null&&e.trimZero&&["y","%"].includes(h)&&m.decimal==="."?a=y=>w.format(c)(y).replace(/(\.\d*?)0+%$/,"$1%").replace(/\.%$/,"%"):e!=null&&e.trimZero&&["z","f"].includes(h)&&m.decimal===","?a=y=>w.format(c)(y).replace(/(,\d*?)0+$/,"$1").replace(/,$/,""):e!=null&&e.trimZero&&["z","f"].includes(h)&&m.decimal==="."?a=y=>w.format(c)(y).replace(/(\.\d*?)0+$/,"$1").replace(/\.$/,""):t?.subtype==="currency"&&t.currency&&m.currency&&h==="s"?a=y=>w.format(c)(y).replace(/G/,"B"):a=it(p.precision)?w.format(",.0f"):w.format(c),i=y=>{var S;if(it(y))return"";if(t.subtype==="duration"&&t.duration&&!e.hideDuration){let _=t.duration.levels?t.duration.levels[0]:t.lowestLevel;return _!==t.lowestLevel&&(y=Sl(y,t.lowestLevel,_)),a(y)+((S=o?.durationShortSuffix)==null?void 0:S[_])}return a(y)}}break}case"datetime":{if(s=o?.smartDateFormats??Dl,u=o?.smartTimeFormats??Tl,it(t.datetimeDisplayMode)){if(e!=null&&e.level){let m=e.level,h=s.find(C=>c.includes(C.key)),g=u.find(C=>c.includes(C.key)),w=h?h["lev"+Math.min(m,5)]:s[0]["lev"+Math.min(m,5)],y=m>5?g?g["lev"+m]:u[0]["lev"+m]:"";c=m>5?w+", "+y:w;let S=c.includes("%amd")&&e.level>=5,_=h?e.level>=2&&h.separator==="~":!1;S?c=_?c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8)):c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8).replaceAll(new RegExp(/[.~\/-]/g),h.separator)):c=_?c.replaceAll(new RegExp(/[~]/g),o.dateSeparator):c}if(e!=null&&e.multi){let m=ft(o.multi[0]),h=ft(o.multi[1]),g=ft(o.multi[2]),w=ft(o.multi[3]),y=ft(o.multi[4]),S=ft(o.multi[6]),_=ft(o.multi[7]),C=ft(o.multi[8]);l=b=>{let M;return In(b)<b?M=m:Yn(b)<b?M=h:Bn(b)<b?M=g:Ee(b)<b?M=w:zn(b)<b?M=Ar(b)<b?y:S:xt(b)<b?M=_:M=C,M(b)}}else l=Cr(o).format(c)}else{let m={quarter_number:{min:1,max:4},month_name:{min:1,max:12},month_number:{min:1,max:12},week_number:{min:1,max:53},day_in_month:{min:1,max:31},day_in_year:{min:1,max:366},weekday_name:{min:0,max:7},weekday_number:{min:0,max:7},hour_in_day:{min:0,max:23},minute_in_hour:{min:0,max:59},second_in_minute:{min:0,max:59}},h=(g,w,y)=>{var S,_,C,b,M;return w==="letter"?((S=g.shortNames)==null?void 0:S.length)>0&&((_=g.shortNames[y])==null?void 0:_.length)>0?(C=g.shortNames[y])==null?void 0:C.charAt(0):"N/A":w==="short"?((b=g.shortNames)==null?void 0:b.length)>0&&g.shortNames[y]?g.shortNames[y]:"N/A":((M=g.longNames)==null?void 0:M.length)>0&&g.longNames[y]?g.longNames[y]:"N/A"};["quarter_number","month_number","week_number","day_in_month","day_in_year","weekday_number","hour_in_day","minute_in_hour","second_in_minute"].includes(t.datetimeDisplayMode)?l=g=>jt(g)&&g>=m[t.datetimeDisplayMode].min&&g<=m[t.datetimeDisplayMode].max?g:"N/A":t.datetimeDisplayMode==="month_name"?l=g=>{let w=[...o.shortMonths],y=[...o.months];return jt(g)&&g>=m[t.datetimeDisplayMode].min&&g<=m[t.datetimeDisplayMode].max?h({shortNames:w,longNames:y},t.monthNameFormat,g-1):"N/A"}:t.datetimeDisplayMode==="weekday_name"?l=g=>{let w=[...o.shortDays],y=[...o.days];return t.weekStart==="monday"&&(w.push(w.shift()??""),y.push(y.shift()??"")),jt(g)&&g>=m[t.datetimeDisplayMode].min&&g<=m[t.datetimeDisplayMode].max?h({shortNames:w,longNames:y},t.weekDayNameFormat,g-1):"N/A"}:l=Cr(o).format(c)}i=m=>{if(it(m))return"";let h=l(m);return gr(h)?h.trim():h};break}case"hierarchy":{i=m=>yr(m,e?e.locale:void 0);break}default:{i=m=>m;break}}return i}var rt={type:"platform",background:"rgb(245,245,245)",itemsBackground:"rgb(255,255,255)",boxShadow:{size:"none",color:"rgb(0, 0, 0)"},title:{align:"left",bold:!1,italic:!1,underline:!1,border:!1},font:{fontFamily:"Lato","font-style":"normal","font-weight":400,fontSize:15},colors:["rgb(68,52,255)","rgb(143,133,255)","rgb(218,214,255)","rgb(191,5,184)","rgb(217,105,212)","rgb(242,205,241)","rgb(248,194,12)","rgb(251,218,109)","rgb(254,243,206)","rgb(9,203,120)","rgb(107,224,174)","rgb(206,245,228)","rgb(122,112,112)","rgb(175,169,169)","rgb(228,226,226)"],borders:{"border-color":"rgba(216,216,216,1)","border-style":"none","border-radius":"12px","border-top-width":"0px","border-left-width":"0px","border-right-width":"0px","border-bottom-width":"0px"},margins:[16,16],mainColor:"rgb(68,52,255)",axis:{},legend:{type:"circle"},tooltip:{background:"rgb(38,38,38)"},itemSpecific:{rounding:8,padding:4}},Ht=(t,e)=>({"border-color":t,"border-style":"none","border-radius":e,"border-top-width":"1px","border-left-width":"1px","border-right-width":"1px","border-bottom-width":"1px"}),Vm={default:{...rt,name:"Default (light)"},default_dark:{...rt,name:"Default (dark)",background:"rgb(61,61,61)",itemsBackground:"rgb(38,38,38)",colors:["rgb(48,36,179)","rgb(105,93,255)","rgb(199,194,255)","rgb(134,4,129)","rgb(204,55,198)","rgb(236,180,234)","rgb(220,141,0)","rgb(249,206,61)","rgb(253,237,182)","rgb(6,142,84)","rgb(58,213,147)","rgb(181,239,215)","rgb(85,78,78)","rgb(149,141,141)","rgb(215,212,212)"],mainColor:"rgb(123,144,255)",tooltip:{background:"rgb(248,248,248)"}},vivid:{...rt,name:"Vivid",background:"#eef3f6",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[12,12],mainColor:"#5867C3",legend:{type:"normal"},tooltip:{},colors:["#5867C3","#00C5DC","#FF525E","#FFAA00","#FFDB03","#86de40","#59b339","#cc27bc","#ff4aed","#bfbfbf","#737373"],font:{fontFamily:"Open Sans",fontSize:13}},seasonal:{...rt,name:"Seasonal",background:"#ffffff",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:Ht("rgba(0,0,0,.1)","8px"),margins:[10,10],mainColor:"#009788",tooltip:{},colors:["#009788","#60cc64","#CDDC39","#FFEB3C","#FEC107","#FF9700","#FE5722","#EA1E63","#9C28B1","#673BB7","#3F51B5","#2196F3","#03A9F5","#00BCD5"],font:{fontFamily:"Open Sans",fontSize:13}},orion:{...rt,name:"Orion's Belt",background:"#00062d",itemsBackground:"#00062d",boxShadow:{size:"L",color:"#64046f"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:Ht("rgba(0, 0, 0, .1)","8px"),mainColor:"#d62750",legend:{type:"normal"},colors:["#880065","#b3005e","#d62750","#ef513e","#fd7b27","#ffa600","#fdae6b"],font:{fontFamily:"Electrolize",fontSize:15}},royale:{...rt,name:"Royale",background:"#0A2747",itemsBackground:"#111e2f",boxShadow:{size:"S",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{"border-radius":"3px"},margins:[10,10],mainColor:"#f4a92c",legend:{type:"circle"},tooltip:{},colors:["#feeaa1","#e6cc85","#ceaf6a","#b79350","#9f7738","#885d20","#704308"],font:{fontFamily:"Exo",fontSize:13}},urban:{...rt,name:"Urban",background:"#42403c",itemsBackground:"#e4dbcd",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[5,5],mainColor:"#33b59e",legend:{type:"circle"},colors:["#33b59e","#453d30","#ffffff","#237869","#165e4e","#b89f76","#7a6138","#543c13","#8a9c98","#44524f"],font:{fontFamily:"Open Sans",fontSize:13}},pinky:{...rt,name:"Pinky Brains",background:"#0F1E43",itemsBackground:"#1B2A4D",title:{align:"center",bold:!0,italic:!1,underline:!1,border:!0},borders:Ht("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#e84281",legend:{type:"normal"},tooltip:{},colors:["#e84281","#d464c2","#a089f2","#46a8ff","#00c0ff","#00d0e8","#49dcc9"],font:{fontFamily:"Capriola",fontSize:15}},bliss:{...rt,name:"Bliss",background:"#ffffff",itemsBackground:"#ffffff",boxShadow:{size:"none",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:Ht("rgba(0, 0, 0, .1)","8px"),margins:[10,10],mainColor:"#0578ff",axis:{},legend:{type:"normal"},tooltip:{},colors:["#b8d8ff","#3ba0ff","#0044f2","#1b00ca","#9114de","#ce42ff","#ff19f6","#ed2bab","#d8175c","#ff303d","#ff6130","#ff9f30","#15BF49","#95E88C"],font:{fontFamily:"Open Sans",fontSize:13}},radiant:{...rt,name:"Radiant",background:"rgba(43,43,56,1)",itemsBackground:"rgba(52,52,69,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:Ht("rgba(255, 255, 255, .08)","8px"),margins:[14,14],mainColor:"#00a4eb",legend:{type:"line"},tooltip:{},colors:["#a6e1ff","#00a4eb","#3f3af0","#9300c7","#f72f5f","#f29b50","#f2d566","#3ae086","#c9c9c9","#7a7a7a"],font:{fontFamily:"Open Sans",fontSize:13}},classic:{...rt,name:"Classic (light)",background:"#F2F2F2",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#ececec",borders:Ht("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#009dff",legend:{type:"normal"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}},classic_dark:{...rt,name:"Classic (dark)",background:"rgb(38,39,50)",itemsBackground:"rgba(52,53,68,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{},margins:[10,10],mainColor:"#0E89E0",legend:{type:"line"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}}};function Ft(t,e){return t==null||e==null?NaN:t<e?-1:t>e?1:t>=e?0:NaN}function Dr(t,e){return t==null||e==null?NaN:e<t?-1:e>t?1:e>=t?0:NaN}function Ne(t){let e,r,n;t.length!==2?(e=Ft,r=(l,s)=>Ft(t(l),s),n=(l,s)=>t(l)-s):(e=t===Ft||t===Dr?t:Fl,r=t,n=t);function o(l,s,u=0,f=l.length){if(u<f){if(e(s,s)!==0)return f;do{let c=u+f>>>1;r(l[c],s)<0?u=c+1:f=c}while(u<f)}return u}function i(l,s,u=0,f=l.length){if(u<f){if(e(s,s)!==0)return f;do{let c=u+f>>>1;r(l[c],s)<=0?u=c+1:f=c}while(u<f)}return u}function a(l,s,u=0,f=l.length){let c=o(l,s,u,f-1);return c>u&&n(l[c-1],s)>-n(l[c],s)?c-1:c}return{left:o,center:a,right:i}}function Fl(){return 0}function Tr(t){return t===null?NaN:+t}var Hn=Ne(Ft),Vn=Hn.right,El=Hn.left,Nl=Ne(Tr).center,Fr=Vn;var bt=class extends Map{constructor(e,r=Yl){if(super(),Object.defineProperties(this,{_intern:{value:new Map},_key:{value:r}}),e!=null)for(let[n,o]of e)this.set(n,o)}get(e){return super.get(Un(this,e))}has(e){return super.has(Un(this,e))}set(e,r){return super.set(Ol(this,e),r)}delete(e){return super.delete(Il(this,e))}};function Un({_intern:t,_key:e},r){let n=e(r);return t.has(n)?t.get(n):r}function Ol({_intern:t,_key:e},r){let n=e(r);return t.has(n)?t.get(n):(t.set(n,r),r)}function Il({_intern:t,_key:e},r){let n=e(r);return t.has(n)&&(r=t.get(n),t.delete(n)),r}function Yl(t){return t!==null&&typeof t=="object"?t.valueOf():t}function Oe(t){return t}function Ie(t,...e){return Bl(t,Oe,Oe,e)}function Bl(t,e,r,n){return function o(i,a){if(a>=n.length)return r(i);let l=new bt,s=n[a++],u=-1;for(let f of i){let c=s(f,++u,i),p=l.get(c);p?p.push(f):l.set(c,[f])}for(let[f,c]of l)l.set(f,o(c,a));return e(l)}(t,0)}var Rl=Math.sqrt(50),zl=Math.sqrt(10),ql=Math.sqrt(2);function Ye(t,e,r){let n=(e-t)/Math.max(0,r),o=Math.floor(Math.log10(n)),i=n/Math.pow(10,o),a=i>=Rl?10:i>=zl?5:i>=ql?2:1,l,s,u;return o<0?(u=Math.pow(10,-o)/a,l=Math.round(t*u),s=Math.round(e*u),l/u<t&&++l,s/u>e&&--s,u=-u):(u=Math.pow(10,o)*a,l=Math.round(t/u),s=Math.round(e/u),l*u<t&&++l,s*u>e&&--s),s<l&&.5<=r&&r<2?Ye(t,e,r*2):[l,s,u]}function Be(t,e,r){if(e=+e,t=+t,r=+r,!(r>0))return[];if(t===e)return[t];let n=e<t,[o,i,a]=n?Ye(e,t,r):Ye(t,e,r);if(!(i>=o))return[];let l=i-o+1,s=new Array(l);if(n)if(a<0)for(let u=0;u<l;++u)s[u]=(i-u)/-a;else for(let u=0;u<l;++u)s[u]=(i-u)*a;else if(a<0)for(let u=0;u<l;++u)s[u]=(o+u)/-a;else for(let u=0;u<l;++u)s[u]=(o+u)*a;return s}function ae(t,e,r){return e=+e,t=+t,r=+r,Ye(t,e,r)[2]}function Er(t,e,r){e=+e,t=+t,r=+r;let n=e<t,o=n?ae(e,t,r):ae(t,e,r);return(n?-1:1)*(o<0?1/-o:o)}function Re(t,e){let r;if(e===void 0)for(let n of t)n!=null&&(r<n||r===void 0&&n>=n)&&(r=n);else{let n=-1;for(let o of t)(o=e(o,++n,t))!=null&&(r<o||r===void 0&&o>=o)&&(r=o)}return r}function ze(t,e,r){t=+t,e=+e,r=(o=arguments.length)<2?(e=t,t=0,1):o<3?1:+r;for(var n=-1,o=Math.max(0,Math.ceil((e-t)/r))|0,i=new Array(o);++n<o;)i[n]=t+n*r;return i}function Gn(t){return t}var Nr=1,Or=2,Ir=3,le=4,Xn=1e-6;function $l(t){return"translate("+t+",0)"}function Pl(t){return"translate(0,"+t+")"}function Ll(t){return e=>+t(e)}function Hl(t,e){return e=Math.max(0,t.bandwidth()-e*2)/2,t.round()&&(e=Math.round(e)),r=>+t(r)+e}function Vl(){return!this.__axis}function Wn(t,e){var r=[],n=null,o=null,i=6,a=6,l=3,s=typeof window<"u"&&window.devicePixelRatio>1?0:.5,u=t===Nr||t===le?-1:1,f=t===le||t===Or?"x":"y",c=t===Nr||t===Ir?$l:Pl;function p(m){var h=n??(e.ticks?e.ticks.apply(e,r):e.domain()),g=o??(e.tickFormat?e.tickFormat.apply(e,r):Gn),w=Math.max(i,0)+l,y=e.range(),S=+y[0]+s,_=+y[y.length-1]+s,C=(e.bandwidth?Hl:Ll)(e.copy(),s),b=m.selection?m.selection():m,M=b.selectAll(".domain").data([null]),E=b.selectAll(".tick").data(h,e).order(),B=E.exit(),q=E.enter().append("g").attr("class","tick"),Q=E.select("line"),x=E.select("text");M=M.merge(M.enter().insert("path",".tick").attr("class","domain").attr("stroke","currentColor")),E=E.merge(q),Q=Q.merge(q.append("line").attr("stroke","currentColor").attr(f+"2",u*i)),x=x.merge(q.append("text").attr("fill","currentColor").attr(f,u*w).attr("dy",t===Nr?"0em":t===Ir?"0.71em":"0.32em")),m!==b&&(M=M.transition(m),E=E.transition(m),Q=Q.transition(m),x=x.transition(m),B=B.transition(m).attr("opacity",Xn).attr("transform",function(A){return isFinite(A=C(A))?c(A+s):this.getAttribute("transform")}),q.attr("opacity",Xn).attr("transform",function(A){var T=this.parentNode.__axis;return c((T&&isFinite(T=T(A))?T:C(A))+s)})),B.remove(),M.attr("d",t===le||t===Or?a?"M"+u*a+","+S+"H"+s+"V"+_+"H"+u*a:"M"+s+","+S+"V"+_:a?"M"+S+","+u*a+"V"+s+"H"+_+"V"+u*a:"M"+S+","+s+"H"+_),E.attr("opacity",1).attr("transform",function(A){return c(C(A)+s)}),Q.attr(f+"2",u*i),x.attr(f,u*w).text(g),b.filter(Vl).attr("fill","none").attr("font-size",10).attr("font-family","sans-serif").attr("text-anchor",t===Or?"start":t===le?"end":"middle"),b.each(function(){this.__axis=C})}return p.scale=function(m){return arguments.length?(e=m,p):e},p.ticks=function(){return r=Array.from(arguments),p},p.tickArguments=function(m){return arguments.length?(r=m==null?[]:Array.from(m),p):r.slice()},p.tickValues=function(m){return arguments.length?(n=m==null?null:Array.from(m),p):n&&n.slice()},p.tickFormat=function(m){return arguments.length?(o=m,p):o},p.tickSize=function(m){return arguments.length?(i=a=+m,p):i},p.tickSizeInner=function(m){return arguments.length?(i=+m,p):i},p.tickSizeOuter=function(m){return arguments.length?(a=+m,p):a},p.tickPadding=function(m){return arguments.length?(l=+m,p):l},p.offset=function(m){return arguments.length?(s=+m,p):s},p}function Yr(t){return Wn(Ir,t)}function Br(t){return Wn(le,t)}var Ul={value:()=>{}};function Zn(){for(var t=0,e=arguments.length,r={},n;t<e;++t){if(!(n=arguments[t]+"")||n in r||/[\s.]/.test(n))throw new Error("illegal type: "+n);r[n]=[]}return new qe(r)}function qe(t){this._=t}function Gl(t,e){return t.trim().split(/^|\s+/).map(function(r){var n="",o=r.indexOf(".");if(o>=0&&(n=r.slice(o+1),r=r.slice(0,o)),r&&!e.hasOwnProperty(r))throw new Error("unknown type: "+r);return{type:r,name:n}})}qe.prototype=Zn.prototype={constructor:qe,on:function(t,e){var r=this._,n=Gl(t+"",r),o,i=-1,a=n.length;if(arguments.length<2){for(;++i<a;)if((o=(t=n[i]).type)&&(o=Xl(r[o],t.name)))return o;return}if(e!=null&&typeof e!="function")throw new Error("invalid callback: "+e);for(;++i<a;)if(o=(t=n[i]).type)r[o]=Qn(r[o],t.name,e);else if(e==null)for(o in r)r[o]=Qn(r[o],t.name,null);return this},copy:function(){var t={},e=this._;for(var r in e)t[r]=e[r].slice();return new qe(t)},call:function(t,e){if((o=arguments.length-2)>0)for(var r=new Array(o),n=0,o,i;n<o;++n)r[n]=arguments[n+2];if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(i=this._[t],n=0,o=i.length;n<o;++n)i[n].value.apply(e,r)},apply:function(t,e,r){if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(var n=this._[t],o=0,i=n.length;o<i;++o)n[o].value.apply(e,r)}};function Xl(t,e){for(var r=0,n=t.length,o;r<n;++r)if((o=t[r]).name===e)return o.value}function Qn(t,e,r){for(var n=0,o=t.length;n<o;++n)if(t[n].name===e){t[n]=Ul,t=t.slice(0,n).concat(t.slice(n+1));break}return r!=null&&t.push({name:e,value:r}),t}var Rr=Zn;var $e="http://www.w3.org/1999/xhtml",zr={svg:"http://www.w3.org/2000/svg",xhtml:$e,xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace",xmlns:"http://www.w3.org/2000/xmlns/"};function mt(t){var e=t+="",r=e.indexOf(":");return r>=0&&(e=t.slice(0,r))!=="xmlns"&&(t=t.slice(r+1)),zr.hasOwnProperty(e)?{space:zr[e],local:t}:t}function Wl(t){return function(){var e=this.ownerDocument,r=this.namespaceURI;return r===$e&&e.documentElement.namespaceURI===$e?e.createElement(t):e.createElementNS(r,t)}}function Ql(t){return function(){return this.ownerDocument.createElementNS(t.space,t.local)}}function Pe(t){var e=mt(t);return(e.local?Ql:Wl)(e)}function Zl(){}function Et(t){return t==null?Zl:function(){return this.querySelector(t)}}function Jn(t){typeof t!="function"&&(t=Et(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,l=n[o]=new Array(a),s,u,f=0;f<a;++f)(s=i[f])&&(u=t.call(s,s.__data__,f,i))&&("__data__"in s&&(u.__data__=s.__data__),l[f]=u);return new Y(n,this._parents)}function se(t){return t==null?[]:Array.isArray(t)?t:Array.from(t)}function Jl(){return[]}function ue(t){return t==null?Jl:function(){return this.querySelectorAll(t)}}function Kl(t){return function(){return se(t.apply(this,arguments))}}function Kn(t){typeof t=="function"?t=Kl(t):t=ue(t);for(var e=this._groups,r=e.length,n=[],o=[],i=0;i<r;++i)for(var a=e[i],l=a.length,s,u=0;u<l;++u)(s=a[u])&&(n.push(t.call(s,s.__data__,u,a)),o.push(s));return new Y(n,o)}function ce(t){return function(){return this.matches(t)}}function Le(t){return function(e){return e.matches(t)}}var jl=Array.prototype.find;function ts(t){return function(){return jl.call(this.children,t)}}function es(){return this.firstElementChild}function jn(t){return this.select(t==null?es:ts(typeof t=="function"?t:Le(t)))}var rs=Array.prototype.filter;function ns(){return Array.from(this.children)}function os(t){return function(){return rs.call(this.children,t)}}function to(t){return this.selectAll(t==null?ns:os(typeof t=="function"?t:Le(t)))}function eo(t){typeof t!="function"&&(t=ce(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,l=n[o]=[],s,u=0;u<a;++u)(s=i[u])&&t.call(s,s.__data__,u,i)&&l.push(s);return new Y(n,this._parents)}function He(t){return new Array(t.length)}function ro(){return new Y(this._enter||this._groups.map(He),this._parents)}function fe(t,e){this.ownerDocument=t.ownerDocument,this.namespaceURI=t.namespaceURI,this._next=null,this._parent=t,this.__data__=e}fe.prototype={constructor:fe,appendChild:function(t){return this._parent.insertBefore(t,this._next)},insertBefore:function(t,e){return this._parent.insertBefore(t,e)},querySelector:function(t){return this._parent.querySelector(t)},querySelectorAll:function(t){return this._parent.querySelectorAll(t)}};function no(t){return function(){return t}}function is(t,e,r,n,o,i){for(var a=0,l,s=e.length,u=i.length;a<u;++a)(l=e[a])?(l.__data__=i[a],n[a]=l):r[a]=new fe(t,i[a]);for(;a<s;++a)(l=e[a])&&(o[a]=l)}function as(t,e,r,n,o,i,a){var l,s,u=new Map,f=e.length,c=i.length,p=new Array(f),m;for(l=0;l<f;++l)(s=e[l])&&(p[l]=m=a.call(s,s.__data__,l,e)+"",u.has(m)?o[l]=s:u.set(m,s));for(l=0;l<c;++l)m=a.call(t,i[l],l,i)+"",(s=u.get(m))?(n[l]=s,s.__data__=i[l],u.delete(m)):r[l]=new fe(t,i[l]);for(l=0;l<f;++l)(s=e[l])&&u.get(p[l])===s&&(o[l]=s)}function ls(t){return t.__data__}function oo(t,e){if(!arguments.length)return Array.from(this,ls);var r=e?as:is,n=this._parents,o=this._groups;typeof t!="function"&&(t=no(t));for(var i=o.length,a=new Array(i),l=new Array(i),s=new Array(i),u=0;u<i;++u){var f=n[u],c=o[u],p=c.length,m=ss(t.call(f,f&&f.__data__,u,n)),h=m.length,g=l[u]=new Array(h),w=a[u]=new Array(h),y=s[u]=new Array(p);r(f,c,g,w,y,m,e);for(var S=0,_=0,C,b;S<h;++S)if(C=g[S]){for(S>=_&&(_=S+1);!(b=w[_])&&++_<h;);C._next=b||null}}return a=new Y(a,n),a._enter=l,a._exit=s,a}function ss(t){return typeof t=="object"&&"length"in t?t:Array.from(t)}function io(){return new Y(this._exit||this._groups.map(He),this._parents)}function ao(t,e,r){var n=this.enter(),o=this,i=this.exit();return typeof t=="function"?(n=t(n),n&&(n=n.selection())):n=n.append(t+""),e!=null&&(o=e(o),o&&(o=o.selection())),r==null?i.remove():r(i),n&&o?n.merge(o).order():o}function lo(t){for(var e=t.selection?t.selection():t,r=this._groups,n=e._groups,o=r.length,i=n.length,a=Math.min(o,i),l=new Array(o),s=0;s<a;++s)for(var u=r[s],f=n[s],c=u.length,p=l[s]=new Array(c),m,h=0;h<c;++h)(m=u[h]||f[h])&&(p[h]=m);for(;s<o;++s)l[s]=r[s];return new Y(l,this._parents)}function so(){for(var t=this._groups,e=-1,r=t.length;++e<r;)for(var n=t[e],o=n.length-1,i=n[o],a;--o>=0;)(a=n[o])&&(i&&a.compareDocumentPosition(i)^4&&i.parentNode.insertBefore(a,i),i=a);return this}function uo(t){t||(t=us);function e(c,p){return c&&p?t(c.__data__,p.__data__):!c-!p}for(var r=this._groups,n=r.length,o=new Array(n),i=0;i<n;++i){for(var a=r[i],l=a.length,s=o[i]=new Array(l),u,f=0;f<l;++f)(u=a[f])&&(s[f]=u);s.sort(e)}return new Y(o,this._parents).order()}function us(t,e){return t<e?-1:t>e?1:t>=e?0:NaN}function co(){var t=arguments[0];return arguments[0]=this,t.apply(null,arguments),this}function fo(){return Array.from(this)}function mo(){for(var t=this._groups,e=0,r=t.length;e<r;++e)for(var n=t[e],o=0,i=n.length;o<i;++o){var a=n[o];if(a)return a}return null}function po(){let t=0;for(let e of this)++t;return t}function ho(){return!this.node()}function go(t){for(var e=this._groups,r=0,n=e.length;r<n;++r)for(var o=e[r],i=0,a=o.length,l;i<a;++i)(l=o[i])&&t.call(l,l.__data__,i,o);return this}function cs(t){return function(){this.removeAttribute(t)}}function fs(t){return function(){this.removeAttributeNS(t.space,t.local)}}function ms(t,e){return function(){this.setAttribute(t,e)}}function ps(t,e){return function(){this.setAttributeNS(t.space,t.local,e)}}function ds(t,e){return function(){var r=e.apply(this,arguments);r==null?this.removeAttribute(t):this.setAttribute(t,r)}}function hs(t,e){return function(){var r=e.apply(this,arguments);r==null?this.removeAttributeNS(t.space,t.local):this.setAttributeNS(t.space,t.local,r)}}function yo(t,e){var r=mt(t);if(arguments.length<2){var n=this.node();return r.local?n.getAttributeNS(r.space,r.local):n.getAttribute(r)}return this.each((e==null?r.local?fs:cs:typeof e=="function"?r.local?hs:ds:r.local?ps:ms)(r,e))}function Ve(t){return t.ownerDocument&&t.ownerDocument.defaultView||t.document&&t||t.defaultView}function gs(t){return function(){this.style.removeProperty(t)}}function ys(t,e,r){return function(){this.style.setProperty(t,e,r)}}function xs(t,e,r){return function(){var n=e.apply(this,arguments);n==null?this.style.removeProperty(t):this.style.setProperty(t,n,r)}}function xo(t,e,r){return arguments.length>1?this.each((e==null?gs:typeof e=="function"?xs:ys)(t,e,r??"")):vt(this.node(),t)}function vt(t,e){return t.style.getPropertyValue(e)||Ve(t).getComputedStyle(t,null).getPropertyValue(e)}function bs(t){return function(){delete this[t]}}function vs(t,e){return function(){this[t]=e}}function ws(t,e){return function(){var r=e.apply(this,arguments);r==null?delete this[t]:this[t]=r}}function bo(t,e){return arguments.length>1?this.each((e==null?bs:typeof e=="function"?ws:vs)(t,e)):this.node()[t]}function vo(t){return t.trim().split(/^|\s+/)}function qr(t){return t.classList||new wo(t)}function wo(t){this._node=t,this._names=vo(t.getAttribute("class")||"")}wo.prototype={add:function(t){var e=this._names.indexOf(t);e<0&&(this._names.push(t),this._node.setAttribute("class",this._names.join(" ")))},remove:function(t){var e=this._names.indexOf(t);e>=0&&(this._names.splice(e,1),this._node.setAttribute("class",this._names.join(" ")))},contains:function(t){return this._names.indexOf(t)>=0}};function _o(t,e){for(var r=qr(t),n=-1,o=e.length;++n<o;)r.add(e[n])}function Co(t,e){for(var r=qr(t),n=-1,o=e.length;++n<o;)r.remove(e[n])}function _s(t){return function(){_o(this,t)}}function Cs(t){return function(){Co(this,t)}}function Ss(t,e){return function(){(e.apply(this,arguments)?_o:Co)(this,t)}}function So(t,e){var r=vo(t+"");if(arguments.length<2){for(var n=qr(this.node()),o=-1,i=r.length;++o<i;)if(!n.contains(r[o]))return!1;return!0}return this.each((typeof e=="function"?Ss:e?_s:Cs)(r,e))}function Ms(){this.textContent=""}function ks(t){return function(){this.textContent=t}}function As(t){return function(){var e=t.apply(this,arguments);this.textContent=e??""}}function Mo(t){return arguments.length?this.each(t==null?Ms:(typeof t=="function"?As:ks)(t)):this.node().textContent}function Ds(){this.innerHTML=""}function Ts(t){return function(){this.innerHTML=t}}function Fs(t){return function(){var e=t.apply(this,arguments);this.innerHTML=e??""}}function ko(t){return arguments.length?this.each(t==null?Ds:(typeof t=="function"?Fs:Ts)(t)):this.node().innerHTML}function Es(){this.nextSibling&&this.parentNode.appendChild(this)}function Ao(){return this.each(Es)}function Ns(){this.previousSibling&&this.parentNode.insertBefore(this,this.parentNode.firstChild)}function Do(){return this.each(Ns)}function To(t){var e=typeof t=="function"?t:Pe(t);return this.select(function(){return this.appendChild(e.apply(this,arguments))})}function Os(){return null}function Fo(t,e){var r=typeof t=="function"?t:Pe(t),n=e==null?Os:typeof e=="function"?e:Et(e);return this.select(function(){return this.insertBefore(r.apply(this,arguments),n.apply(this,arguments)||null)})}function Is(){var t=this.parentNode;t&&t.removeChild(this)}function Eo(){return this.each(Is)}function Ys(){var t=this.cloneNode(!1),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function Bs(){var t=this.cloneNode(!0),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function No(t){return this.select(t?Bs:Ys)}function Oo(t){return arguments.length?this.property("__data__",t):this.node().__data__}function Rs(t){return function(e){t.call(this,e,this.__data__)}}function zs(t){return t.trim().split(/^|\s+/).map(function(e){var r="",n=e.indexOf(".");return n>=0&&(r=e.slice(n+1),e=e.slice(0,n)),{type:e,name:r}})}function qs(t){return function(){var e=this.__on;if(e){for(var r=0,n=-1,o=e.length,i;r<o;++r)i=e[r],(!t.type||i.type===t.type)&&i.name===t.name?this.removeEventListener(i.type,i.listener,i.options):e[++n]=i;++n?e.length=n:delete this.__on}}}function $s(t,e,r){return function(){var n=this.__on,o,i=Rs(e);if(n){for(var a=0,l=n.length;a<l;++a)if((o=n[a]).type===t.type&&o.name===t.name){this.removeEventListener(o.type,o.listener,o.options),this.addEventListener(o.type,o.listener=i,o.options=r),o.value=e;return}}this.addEventListener(t.type,i,r),o={type:t.type,name:t.name,value:e,listener:i,options:r},n?n.push(o):this.__on=[o]}}function Io(t,e,r){var n=zs(t+""),o,i=n.length,a;if(arguments.length<2){var l=this.node().__on;if(l){for(var s=0,u=l.length,f;s<u;++s)for(o=0,f=l[s];o<i;++o)if((a=n[o]).type===f.type&&a.name===f.name)return f.value}return}for(l=e?$s:qs,o=0;o<i;++o)this.each(l(n[o],e,r));return this}function Yo(t,e,r){var n=Ve(t),o=n.CustomEvent;typeof o=="function"?o=new o(e,r):(o=n.document.createEvent("Event"),r?(o.initEvent(e,r.bubbles,r.cancelable),o.detail=r.detail):o.initEvent(e,!1,!1)),t.dispatchEvent(o)}function Ps(t,e){return function(){return Yo(this,t,e)}}function Ls(t,e){return function(){return Yo(this,t,e.apply(this,arguments))}}function Bo(t,e){return this.each((typeof e=="function"?Ls:Ps)(t,e))}function*Ro(){for(var t=this._groups,e=0,r=t.length;e<r;++e)for(var n=t[e],o=0,i=n.length,a;o<i;++o)(a=n[o])&&(yield a)}var me=[null];function Y(t,e){this._groups=t,this._parents=e}function zo(){return new Y([[document.documentElement]],me)}function Hs(){return this}Y.prototype=zo.prototype={constructor:Y,select:Jn,selectAll:Kn,selectChild:jn,selectChildren:to,filter:eo,data:oo,enter:ro,exit:io,join:ao,merge:lo,selection:Hs,order:so,sort:uo,call:co,nodes:fo,node:mo,size:po,empty:ho,each:go,attr:yo,style:xo,property:bo,classed:So,text:Mo,html:ko,raise:Ao,lower:Do,append:To,insert:Fo,remove:Eo,clone:No,datum:Oo,on:Io,dispatch:Bo,[Symbol.iterator]:Ro};var pt=zo;function dt(t){return typeof t=="string"?new Y([[document.querySelector(t)]],[document.documentElement]):new Y([[t]],me)}function $r(t){return typeof t=="string"?new Y([document.querySelectorAll(t)],[document.documentElement]):new Y([se(t)],me)}function Ue(t,e,r){t.prototype=e.prototype=r,r.constructor=t}function Pr(t,e){var r=Object.create(t.prototype);for(var n in e)r[n]=e[n];return r}function he(){}var pe=.7,We=1/pe,Vt="\\s*([+-]?\\d+)\\s*",de="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*",at="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*",Vs=/^#([0-9a-f]{3,8})$/,Us=new RegExp(`^rgb\\(${Vt},${Vt},${Vt}\\)$`),Gs=new RegExp(`^rgb\\(${at},${at},${at}\\)$`),Xs=new RegExp(`^rgba\\(${Vt},${Vt},${Vt},${de}\\)$`),Ws=new RegExp(`^rgba\\(${at},${at},${at},${de}\\)$`),Qs=new RegExp(`^hsl\\(${de},${at},${at}\\)$`),Zs=new RegExp(`^hsla\\(${de},${at},${at},${de}\\)$`),qo={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074};Ue(he,L,{copy(t){return Object.assign(new this.constructor,this,t)},displayable(){return this.rgb().displayable()},hex:$o,formatHex:$o,formatHex8:Js,formatHsl:Ks,formatRgb:Po,toString:Po});function $o(){return this.rgb().formatHex()}function Js(){return this.rgb().formatHex8()}function Ks(){return Xo(this).formatHsl()}function Po(){return this.rgb().formatRgb()}function L(t){var e,r;return t=(t+"").trim().toLowerCase(),(e=Vs.exec(t))?(r=e[1].length,e=parseInt(e[1],16),r===6?Lo(e):r===3?new j(e>>8&15|e>>4&240,e>>4&15|e&240,(e&15)<<4|e&15,1):r===8?Ge(e>>24&255,e>>16&255,e>>8&255,(e&255)/255):r===4?Ge(e>>12&15|e>>8&240,e>>8&15|e>>4&240,e>>4&15|e&240,((e&15)<<4|e&15)/255):null):(e=Us.exec(t))?new j(e[1],e[2],e[3],1):(e=Gs.exec(t))?new j(e[1]*255/100,e[2]*255/100,e[3]*255/100,1):(e=Xs.exec(t))?Ge(e[1],e[2],e[3],e[4]):(e=Ws.exec(t))?Ge(e[1]*255/100,e[2]*255/100,e[3]*255/100,e[4]):(e=Qs.exec(t))?Uo(e[1],e[2]/100,e[3]/100,1):(e=Zs.exec(t))?Uo(e[1],e[2]/100,e[3]/100,e[4]):qo.hasOwnProperty(t)?Lo(qo[t]):t==="transparent"?new j(NaN,NaN,NaN,0):null}function Lo(t){return new j(t>>16&255,t>>8&255,t&255,1)}function Ge(t,e,r,n){return n<=0&&(t=e=r=NaN),new j(t,e,r,n)}function js(t){return t instanceof he||(t=L(t)),t?(t=t.rgb(),new j(t.r,t.g,t.b,t.opacity)):new j}function lt(t,e,r,n){return arguments.length===1?js(t):new j(t,e,r,n??1)}function j(t,e,r,n){this.r=+t,this.g=+e,this.b=+r,this.opacity=+n}Ue(j,lt,Pr(he,{brighter(t){return t=t==null?We:Math.pow(We,t),new j(this.r*t,this.g*t,this.b*t,this.opacity)},darker(t){return t=t==null?pe:Math.pow(pe,t),new j(this.r*t,this.g*t,this.b*t,this.opacity)},rgb(){return this},clamp(){return new j(Ot(this.r),Ot(this.g),Ot(this.b),Qe(this.opacity))},displayable(){return-.5<=this.r&&this.r<255.5&&-.5<=this.g&&this.g<255.5&&-.5<=this.b&&this.b<255.5&&0<=this.opacity&&this.opacity<=1},hex:Ho,formatHex:Ho,formatHex8:tu,formatRgb:Vo,toString:Vo}));function Ho(){return`#${Nt(this.r)}${Nt(this.g)}${Nt(this.b)}`}function tu(){return`#${Nt(this.r)}${Nt(this.g)}${Nt(this.b)}${Nt((isNaN(this.opacity)?1:this.opacity)*255)}`}function Vo(){let t=Qe(this.opacity);return`${t===1?"rgb(":"rgba("}${Ot(this.r)}, ${Ot(this.g)}, ${Ot(this.b)}${t===1?")":`, ${t})`}`}function Qe(t){return isNaN(t)?1:Math.max(0,Math.min(1,t))}function Ot(t){return Math.max(0,Math.min(255,Math.round(t)||0))}function Nt(t){return t=Ot(t),(t<16?"0":"")+t.toString(16)}function Uo(t,e,r,n){return n<=0?t=e=r=NaN:r<=0||r>=1?t=e=NaN:e<=0&&(t=NaN),new ot(t,e,r,n)}function Xo(t){if(t instanceof ot)return new ot(t.h,t.s,t.l,t.opacity);if(t instanceof he||(t=L(t)),!t)return new ot;if(t instanceof ot)return t;t=t.rgb();var e=t.r/255,r=t.g/255,n=t.b/255,o=Math.min(e,r,n),i=Math.max(e,r,n),a=NaN,l=i-o,s=(i+o)/2;return l?(e===i?a=(r-n)/l+(r<n)*6:r===i?a=(n-e)/l+2:a=(e-r)/l+4,l/=s<.5?i+o:2-i-o,a*=60):l=s>0&&s<1?0:a,new ot(a,l,s,t.opacity)}function Wo(t,e,r,n){return arguments.length===1?Xo(t):new ot(t,e,r,n??1)}function ot(t,e,r,n){this.h=+t,this.s=+e,this.l=+r,this.opacity=+n}Ue(ot,Wo,Pr(he,{brighter(t){return t=t==null?We:Math.pow(We,t),new ot(this.h,this.s,this.l*t,this.opacity)},darker(t){return t=t==null?pe:Math.pow(pe,t),new ot(this.h,this.s,this.l*t,this.opacity)},rgb(){var t=this.h%360+(this.h<0)*360,e=isNaN(t)||isNaN(this.s)?0:this.s,r=this.l,n=r+(r<.5?r:1-r)*e,o=2*r-n;return new j(Lr(t>=240?t-240:t+120,o,n),Lr(t,o,n),Lr(t<120?t+240:t-120,o,n),this.opacity)},clamp(){return new ot(Go(this.h),Xe(this.s),Xe(this.l),Qe(this.opacity))},displayable(){return(0<=this.s&&this.s<=1||isNaN(this.s))&&0<=this.l&&this.l<=1&&0<=this.opacity&&this.opacity<=1},formatHsl(){let t=Qe(this.opacity);return`${t===1?"hsl(":"hsla("}${Go(this.h)}, ${Xe(this.s)*100}%, ${Xe(this.l)*100}%${t===1?")":`, ${t})`}`}}));function Go(t){return t=(t||0)%360,t<0?t+360:t}function Xe(t){return Math.max(0,Math.min(1,t||0))}function Lr(t,e,r){return(t<60?e+(r-e)*t/60:t<180?r:t<240?e+(r-e)*(240-t)/60:e)*255}function Hr(t,e,r,n,o){var i=t*t,a=i*t;return((1-3*t+3*i-a)*e+(4-6*i+3*a)*r+(1+3*t+3*i-3*a)*n+a*o)/6}function Qo(t){var e=t.length-1;return function(r){var n=r<=0?r=0:r>=1?(r=1,e-1):Math.floor(r*e),o=t[n],i=t[n+1],a=n>0?t[n-1]:2*o-i,l=n<e-1?t[n+2]:2*i-o;return Hr((r-n/e)*e,a,o,i,l)}}function Zo(t){var e=t.length;return function(r){var n=Math.floor(((r%=1)<0?++r:r)*e),o=t[(n+e-1)%e],i=t[n%e],a=t[(n+1)%e],l=t[(n+2)%e];return Hr((r-n/e)*e,o,i,a,l)}}var ge=t=>()=>t;function eu(t,e){return function(r){return t+r*e}}function ru(t,e,r){return t=Math.pow(t,r),e=Math.pow(e,r)-t,r=1/r,function(n){return Math.pow(t+n*e,r)}}function Jo(t){return(t=+t)==1?Ze:function(e,r){return r-e?ru(e,r,t):ge(isNaN(e)?r:e)}}function Ze(t,e){var r=e-t;return r?eu(t,r):ge(isNaN(t)?e:t)}var st=function t(e){var r=Jo(e);function n(o,i){var a=r((o=lt(o)).r,(i=lt(i)).r),l=r(o.g,i.g),s=r(o.b,i.b),u=Ze(o.opacity,i.opacity);return function(f){return o.r=a(f),o.g=l(f),o.b=s(f),o.opacity=u(f),o+""}}return n.gamma=t,n}(1);function Ko(t){return function(e){var r=e.length,n=new Array(r),o=new Array(r),i=new Array(r),a,l;for(a=0;a<r;++a)l=lt(e[a]),n[a]=l.r||0,o[a]=l.g||0,i[a]=l.b||0;return n=t(n),o=t(o),i=t(i),l.opacity=1,function(s){return l.r=n(s),l.g=o(s),l.b=i(s),l+""}}}var nu=Ko(Qo),ou=Ko(Zo);function jo(t,e){e||(e=[]);var r=t?Math.min(e.length,t.length):0,n=e.slice(),o;return function(i){for(o=0;o<r;++o)n[o]=t[o]*(1-i)+e[o]*i;return n}}function ti(t){return ArrayBuffer.isView(t)&&!(t instanceof DataView)}function ei(t,e){var r=e?e.length:0,n=t?Math.min(r,t.length):0,o=new Array(n),i=new Array(r),a;for(a=0;a<n;++a)o[a]=It(t[a],e[a]);for(;a<r;++a)i[a]=e[a];return function(l){for(a=0;a<n;++a)i[a]=o[a](l);return i}}function ri(t,e){var r=new Date;return t=+t,e=+e,function(n){return r.setTime(t*(1-n)+e*n),r}}function X(t,e){return t=+t,e=+e,function(r){return t*(1-r)+e*r}}function ni(t,e){var r={},n={},o;(t===null||typeof t!="object")&&(t={}),(e===null||typeof e!="object")&&(e={});for(o in e)o in t?r[o]=It(t[o],e[o]):n[o]=e[o];return function(i){for(o in r)n[o]=r[o](i);return n}}var Ur=/[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,Vr=new RegExp(Ur.source,"g");function iu(t){return function(){return t}}function au(t){return function(e){return t(e)+""}}function ye(t,e){var r=Ur.lastIndex=Vr.lastIndex=0,n,o,i,a=-1,l=[],s=[];for(t=t+"",e=e+"";(n=Ur.exec(t))&&(o=Vr.exec(e));)(i=o.index)>r&&(i=e.slice(r,i),l[a]?l[a]+=i:l[++a]=i),(n=n[0])===(o=o[0])?l[a]?l[a]+=o:l[++a]=o:(l[++a]=null,s.push({i:a,x:X(n,o)})),r=Vr.lastIndex;return r<e.length&&(i=e.slice(r),l[a]?l[a]+=i:l[++a]=i),l.length<2?s[0]?au(s[0].x):iu(e):(e=s.length,function(u){for(var f=0,c;f<e;++f)l[(c=s[f]).i]=c.x(u);return l.join("")})}function It(t,e){var r=typeof e,n;return e==null||r==="boolean"?ge(e):(r==="number"?X:r==="string"?(n=L(e))?(e=n,st):ye:e instanceof L?st:e instanceof Date?ri:ti(e)?jo:Array.isArray(e)?ei:typeof e.valueOf!="function"&&typeof e.toString!="function"||isNaN(e)?ni:X)(t,e)}function Gr(t,e){return t=+t,e=+e,function(r){return Math.round(t*(1-r)+e*r)}}var oi=180/Math.PI,Je={translateX:0,translateY:0,rotate:0,skewX:0,scaleX:1,scaleY:1};function Xr(t,e,r,n,o,i){var a,l,s;return(a=Math.sqrt(t*t+e*e))&&(t/=a,e/=a),(s=t*r+e*n)&&(r-=t*s,n-=e*s),(l=Math.sqrt(r*r+n*n))&&(r/=l,n/=l,s/=l),t*n<e*r&&(t=-t,e=-e,s=-s,a=-a),{translateX:o,translateY:i,rotate:Math.atan2(e,t)*oi,skewX:Math.atan(s)*oi,scaleX:a,scaleY:l}}var Ke;function ii(t){let e=new(typeof DOMMatrix=="function"?DOMMatrix:WebKitCSSMatrix)(t+"");return e.isIdentity?Je:Xr(e.a,e.b,e.c,e.d,e.e,e.f)}function ai(t){return t==null?Je:(Ke||(Ke=document.createElementNS("http://www.w3.org/2000/svg","g")),Ke.setAttribute("transform",t),(t=Ke.transform.baseVal.consolidate())?(t=t.matrix,Xr(t.a,t.b,t.c,t.d,t.e,t.f)):Je)}function li(t,e,r,n){function o(u){return u.length?u.pop()+" ":""}function i(u,f,c,p,m,h){if(u!==c||f!==p){var g=m.push("translate(",null,e,null,r);h.push({i:g-4,x:X(u,c)},{i:g-2,x:X(f,p)})}else(c||p)&&m.push("translate("+c+e+p+r)}function a(u,f,c,p){u!==f?(u-f>180?f+=360:f-u>180&&(u+=360),p.push({i:c.push(o(c)+"rotate(",null,n)-2,x:X(u,f)})):f&&c.push(o(c)+"rotate("+f+n)}function l(u,f,c,p){u!==f?p.push({i:c.push(o(c)+"skewX(",null,n)-2,x:X(u,f)}):f&&c.push(o(c)+"skewX("+f+n)}function s(u,f,c,p,m,h){if(u!==c||f!==p){var g=m.push(o(m)+"scale(",null,",",null,")");h.push({i:g-4,x:X(u,c)},{i:g-2,x:X(f,p)})}else(c!==1||p!==1)&&m.push(o(m)+"scale("+c+","+p+")")}return function(u,f){var c=[],p=[];return u=t(u),f=t(f),i(u.translateX,u.translateY,f.translateX,f.translateY,c,p),a(u.rotate,f.rotate,c,p),l(u.skewX,f.skewX,c,p),s(u.scaleX,u.scaleY,f.scaleX,f.scaleY,c,p),u=f=null,function(m){for(var h=-1,g=p.length,w;++h<g;)c[(w=p[h]).i]=w.x(m);return c.join("")}}}var Wr=li(ii,"px, ","px)","deg)"),Qr=li(ai,", ",")",")");var Ut=0,be=0,xe=0,ui=1e3,je,ve,tr=0,Yt=0,er=0,we=typeof performance=="object"&&performance.now?performance:Date,ci=typeof window=="object"&&window.requestAnimationFrame?window.requestAnimationFrame.bind(window):function(t){setTimeout(t,17)};function Ce(){return Yt||(ci(lu),Yt=we.now()+er)}function lu(){Yt=0}function _e(){this._call=this._time=this._next=null}_e.prototype=rr.prototype={constructor:_e,restart:function(t,e,r){if(typeof t!="function")throw new TypeError("callback is not a function");r=(r==null?Ce():+r)+(e==null?0:+e),!this._next&&ve!==this&&(ve?ve._next=this:je=this,ve=this),this._call=t,this._time=r,Zr()},stop:function(){this._call&&(this._call=null,this._time=1/0,Zr())}};function rr(t,e,r){var n=new _e;return n.restart(t,e,r),n}function fi(){Ce(),++Ut;for(var t=je,e;t;)(e=Yt-t._time)>=0&&t._call.call(void 0,e),t=t._next;--Ut}function si(){Yt=(tr=we.now())+er,Ut=be=0;try{fi()}finally{Ut=0,uu(),Yt=0}}function su(){var t=we.now(),e=t-tr;e>ui&&(er-=e,tr=t)}function uu(){for(var t,e=je,r,n=1/0;e;)e._call?(n>e._time&&(n=e._time),t=e,e=e._next):(r=e._next,e._next=null,e=t?t._next=r:je=r);ve=t,Zr(n)}function Zr(t){if(!Ut){be&&(be=clearTimeout(be));var e=t-Yt;e>24?(t<1/0&&(be=setTimeout(si,t-we.now()-er)),xe&&(xe=clearInterval(xe))):(xe||(tr=we.now(),xe=setInterval(su,ui)),Ut=1,ci(si))}}function nr(t,e,r){var n=new _e;return e=e==null?0:+e,n.restart(o=>{n.stop(),t(o+e)},e,r),n}var cu=Rr("start","end","cancel","interrupt"),fu=[],di=0,mi=1,ir=2,or=3,pi=4,ar=5,Se=6;function wt(t,e,r,n,o,i){var a=t.__transition;if(!a)t.__transition={};else if(r in a)return;mu(t,r,{name:e,index:n,group:o,on:cu,tween:fu,time:i.time,delay:i.delay,duration:i.duration,ease:i.ease,timer:null,state:di})}function Me(t,e){var r=H(t,e);if(r.state>di)throw new Error("too late; already scheduled");return r}function W(t,e){var r=H(t,e);if(r.state>or)throw new Error("too late; already running");return r}function H(t,e){var r=t.__transition;if(!r||!(r=r[e]))throw new Error("transition not found");return r}function mu(t,e,r){var n=t.__transition,o;n[e]=r,r.timer=rr(i,0,r.time);function i(u){r.state=mi,r.timer.restart(a,r.delay,r.time),r.delay<=u&&a(u-r.delay)}function a(u){var f,c,p,m;if(r.state!==mi)return s();for(f in n)if(m=n[f],m.name===r.name){if(m.state===or)return nr(a);m.state===pi?(m.state=Se,m.timer.stop(),m.on.call("interrupt",t,t.__data__,m.index,m.group),delete n[f]):+f<e&&(m.state=Se,m.timer.stop(),m.on.call("cancel",t,t.__data__,m.index,m.group),delete n[f])}if(nr(function(){r.state===or&&(r.state=pi,r.timer.restart(l,r.delay,r.time),l(u))}),r.state=ir,r.on.call("start",t,t.__data__,r.index,r.group),r.state===ir){for(r.state=or,o=new Array(p=r.tween.length),f=0,c=-1;f<p;++f)(m=r.tween[f].value.call(t,t.__data__,r.index,r.group))&&(o[++c]=m);o.length=c+1}}function l(u){for(var f=u<r.duration?r.ease.call(null,u/r.duration):(r.timer.restart(s),r.state=ar,1),c=-1,p=o.length;++c<p;)o[c].call(t,f);r.state===ar&&(r.on.call("end",t,t.__data__,r.index,r.group),s())}function s(){r.state=Se,r.timer.stop(),delete n[e];for(var u in n)return;delete t.__transition}}function lr(t,e){var r=t.__transition,n,o,i=!0,a;if(r){e=e==null?null:e+"";for(a in r){if((n=r[a]).name!==e){i=!1;continue}o=n.state>ir&&n.state<ar,n.state=Se,n.timer.stop(),n.on.call(o?"interrupt":"cancel",t,t.__data__,n.index,n.group),delete r[a]}i&&delete t.__transition}}function hi(t){return this.each(function(){lr(this,t)})}function pu(t,e){var r,n;return function(){var o=W(this,t),i=o.tween;if(i!==r){n=r=i;for(var a=0,l=n.length;a<l;++a)if(n[a].name===e){n=n.slice(),n.splice(a,1);break}}o.tween=n}}function du(t,e,r){var n,o;if(typeof r!="function")throw new Error;return function(){var i=W(this,t),a=i.tween;if(a!==n){o=(n=a).slice();for(var l={name:e,value:r},s=0,u=o.length;s<u;++s)if(o[s].name===e){o[s]=l;break}s===u&&o.push(l)}i.tween=o}}function gi(t,e){var r=this._id;if(t+="",arguments.length<2){for(var n=H(this.node(),r).tween,o=0,i=n.length,a;o<i;++o)if((a=n[o]).name===t)return a.value;return null}return this.each((e==null?pu:du)(r,t,e))}function Gt(t,e,r){var n=t._id;return t.each(function(){var o=W(this,n);(o.value||(o.value={}))[e]=r.apply(this,arguments)}),function(o){return H(o,n).value[e]}}function sr(t,e){var r;return(typeof e=="number"?X:e instanceof L?st:(r=L(e))?(e=r,st):ye)(t,e)}function hu(t){return function(){this.removeAttribute(t)}}function gu(t){return function(){this.removeAttributeNS(t.space,t.local)}}function yu(t,e,r){var n,o=r+"",i;return function(){var a=this.getAttribute(t);return a===o?null:a===n?i:i=e(n=a,r)}}function xu(t,e,r){var n,o=r+"",i;return function(){var a=this.getAttributeNS(t.space,t.local);return a===o?null:a===n?i:i=e(n=a,r)}}function bu(t,e,r){var n,o,i;return function(){var a,l=r(this),s;return l==null?void this.removeAttribute(t):(a=this.getAttribute(t),s=l+"",a===s?null:a===n&&s===o?i:(o=s,i=e(n=a,l)))}}function vu(t,e,r){var n,o,i;return function(){var a,l=r(this),s;return l==null?void this.removeAttributeNS(t.space,t.local):(a=this.getAttributeNS(t.space,t.local),s=l+"",a===s?null:a===n&&s===o?i:(o=s,i=e(n=a,l)))}}function yi(t,e){var r=mt(t),n=r==="transform"?Qr:sr;return this.attrTween(t,typeof e=="function"?(r.local?vu:bu)(r,n,Gt(this,"attr."+t,e)):e==null?(r.local?gu:hu)(r):(r.local?xu:yu)(r,n,e))}function wu(t,e){return function(r){this.setAttribute(t,e.call(this,r))}}function _u(t,e){return function(r){this.setAttributeNS(t.space,t.local,e.call(this,r))}}function Cu(t,e){var r,n;function o(){var i=e.apply(this,arguments);return i!==n&&(r=(n=i)&&_u(t,i)),r}return o._value=e,o}function Su(t,e){var r,n;function o(){var i=e.apply(this,arguments);return i!==n&&(r=(n=i)&&wu(t,i)),r}return o._value=e,o}function xi(t,e){var r="attr."+t;if(arguments.length<2)return(r=this.tween(r))&&r._value;if(e==null)return this.tween(r,null);if(typeof e!="function")throw new Error;var n=mt(t);return this.tween(r,(n.local?Cu:Su)(n,e))}function Mu(t,e){return function(){Me(this,t).delay=+e.apply(this,arguments)}}function ku(t,e){return e=+e,function(){Me(this,t).delay=e}}function bi(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?Mu:ku)(e,t)):H(this.node(),e).delay}function Au(t,e){return function(){W(this,t).duration=+e.apply(this,arguments)}}function Du(t,e){return e=+e,function(){W(this,t).duration=e}}function vi(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?Au:Du)(e,t)):H(this.node(),e).duration}function Tu(t,e){if(typeof e!="function")throw new Error;return function(){W(this,t).ease=e}}function wi(t){var e=this._id;return arguments.length?this.each(Tu(e,t)):H(this.node(),e).ease}function Fu(t,e){return function(){var r=e.apply(this,arguments);if(typeof r!="function")throw new Error;W(this,t).ease=r}}function _i(t){if(typeof t!="function")throw new Error;return this.each(Fu(this._id,t))}function Ci(t){typeof t!="function"&&(t=ce(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var i=e[o],a=i.length,l=n[o]=[],s,u=0;u<a;++u)(s=i[u])&&t.call(s,s.__data__,u,i)&&l.push(s);return new K(n,this._parents,this._name,this._id)}function Si(t){if(t._id!==this._id)throw new Error;for(var e=this._groups,r=t._groups,n=e.length,o=r.length,i=Math.min(n,o),a=new Array(n),l=0;l<i;++l)for(var s=e[l],u=r[l],f=s.length,c=a[l]=new Array(f),p,m=0;m<f;++m)(p=s[m]||u[m])&&(c[m]=p);for(;l<n;++l)a[l]=e[l];return new K(a,this._parents,this._name,this._id)}function Eu(t){return(t+"").trim().split(/^|\s+/).every(function(e){var r=e.indexOf(".");return r>=0&&(e=e.slice(0,r)),!e||e==="start"})}function Nu(t,e,r){var n,o,i=Eu(e)?Me:W;return function(){var a=i(this,t),l=a.on;l!==n&&(o=(n=l).copy()).on(e,r),a.on=o}}function Mi(t,e){var r=this._id;return arguments.length<2?H(this.node(),r).on.on(t):this.each(Nu(r,t,e))}function Ou(t){return function(){var e=this.parentNode;for(var r in this.__transition)if(+r!==t)return;e&&e.removeChild(this)}}function ki(){return this.on("end.remove",Ou(this._id))}function Ai(t){var e=this._name,r=this._id;typeof t!="function"&&(t=Et(t));for(var n=this._groups,o=n.length,i=new Array(o),a=0;a<o;++a)for(var l=n[a],s=l.length,u=i[a]=new Array(s),f,c,p=0;p<s;++p)(f=l[p])&&(c=t.call(f,f.__data__,p,l))&&("__data__"in f&&(c.__data__=f.__data__),u[p]=c,wt(u[p],e,r,p,u,H(f,r)));return new K(i,this._parents,e,r)}function Di(t){var e=this._name,r=this._id;typeof t!="function"&&(t=ue(t));for(var n=this._groups,o=n.length,i=[],a=[],l=0;l<o;++l)for(var s=n[l],u=s.length,f,c=0;c<u;++c)if(f=s[c]){for(var p=t.call(f,f.__data__,c,s),m,h=H(f,r),g=0,w=p.length;g<w;++g)(m=p[g])&&wt(m,e,r,g,p,h);i.push(p),a.push(f)}return new K(i,a,e,r)}var Iu=pt.prototype.constructor;function Ti(){return new Iu(this._groups,this._parents)}function Yu(t,e){var r,n,o;return function(){var i=vt(this,t),a=(this.style.removeProperty(t),vt(this,t));return i===a?null:i===r&&a===n?o:o=e(r=i,n=a)}}function Fi(t){return function(){this.style.removeProperty(t)}}function Bu(t,e,r){var n,o=r+"",i;return function(){var a=vt(this,t);return a===o?null:a===n?i:i=e(n=a,r)}}function Ru(t,e,r){var n,o,i;return function(){var a=vt(this,t),l=r(this),s=l+"";return l==null&&(s=l=(this.style.removeProperty(t),vt(this,t))),a===s?null:a===n&&s===o?i:(o=s,i=e(n=a,l))}}function zu(t,e){var r,n,o,i="style."+e,a="end."+i,l;return function(){var s=W(this,t),u=s.on,f=s.value[i]==null?l||(l=Fi(e)):void 0;(u!==r||o!==f)&&(n=(r=u).copy()).on(a,o=f),s.on=n}}function Ei(t,e,r){var n=(t+="")=="transform"?Wr:sr;return e==null?this.styleTween(t,Yu(t,n)).on("end.style."+t,Fi(t)):typeof e=="function"?this.styleTween(t,Ru(t,n,Gt(this,"style."+t,e))).each(zu(this._id,t)):this.styleTween(t,Bu(t,n,e),r).on("end.style."+t,null)}function qu(t,e,r){return function(n){this.style.setProperty(t,e.call(this,n),r)}}function $u(t,e,r){var n,o;function i(){var a=e.apply(this,arguments);return a!==o&&(n=(o=a)&&qu(t,a,r)),n}return i._value=e,i}function Ni(t,e,r){var n="style."+(t+="");if(arguments.length<2)return(n=this.tween(n))&&n._value;if(e==null)return this.tween(n,null);if(typeof e!="function")throw new Error;return this.tween(n,$u(t,e,r??""))}function Pu(t){return function(){this.textContent=t}}function Lu(t){return function(){var e=t(this);this.textContent=e??""}}function Oi(t){return this.tween("text",typeof t=="function"?Lu(Gt(this,"text",t)):Pu(t==null?"":t+""))}function Hu(t){return function(e){this.textContent=t.call(this,e)}}function Vu(t){var e,r;function n(){var o=t.apply(this,arguments);return o!==r&&(e=(r=o)&&Hu(o)),e}return n._value=t,n}function Ii(t){var e="text";if(arguments.length<1)return(e=this.tween(e))&&e._value;if(t==null)return this.tween(e,null);if(typeof t!="function")throw new Error;return this.tween(e,Vu(t))}function Yi(){for(var t=this._name,e=this._id,r=ur(),n=this._groups,o=n.length,i=0;i<o;++i)for(var a=n[i],l=a.length,s,u=0;u<l;++u)if(s=a[u]){var f=H(s,e);wt(s,t,r,u,a,{time:f.time+f.delay+f.duration,delay:0,duration:f.duration,ease:f.ease})}return new K(n,this._parents,t,r)}function Bi(){var t,e,r=this,n=r._id,o=r.size();return new Promise(function(i,a){var l={value:a},s={value:function(){--o===0&&i()}};r.each(function(){var u=W(this,n),f=u.on;f!==t&&(e=(t=f).copy(),e._.cancel.push(l),e._.interrupt.push(l),e._.end.push(s)),u.on=e}),o===0&&i()})}var Uu=0;function K(t,e,r,n){this._groups=t,this._parents=e,this._name=r,this._id=n}function Ri(t){return pt().transition(t)}function ur(){return++Uu}var ht=pt.prototype;K.prototype=Ri.prototype={constructor:K,select:Ai,selectAll:Di,selectChild:ht.selectChild,selectChildren:ht.selectChildren,filter:Ci,merge:Si,selection:Ti,transition:Yi,call:ht.call,nodes:ht.nodes,node:ht.node,size:ht.size,empty:ht.empty,each:ht.each,on:Mi,attr:yi,attrTween:xi,style:Ei,styleTween:Ni,text:Oi,textTween:Ii,remove:ki,tween:gi,delay:bi,duration:vi,ease:wi,easeVarying:_i,end:Bi,[Symbol.iterator]:ht[Symbol.iterator]};function cr(t){return((t*=2)<=1?t*t*t:(t-=2)*t*t+2)/2}var Gu={time:null,delay:0,duration:250,ease:cr};function Xu(t,e){for(var r;!(r=t.__transition)||!(r=r[e]);)if(!(t=t.parentNode))throw new Error(`transition ${e} not found`);return r}function zi(t){var e,r;t instanceof K?(e=t._id,t=t._name):(e=ur(),(r=Gu).time=Ce(),t=t==null?null:t+"");for(var n=this._groups,o=n.length,i=0;i<o;++i)for(var a=n[i],l=a.length,s,u=0;u<l;++u)(s=a[u])&&wt(s,t,e,u,a,r||Xu(s,e));return new K(n,this._parents,t,e)}pt.prototype.interrupt=hi;pt.prototype.transition=zi;var{abs:Wy,max:Qy,min:Zy}=Math;function qi(t){return[+t[0],+t[1]]}function Wu(t){return[qi(t[0]),qi(t[1])]}var Jy={name:"x",handles:["w","e"].map(Jr),input:function(t,e){return t==null?null:[[+t[0],e[0][1]],[+t[1],e[1][1]]]},output:function(t){return t&&[t[0][0],t[1][0]]}},Ky={name:"y",handles:["n","s"].map(Jr),input:function(t,e){return t==null?null:[[e[0][0],+t[0]],[e[1][0],+t[1]]]},output:function(t){return t&&[t[0][1],t[1][1]]}},jy={name:"xy",handles:["n","w","e","s","nw","ne","sw","se"].map(Jr),input:function(t){return t==null?null:Wu(t)},output:function(t){return t}};function Jr(t){return{type:t}}function $i(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function Bt(t,e){if((r=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var r,n=t.slice(0,r);return[n.length>1?n[0]+n.slice(2):n,+t.slice(r+1)]}function ut(t){return t=Bt(Math.abs(t)),t?t[1]:NaN}function Pi(t,e){return function(r,n){for(var o=r.length,i=[],a=0,l=t[0],s=0;o>0&&l>0&&(s+l+1>n&&(l=Math.max(1,n-s)),i.push(r.substring(o-=l,o+l)),!((s+=l+1)>n));)l=t[a=(a+1)%t.length];return i.reverse().join(e)}}function Li(t){return function(e){return e.replace(/[0-9]/g,function(r){return t[+r]})}}var Qu=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function _t(t){if(!(e=Qu.exec(t)))throw new Error("invalid format: "+t);var e;return new fr({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}_t.prototype=fr.prototype;function fr(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}fr.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function Hi(t){t:for(var e=t.length,r=1,n=-1,o;r<e;++r)switch(t[r]){case".":n=o=r;break;case"0":n===0&&(n=r),o=r;break;default:if(!+t[r])break t;n>0&&(n=0);break}return n>0?t.slice(0,n)+t.slice(o+1):t}var Kr;function Vi(t,e){var r=Bt(t,e);if(!r)return t+"";var n=r[0],o=r[1],i=o-(Kr=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,a=n.length;return i===a?n:i>a?n+new Array(i-a+1).join("0"):i>0?n.slice(0,i)+"."+n.slice(i):"0."+new Array(1-i).join("0")+Bt(t,Math.max(0,e+i-1))[0]}function jr(t,e){var r=Bt(t,e);if(!r)return t+"";var n=r[0],o=r[1];return o<0?"0."+new Array(-o).join("0")+n:n.length>o+1?n.slice(0,o+1)+"."+n.slice(o+1):n+new Array(o-n.length+2).join("0")}var tn={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:$i,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>jr(t*100,e),r:jr,s:Vi,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function en(t){return t}var Ui=Array.prototype.map,Gi=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function Xi(t){var e=t.grouping===void 0||t.thousands===void 0?en:Pi(Ui.call(t.grouping,Number),t.thousands+""),r=t.currency===void 0?"":t.currency[0]+"",n=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",i=t.numerals===void 0?en:Li(Ui.call(t.numerals,String)),a=t.percent===void 0?"%":t.percent+"",l=t.minus===void 0?"\u2212":t.minus+"",s=t.nan===void 0?"NaN":t.nan+"";function u(c){c=_t(c);var p=c.fill,m=c.align,h=c.sign,g=c.symbol,w=c.zero,y=c.width,S=c.comma,_=c.precision,C=c.trim,b=c.type;b==="n"?(S=!0,b="g"):tn[b]||(_===void 0&&(_=12),C=!0,b="g"),(w||p==="0"&&m==="=")&&(w=!0,p="0",m="=");var M=g==="$"?r:g==="#"&&/[boxX]/.test(b)?"0"+b.toLowerCase():"",E=g==="$"?n:/[%p]/.test(b)?a:"",B=tn[b],q=/[defgprs%]/.test(b);_=_===void 0?6:/[gprs]/.test(b)?Math.max(1,Math.min(21,_)):Math.max(0,Math.min(20,_));function Q(x){var A=M,T=E,O,U,$;if(b==="c")T=B(x)+T,x="";else{x=+x;var z=x<0||1/x<0;if(x=isNaN(x)?s:B(Math.abs(x),_),C&&(x=Hi(x)),z&&+x==0&&h!=="+"&&(z=!1),A=(z?h==="("?h:l:h==="-"||h==="("?"":h)+A,T=(b==="s"?Gi[8+Kr/3]:"")+T+(z&&h==="("?")":""),q){for(O=-1,U=x.length;++O<U;)if($=x.charCodeAt(O),48>$||$>57){T=($===46?o+x.slice(O+1):x.slice(O))+T,x=x.slice(0,O);break}}}S&&!w&&(x=e(x,1/0));var Z=A.length+x.length+T.length,I=Z<y?new Array(y-Z+1).join(p):"";switch(S&&w&&(x=e(I+x,I.length?y-T.length:1/0),I=""),m){case"<":x=A+x+T+I;break;case"=":x=A+I+x+T;break;case"^":x=I.slice(0,Z=I.length>>1)+A+x+T+I.slice(Z);break;default:x=I+A+x+T;break}return i(x)}return Q.toString=function(){return c+""},Q}function f(c,p){var m=u((c=_t(c),c.type="f",c)),h=Math.max(-8,Math.min(8,Math.floor(ut(p)/3)))*3,g=Math.pow(10,-h),w=Gi[8+h/3];return function(y){return m(g*y)+w}}return{format:u,formatPrefix:f}}var mr,pr,dr;rn({thousands:",",grouping:[3],currency:["$",""]});function rn(t){return mr=Xi(t),pr=mr.format,dr=mr.formatPrefix,mr}function nn(t){return Math.max(0,-ut(Math.abs(t)))}function on(t,e){return Math.max(0,Math.max(-8,Math.min(8,Math.floor(ut(e)/3)))*3-ut(Math.abs(t)))}function an(t,e){return t=Math.abs(t),e=Math.abs(e)-t,Math.max(0,ut(e)-ut(t))+1}function Xt(t,e){switch(arguments.length){case 0:break;case 1:this.range(t);break;default:this.range(e).domain(t);break}return this}var ln=Symbol("implicit");function Rt(){var t=new bt,e=[],r=[],n=ln;function o(i){let a=t.get(i);if(a===void 0){if(n!==ln)return n;t.set(i,a=e.push(i)-1)}return r[a%r.length]}return o.domain=function(i){if(!arguments.length)return e.slice();e=[],t=new bt;for(let a of i)t.has(a)||t.set(a,e.push(a)-1);return o},o.range=function(i){return arguments.length?(r=Array.from(i),o):r.slice()},o.unknown=function(i){return arguments.length?(n=i,o):n},o.copy=function(){return Rt(e,r).unknown(n)},Xt.apply(o,arguments),o}function Wt(){var t=Rt().unknown(void 0),e=t.domain,r=t.range,n=0,o=1,i,a,l=!1,s=0,u=0,f=.5;delete t.unknown;function c(){var p=e().length,m=o<n,h=m?o:n,g=m?n:o;i=(g-h)/Math.max(1,p-s+u*2),l&&(i=Math.floor(i)),h+=(g-h-i*(p-s))*f,a=i*(1-s),l&&(h=Math.round(h),a=Math.round(a));var w=ze(p).map(function(y){return h+i*y});return r(m?w.reverse():w)}return t.domain=function(p){return arguments.length?(e(p),c()):e()},t.range=function(p){return arguments.length?([n,o]=p,n=+n,o=+o,c()):[n,o]},t.rangeRound=function(p){return[n,o]=p,n=+n,o=+o,l=!0,c()},t.bandwidth=function(){return a},t.step=function(){return i},t.round=function(p){return arguments.length?(l=!!p,c()):l},t.padding=function(p){return arguments.length?(s=Math.min(1,u=+p),c()):s},t.paddingInner=function(p){return arguments.length?(s=Math.min(1,p),c()):s},t.paddingOuter=function(p){return arguments.length?(u=+p,c()):u},t.align=function(p){return arguments.length?(f=Math.max(0,Math.min(1,p)),c()):f},t.copy=function(){return Wt(e(),[n,o]).round(l).paddingInner(s).paddingOuter(u).align(f)},Xt.apply(c(),arguments)}function sn(t){return function(){return t}}function un(t){return+t}var Wi=[0,1];function Qt(t){return t}function cn(t,e){return(e-=t=+t)?function(r){return(r-t)/e}:sn(isNaN(e)?NaN:.5)}function Zu(t,e){var r;return t>e&&(r=t,t=e,e=r),function(n){return Math.max(t,Math.min(e,n))}}function Ju(t,e,r){var n=t[0],o=t[1],i=e[0],a=e[1];return o<n?(n=cn(o,n),i=r(a,i)):(n=cn(n,o),i=r(i,a)),function(l){return i(n(l))}}function Ku(t,e,r){var n=Math.min(t.length,e.length)-1,o=new Array(n),i=new Array(n),a=-1;for(t[n]<t[0]&&(t=t.slice().reverse(),e=e.slice().reverse());++a<n;)o[a]=cn(t[a],t[a+1]),i[a]=r(e[a],e[a+1]);return function(l){var s=Fr(t,l,1,n)-1;return i[s](o[s](l))}}function Qi(t,e){return e.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown())}function ju(){var t=Wi,e=Wi,r=It,n,o,i,a=Qt,l,s,u;function f(){var p=Math.min(t.length,e.length);return a!==Qt&&(a=Zu(t[0],t[p-1])),l=p>2?Ku:Ju,s=u=null,c}function c(p){return p==null||isNaN(p=+p)?i:(s||(s=l(t.map(n),e,r)))(n(a(p)))}return c.invert=function(p){return a(o((u||(u=l(e,t.map(n),X)))(p)))},c.domain=function(p){return arguments.length?(t=Array.from(p,un),f()):t.slice()},c.range=function(p){return arguments.length?(e=Array.from(p),f()):e.slice()},c.rangeRound=function(p){return e=Array.from(p),r=Gr,f()},c.clamp=function(p){return arguments.length?(a=p?!0:Qt,f()):a!==Qt},c.interpolate=function(p){return arguments.length?(r=p,f()):r},c.unknown=function(p){return arguments.length?(i=p,c):i},function(p,m){return n=p,o=m,f()}}function fn(){return ju()(Qt,Qt)}function mn(t,e,r,n){var o=Er(t,e,r),i;switch(n=_t(n??",f"),n.type){case"s":{var a=Math.max(Math.abs(t),Math.abs(e));return n.precision==null&&!isNaN(i=on(o,a))&&(n.precision=i),dr(n,a)}case"":case"e":case"g":case"p":case"r":{n.precision==null&&!isNaN(i=an(o,Math.max(Math.abs(t),Math.abs(e))))&&(n.precision=i-(n.type==="e"));break}case"f":case"%":{n.precision==null&&!isNaN(i=nn(o))&&(n.precision=i-(n.type==="%")*2);break}}return pr(n)}function tc(t){var e=t.domain;return t.ticks=function(r){var n=e();return Be(n[0],n[n.length-1],r??10)},t.tickFormat=function(r,n){var o=e();return mn(o[0],o[o.length-1],r??10,n)},t.nice=function(r){r==null&&(r=10);var n=e(),o=0,i=n.length-1,a=n[o],l=n[i],s,u,f=10;for(l<a&&(u=a,a=l,l=u,u=o,o=i,i=u);f-- >0;){if(u=ae(a,l,r),u===s)return n[o]=a,n[i]=l,e(n);if(u>0)a=Math.floor(a/u)*u,l=Math.ceil(l/u)*u;else if(u<0)a=Math.ceil(a*u)/u,l=Math.floor(l*u)/u;else break;s=u}return t},t}function ke(){var t=fn();return t.copy=function(){return Qi(t,ke())},Xt.apply(t,arguments),tc(t)}function Ct(t,e,r){this.k=t,this.x=e,this.y=r}Ct.prototype={constructor:Ct,scale:function(t){return t===1?this:new Ct(this.k*t,this.x,this.y)},translate:function(t,e){return t===0&e===0?this:new Ct(this.k,this.x+this.k*t,this.y+this.k*e)},apply:function(t){return[t[0]*this.k+this.x,t[1]*this.k+this.y]},applyX:function(t){return t*this.k+this.x},applyY:function(t){return t*this.k+this.y},invert:function(t){return[(t[0]-this.x)/this.k,(t[1]-this.y)/this.k]},invertX:function(t){return(t-this.x)/this.k},invertY:function(t){return(t-this.y)/this.k},rescaleX:function(t){return t.copy().domain(t.range().map(this.invertX,this).map(t.invert,t))},rescaleY:function(t){return t.copy().domain(t.range().map(this.invertY,this).map(t.invert,t))},toString:function(){return"translate("+this.x+","+this.y+") scale("+this.k+")"}};var pn=new Ct(1,0,0);dn.prototype=Ct.prototype;function dn(t){for(;!t.__zoom;)if(!(t=t.parentNode))return pn;return t.__zoom}var R={selectedBars:new Set};function Zi(t,e="#ffffff"){let r=L(t??e)??L(e);return lt(r?.toString()??e)}function rc(t){let e=r=>{let n=r/255;return n<=.03928?n/12.92:Math.pow((n+.055)/1.055,2.4)};return .2126*e(t.r)+.7152*e(t.g)+.0722*e(t.b)}function gt(t,e=.2){let r=L(t);return r?st(r,"#ffffff")(Math.min(1,Math.max(0,e))):t}function zt(t,e=.2){let r=L(t);return r?st(r,"#000000")(Math.min(1,Math.max(0,e))):t}function nc(t,e,r){if(r<=t.length)return t.slice(0,r);let n=[...t],o=[.15,-.15,.3,-.3,.45,-.45,.6,-.6],i=0;for(;n.length<r;){let a=o[i%o.length],l=Math.min(.85,Math.abs(a)),s=a>=0?gt(e,l):zt(e,l);n.push(s),i++}return n.slice(0,r)}function hn(t){let e=t?.itemsBackground||"#ffffff",r=Zi(e),n=rc(r),o=n<.45?"#f8fafc":"#1f2937",i=n<.45?gt(e,.25):zt(e,.15),a=L(i)?.formatHex()??"#d1d5db",l=(t?.colors??[]).filter(Boolean),s=t?.mainColor||l[0],u='-apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif',f=Math.max(2,Math.min(16,t?.itemSpecific?.rounding??8)),c=t?.itemSpecific?.padding,p=typeof c=="number"?Math.max(.05,Math.min(.35,c/100)):.18,m=L(zt(s,.55))??lt(15,23,42),h=L(s)??lt(99,102,241),g=`rgba(${m.r}, ${m.g}, ${m.b}, ${n<.45?.55:.25})`,w=`rgba(${h.r}, ${h.g}, ${h.b}, ${n<.45?.55:.35})`,y=t?.tooltip?.background||(n<.45?gt(e,.18):zt(e,.35)),S=Zi(y),_=`rgba(${S.r}, ${S.g}, ${S.b}, 0.70)`,C=n<.45?"#0f172a":"#f8fafc",b=n<.45?gt(e,.22):zt(e,.08),M=b,E=n<.45?gt(b,.12):zt(b,.12),B=n<.45?gt(b,.18):zt(b,.18);return{backgroundColor:e,axisTextColor:o,axisLineColor:a,fontFamily:u,basePalette:l,mainColor:s,barRounding:f,barPadding:p,hoverShadow:g,selectedShadow:w,tooltipBackground:_,tooltipColor:C,controlBackground:M,controlBorder:E,controlText:o,controlHoverBackground:B}}function oc(t){let e={type:"customEvent",data:t};window.parent.postMessage(e,"*")}function Ji(t){let e={type:"setFilter",filters:t};window.parent.postMessage(e,"*")}function Ki(t,e){let a=e-60-30,l=Math.max(1,Math.floor(a/140));return Math.ceil(t.length/l)*24}var ic=({container:t,data:e=[],slots:r=[],slotConfigurations:n=[],options:o={},language:i="en",dimensions:{width:a,height:l}={width:0,height:0}})=>{let s=hn(o.theme);t.__themeContext=s;let u=ta(t,s);R.categorySlot=r.find(C=>C.name==="category"),R.measureSlot=r.find(C=>C.name==="measure"),R.groupSlot=r.find(C=>C.name==="legend");let f=R.measureSlot?.content?.[0]?Lt(R.measureSlot.content[0]):C=>new Intl.NumberFormat(i).format(C),c=R.categorySlot?.content?.length>0,p=R.measureSlot?.content?.length>0,m=[];if(!e.length||!c||!p){let C=["Product A","Product B","Product C","Product D","Product E"],b=["Region 1","Region 2","Region 3"],M=[];for(let E=0;E<C.length;E++)for(let B=0;B<b.length;B++){let q=Math.floor(Math.random()*800)+200;M.push({category:C[E],group:b[B],value:f(q),rawValue:q,columnId:`column_${E}_${B}`,datasetId:`dataset_${E}_${B}`})}m=M}else m=lc(e,R.measureSlot,R.categorySlot,R.groupSlot,f);let h=Array.from(new Set(m.map(C=>C.group))),y={top:40+(h.length>1||h.length===1&&h[0]!=="Default"?Ki(h,a):0),right:30,bottom:60,left:60},S=a-y.left-y.right,_=l-y.top-y.bottom;ji(u,m,a,l,y,S,_,s,f),t.__chartData=m},ac=({container:t,slots:e=[],slotConfigurations:r=[],options:n={},language:o="en",dimensions:{width:i,height:a}={width:0,height:0}})=>{let l=t.__chartData||[],s=t.__themeContext,u=n.theme?hn(n.theme):s??hn(void 0);t.__themeContext=u;let f=R.measureSlot?.content?.[0]?Lt(R.measureSlot.content[0]):S=>new Intl.NumberFormat(o).format(S),c=ta(t,u),p=Array.from(new Set(l.map(S=>S.group))),g={top:40+(p.length>1||p.length===1&&p[0]!=="Default"?Ki(p,i):0),right:30,bottom:60,left:60},w=i-g.left-g.right,y=a-g.top-g.bottom;ji(c,l,i,a,g,w,y,u,f),t.__chartData=l};function ji(t,e,r,n,o,i,a,l,s){let u=dt(t).append("svg").attr("width",r).attr("height",n).attr("class","bar-chart-svg");l.fontFamily&&u.style("font-family",l.fontFamily);let f=u.append("g").attr("transform",`translate(${o.left},${o.top})`),c=Ie(e,A=>A.category),p=Array.from(c.keys()),m=Array.from(new Set(e.map(A=>A.group))),h=nc(l.basePalette,l.mainColor,Math.max(m.length,1)),g=Rt().domain(m).range(h),w=Wt().domain(p).range([0,i]).padding(l.barPadding),y=m.length>1||m.length===1&&m[0]!=="Default",S=Wt().domain(m).range([0,Math.max(w.bandwidth(),0)]).padding(y?Math.min(.35,l.barPadding*.6):.08),_=y?S.bandwidth():w.bandwidth(),C=Math.min(l.barRounding,Math.max(_,0)/2),b=Re(e,A=>A.rawValue)||0,M=ke().domain([0,b===0?1:b*1.1]).range([a,0]).nice(),E=f.append("g").attr("class","axis x-axis").attr("transform",`translate(0,${a})`).call(Yr(w).tickSizeOuter(0));E.selectAll("text").attr("transform","rotate(-45)").style("text-anchor","end").attr("dx","-.8em").attr("dy",".15em").style("fill",l.axisTextColor),l.fontFamily&&E.selectAll("text").style("font-family",l.fontFamily),E.selectAll("line").attr("stroke",l.axisLineColor),E.selectAll("path").attr("stroke",l.axisLineColor);let B=Br(M).ticks(6).tickSize(-i).tickSizeOuter(0).tickFormat(A=>s(Number(A))),q=f.append("g").attr("class","axis y-axis").call(B);q.selectAll("text").style("fill",l.axisTextColor),l.fontFamily&&q.selectAll("text").style("font-family",l.fontFamily),q.selectAll("line").attr("stroke",l.axisLineColor).attr("stroke-dasharray","2,4"),q.selectAll("path").attr("stroke",l.axisLineColor);let Q=dt(t).append("div").attr("class","tooltip").style("opacity",0).style("background-color",l.tooltipBackground).style("color",l.tooltipColor).style("box-shadow",`0 12px 24px ${l.hoverShadow}`);if(p.forEach(A=>{let T=e.filter(O=>O.category===A);m.forEach(O=>{let U=T.find(J=>J.group===O);if(!U)return;let $=`${A}-${O}`,z=g(O),Z=(w(A)??0)+(y?S(O)??0:0),I=y?S.bandwidth():w.bandwidth(),Zt=a-M(U.rawValue);f.append("rect").attr("class","bar").attr("data-bar-id",$).attr("data-base-fill",z).attr("x",Z).attr("y",M(U.rawValue)).attr("width",I).attr("height",Zt).attr("fill",z).attr("rx",C).attr("ry",C).on("mouseover",function(J){let nt=dt(this),ct=nt.attr("data-base-fill")||z,Kt=gt(ct,.18);nt.raise().attr("fill",Kt).style("filter",`drop-shadow(0 12px 20px ${l.hoverShadow})`);let Ae=r/2,St=16,k=J.offsetX>=Ae?Math.max(0,J.offsetX-200-St):J.offsetX+St;Q.interrupt().style("opacity",1).html(`<div class="tooltip-title">${A}</div><div class="tooltip-row"><span>${O}</span><span>${U.value}</span></div>`).style("left",`${k}px`).style("top",`${Math.max(0,J.offsetY-56)}px`)}).on("mouseout",function(){let J=dt(this),nt=J.attr("data-base-fill")||z,ct=J.attr("data-bar-id");(ct?R.selectedBars.has(ct):!1)?J.attr("fill",gt(nt,.25)).style("filter",`drop-shadow(0 18px 32px ${l.selectedShadow})`):J.attr("fill",nt).style("filter","none"),Q.transition().duration(120).style("opacity",0)}).on("click",function(J){J.stopPropagation();let nt=dt(this),ct=nt.attr("data-base-fill")||z;R.selectedBars.has($)?R.selectedBars.delete($):R.selectedBars.add($),R.selectedBars.has($)?nt.classed("bar-selected",!0).attr("fill",gt(ct,.25)).attr("stroke",l.axisTextColor).attr("stroke-width",1.25).style("filter",`drop-shadow(0 20px 36px ${l.selectedShadow})`):nt.classed("bar-selected",!1).attr("fill",ct).attr("stroke","none").attr("stroke-width",0).style("filter","none"),dt(t).select(".clear-filter-btn").classed("visible",R.selectedBars.size>0);let St=[],Mt=new Map;Array.from(R.selectedBars).forEach(v=>{let[k]=v.split("-"),D=R.categorySlot?.content[0];if(!D)return;let d=`${D.columnId||D.column}:${D.datasetId||D.set}`;Mt.has(d)||Mt.set(d,new Set),Mt.get(d)?.add(k)}),Mt.forEach((v,k)=>{let[D,d]=k.split(":"),P=Array.from(v);St.push({expression:P.length>1?"? in ?":"? = ?",parameters:[{column_id:D,dataset_id:d,level:R.categorySlot?.content[0]?.level||void 0},P.length>1?P:P[0]],properties:{origin:"filterFromVizItem",type:"where"}})}),Ji(St),oc({category:A,group:O,value:U.value,rawValue:U.rawValue})})})}),y){let U=Math.max(1,Math.floor(i/140)),$=u.append("g").attr("class","legend").attr("transform",`translate(${o.left}, ${Math.max(16,20)})`);m.forEach((z,Z)=>{let I=Math.floor(Z/U),Zt=Z%U,Jt=$.append("g").attr("class","legend-item").attr("transform",`translate(${Zt*140}, ${I*24})`);Jt.append("rect").attr("class","legend-color").attr("x",0).attr("y",-9).attr("width",14).attr("height",14).attr("rx",Math.max(C/2,2)).attr("ry",Math.max(C/2,2)).attr("fill",g(z)),Jt.append("text").attr("x",20).attr("y",2).style("fill",l.axisTextColor).style("font-size","12px").style("font-weight",500).text(z)})}}function ta(t,e){t.innerHTML="",t.style.background=e.backgroundColor;let r=document.createElement("div");r.className="bar-chart-container",r.style.background=e.backgroundColor,r.style.setProperty("--chart-background",e.backgroundColor),r.style.setProperty("--axis-text-color",e.axisTextColor),r.style.setProperty("--axis-line-color",e.axisLineColor),r.style.setProperty("--control-bg",e.controlBackground),r.style.setProperty("--control-border",e.controlBorder),r.style.setProperty("--control-text",e.controlText),r.style.setProperty("--control-hover-bg",e.controlHoverBackground),r.style.setProperty("--hover-shadow",e.hoverShadow),r.style.setProperty("--selected-shadow",e.selectedShadow),r.style.setProperty("--tooltip-bg",e.tooltipBackground),r.style.setProperty("--tooltip-color",e.tooltipColor),r.style.setProperty("--bar-radius",`${e.barRounding}px`),r.style.setProperty("--chart-font-family",e.fontFamily),e.fontFamily&&(r.style.fontFamily=e.fontFamily),t.appendChild(r);let n=document.createElement("button");return n.className="clear-filter-btn",n.textContent="Clear Filters",n.onclick=()=>{R.selectedBars.clear(),$r(".bar").classed("bar-selected",!1).each(function(){let o=dt(this),i=o.attr("data-base-fill");i&&o.attr("fill",i),o.attr("stroke","none").attr("stroke-width",0).style("filter","none")}),n.classList.remove("visible"),Ji([])},r.appendChild(n),r}function lc(t,e,r,n,o){let i={category:r?.content[0]?Lt(r.content[0],{level:r.content[0].level||9}):s=>String(s),group:n?.content[0]?Lt(n.content[0],{level:n.content[0].level||9}):s=>String(s)},a=n?.content?.length>0,l={category:0,group:a?1:-1,measure:a?2:1};return(t??[]).map(s=>{let u=s[l.category]?.name?.en||s[l.category]||"Unknown",f=i.category(r.content[0].type==="datetime"?new Date(u):u),c=s[l.group]?.name?.en||s[l.group]||"Default",p=a?i.group(n.content[0].type==="datetime"?new Date(c):c):"Default",m=Number(s[l.measure])||0,h=o(m);return{category:String(f),group:String(p),value:h,rawValue:m,columnId:s[l.measure]?.columnId,datasetId:s[l.measure]?.datasetId}})}export{ic as render,ac as resize};
/*! Bundled license information:

@luzmo/analytics-components-kit/components/decompose-numeric-format-BuZcjH2k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/localize-BX7q0S0M.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/formatter-CQDms6fU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/area-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bar-chart-slots.config-MQAjNXqV.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/box-plot-slots.config-BRhnF2FE.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bubble-chart-slots.config-Bbh94VgZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bullet-chart-slots.config-BlWTleBt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/choropleth-map-slots.config-B-uJTj4q.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circle-pack-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circular-gauge-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/column-chart-slots.config-DAdAk17k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/combination-chart-slots.config-CqKLFKCZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/conditional-number-slots.config-L3t5pb1-.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/date-filter-slots.config-CxB8IF5B.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/donut-chart-slots.config-BEwhfq27.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/dropdown-filter-slots.config-B8J6ftCh.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/evolution-number-slots.config-CW21b2ua.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/funnel-chart-slots.config-BBhMS2qi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-table-slots.config-DJkP72oT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/hexbin-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/image-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/line-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/marker-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/ohlc-chart-slots.config-Cvy5n1xv.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/parallel-coordinates-plot-slots.config-CQW2CJW6.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pivot-table-slots.config-BH5fOJre.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pyramid-chart-slots.config-Cm9bQsXT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/radar-chart-slots.config-Dpmytmc3.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/regular-table-slots.config-EUS-V9lL.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/route-map-slots.config-DYCcaQZi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sankey-diagram-slots.config-BSTBEZDe.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/scatter-plot-slots.config-BuWYqDWK.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/search-filter-slots.config-DmiVXOva.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slicer-filter-slots.config-CHQ0ZXga.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slider-filter-slots.config-BN3K1rnl.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/speedometer-chart-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/spike-map-slots.config-CuqpgkvN.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/strip-plot-slots.config-Co8ghEv8.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sunburst-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/symbol-map-slots.config-C5CKaVED.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/text-slots.config-Hy5yNIAX.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/treemap-chart-slots.config-xLD22K9V.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/venn-diagram-slots.config-DPmj71cR.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/video-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/wordcloud-chart-slots.config-BS4sOOHt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/index-BEAYzHcY.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/utils.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)
*/
