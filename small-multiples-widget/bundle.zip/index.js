function jr(t){let e=/(?:([^{])?([<>=^]))?([+\- \()])?([$#])?(0)?(\d+)?([,_])?(\.-?\d+)?([a-z%]{1,2})?/i.exec(t)??[];return{fill:e[1]||" ",align:e[2]||">",sign:e[3]||"-",symbol:e[4]||"",zfill:e[5],width:+e[6],comma:e[7],precision:e[8],typeFormat:e[9]}}function Gt(t){return t==null}function to(t){return typeof t=="string"||t instanceof String}function cn(t){return!Number.isNaN(t)&&Number.isFinite(t)}function Hl(t){return typeof t=="boolean"}function ql(t){return t!==null&&typeof t=="object"&&!Array.isArray(t)}function Pl(t){return t!==null&&typeof t=="object"&&Object.keys(t).length===0}function eo(t,e,n){if(to(t)||cn(t)||Hl(t))return t.toString();if(Gt(t)||!ql(t)||Pl(t))return"";let r="",o=Object.keys(t);return n!=null&&n.allowEmpty?(e&&t[e]!==void 0&&(r=t[e]),r===void 0&&(r="")):(e&&t[e]&&(r=t[e]),(Gt(r)||r==="")&&o!=null&&o.length&&(r=t[o[0]])),r}function Vl(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function Wn(t,e){if((n=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var n,r=t.slice(0,n);return[r.length>1?r[0]+r.slice(2):r,+t.slice(n+1)]}function Wl(t){return t=Wn(Math.abs(t)),t?t[1]:NaN}function Gl(t,e){return function(n,r){for(var o=n.length,a=[],i=0,s=t[0],u=0;o>0&&s>0&&(u+s+1>r&&(s=Math.max(1,r-u)),a.push(n.substring(o-=s,o+s)),!((u+=s+1)>r));)s=t[i=(i+1)%t.length];return a.reverse().join(e)}}function Xl(t){return function(e){return e.replace(/[0-9]/g,function(n){return t[+n]})}}var Ql=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function io(t){if(!(e=Ql.exec(t)))throw new Error("invalid format: "+t);var e;return new uo({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}io.prototype=uo.prototype;function uo(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}uo.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function Zl(t){t:for(var e=t.length,n=1,r=-1,o;n<e;++n)switch(t[n]){case".":r=o=n;break;case"0":r===0&&(r=n),o=n;break;default:if(!+t[n])break t;r>0&&(r=0);break}return r>0?t.slice(0,r)+t.slice(o+1):t}var Na;function Jl(t,e){var n=Wn(t,e);if(!n)return t+"";var r=n[0],o=n[1],a=o-(Na=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,i=r.length;return a===i?r:a>i?r+new Array(a-i+1).join("0"):a>0?r.slice(0,a)+"."+r.slice(a):"0."+new Array(1-a).join("0")+Wn(t,Math.max(0,e+a-1))[0]}function ba(t,e){var n=Wn(t,e);if(!n)return t+"";var r=n[0],o=n[1];return o<0?"0."+new Array(-o).join("0")+r:r.length>o+1?r.slice(0,o+1)+"."+r.slice(o+1):r+new Array(o-r.length+2).join("0")}var va={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:Vl,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>ba(t*100,e),r:ba,s:Jl,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function wa(t){return t}var Sa=Array.prototype.map,Ma=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function Kl(t){var e=t.grouping===void 0||t.thousands===void 0?wa:Gl(Sa.call(t.grouping,Number),t.thousands+""),n=t.currency===void 0?"":t.currency[0]+"",r=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",a=t.numerals===void 0?wa:Xl(Sa.call(t.numerals,String)),i=t.percent===void 0?"%":t.percent+"",s=t.minus===void 0?"\u2212":t.minus+"",u=t.nan===void 0?"NaN":t.nan+"";function l(c){c=io(c);var m=c.fill,d=c.align,b=c.sign,M=c.symbol,h=c.zero,g=c.width,T=c.comma,x=c.precision,_=c.trim,v=c.type;v==="n"?(T=!0,v="g"):va[v]||(x===void 0&&(x=12),_=!0,v="g"),(h||m==="0"&&d==="=")&&(h=!0,m="0",d="=");var w=M==="$"?n:M==="#"&&/[boxX]/.test(v)?"0"+v.toLowerCase():"",O=M==="$"?r:/[%p]/.test(v)?i:"",R=va[v],st=/[defgprs%]/.test(v);x=x===void 0?6:/[gprs]/.test(v)?Math.max(1,Math.min(21,x)):Math.max(0,Math.min(20,x));function q(S){var H=w,Y=O,Z,gt,G;if(v==="c")Y=R(S)+Y,S="";else{S=+S;var K=S<0||1/S<0;if(S=isNaN(S)?u:R(Math.abs(S),x),_&&(S=Zl(S)),K&&+S==0&&b!=="+"&&(K=!1),H=(K?b==="("?b:s:b==="-"||b==="("?"":b)+H,Y=(v==="s"?Ma[8+Na/3]:"")+Y+(K&&b==="("?")":""),st){for(Z=-1,gt=S.length;++Z<gt;)if(G=S.charCodeAt(Z),48>G||G>57){Y=(G===46?o+S.slice(Z+1):S.slice(Z))+Y,S=S.slice(0,Z);break}}}T&&!h&&(S=e(S,1/0));var ht=H.length+S.length+Y.length,B=ht<g?new Array(g-ht+1).join(m):"";switch(T&&h&&(S=e(B+S,B.length?g-Y.length:1/0),B=""),d){case"<":S=H+S+Y+B;break;case"=":S=H+B+S+Y;break;case"^":S=B.slice(0,ht=B.length>>1)+H+S+Y+B.slice(ht);break;default:S=B+H+S+Y;break}return a(S)}return q.toString=function(){return c+""},q}function f(c,m){var d=l((c=io(c),c.type="f",c)),b=Math.max(-8,Math.min(8,Math.floor(Wl(m)/3)))*3,M=Math.pow(10,-b),h=Ma[8+b/3];return function(g){return d(M*g)+h}}return{format:l,formatPrefix:f}}var no=new Date,ro=new Date;function At(t,e,n,r){function o(a){return t(a=arguments.length===0?new Date:new Date(+a)),a}return o.floor=a=>(t(a=new Date(+a)),a),o.ceil=a=>(t(a=new Date(a-1)),e(a,1),t(a),a),o.round=a=>{let i=o(a),s=o.ceil(a);return a-i<s-a?i:s},o.offset=(a,i)=>(e(a=new Date(+a),i==null?1:Math.floor(i)),a),o.range=(a,i,s)=>{let u=[];if(a=o.ceil(a),s=s==null?1:Math.floor(s),!(a<i)||!(s>0))return u;let l;do u.push(l=new Date(+a)),e(a,s),t(a);while(l<a&&a<i);return u},o.filter=a=>At(i=>{if(i>=i)for(;t(i),!a(i);)i.setTime(i-1)},(i,s)=>{if(i>=i)if(s<0)for(;++s<=0;)for(;e(i,-1),!a(i););else for(;--s>=0;)for(;e(i,1),!a(i););}),n&&(o.count=(a,i)=>(no.setTime(+a),ro.setTime(+i),t(no),t(ro),Math.floor(n(no,ro))),o.every=a=>(a=Math.floor(a),!isFinite(a)||!(a>0)?null:a>1?o.filter(r?i=>r(i)%a===0:i=>o.count(0,i)%a===0):o)),o}var dn=1e3,ue=dn*60,hn=ue*60,gn=hn*24,Oa=gn*7,Ua=At(t=>{t.setTime(t-t.getMilliseconds())},(t,e)=>{t.setTime(+t+e*dn)},(t,e)=>(e-t)/dn,t=>t.getUTCSeconds());Ua.range;var Ra=At(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*dn)},(t,e)=>{t.setTime(+t+e*ue)},(t,e)=>(e-t)/ue,t=>t.getMinutes());Ra.range;var jl=At(t=>{t.setUTCSeconds(0,0)},(t,e)=>{t.setTime(+t+e*ue)},(t,e)=>(e-t)/ue,t=>t.getUTCMinutes());jl.range;var Ba=At(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*dn-t.getMinutes()*ue)},(t,e)=>{t.setTime(+t+e*hn)},(t,e)=>(e-t)/hn,t=>t.getHours());Ba.range;var tu=At(t=>{t.setUTCMinutes(0,0,0)},(t,e)=>{t.setTime(+t+e*hn)},(t,e)=>(e-t)/hn,t=>t.getUTCHours());tu.range;var Qn=At(t=>t.setHours(0,0,0,0),(t,e)=>t.setDate(t.getDate()+e),(t,e)=>(e-t-(e.getTimezoneOffset()-t.getTimezoneOffset())*ue)/gn,t=>t.getDate()-1);Qn.range;var co=At(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/gn,t=>t.getUTCDate()-1);co.range;var eu=At(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/gn,t=>Math.floor(t/gn));eu.range;function we(t){return At(e=>{e.setDate(e.getDate()-(e.getDay()+7-t)%7),e.setHours(0,0,0,0)},(e,n)=>{e.setDate(e.getDate()+n*7)},(e,n)=>(n-e-(n.getTimezoneOffset()-e.getTimezoneOffset())*ue)/Oa)}var fo=we(0),Gn=we(1),nu=we(2),ru=we(3),Pe=we(4),ou=we(5),au=we(6);fo.range;Gn.range;nu.range;ru.range;Pe.range;ou.range;au.range;function Se(t){return At(e=>{e.setUTCDate(e.getUTCDate()-(e.getUTCDay()+7-t)%7),e.setUTCHours(0,0,0,0)},(e,n)=>{e.setUTCDate(e.getUTCDate()+n*7)},(e,n)=>(n-e)/Oa)}var $a=Se(0),Xn=Se(1),iu=Se(2),su=Se(3),Ve=Se(4),lu=Se(5),uu=Se(6);$a.range;Xn.range;iu.range;su.range;Ve.range;lu.range;uu.range;var za=At(t=>{t.setDate(1),t.setHours(0,0,0,0)},(t,e)=>{t.setMonth(t.getMonth()+e)},(t,e)=>e.getMonth()-t.getMonth()+(e.getFullYear()-t.getFullYear())*12,t=>t.getMonth());za.range;var cu=At(t=>{t.setUTCDate(1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCMonth(t.getUTCMonth()+e)},(t,e)=>e.getUTCMonth()-t.getUTCMonth()+(e.getUTCFullYear()-t.getUTCFullYear())*12,t=>t.getUTCMonth());cu.range;var ce=At(t=>{t.setMonth(0,1),t.setHours(0,0,0,0)},(t,e)=>{t.setFullYear(t.getFullYear()+e)},(t,e)=>e.getFullYear()-t.getFullYear(),t=>t.getFullYear());ce.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:At(e=>{e.setFullYear(Math.floor(e.getFullYear()/t)*t),e.setMonth(0,1),e.setHours(0,0,0,0)},(e,n)=>{e.setFullYear(e.getFullYear()+n*t)});ce.range;var ve=At(t=>{t.setUTCMonth(0,1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCFullYear(t.getUTCFullYear()+e)},(t,e)=>e.getUTCFullYear()-t.getUTCFullYear(),t=>t.getUTCFullYear());ve.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:At(e=>{e.setUTCFullYear(Math.floor(e.getUTCFullYear()/t)*t),e.setUTCMonth(0,1),e.setUTCHours(0,0,0,0)},(e,n)=>{e.setUTCFullYear(e.getUTCFullYear()+n*t)});ve.range;function oo(t){if(0<=t.y&&t.y<100){var e=new Date(-1,t.m,t.d,t.H,t.M,t.S,t.L);return e.setFullYear(t.y),e}return new Date(t.y,t.m,t.d,t.H,t.M,t.S,t.L)}function ao(t){if(0<=t.y&&t.y<100){var e=new Date(Date.UTC(-1,t.m,t.d,t.H,t.M,t.S,t.L));return e.setUTCFullYear(t.y),e}return new Date(Date.UTC(t.y,t.m,t.d,t.H,t.M,t.S,t.L))}function fn(t,e,n){return{y:t,m:e,d:n,H:0,M:0,S:0,L:0}}function so(t){var e=t.dateTime,n=t.date,r=t.time,o=t.periods,a=t.days,i=t.shortDays,s=t.months,u=t.shortMonths,l=mn(o),f=pn(o),c=mn(a),m=pn(a),d=mn(i),b=pn(i),M=mn(s),h=pn(s),g=mn(u),T=pn(u),x={a:K,A:ht,b:B,B:ft,c:null,d:Fa,e:Fa,f:Iu,g:qu,G:Vu,H:Au,I:Eu,j:Yu,L:La,m:Nu,M:Ou,p:mt,q:pt,Q:Ya,s:Ia,S:Uu,u:Ru,U:Bu,V:$u,w:zu,W:Lu,x:null,X:null,y:Hu,Y:Pu,Z:Wu,"%":Ea},_={a:Pt,A:Vt,b:E,B:j,c:null,d:Aa,e:Aa,f:Zu,g:ic,G:lc,H:Gu,I:Xu,j:Qu,L:qa,m:Ju,M:Ku,p:X,q:P,Q:Ya,s:Ia,S:ju,u:tc,U:ec,V:nc,w:rc,W:oc,x:null,X:null,y:ac,Y:sc,Z:uc,"%":Ea},v={a:q,A:S,b:H,B:Y,c:Z,d:ka,e:ka,f:Tu,g:Ta,G:_a,H:Da,I:Da,j:Su,L:_u,m:wu,M:Mu,p:st,q:vu,Q:Du,s:Fu,S:Cu,u:hu,U:gu,V:yu,w:du,W:xu,x:gt,X:G,y:Ta,Y:_a,Z:bu,"%":ku};x.x=w(n,x),x.X=w(r,x),x.c=w(e,x),_.x=w(n,_),_.X=w(r,_),_.c=w(e,_);function w(y,C){return function(k){var p=[],L=-1,A=0,V=y.length,I,D,U;for(k instanceof Date||(k=new Date(+k));++L<V;)y.charCodeAt(L)===37&&(p.push(y.slice(A,L)),(D=Ca[I=y.charAt(++L)])!=null?I=y.charAt(++L):D=I==="e"?" ":"0",(U=C[I])&&(I=U(k,D)),p.push(I),A=L+1);return p.push(y.slice(A,L)),p.join("")}}function O(y,C){return function(k){var p=fn(1900,void 0,1),L=R(p,y,k+="",0),A,V;if(L!=k.length)return null;if("Q"in p)return new Date(p.Q);if("s"in p)return new Date(p.s*1e3+("L"in p?p.L:0));if(C&&!("Z"in p)&&(p.Z=0),"p"in p&&(p.H=p.H%12+p.p*12),p.m===void 0&&(p.m="q"in p?p.q:0),"V"in p){if(p.V<1||p.V>53)return null;"w"in p||(p.w=1),"Z"in p?(A=ao(fn(p.y,0,1)),V=A.getUTCDay(),A=V>4||V===0?Xn.ceil(A):Xn(A),A=co.offset(A,(p.V-1)*7),p.y=A.getUTCFullYear(),p.m=A.getUTCMonth(),p.d=A.getUTCDate()+(p.w+6)%7):(A=oo(fn(p.y,0,1)),V=A.getDay(),A=V>4||V===0?Gn.ceil(A):Gn(A),A=Qn.offset(A,(p.V-1)*7),p.y=A.getFullYear(),p.m=A.getMonth(),p.d=A.getDate()+(p.w+6)%7)}else("W"in p||"U"in p)&&("w"in p||(p.w="u"in p?p.u%7:"W"in p?1:0),V="Z"in p?ao(fn(p.y,0,1)).getUTCDay():oo(fn(p.y,0,1)).getDay(),p.m=0,p.d="W"in p?(p.w+6)%7+p.W*7-(V+5)%7:p.w+p.U*7-(V+6)%7);return"Z"in p?(p.H+=p.Z/100|0,p.M+=p.Z%100,ao(p)):oo(p)}}function R(y,C,k,p){for(var L=0,A=C.length,V=k.length,I,D;L<A;){if(p>=V)return-1;if(I=C.charCodeAt(L++),I===37){if(I=C.charAt(L++),D=v[I in Ca?C.charAt(L++):I],!D||(p=D(y,k,p))<0)return-1}else if(I!=k.charCodeAt(p++))return-1}return p}function st(y,C,k){var p=l.exec(C.slice(k));return p?(y.p=f.get(p[0].toLowerCase()),k+p[0].length):-1}function q(y,C,k){var p=d.exec(C.slice(k));return p?(y.w=b.get(p[0].toLowerCase()),k+p[0].length):-1}function S(y,C,k){var p=c.exec(C.slice(k));return p?(y.w=m.get(p[0].toLowerCase()),k+p[0].length):-1}function H(y,C,k){var p=g.exec(C.slice(k));return p?(y.m=T.get(p[0].toLowerCase()),k+p[0].length):-1}function Y(y,C,k){var p=M.exec(C.slice(k));return p?(y.m=h.get(p[0].toLowerCase()),k+p[0].length):-1}function Z(y,C,k){return R(y,e,C,k)}function gt(y,C,k){return R(y,n,C,k)}function G(y,C,k){return R(y,r,C,k)}function K(y){return i[y.getDay()]}function ht(y){return a[y.getDay()]}function B(y){return u[y.getMonth()]}function ft(y){return s[y.getMonth()]}function mt(y){return o[+(y.getHours()>=12)]}function pt(y){return 1+~~(y.getMonth()/3)}function Pt(y){return i[y.getUTCDay()]}function Vt(y){return a[y.getUTCDay()]}function E(y){return u[y.getUTCMonth()]}function j(y){return s[y.getUTCMonth()]}function X(y){return o[+(y.getUTCHours()>=12)]}function P(y){return 1+~~(y.getUTCMonth()/3)}return{format:function(y){var C=w(y+="",x);return C.toString=function(){return y},C},parse:function(y){var C=O(y+="",!1);return C.toString=function(){return y},C},utcFormat:function(y){var C=w(y+="",_);return C.toString=function(){return y},C},utcParse:function(y){var C=O(y+="",!0);return C.toString=function(){return y},C}}}var Ca={"-":"",_:" ",0:"0"},kt=/^\s*\d+/,fu=/^%/,mu=/[\\^$*+?|[\]().{}]/g;function ot(t,e,n){var r=t<0?"-":"",o=(r?-t:t)+"",a=o.length;return r+(a<n?new Array(n-a+1).join(e)+o:o)}function pu(t){return t.replace(mu,"\\$&")}function mn(t){return new RegExp("^(?:"+t.map(pu).join("|")+")","i")}function pn(t){return new Map(t.map((e,n)=>[e.toLowerCase(),n]))}function du(t,e,n){var r=kt.exec(e.slice(n,n+1));return r?(t.w=+r[0],n+r[0].length):-1}function hu(t,e,n){var r=kt.exec(e.slice(n,n+1));return r?(t.u=+r[0],n+r[0].length):-1}function gu(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.U=+r[0],n+r[0].length):-1}function yu(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.V=+r[0],n+r[0].length):-1}function xu(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.W=+r[0],n+r[0].length):-1}function _a(t,e,n){var r=kt.exec(e.slice(n,n+4));return r?(t.y=+r[0],n+r[0].length):-1}function Ta(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.y=+r[0]+(+r[0]>68?1900:2e3),n+r[0].length):-1}function bu(t,e,n){var r=/^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(n,n+6));return r?(t.Z=r[1]?0:-(r[2]+(r[3]||"00")),n+r[0].length):-1}function vu(t,e,n){var r=kt.exec(e.slice(n,n+1));return r?(t.q=r[0]*3-3,n+r[0].length):-1}function wu(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.m=r[0]-1,n+r[0].length):-1}function ka(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.d=+r[0],n+r[0].length):-1}function Su(t,e,n){var r=kt.exec(e.slice(n,n+3));return r?(t.m=0,t.d=+r[0],n+r[0].length):-1}function Da(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.H=+r[0],n+r[0].length):-1}function Mu(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.M=+r[0],n+r[0].length):-1}function Cu(t,e,n){var r=kt.exec(e.slice(n,n+2));return r?(t.S=+r[0],n+r[0].length):-1}function _u(t,e,n){var r=kt.exec(e.slice(n,n+3));return r?(t.L=+r[0],n+r[0].length):-1}function Tu(t,e,n){var r=kt.exec(e.slice(n,n+6));return r?(t.L=Math.floor(r[0]/1e3),n+r[0].length):-1}function ku(t,e,n){var r=fu.exec(e.slice(n,n+1));return r?n+r[0].length:-1}function Du(t,e,n){var r=kt.exec(e.slice(n));return r?(t.Q=+r[0],n+r[0].length):-1}function Fu(t,e,n){var r=kt.exec(e.slice(n));return r?(t.s=+r[0],n+r[0].length):-1}function Fa(t,e){return ot(t.getDate(),e,2)}function Au(t,e){return ot(t.getHours(),e,2)}function Eu(t,e){return ot(t.getHours()%12||12,e,2)}function Yu(t,e){return ot(1+Qn.count(ce(t),t),e,3)}function La(t,e){return ot(t.getMilliseconds(),e,3)}function Iu(t,e){return La(t,e)+"000"}function Nu(t,e){return ot(t.getMonth()+1,e,2)}function Ou(t,e){return ot(t.getMinutes(),e,2)}function Uu(t,e){return ot(t.getSeconds(),e,2)}function Ru(t){var e=t.getDay();return e===0?7:e}function Bu(t,e){return ot(fo.count(ce(t)-1,t),e,2)}function Ha(t){var e=t.getDay();return e>=4||e===0?Pe(t):Pe.ceil(t)}function $u(t,e){return t=Ha(t),ot(Pe.count(ce(t),t)+(ce(t).getDay()===4),e,2)}function zu(t){return t.getDay()}function Lu(t,e){return ot(Gn.count(ce(t)-1,t),e,2)}function Hu(t,e){return ot(t.getFullYear()%100,e,2)}function qu(t,e){return t=Ha(t),ot(t.getFullYear()%100,e,2)}function Pu(t,e){return ot(t.getFullYear()%1e4,e,4)}function Vu(t,e){var n=t.getDay();return t=n>=4||n===0?Pe(t):Pe.ceil(t),ot(t.getFullYear()%1e4,e,4)}function Wu(t){var e=t.getTimezoneOffset();return(e>0?"-":(e*=-1,"+"))+ot(e/60|0,"0",2)+ot(e%60,"0",2)}function Aa(t,e){return ot(t.getUTCDate(),e,2)}function Gu(t,e){return ot(t.getUTCHours(),e,2)}function Xu(t,e){return ot(t.getUTCHours()%12||12,e,2)}function Qu(t,e){return ot(1+co.count(ve(t),t),e,3)}function qa(t,e){return ot(t.getUTCMilliseconds(),e,3)}function Zu(t,e){return qa(t,e)+"000"}function Ju(t,e){return ot(t.getUTCMonth()+1,e,2)}function Ku(t,e){return ot(t.getUTCMinutes(),e,2)}function ju(t,e){return ot(t.getUTCSeconds(),e,2)}function tc(t){var e=t.getUTCDay();return e===0?7:e}function ec(t,e){return ot($a.count(ve(t)-1,t),e,2)}function Pa(t){var e=t.getUTCDay();return e>=4||e===0?Ve(t):Ve.ceil(t)}function nc(t,e){return t=Pa(t),ot(Ve.count(ve(t),t)+(ve(t).getUTCDay()===4),e,2)}function rc(t){return t.getUTCDay()}function oc(t,e){return ot(Xn.count(ve(t)-1,t),e,2)}function ac(t,e){return ot(t.getUTCFullYear()%100,e,2)}function ic(t,e){return t=Pa(t),ot(t.getUTCFullYear()%100,e,2)}function sc(t,e){return ot(t.getUTCFullYear()%1e4,e,4)}function lc(t,e){var n=t.getUTCDay();return t=n>=4||n===0?Ve(t):Ve.ceil(t),ot(t.getUTCFullYear()%1e4,e,4)}function uc(){return"+0000"}function Ea(){return"%"}function Ya(t){return+t}function Ia(t){return Math.floor(+t/1e3)}var qe,ee;cc({dateTime:"%x, %X",date:"%-m/%-d/%Y",time:"%-I:%M:%S %p",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]});function cc(t){return qe=so(t),ee=qe.format,qe.parse,qe.utcFormat,qe.utcParse,qe}var lo=[[1,4,12,52,365,365*24,365*24*60,365*24*60*60,365*24*60*60*1e3],[1/4,1,3,13,91,91*24,91*24*60,91*24*60*60,91*24*60*60*1e3],[1/12,1/3,1,4,30,30*24,30*24*60,30*24*60*60,30*24*60*60*1e3],[1/52,1/13,1/4,1,7,7*24,7*24*60,7*24*60*60,7*24*60*60*1e3],[1/365,1/91,1/30,1/7,1,24,24*60,24*60*60,24*60*60*1e3],[1/(365*24),1/(91*24),1/(30*24),1/(7*24),1/24,1,60,60*60,60*60*1e3],[1/(365*24*60),1/(91*24*60),1/(30*24*60),1/(7*24*60),1/(24*60),1/60,1,60,60*1e3],[1/(365*24*60*60),1/(91*24*60*60),1/(30*24*60*60),1/(7*24*60*60),1/(24*60*60),1/(60*60),1/60,1,1e3],[1/(365*24*60*60*1e3),1/(91*24*60*60*1e3),1/(30*24*60*60*1e3),1/(7*24*60*60*1e3),1/(24*60*60*1e3),1/(60*60*1e3),1/(60*1e3),1/1e3,1]];function fc(t,e,n){if(Gt(t))return;if(!e||!n||e===n)return t;let r=lo[e-1][n-1];if(r)return t*r}function mc(t,e,n,r){if(Gt(t)||!e.lowestLevel||n.length===0)return"";let o=[],a=0,i=Math.round(t*lo[e.lowestLevel-1][8]),s=9;for(let[,l]of n.entries())if(t){i=i-a;let f=lo[l-1][s-1],c=Math.floor(i/f);a=c*f,o.push({level:l,value:c})}else o.push({level:l,value:0});let u="";for(let[l,f]of o.entries())if(e.duration.format==="time"){let c=f.value;[6,7,8].includes(f.level)&&f.value<10?c="0"+f.value.toString():f.level===9&&f.value<10?c="00"+f.value.toString():f.level===9&&f.value<100&&(c="0"+f.value.toString()),u+=(l===0?"":f.level===9?".":":")+c}else if(e.duration.format==="long"){let c=r.durationLongSuffix;u+=f.value+" "+c[f.level]+(l===o.length-1?"":" ")}else{let c=r.durationShortSuffix;u+=f.value+""+c[f.level]+(l===o.length-1?"":" ")}return u}var pc={decimal:".",thousands:",",grouping:[3],currency:["$",""],dateTime:"%a %b %e %X %Y",date:"%m/%d/%Y",dateSeparator:"/",time:"%H:%M:%S",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],levels:["All","Year","Quarter","Month","Week","Date","Hour","Minute","Second","Millisecond"],shortLevels:["All","Yr","Qtr","Mth","Wk","Date","Hr","Min","Sec","Msec"],durationLongSuffix:["","years","quarters","months","weeks","days","hours","minutes","seconds","milliseconds"],durationShortSuffix:["","y","q","mo","w","d","h","m","s","ms"],multi:[".%L",":%S","%I:%M","%I %p","%a %d","W%G","%b %d","%B","%Y"]},dc="%d-%m-%Y",hc=[{key:"%a %e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%a %e %b %Y",monthType:"name",longText:!1,weekday:!0},{key:"%e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%e %b %Y",monthType:"name",longText:!1,weekday:!1},{key:"%a %e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%a %e %B %Y",monthType:"name",longText:!0,weekday:!0},{key:"%e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%e %B %Y",monthType:"name",longText:!0,weekday:!1},{key:"%d/%m/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"W%V/%G",lev5:"%d/%m/%Y",monthType:"number",mmdd:!1,separator:"/"},{key:"%d-%m-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"W%V-%G",lev5:"%d-%m-%Y",monthType:"number",mmdd:!1,separator:"-"},{key:"%d.%m.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"W%V.%G",lev5:"%d.%m.%Y",monthType:"number",mmdd:!1,separator:"."},{key:"%d~%m~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"W%V~%G",lev5:"%d~%m~%Y",monthType:"number",mmdd:!1,separator:"~"},{key:"%m/%d/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%m/%d/%Y",monthType:"number",mmdd:!0,separator:"/"},{key:"%m-%d-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%m-%d-%Y",monthType:"number",mmdd:!0,separator:"-"},{key:"%m.%d.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%m.%d.%Y",monthType:"number",mmdd:!0,separator:"."},{key:"%m~%d~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%m~%d~%Y",monthType:"number",mmdd:!0,separator:"~"},{key:"%amd/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%amd/%Y",monthType:"number",mmdd:null,separator:"/"},{key:"%amd-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%amd-%Y",monthType:"number",mmdd:null,separator:"-"},{key:"%amd.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%amd.%Y",monthType:"number",mmdd:null,separator:"."},{key:"%amd~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%amd~%Y",monthType:"number",mmdd:null,separator:"~"}],gc=[{key:"%H:%M:%S.%L",lev6:"%H:00",lev7:"%H:%M",lev8:"%H:%M:%S",lev9:"%H:%M:%S.%L",ampm:!1},{key:"%I:%M:%S.%L %p",lev6:"%I:00 %p",lev7:"%I:%M %p",lev8:"%I:%M:%S %p",lev9:"%I:%M:%S.%L %p",ampm:!0}];function Xt(t,e){var n,r;e=e||{};let o=e.localFormats||pc,a,i,s,u=[],l=[],f="datetime",c;e&&e.multi&&(f="datetime"),(!t||!t.format)&&(f="hierarchy"),t&&t.type&&(f=t.type),t&&t.format?c=t.format:f==="numeric"?c=",.0f":f==="datetime"?c=dc:c="";let m=jr(c);switch(m.precision&&m.typeFormat&&(f="numeric"),f){case"numeric":{if(t.subtype==="duration"&&t.duration&&t.duration.levels&&t.duration.levels.length>1&&!e.hideDuration)a=d=>Gt(d)?"":mc(d,t,t.duration.levels,o);else{let d={...o},b=m.typeFormat,M=!1;switch(b.length===2&&b.startsWith("a")&&(M=!0,b=b.slice(1,2),c=c.replace(/a/,"")),M?(d.decimal=o.decimal,d.thousands=o.thousands):["z","y","w"].includes(b)?(d.decimal=",",d.thousands="."):(d.decimal=".",d.thousands=","),b){case"z":{c=c.replace("z","f");break}case"y":{c=c.replace("y","%");break}case"w":{c=c.replace("w","s");break}}if(t?.subtype==="currency"&&t.currency){let g="\xA0",T=d.currency.findIndex(w=>w.length>0),x=d.currency[T].startsWith(g),_=d.currency[T].endsWith(g),v=`${x?g:""}${t.currency}${_?g:""}`;d.currency[T]=v}let h=Kl(d);b!=="%"&&t?.subtype==="currency"&&t.currency&&d.currency&&!(e!=null&&e.hideCurrency)&&!["count","distinctcount"].includes(t.aggregationFunc)&&!(t.aggregationFunc==="rate"&&((n=t.aggregationWeight)==null?void 0:n.columnSubType)==="currency")&&((r=t.periodOverPeriod)==null?void 0:r.type)!=="percentageChange"&&(c="$"+c),e!=null&&e.trimZero&&["y","%"].includes(b)&&d.decimal===","?i=g=>h.format(c)(g).replace(/(,\d*?)0+%$/,"$1%").replace(/,%$/,"%"):e!=null&&e.trimZero&&["y","%"].includes(b)&&d.decimal==="."?i=g=>h.format(c)(g).replace(/(\.\d*?)0+%$/,"$1%").replace(/\.%$/,"%"):e!=null&&e.trimZero&&["z","f"].includes(b)&&d.decimal===","?i=g=>h.format(c)(g).replace(/(,\d*?)0+$/,"$1").replace(/,$/,""):e!=null&&e.trimZero&&["z","f"].includes(b)&&d.decimal==="."?i=g=>h.format(c)(g).replace(/(\.\d*?)0+$/,"$1").replace(/\.$/,""):t?.subtype==="currency"&&t.currency&&d.currency&&b==="s"?i=g=>h.format(c)(g).replace(/G/,"B"):i=Gt(m.precision)?h.format(",.0f"):h.format(c),a=g=>{var T;if(Gt(g))return"";if(t.subtype==="duration"&&t.duration&&!e.hideDuration){let x=t.duration.levels?t.duration.levels[0]:t.lowestLevel;return x!==t.lowestLevel&&(g=fc(g,t.lowestLevel,x)),i(g)+((T=o?.durationShortSuffix)==null?void 0:T[x])}return i(g)}}break}case"datetime":{if(u=o?.smartDateFormats??hc,l=o?.smartTimeFormats??gc,Gt(t.datetimeDisplayMode)){if(e!=null&&e.level){let d=e.level,b=u.find(_=>c.includes(_.key)),M=l.find(_=>c.includes(_.key)),h=b?b["lev"+Math.min(d,5)]:u[0]["lev"+Math.min(d,5)],g=d>5?M?M["lev"+d]:l[0]["lev"+d]:"";c=d>5?h+", "+g:h;let T=c.includes("%amd")&&e.level>=5,x=b?e.level>=2&&b.separator==="~":!1;T?c=x?c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8)):c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8).replaceAll(new RegExp(/[.~\/-]/g),b.separator)):c=x?c.replaceAll(new RegExp(/[~]/g),o.dateSeparator):c}if(e!=null&&e.multi){let d=ee(o.multi[0]),b=ee(o.multi[1]),M=ee(o.multi[2]),h=ee(o.multi[3]),g=ee(o.multi[4]),T=ee(o.multi[6]),x=ee(o.multi[7]),_=ee(o.multi[8]);s=v=>{let w;return Ua(v)<v?w=d:Ra(v)<v?w=b:Ba(v)<v?w=M:Qn(v)<v?w=h:za(v)<v?w=fo(v)<v?g:T:ce(v)<v?w=x:w=_,w(v)}}else s=so(o).format(c)}else{let d={quarter_number:{min:1,max:4},month_name:{min:1,max:12},month_number:{min:1,max:12},week_number:{min:1,max:53},day_in_month:{min:1,max:31},day_in_year:{min:1,max:366},weekday_name:{min:0,max:7},weekday_number:{min:0,max:7},hour_in_day:{min:0,max:23},minute_in_hour:{min:0,max:59},second_in_minute:{min:0,max:59}},b=(M,h,g)=>{var T,x,_,v,w;return h==="letter"?((T=M.shortNames)==null?void 0:T.length)>0&&((x=M.shortNames[g])==null?void 0:x.length)>0?(_=M.shortNames[g])==null?void 0:_.charAt(0):"N/A":h==="short"?((v=M.shortNames)==null?void 0:v.length)>0&&M.shortNames[g]?M.shortNames[g]:"N/A":((w=M.longNames)==null?void 0:w.length)>0&&M.longNames[g]?M.longNames[g]:"N/A"};["quarter_number","month_number","week_number","day_in_month","day_in_year","weekday_number","hour_in_day","minute_in_hour","second_in_minute"].includes(t.datetimeDisplayMode)?s=M=>cn(M)&&M>=d[t.datetimeDisplayMode].min&&M<=d[t.datetimeDisplayMode].max?M:"N/A":t.datetimeDisplayMode==="month_name"?s=M=>{let h=[...o.shortMonths],g=[...o.months];return cn(M)&&M>=d[t.datetimeDisplayMode].min&&M<=d[t.datetimeDisplayMode].max?b({shortNames:h,longNames:g},t.monthNameFormat,M-1):"N/A"}:t.datetimeDisplayMode==="weekday_name"?s=M=>{let h=[...o.shortDays],g=[...o.days];return t.weekStart==="monday"&&(h.push(h.shift()??""),g.push(g.shift()??"")),cn(M)&&M>=d[t.datetimeDisplayMode].min&&M<=d[t.datetimeDisplayMode].max?b({shortNames:h,longNames:g},t.weekDayNameFormat,M-1):"N/A"}:s=so(o).format(c)}a=d=>{if(Gt(d))return"";let b=s(d);return to(b)?b.trim():b};break}case"hierarchy":{a=d=>eo(d,e?e.locale:void 0);break}default:{a=d=>d;break}}return a}var zt={type:"platform",background:"rgb(245,245,245)",itemsBackground:"rgb(255,255,255)",boxShadow:{size:"none",color:"rgb(0, 0, 0)"},title:{align:"left",bold:!1,italic:!1,underline:!1,border:!1},font:{fontFamily:"Lato","font-style":"normal","font-weight":400,fontSize:15},colors:["rgb(68,52,255)","rgb(143,133,255)","rgb(218,214,255)","rgb(191,5,184)","rgb(217,105,212)","rgb(242,205,241)","rgb(248,194,12)","rgb(251,218,109)","rgb(254,243,206)","rgb(9,203,120)","rgb(107,224,174)","rgb(206,245,228)","rgb(122,112,112)","rgb(175,169,169)","rgb(228,226,226)"],borders:{"border-color":"rgba(216,216,216,1)","border-style":"none","border-radius":"12px","border-top-width":"0px","border-left-width":"0px","border-right-width":"0px","border-bottom-width":"0px"},margins:[16,16],mainColor:"rgb(68,52,255)",axis:{},legend:{type:"circle"},tooltip:{background:"rgb(38,38,38)"},itemSpecific:{rounding:8,padding:4}},We=(t,e)=>({"border-color":t,"border-style":"none","border-radius":e,"border-top-width":"1px","border-left-width":"1px","border-right-width":"1px","border-bottom-width":"1px"}),fg={default:{...zt,name:"Default (light)"},default_dark:{...zt,name:"Default (dark)",background:"rgb(61,61,61)",itemsBackground:"rgb(38,38,38)",colors:["rgb(48,36,179)","rgb(105,93,255)","rgb(199,194,255)","rgb(134,4,129)","rgb(204,55,198)","rgb(236,180,234)","rgb(220,141,0)","rgb(249,206,61)","rgb(253,237,182)","rgb(6,142,84)","rgb(58,213,147)","rgb(181,239,215)","rgb(85,78,78)","rgb(149,141,141)","rgb(215,212,212)"],mainColor:"rgb(123,144,255)",tooltip:{background:"rgb(248,248,248)"}},vivid:{...zt,name:"Vivid",background:"#eef3f6",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[12,12],mainColor:"#5867C3",legend:{type:"normal"},tooltip:{},colors:["#5867C3","#00C5DC","#FF525E","#FFAA00","#FFDB03","#86de40","#59b339","#cc27bc","#ff4aed","#bfbfbf","#737373"],font:{fontFamily:"Open Sans",fontSize:13}},seasonal:{...zt,name:"Seasonal",background:"#ffffff",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:We("rgba(0,0,0,.1)","8px"),margins:[10,10],mainColor:"#009788",tooltip:{},colors:["#009788","#60cc64","#CDDC39","#FFEB3C","#FEC107","#FF9700","#FE5722","#EA1E63","#9C28B1","#673BB7","#3F51B5","#2196F3","#03A9F5","#00BCD5"],font:{fontFamily:"Open Sans",fontSize:13}},orion:{...zt,name:"Orion's Belt",background:"#00062d",itemsBackground:"#00062d",boxShadow:{size:"L",color:"#64046f"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:We("rgba(0, 0, 0, .1)","8px"),mainColor:"#d62750",legend:{type:"normal"},colors:["#880065","#b3005e","#d62750","#ef513e","#fd7b27","#ffa600","#fdae6b"],font:{fontFamily:"Electrolize",fontSize:15}},royale:{...zt,name:"Royale",background:"#0A2747",itemsBackground:"#111e2f",boxShadow:{size:"S",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{"border-radius":"3px"},margins:[10,10],mainColor:"#f4a92c",legend:{type:"circle"},tooltip:{},colors:["#feeaa1","#e6cc85","#ceaf6a","#b79350","#9f7738","#885d20","#704308"],font:{fontFamily:"Exo",fontSize:13}},urban:{...zt,name:"Urban",background:"#42403c",itemsBackground:"#e4dbcd",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[5,5],mainColor:"#33b59e",legend:{type:"circle"},colors:["#33b59e","#453d30","#ffffff","#237869","#165e4e","#b89f76","#7a6138","#543c13","#8a9c98","#44524f"],font:{fontFamily:"Open Sans",fontSize:13}},pinky:{...zt,name:"Pinky Brains",background:"#0F1E43",itemsBackground:"#1B2A4D",title:{align:"center",bold:!0,italic:!1,underline:!1,border:!0},borders:We("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#e84281",legend:{type:"normal"},tooltip:{},colors:["#e84281","#d464c2","#a089f2","#46a8ff","#00c0ff","#00d0e8","#49dcc9"],font:{fontFamily:"Capriola",fontSize:15}},bliss:{...zt,name:"Bliss",background:"#ffffff",itemsBackground:"#ffffff",boxShadow:{size:"none",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:We("rgba(0, 0, 0, .1)","8px"),margins:[10,10],mainColor:"#0578ff",axis:{},legend:{type:"normal"},tooltip:{},colors:["#b8d8ff","#3ba0ff","#0044f2","#1b00ca","#9114de","#ce42ff","#ff19f6","#ed2bab","#d8175c","#ff303d","#ff6130","#ff9f30","#15BF49","#95E88C"],font:{fontFamily:"Open Sans",fontSize:13}},radiant:{...zt,name:"Radiant",background:"rgba(43,43,56,1)",itemsBackground:"rgba(52,52,69,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:We("rgba(255, 255, 255, .08)","8px"),margins:[14,14],mainColor:"#00a4eb",legend:{type:"line"},tooltip:{},colors:["#a6e1ff","#00a4eb","#3f3af0","#9300c7","#f72f5f","#f29b50","#f2d566","#3ae086","#c9c9c9","#7a7a7a"],font:{fontFamily:"Open Sans",fontSize:13}},classic:{...zt,name:"Classic (light)",background:"#F2F2F2",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#ececec",borders:We("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#009dff",legend:{type:"normal"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}},classic_dark:{...zt,name:"Classic (dark)",background:"rgb(38,39,50)",itemsBackground:"rgba(52,53,68,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{},margins:[10,10],mainColor:"#0E89E0",legend:{type:"line"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}}};function Me(t,e){return t==null||e==null?NaN:t<e?-1:t>e?1:t>=e?0:NaN}function mo(t,e){return t==null||e==null?NaN:e<t?-1:e>t?1:e>=t?0:NaN}function Ce(t){let e,n,r;t.length!==2?(e=Me,n=(s,u)=>Me(t(s),u),r=(s,u)=>t(s)-u):(e=t===Me||t===mo?t:yc,n=t,r=t);function o(s,u,l=0,f=s.length){if(l<f){if(e(u,u)!==0)return f;do{let c=l+f>>>1;n(s[c],u)<0?l=c+1:f=c}while(l<f)}return l}function a(s,u,l=0,f=s.length){if(l<f){if(e(u,u)!==0)return f;do{let c=l+f>>>1;n(s[c],u)<=0?l=c+1:f=c}while(l<f)}return l}function i(s,u,l=0,f=s.length){let c=o(s,u,l,f-1);return c>l&&r(s[c-1],u)>-r(s[c],u)?c-1:c}return{left:o,center:i,right:a}}function yc(){return 0}function po(t){return t===null?NaN:+t}var Va=Ce(Me),Wa=Va.right,xc=Va.left,bc=Ce(po).center,ho=Wa;function Zn(t,e){let n,r;if(e===void 0)for(let o of t)o!=null&&(n===void 0?o>=o&&(n=r=o):(n>o&&(n=o),r<o&&(r=o)));else{let o=-1;for(let a of t)(a=e(a,++o,t))!=null&&(n===void 0?a>=a&&(n=r=a):(n>a&&(n=a),r<a&&(r=a)))}return[n,r]}var Ge=class extends Map{constructor(e,n=Sc){if(super(),Object.defineProperties(this,{_intern:{value:new Map},_key:{value:n}}),e!=null)for(let[r,o]of e)this.set(r,o)}get(e){return super.get(Ga(this,e))}has(e){return super.has(Ga(this,e))}set(e,n){return super.set(vc(this,e),n)}delete(e){return super.delete(wc(this,e))}};function Ga({_intern:t,_key:e},n){let r=e(n);return t.has(r)?t.get(r):n}function vc({_intern:t,_key:e},n){let r=e(n);return t.has(r)?t.get(r):(t.set(r,n),n)}function wc({_intern:t,_key:e},n){let r=e(n);return t.has(r)&&(n=t.get(r),t.delete(r)),n}function Sc(t){return t!==null&&typeof t=="object"?t.valueOf():t}var Mc=Math.sqrt(50),Cc=Math.sqrt(10),_c=Math.sqrt(2);function Jn(t,e,n){let r=(e-t)/Math.max(0,n),o=Math.floor(Math.log10(r)),a=r/Math.pow(10,o),i=a>=Mc?10:a>=Cc?5:a>=_c?2:1,s,u,l;return o<0?(l=Math.pow(10,-o)/i,s=Math.round(t*l),u=Math.round(e*l),s/l<t&&++s,u/l>e&&--u,l=-l):(l=Math.pow(10,o)*i,s=Math.round(t/l),u=Math.round(e/l),s*l<t&&++s,u*l>e&&--u),u<s&&.5<=n&&n<2?Jn(t,e,n*2):[s,u,l]}function Kn(t,e,n){if(e=+e,t=+t,n=+n,!(n>0))return[];if(t===e)return[t];let r=e<t,[o,a,i]=r?Jn(e,t,n):Jn(t,e,n);if(!(a>=o))return[];let s=a-o+1,u=new Array(s);if(r)if(i<0)for(let l=0;l<s;++l)u[l]=(a-l)/-i;else for(let l=0;l<s;++l)u[l]=(a-l)*i;else if(i<0)for(let l=0;l<s;++l)u[l]=(o+l)/-i;else for(let l=0;l<s;++l)u[l]=(o+l)*i;return u}function yn(t,e,n){return e=+e,t=+t,n=+n,Jn(t,e,n)[2]}function Xe(t,e,n){e=+e,t=+t,n=+n;let r=e<t,o=r?yn(e,t,n):yn(t,e,n);return(r?-1:1)*(o<0?1/-o:o)}function jn(t,e){let n;if(e===void 0)for(let r of t)r!=null&&(n<r||n===void 0&&r>=r)&&(n=r);else{let r=-1;for(let o of t)(o=e(o,++r,t))!=null&&(n<o||n===void 0&&o>=o)&&(n=o)}return n}function tr(t,e){let n;if(e===void 0)for(let r of t)r!=null&&(n>r||n===void 0&&r>=r)&&(n=r);else{let r=-1;for(let o of t)(o=e(o,++r,t))!=null&&(n>o||n===void 0&&o>=o)&&(n=o)}return n}function er(t,e,n){t=+t,e=+e,n=(o=arguments.length)<2?(e=t,t=0,1):o<3?1:+n;for(var r=-1,o=Math.max(0,Math.ceil((e-t)/n))|0,a=new Array(o);++r<o;)a[r]=t+r*n;return a}function Xa(t){return t}var go=1,yo=2,xo=3,xn=4,Qa=1e-6;function Tc(t){return"translate("+t+",0)"}function kc(t){return"translate(0,"+t+")"}function Dc(t){return e=>+t(e)}function Fc(t,e){return e=Math.max(0,t.bandwidth()-e*2)/2,t.round()&&(e=Math.round(e)),n=>+t(n)+e}function Ac(){return!this.__axis}function Za(t,e){var n=[],r=null,o=null,a=6,i=6,s=3,u=typeof window<"u"&&window.devicePixelRatio>1?0:.5,l=t===go||t===xn?-1:1,f=t===xn||t===yo?"x":"y",c=t===go||t===xo?Tc:kc;function m(d){var b=r??(e.ticks?e.ticks.apply(e,n):e.domain()),M=o??(e.tickFormat?e.tickFormat.apply(e,n):Xa),h=Math.max(a,0)+s,g=e.range(),T=+g[0]+u,x=+g[g.length-1]+u,_=(e.bandwidth?Fc:Dc)(e.copy(),u),v=d.selection?d.selection():d,w=v.selectAll(".domain").data([null]),O=v.selectAll(".tick").data(b,e).order(),R=O.exit(),st=O.enter().append("g").attr("class","tick"),q=O.select("line"),S=O.select("text");w=w.merge(w.enter().insert("path",".tick").attr("class","domain").attr("stroke","currentColor")),O=O.merge(st),q=q.merge(st.append("line").attr("stroke","currentColor").attr(f+"2",l*a)),S=S.merge(st.append("text").attr("fill","currentColor").attr(f,l*h).attr("dy",t===go?"0em":t===xo?"0.71em":"0.32em")),d!==v&&(w=w.transition(d),O=O.transition(d),q=q.transition(d),S=S.transition(d),R=R.transition(d).attr("opacity",Qa).attr("transform",function(H){return isFinite(H=_(H))?c(H+u):this.getAttribute("transform")}),st.attr("opacity",Qa).attr("transform",function(H){var Y=this.parentNode.__axis;return c((Y&&isFinite(Y=Y(H))?Y:_(H))+u)})),R.remove(),w.attr("d",t===xn||t===yo?i?"M"+l*i+","+T+"H"+u+"V"+x+"H"+l*i:"M"+u+","+T+"V"+x:i?"M"+T+","+l*i+"V"+u+"H"+x+"V"+l*i:"M"+T+","+u+"H"+x),O.attr("opacity",1).attr("transform",function(H){return c(_(H)+u)}),q.attr(f+"2",l*a),S.attr(f,l*h).text(M),v.filter(Ac).attr("fill","none").attr("font-size",10).attr("font-family","sans-serif").attr("text-anchor",t===yo?"start":t===xn?"end":"middle"),v.each(function(){this.__axis=_})}return m.scale=function(d){return arguments.length?(e=d,m):e},m.ticks=function(){return n=Array.from(arguments),m},m.tickArguments=function(d){return arguments.length?(n=d==null?[]:Array.from(d),m):n.slice()},m.tickValues=function(d){return arguments.length?(r=d==null?null:Array.from(d),m):r&&r.slice()},m.tickFormat=function(d){return arguments.length?(o=d,m):o},m.tickSize=function(d){return arguments.length?(a=i=+d,m):a},m.tickSizeInner=function(d){return arguments.length?(a=+d,m):a},m.tickSizeOuter=function(d){return arguments.length?(i=+d,m):i},m.tickPadding=function(d){return arguments.length?(s=+d,m):s},m.offset=function(d){return arguments.length?(u=+d,m):u},m}function bn(t){return Za(xo,t)}function bo(t){return Za(xn,t)}var Ec={value:()=>{}};function Ka(){for(var t=0,e=arguments.length,n={},r;t<e;++t){if(!(r=arguments[t]+"")||r in n||/[\s.]/.test(r))throw new Error("illegal type: "+r);n[r]=[]}return new nr(n)}function nr(t){this._=t}function Yc(t,e){return t.trim().split(/^|\s+/).map(function(n){var r="",o=n.indexOf(".");if(o>=0&&(r=n.slice(o+1),n=n.slice(0,o)),n&&!e.hasOwnProperty(n))throw new Error("unknown type: "+n);return{type:n,name:r}})}nr.prototype=Ka.prototype={constructor:nr,on:function(t,e){var n=this._,r=Yc(t+"",n),o,a=-1,i=r.length;if(arguments.length<2){for(;++a<i;)if((o=(t=r[a]).type)&&(o=Ic(n[o],t.name)))return o;return}if(e!=null&&typeof e!="function")throw new Error("invalid callback: "+e);for(;++a<i;)if(o=(t=r[a]).type)n[o]=Ja(n[o],t.name,e);else if(e==null)for(o in n)n[o]=Ja(n[o],t.name,null);return this},copy:function(){var t={},e=this._;for(var n in e)t[n]=e[n].slice();return new nr(t)},call:function(t,e){if((o=arguments.length-2)>0)for(var n=new Array(o),r=0,o,a;r<o;++r)n[r]=arguments[r+2];if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(a=this._[t],r=0,o=a.length;r<o;++r)a[r].value.apply(e,n)},apply:function(t,e,n){if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(var r=this._[t],o=0,a=r.length;o<a;++o)r[o].value.apply(e,n)}};function Ic(t,e){for(var n=0,r=t.length,o;n<r;++n)if((o=t[n]).name===e)return o.value}function Ja(t,e,n){for(var r=0,o=t.length;r<o;++r)if(t[r].name===e){t[r]=Ec,t=t.slice(0,r).concat(t.slice(r+1));break}return n!=null&&t.push({name:e,value:n}),t}var vn=Ka;var rr="http://www.w3.org/1999/xhtml",vo={svg:"http://www.w3.org/2000/svg",xhtml:rr,xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace",xmlns:"http://www.w3.org/2000/xmlns/"};function ne(t){var e=t+="",n=e.indexOf(":");return n>=0&&(e=t.slice(0,n))!=="xmlns"&&(t=t.slice(n+1)),vo.hasOwnProperty(e)?{space:vo[e],local:t}:t}function Nc(t){return function(){var e=this.ownerDocument,n=this.namespaceURI;return n===rr&&e.documentElement.namespaceURI===rr?e.createElement(t):e.createElementNS(n,t)}}function Oc(t){return function(){return this.ownerDocument.createElementNS(t.space,t.local)}}function or(t){var e=ne(t);return(e.local?Oc:Nc)(e)}function Uc(){}function _e(t){return t==null?Uc:function(){return this.querySelector(t)}}function ja(t){typeof t!="function"&&(t=_e(t));for(var e=this._groups,n=e.length,r=new Array(n),o=0;o<n;++o)for(var a=e[o],i=a.length,s=r[o]=new Array(i),u,l,f=0;f<i;++f)(u=a[f])&&(l=t.call(u,u.__data__,f,a))&&("__data__"in u&&(l.__data__=u.__data__),s[f]=l);return new yt(r,this._parents)}function wo(t){return t==null?[]:Array.isArray(t)?t:Array.from(t)}function Rc(){return[]}function wn(t){return t==null?Rc:function(){return this.querySelectorAll(t)}}function Bc(t){return function(){return wo(t.apply(this,arguments))}}function ti(t){typeof t=="function"?t=Bc(t):t=wn(t);for(var e=this._groups,n=e.length,r=[],o=[],a=0;a<n;++a)for(var i=e[a],s=i.length,u,l=0;l<s;++l)(u=i[l])&&(r.push(t.call(u,u.__data__,l,i)),o.push(u));return new yt(r,o)}function Sn(t){return function(){return this.matches(t)}}function ar(t){return function(e){return e.matches(t)}}var $c=Array.prototype.find;function zc(t){return function(){return $c.call(this.children,t)}}function Lc(){return this.firstElementChild}function ei(t){return this.select(t==null?Lc:zc(typeof t=="function"?t:ar(t)))}var Hc=Array.prototype.filter;function qc(){return Array.from(this.children)}function Pc(t){return function(){return Hc.call(this.children,t)}}function ni(t){return this.selectAll(t==null?qc:Pc(typeof t=="function"?t:ar(t)))}function ri(t){typeof t!="function"&&(t=Sn(t));for(var e=this._groups,n=e.length,r=new Array(n),o=0;o<n;++o)for(var a=e[o],i=a.length,s=r[o]=[],u,l=0;l<i;++l)(u=a[l])&&t.call(u,u.__data__,l,a)&&s.push(u);return new yt(r,this._parents)}function ir(t){return new Array(t.length)}function oi(){return new yt(this._enter||this._groups.map(ir),this._parents)}function Mn(t,e){this.ownerDocument=t.ownerDocument,this.namespaceURI=t.namespaceURI,this._next=null,this._parent=t,this.__data__=e}Mn.prototype={constructor:Mn,appendChild:function(t){return this._parent.insertBefore(t,this._next)},insertBefore:function(t,e){return this._parent.insertBefore(t,e)},querySelector:function(t){return this._parent.querySelector(t)},querySelectorAll:function(t){return this._parent.querySelectorAll(t)}};function ai(t){return function(){return t}}function Vc(t,e,n,r,o,a){for(var i=0,s,u=e.length,l=a.length;i<l;++i)(s=e[i])?(s.__data__=a[i],r[i]=s):n[i]=new Mn(t,a[i]);for(;i<u;++i)(s=e[i])&&(o[i]=s)}function Wc(t,e,n,r,o,a,i){var s,u,l=new Map,f=e.length,c=a.length,m=new Array(f),d;for(s=0;s<f;++s)(u=e[s])&&(m[s]=d=i.call(u,u.__data__,s,e)+"",l.has(d)?o[s]=u:l.set(d,u));for(s=0;s<c;++s)d=i.call(t,a[s],s,a)+"",(u=l.get(d))?(r[s]=u,u.__data__=a[s],l.delete(d)):n[s]=new Mn(t,a[s]);for(s=0;s<f;++s)(u=e[s])&&l.get(m[s])===u&&(o[s]=u)}function Gc(t){return t.__data__}function ii(t,e){if(!arguments.length)return Array.from(this,Gc);var n=e?Wc:Vc,r=this._parents,o=this._groups;typeof t!="function"&&(t=ai(t));for(var a=o.length,i=new Array(a),s=new Array(a),u=new Array(a),l=0;l<a;++l){var f=r[l],c=o[l],m=c.length,d=Xc(t.call(f,f&&f.__data__,l,r)),b=d.length,M=s[l]=new Array(b),h=i[l]=new Array(b),g=u[l]=new Array(m);n(f,c,M,h,g,d,e);for(var T=0,x=0,_,v;T<b;++T)if(_=M[T]){for(T>=x&&(x=T+1);!(v=h[x])&&++x<b;);_._next=v||null}}return i=new yt(i,r),i._enter=s,i._exit=u,i}function Xc(t){return typeof t=="object"&&"length"in t?t:Array.from(t)}function si(){return new yt(this._exit||this._groups.map(ir),this._parents)}function li(t,e,n){var r=this.enter(),o=this,a=this.exit();return typeof t=="function"?(r=t(r),r&&(r=r.selection())):r=r.append(t+""),e!=null&&(o=e(o),o&&(o=o.selection())),n==null?a.remove():n(a),r&&o?r.merge(o).order():o}function ui(t){for(var e=t.selection?t.selection():t,n=this._groups,r=e._groups,o=n.length,a=r.length,i=Math.min(o,a),s=new Array(o),u=0;u<i;++u)for(var l=n[u],f=r[u],c=l.length,m=s[u]=new Array(c),d,b=0;b<c;++b)(d=l[b]||f[b])&&(m[b]=d);for(;u<o;++u)s[u]=n[u];return new yt(s,this._parents)}function ci(){for(var t=this._groups,e=-1,n=t.length;++e<n;)for(var r=t[e],o=r.length-1,a=r[o],i;--o>=0;)(i=r[o])&&(a&&i.compareDocumentPosition(a)^4&&a.parentNode.insertBefore(i,a),a=i);return this}function fi(t){t||(t=Qc);function e(c,m){return c&&m?t(c.__data__,m.__data__):!c-!m}for(var n=this._groups,r=n.length,o=new Array(r),a=0;a<r;++a){for(var i=n[a],s=i.length,u=o[a]=new Array(s),l,f=0;f<s;++f)(l=i[f])&&(u[f]=l);u.sort(e)}return new yt(o,this._parents).order()}function Qc(t,e){return t<e?-1:t>e?1:t>=e?0:NaN}function mi(){var t=arguments[0];return arguments[0]=this,t.apply(null,arguments),this}function pi(){return Array.from(this)}function di(){for(var t=this._groups,e=0,n=t.length;e<n;++e)for(var r=t[e],o=0,a=r.length;o<a;++o){var i=r[o];if(i)return i}return null}function hi(){let t=0;for(let e of this)++t;return t}function gi(){return!this.node()}function yi(t){for(var e=this._groups,n=0,r=e.length;n<r;++n)for(var o=e[n],a=0,i=o.length,s;a<i;++a)(s=o[a])&&t.call(s,s.__data__,a,o);return this}function Zc(t){return function(){this.removeAttribute(t)}}function Jc(t){return function(){this.removeAttributeNS(t.space,t.local)}}function Kc(t,e){return function(){this.setAttribute(t,e)}}function jc(t,e){return function(){this.setAttributeNS(t.space,t.local,e)}}function tf(t,e){return function(){var n=e.apply(this,arguments);n==null?this.removeAttribute(t):this.setAttribute(t,n)}}function ef(t,e){return function(){var n=e.apply(this,arguments);n==null?this.removeAttributeNS(t.space,t.local):this.setAttributeNS(t.space,t.local,n)}}function xi(t,e){var n=ne(t);if(arguments.length<2){var r=this.node();return n.local?r.getAttributeNS(n.space,n.local):r.getAttribute(n)}return this.each((e==null?n.local?Jc:Zc:typeof e=="function"?n.local?ef:tf:n.local?jc:Kc)(n,e))}function sr(t){return t.ownerDocument&&t.ownerDocument.defaultView||t.document&&t||t.defaultView}function nf(t){return function(){this.style.removeProperty(t)}}function rf(t,e,n){return function(){this.style.setProperty(t,e,n)}}function of(t,e,n){return function(){var r=e.apply(this,arguments);r==null?this.style.removeProperty(t):this.style.setProperty(t,r,n)}}function bi(t,e,n){return arguments.length>1?this.each((e==null?nf:typeof e=="function"?of:rf)(t,e,n??"")):fe(this.node(),t)}function fe(t,e){return t.style.getPropertyValue(e)||sr(t).getComputedStyle(t,null).getPropertyValue(e)}function af(t){return function(){delete this[t]}}function sf(t,e){return function(){this[t]=e}}function lf(t,e){return function(){var n=e.apply(this,arguments);n==null?delete this[t]:this[t]=n}}function vi(t,e){return arguments.length>1?this.each((e==null?af:typeof e=="function"?lf:sf)(t,e)):this.node()[t]}function wi(t){return t.trim().split(/^|\s+/)}function So(t){return t.classList||new Si(t)}function Si(t){this._node=t,this._names=wi(t.getAttribute("class")||"")}Si.prototype={add:function(t){var e=this._names.indexOf(t);e<0&&(this._names.push(t),this._node.setAttribute("class",this._names.join(" ")))},remove:function(t){var e=this._names.indexOf(t);e>=0&&(this._names.splice(e,1),this._node.setAttribute("class",this._names.join(" ")))},contains:function(t){return this._names.indexOf(t)>=0}};function Mi(t,e){for(var n=So(t),r=-1,o=e.length;++r<o;)n.add(e[r])}function Ci(t,e){for(var n=So(t),r=-1,o=e.length;++r<o;)n.remove(e[r])}function uf(t){return function(){Mi(this,t)}}function cf(t){return function(){Ci(this,t)}}function ff(t,e){return function(){(e.apply(this,arguments)?Mi:Ci)(this,t)}}function _i(t,e){var n=wi(t+"");if(arguments.length<2){for(var r=So(this.node()),o=-1,a=n.length;++o<a;)if(!r.contains(n[o]))return!1;return!0}return this.each((typeof e=="function"?ff:e?uf:cf)(n,e))}function mf(){this.textContent=""}function pf(t){return function(){this.textContent=t}}function df(t){return function(){var e=t.apply(this,arguments);this.textContent=e??""}}function Ti(t){return arguments.length?this.each(t==null?mf:(typeof t=="function"?df:pf)(t)):this.node().textContent}function hf(){this.innerHTML=""}function gf(t){return function(){this.innerHTML=t}}function yf(t){return function(){var e=t.apply(this,arguments);this.innerHTML=e??""}}function ki(t){return arguments.length?this.each(t==null?hf:(typeof t=="function"?yf:gf)(t)):this.node().innerHTML}function xf(){this.nextSibling&&this.parentNode.appendChild(this)}function Di(){return this.each(xf)}function bf(){this.previousSibling&&this.parentNode.insertBefore(this,this.parentNode.firstChild)}function Fi(){return this.each(bf)}function Ai(t){var e=typeof t=="function"?t:or(t);return this.select(function(){return this.appendChild(e.apply(this,arguments))})}function vf(){return null}function Ei(t,e){var n=typeof t=="function"?t:or(t),r=e==null?vf:typeof e=="function"?e:_e(e);return this.select(function(){return this.insertBefore(n.apply(this,arguments),r.apply(this,arguments)||null)})}function wf(){var t=this.parentNode;t&&t.removeChild(this)}function Yi(){return this.each(wf)}function Sf(){var t=this.cloneNode(!1),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function Mf(){var t=this.cloneNode(!0),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function Ii(t){return this.select(t?Mf:Sf)}function Ni(t){return arguments.length?this.property("__data__",t):this.node().__data__}function Cf(t){return function(e){t.call(this,e,this.__data__)}}function _f(t){return t.trim().split(/^|\s+/).map(function(e){var n="",r=e.indexOf(".");return r>=0&&(n=e.slice(r+1),e=e.slice(0,r)),{type:e,name:n}})}function Tf(t){return function(){var e=this.__on;if(e){for(var n=0,r=-1,o=e.length,a;n<o;++n)a=e[n],(!t.type||a.type===t.type)&&a.name===t.name?this.removeEventListener(a.type,a.listener,a.options):e[++r]=a;++r?e.length=r:delete this.__on}}}function kf(t,e,n){return function(){var r=this.__on,o,a=Cf(e);if(r){for(var i=0,s=r.length;i<s;++i)if((o=r[i]).type===t.type&&o.name===t.name){this.removeEventListener(o.type,o.listener,o.options),this.addEventListener(o.type,o.listener=a,o.options=n),o.value=e;return}}this.addEventListener(t.type,a,n),o={type:t.type,name:t.name,value:e,listener:a,options:n},r?r.push(o):this.__on=[o]}}function Oi(t,e,n){var r=_f(t+""),o,a=r.length,i;if(arguments.length<2){var s=this.node().__on;if(s){for(var u=0,l=s.length,f;u<l;++u)for(o=0,f=s[u];o<a;++o)if((i=r[o]).type===f.type&&i.name===f.name)return f.value}return}for(s=e?kf:Tf,o=0;o<a;++o)this.each(s(r[o],e,n));return this}function Ui(t,e,n){var r=sr(t),o=r.CustomEvent;typeof o=="function"?o=new o(e,n):(o=r.document.createEvent("Event"),n?(o.initEvent(e,n.bubbles,n.cancelable),o.detail=n.detail):o.initEvent(e,!1,!1)),t.dispatchEvent(o)}function Df(t,e){return function(){return Ui(this,t,e)}}function Ff(t,e){return function(){return Ui(this,t,e.apply(this,arguments))}}function Ri(t,e){return this.each((typeof e=="function"?Ff:Df)(t,e))}function*Bi(){for(var t=this._groups,e=0,n=t.length;e<n;++e)for(var r=t[e],o=0,a=r.length,i;o<a;++o)(i=r[o])&&(yield i)}var Mo=[null];function yt(t,e){this._groups=t,this._parents=e}function $i(){return new yt([[document.documentElement]],Mo)}function Af(){return this}yt.prototype=$i.prototype={constructor:yt,select:ja,selectAll:ti,selectChild:ei,selectChildren:ni,filter:ri,data:ii,enter:oi,exit:si,join:li,merge:ui,selection:Af,order:ci,sort:fi,call:mi,nodes:pi,node:di,size:hi,empty:gi,each:yi,attr:xi,style:bi,property:vi,classed:_i,text:Ti,html:ki,raise:Di,lower:Fi,append:Ai,insert:Ei,remove:Yi,clone:Ii,datum:Ni,on:Oi,dispatch:Ri,[Symbol.iterator]:Bi};var re=$i;function et(t){return typeof t=="string"?new yt([[document.querySelector(t)]],[document.documentElement]):new yt([[t]],Mo)}function zi(t){let e;for(;e=t.sourceEvent;)t=e;return t}function me(t,e){if(t=zi(t),e===void 0&&(e=t.currentTarget),e){var n=e.ownerSVGElement||e;if(n.createSVGPoint){var r=n.createSVGPoint();return r.x=t.clientX,r.y=t.clientY,r=r.matrixTransform(e.getScreenCTM().inverse()),[r.x,r.y]}if(e.getBoundingClientRect){var o=e.getBoundingClientRect();return[t.clientX-o.left-e.clientLeft,t.clientY-o.top-e.clientTop]}}return[t.pageX,t.pageY]}var lr={capture:!0,passive:!1};function ur(t){t.preventDefault(),t.stopImmediatePropagation()}function Co(t){var e=t.document.documentElement,n=et(t).on("dragstart.drag",ur,lr);"onselectstart"in e?n.on("selectstart.drag",ur,lr):(e.__noselect=e.style.MozUserSelect,e.style.MozUserSelect="none")}function _o(t,e){var n=t.document.documentElement,r=et(t).on("dragstart.drag",null);e&&(r.on("click.drag",ur,lr),setTimeout(function(){r.on("click.drag",null)},0)),"onselectstart"in n?r.on("selectstart.drag",null):(n.style.MozUserSelect=n.__noselect,delete n.__noselect)}function cr(t,e,n){t.prototype=e.prototype=n,n.constructor=t}function To(t,e){var n=Object.create(t.prototype);for(var r in e)n[r]=e[r];return n}function Tn(){}var Cn=.7,pr=1/Cn,Qe="\\s*([+-]?\\d+)\\s*",_n="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*",Qt="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*",Ef=/^#([0-9a-f]{3,8})$/,Yf=new RegExp(`^rgb\\(${Qe},${Qe},${Qe}\\)$`),If=new RegExp(`^rgb\\(${Qt},${Qt},${Qt}\\)$`),Nf=new RegExp(`^rgba\\(${Qe},${Qe},${Qe},${_n}\\)$`),Of=new RegExp(`^rgba\\(${Qt},${Qt},${Qt},${_n}\\)$`),Uf=new RegExp(`^hsl\\(${_n},${Qt},${Qt}\\)$`),Rf=new RegExp(`^hsla\\(${_n},${Qt},${Qt},${_n}\\)$`),Li={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074};cr(Tn,Et,{copy(t){return Object.assign(new this.constructor,this,t)},displayable(){return this.rgb().displayable()},hex:Hi,formatHex:Hi,formatHex8:Bf,formatHsl:$f,formatRgb:qi,toString:qi});function Hi(){return this.rgb().formatHex()}function Bf(){return this.rgb().formatHex8()}function $f(){return Qi(this).formatHsl()}function qi(){return this.rgb().formatRgb()}function Et(t){var e,n;return t=(t+"").trim().toLowerCase(),(e=Ef.exec(t))?(n=e[1].length,e=parseInt(e[1],16),n===6?Pi(e):n===3?new Bt(e>>8&15|e>>4&240,e>>4&15|e&240,(e&15)<<4|e&15,1):n===8?fr(e>>24&255,e>>16&255,e>>8&255,(e&255)/255):n===4?fr(e>>12&15|e>>8&240,e>>8&15|e>>4&240,e>>4&15|e&240,((e&15)<<4|e&15)/255):null):(e=Yf.exec(t))?new Bt(e[1],e[2],e[3],1):(e=If.exec(t))?new Bt(e[1]*255/100,e[2]*255/100,e[3]*255/100,1):(e=Nf.exec(t))?fr(e[1],e[2],e[3],e[4]):(e=Of.exec(t))?fr(e[1]*255/100,e[2]*255/100,e[3]*255/100,e[4]):(e=Uf.exec(t))?Gi(e[1],e[2]/100,e[3]/100,1):(e=Rf.exec(t))?Gi(e[1],e[2]/100,e[3]/100,e[4]):Li.hasOwnProperty(t)?Pi(Li[t]):t==="transparent"?new Bt(NaN,NaN,NaN,0):null}function Pi(t){return new Bt(t>>16&255,t>>8&255,t&255,1)}function fr(t,e,n,r){return r<=0&&(t=e=n=NaN),new Bt(t,e,n,r)}function zf(t){return t instanceof Tn||(t=Et(t)),t?(t=t.rgb(),new Bt(t.r,t.g,t.b,t.opacity)):new Bt}function Lt(t,e,n,r){return arguments.length===1?zf(t):new Bt(t,e,n,r??1)}function Bt(t,e,n,r){this.r=+t,this.g=+e,this.b=+n,this.opacity=+r}cr(Bt,Lt,To(Tn,{brighter(t){return t=t==null?pr:Math.pow(pr,t),new Bt(this.r*t,this.g*t,this.b*t,this.opacity)},darker(t){return t=t==null?Cn:Math.pow(Cn,t),new Bt(this.r*t,this.g*t,this.b*t,this.opacity)},rgb(){return this},clamp(){return new Bt(ke(this.r),ke(this.g),ke(this.b),dr(this.opacity))},displayable(){return-.5<=this.r&&this.r<255.5&&-.5<=this.g&&this.g<255.5&&-.5<=this.b&&this.b<255.5&&0<=this.opacity&&this.opacity<=1},hex:Vi,formatHex:Vi,formatHex8:Lf,formatRgb:Wi,toString:Wi}));function Vi(){return`#${Te(this.r)}${Te(this.g)}${Te(this.b)}`}function Lf(){return`#${Te(this.r)}${Te(this.g)}${Te(this.b)}${Te((isNaN(this.opacity)?1:this.opacity)*255)}`}function Wi(){let t=dr(this.opacity);return`${t===1?"rgb(":"rgba("}${ke(this.r)}, ${ke(this.g)}, ${ke(this.b)}${t===1?")":`, ${t})`}`}function dr(t){return isNaN(t)?1:Math.max(0,Math.min(1,t))}function ke(t){return Math.max(0,Math.min(255,Math.round(t)||0))}function Te(t){return t=ke(t),(t<16?"0":"")+t.toString(16)}function Gi(t,e,n,r){return r<=0?t=e=n=NaN:n<=0||n>=1?t=e=NaN:e<=0&&(t=NaN),new Ht(t,e,n,r)}function Qi(t){if(t instanceof Ht)return new Ht(t.h,t.s,t.l,t.opacity);if(t instanceof Tn||(t=Et(t)),!t)return new Ht;if(t instanceof Ht)return t;t=t.rgb();var e=t.r/255,n=t.g/255,r=t.b/255,o=Math.min(e,n,r),a=Math.max(e,n,r),i=NaN,s=a-o,u=(a+o)/2;return s?(e===a?i=(n-r)/s+(n<r)*6:n===a?i=(r-e)/s+2:i=(e-n)/s+4,s/=u<.5?a+o:2-a-o,i*=60):s=u>0&&u<1?0:i,new Ht(i,s,u,t.opacity)}function Zi(t,e,n,r){return arguments.length===1?Qi(t):new Ht(t,e,n,r??1)}function Ht(t,e,n,r){this.h=+t,this.s=+e,this.l=+n,this.opacity=+r}cr(Ht,Zi,To(Tn,{brighter(t){return t=t==null?pr:Math.pow(pr,t),new Ht(this.h,this.s,this.l*t,this.opacity)},darker(t){return t=t==null?Cn:Math.pow(Cn,t),new Ht(this.h,this.s,this.l*t,this.opacity)},rgb(){var t=this.h%360+(this.h<0)*360,e=isNaN(t)||isNaN(this.s)?0:this.s,n=this.l,r=n+(n<.5?n:1-n)*e,o=2*n-r;return new Bt(ko(t>=240?t-240:t+120,o,r),ko(t,o,r),ko(t<120?t+240:t-120,o,r),this.opacity)},clamp(){return new Ht(Xi(this.h),mr(this.s),mr(this.l),dr(this.opacity))},displayable(){return(0<=this.s&&this.s<=1||isNaN(this.s))&&0<=this.l&&this.l<=1&&0<=this.opacity&&this.opacity<=1},formatHsl(){let t=dr(this.opacity);return`${t===1?"hsl(":"hsla("}${Xi(this.h)}, ${mr(this.s)*100}%, ${mr(this.l)*100}%${t===1?")":`, ${t})`}`}}));function Xi(t){return t=(t||0)%360,t<0?t+360:t}function mr(t){return Math.max(0,Math.min(1,t||0))}function ko(t,e,n){return(t<60?e+(n-e)*t/60:t<180?n:t<240?e+(n-e)*(240-t)/60:e)*255}function Do(t,e,n,r,o){var a=t*t,i=a*t;return((1-3*t+3*a-i)*e+(4-6*a+3*i)*n+(1+3*t+3*a-3*i)*r+i*o)/6}function Ji(t){var e=t.length-1;return function(n){var r=n<=0?n=0:n>=1?(n=1,e-1):Math.floor(n*e),o=t[r],a=t[r+1],i=r>0?t[r-1]:2*o-a,s=r<e-1?t[r+2]:2*a-o;return Do((n-r/e)*e,i,o,a,s)}}function Ki(t){var e=t.length;return function(n){var r=Math.floor(((n%=1)<0?++n:n)*e),o=t[(r+e-1)%e],a=t[r%e],i=t[(r+1)%e],s=t[(r+2)%e];return Do((n-r/e)*e,o,a,i,s)}}var kn=t=>()=>t;function Hf(t,e){return function(n){return t+n*e}}function qf(t,e,n){return t=Math.pow(t,n),e=Math.pow(e,n)-t,n=1/n,function(r){return Math.pow(t+r*e,n)}}function ji(t){return(t=+t)==1?hr:function(e,n){return n-e?qf(e,n,t):kn(isNaN(e)?n:e)}}function hr(t,e){var n=e-t;return n?Hf(t,n):kn(isNaN(t)?e:t)}var Zt=function t(e){var n=ji(e);function r(o,a){var i=n((o=Lt(o)).r,(a=Lt(a)).r),s=n(o.g,a.g),u=n(o.b,a.b),l=hr(o.opacity,a.opacity);return function(f){return o.r=i(f),o.g=s(f),o.b=u(f),o.opacity=l(f),o+""}}return r.gamma=t,r}(1);function ts(t){return function(e){var n=e.length,r=new Array(n),o=new Array(n),a=new Array(n),i,s;for(i=0;i<n;++i)s=Lt(e[i]),r[i]=s.r||0,o[i]=s.g||0,a[i]=s.b||0;return r=t(r),o=t(o),a=t(a),s.opacity=1,function(u){return s.r=r(u),s.g=o(u),s.b=a(u),s+""}}}var Pf=ts(Ji),Vf=ts(Ki);function es(t,e){e||(e=[]);var n=t?Math.min(e.length,t.length):0,r=e.slice(),o;return function(a){for(o=0;o<n;++o)r[o]=t[o]*(1-a)+e[o]*a;return r}}function ns(t){return ArrayBuffer.isView(t)&&!(t instanceof DataView)}function rs(t,e){var n=e?e.length:0,r=t?Math.min(n,t.length):0,o=new Array(r),a=new Array(n),i;for(i=0;i<r;++i)o[i]=oe(t[i],e[i]);for(;i<n;++i)a[i]=e[i];return function(s){for(i=0;i<r;++i)a[i]=o[i](s);return a}}function os(t,e){var n=new Date;return t=+t,e=+e,function(r){return n.setTime(t*(1-r)+e*r),n}}function Yt(t,e){return t=+t,e=+e,function(n){return t*(1-n)+e*n}}function as(t,e){var n={},r={},o;(t===null||typeof t!="object")&&(t={}),(e===null||typeof e!="object")&&(e={});for(o in e)o in t?n[o]=oe(t[o],e[o]):r[o]=e[o];return function(a){for(o in n)r[o]=n[o](a);return r}}var Ao=/[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,Fo=new RegExp(Ao.source,"g");function Wf(t){return function(){return t}}function Gf(t){return function(e){return t(e)+""}}function Dn(t,e){var n=Ao.lastIndex=Fo.lastIndex=0,r,o,a,i=-1,s=[],u=[];for(t=t+"",e=e+"";(r=Ao.exec(t))&&(o=Fo.exec(e));)(a=o.index)>n&&(a=e.slice(n,a),s[i]?s[i]+=a:s[++i]=a),(r=r[0])===(o=o[0])?s[i]?s[i]+=o:s[++i]=o:(s[++i]=null,u.push({i,x:Yt(r,o)})),n=Fo.lastIndex;return n<e.length&&(a=e.slice(n),s[i]?s[i]+=a:s[++i]=a),s.length<2?u[0]?Gf(u[0].x):Wf(e):(e=u.length,function(l){for(var f=0,c;f<e;++f)s[(c=u[f]).i]=c.x(l);return s.join("")})}function oe(t,e){var n=typeof e,r;return e==null||n==="boolean"?kn(e):(n==="number"?Yt:n==="string"?(r=Et(e))?(e=r,Zt):Dn:e instanceof Et?Zt:e instanceof Date?os:ns(e)?es:Array.isArray(e)?rs:typeof e.valueOf!="function"&&typeof e.toString!="function"||isNaN(e)?as:Yt)(t,e)}function Eo(t,e){return t=+t,e=+e,function(n){return Math.round(t*(1-n)+e*n)}}var is=180/Math.PI,gr={translateX:0,translateY:0,rotate:0,skewX:0,scaleX:1,scaleY:1};function Yo(t,e,n,r,o,a){var i,s,u;return(i=Math.sqrt(t*t+e*e))&&(t/=i,e/=i),(u=t*n+e*r)&&(n-=t*u,r-=e*u),(s=Math.sqrt(n*n+r*r))&&(n/=s,r/=s,u/=s),t*r<e*n&&(t=-t,e=-e,u=-u,i=-i),{translateX:o,translateY:a,rotate:Math.atan2(e,t)*is,skewX:Math.atan(u)*is,scaleX:i,scaleY:s}}var yr;function ss(t){let e=new(typeof DOMMatrix=="function"?DOMMatrix:WebKitCSSMatrix)(t+"");return e.isIdentity?gr:Yo(e.a,e.b,e.c,e.d,e.e,e.f)}function ls(t){return t==null?gr:(yr||(yr=document.createElementNS("http://www.w3.org/2000/svg","g")),yr.setAttribute("transform",t),(t=yr.transform.baseVal.consolidate())?(t=t.matrix,Yo(t.a,t.b,t.c,t.d,t.e,t.f)):gr)}function us(t,e,n,r){function o(l){return l.length?l.pop()+" ":""}function a(l,f,c,m,d,b){if(l!==c||f!==m){var M=d.push("translate(",null,e,null,n);b.push({i:M-4,x:Yt(l,c)},{i:M-2,x:Yt(f,m)})}else(c||m)&&d.push("translate("+c+e+m+n)}function i(l,f,c,m){l!==f?(l-f>180?f+=360:f-l>180&&(l+=360),m.push({i:c.push(o(c)+"rotate(",null,r)-2,x:Yt(l,f)})):f&&c.push(o(c)+"rotate("+f+r)}function s(l,f,c,m){l!==f?m.push({i:c.push(o(c)+"skewX(",null,r)-2,x:Yt(l,f)}):f&&c.push(o(c)+"skewX("+f+r)}function u(l,f,c,m,d,b){if(l!==c||f!==m){var M=d.push(o(d)+"scale(",null,",",null,")");b.push({i:M-4,x:Yt(l,c)},{i:M-2,x:Yt(f,m)})}else(c!==1||m!==1)&&d.push(o(d)+"scale("+c+","+m+")")}return function(l,f){var c=[],m=[];return l=t(l),f=t(f),a(l.translateX,l.translateY,f.translateX,f.translateY,c,m),i(l.rotate,f.rotate,c,m),s(l.skewX,f.skewX,c,m),u(l.scaleX,l.scaleY,f.scaleX,f.scaleY,c,m),l=f=null,function(d){for(var b=-1,M=m.length,h;++b<M;)c[(h=m[b]).i]=h.x(d);return c.join("")}}}var Io=us(ss,"px, ","px)","deg)"),No=us(ls,", ",")",")");var Ze=0,An=0,Fn=0,fs=1e3,xr,En,br=0,De=0,vr=0,Yn=typeof performance=="object"&&performance.now?performance:Date,ms=typeof window=="object"&&window.requestAnimationFrame?window.requestAnimationFrame.bind(window):function(t){setTimeout(t,17)};function Nn(){return De||(ms(Xf),De=Yn.now()+vr)}function Xf(){De=0}function In(){this._call=this._time=this._next=null}In.prototype=wr.prototype={constructor:In,restart:function(t,e,n){if(typeof t!="function")throw new TypeError("callback is not a function");n=(n==null?Nn():+n)+(e==null?0:+e),!this._next&&En!==this&&(En?En._next=this:xr=this,En=this),this._call=t,this._time=n,Oo()},stop:function(){this._call&&(this._call=null,this._time=1/0,Oo())}};function wr(t,e,n){var r=new In;return r.restart(t,e,n),r}function ps(){Nn(),++Ze;for(var t=xr,e;t;)(e=De-t._time)>=0&&t._call.call(void 0,e),t=t._next;--Ze}function cs(){De=(br=Yn.now())+vr,Ze=An=0;try{ps()}finally{Ze=0,Zf(),De=0}}function Qf(){var t=Yn.now(),e=t-br;e>fs&&(vr-=e,br=t)}function Zf(){for(var t,e=xr,n,r=1/0;e;)e._call?(r>e._time&&(r=e._time),t=e,e=e._next):(n=e._next,e._next=null,e=t?t._next=n:xr=n);En=t,Oo(r)}function Oo(t){if(!Ze){An&&(An=clearTimeout(An));var e=t-De;e>24?(t<1/0&&(An=setTimeout(cs,t-Yn.now()-vr)),Fn&&(Fn=clearInterval(Fn))):(Fn||(br=Yn.now(),Fn=setInterval(Qf,fs)),Ze=1,ms(cs))}}function Sr(t,e,n){var r=new In;return e=e==null?0:+e,r.restart(o=>{r.stop(),t(o+e)},e,n),r}var Jf=vn("start","end","cancel","interrupt"),Kf=[],gs=0,ds=1,Cr=2,Mr=3,hs=4,_r=5,On=6;function pe(t,e,n,r,o,a){var i=t.__transition;if(!i)t.__transition={};else if(n in i)return;jf(t,n,{name:e,index:r,group:o,on:Jf,tween:Kf,time:a.time,delay:a.delay,duration:a.duration,ease:a.ease,timer:null,state:gs})}function Un(t,e){var n=_t(t,e);if(n.state>gs)throw new Error("too late; already scheduled");return n}function It(t,e){var n=_t(t,e);if(n.state>Mr)throw new Error("too late; already running");return n}function _t(t,e){var n=t.__transition;if(!n||!(n=n[e]))throw new Error("transition not found");return n}function jf(t,e,n){var r=t.__transition,o;r[e]=n,n.timer=wr(a,0,n.time);function a(l){n.state=ds,n.timer.restart(i,n.delay,n.time),n.delay<=l&&i(l-n.delay)}function i(l){var f,c,m,d;if(n.state!==ds)return u();for(f in r)if(d=r[f],d.name===n.name){if(d.state===Mr)return Sr(i);d.state===hs?(d.state=On,d.timer.stop(),d.on.call("interrupt",t,t.__data__,d.index,d.group),delete r[f]):+f<e&&(d.state=On,d.timer.stop(),d.on.call("cancel",t,t.__data__,d.index,d.group),delete r[f])}if(Sr(function(){n.state===Mr&&(n.state=hs,n.timer.restart(s,n.delay,n.time),s(l))}),n.state=Cr,n.on.call("start",t,t.__data__,n.index,n.group),n.state===Cr){for(n.state=Mr,o=new Array(m=n.tween.length),f=0,c=-1;f<m;++f)(d=n.tween[f].value.call(t,t.__data__,n.index,n.group))&&(o[++c]=d);o.length=c+1}}function s(l){for(var f=l<n.duration?n.ease.call(null,l/n.duration):(n.timer.restart(u),n.state=_r,1),c=-1,m=o.length;++c<m;)o[c].call(t,f);n.state===_r&&(n.on.call("end",t,t.__data__,n.index,n.group),u())}function u(){n.state=On,n.timer.stop(),delete r[e];for(var l in r)return;delete t.__transition}}function Fe(t,e){var n=t.__transition,r,o,a=!0,i;if(n){e=e==null?null:e+"";for(i in n){if((r=n[i]).name!==e){a=!1;continue}o=r.state>Cr&&r.state<_r,r.state=On,r.timer.stop(),r.on.call(o?"interrupt":"cancel",t,t.__data__,r.index,r.group),delete n[i]}a&&delete t.__transition}}function ys(t){return this.each(function(){Fe(this,t)})}function tm(t,e){var n,r;return function(){var o=It(this,t),a=o.tween;if(a!==n){r=n=a;for(var i=0,s=r.length;i<s;++i)if(r[i].name===e){r=r.slice(),r.splice(i,1);break}}o.tween=r}}function em(t,e,n){var r,o;if(typeof n!="function")throw new Error;return function(){var a=It(this,t),i=a.tween;if(i!==r){o=(r=i).slice();for(var s={name:e,value:n},u=0,l=o.length;u<l;++u)if(o[u].name===e){o[u]=s;break}u===l&&o.push(s)}a.tween=o}}function xs(t,e){var n=this._id;if(t+="",arguments.length<2){for(var r=_t(this.node(),n).tween,o=0,a=r.length,i;o<a;++o)if((i=r[o]).name===t)return i.value;return null}return this.each((e==null?tm:em)(n,t,e))}function Je(t,e,n){var r=t._id;return t.each(function(){var o=It(this,r);(o.value||(o.value={}))[e]=n.apply(this,arguments)}),function(o){return _t(o,r).value[e]}}function Tr(t,e){var n;return(typeof e=="number"?Yt:e instanceof Et?Zt:(n=Et(e))?(e=n,Zt):Dn)(t,e)}function nm(t){return function(){this.removeAttribute(t)}}function rm(t){return function(){this.removeAttributeNS(t.space,t.local)}}function om(t,e,n){var r,o=n+"",a;return function(){var i=this.getAttribute(t);return i===o?null:i===r?a:a=e(r=i,n)}}function am(t,e,n){var r,o=n+"",a;return function(){var i=this.getAttributeNS(t.space,t.local);return i===o?null:i===r?a:a=e(r=i,n)}}function im(t,e,n){var r,o,a;return function(){var i,s=n(this),u;return s==null?void this.removeAttribute(t):(i=this.getAttribute(t),u=s+"",i===u?null:i===r&&u===o?a:(o=u,a=e(r=i,s)))}}function sm(t,e,n){var r,o,a;return function(){var i,s=n(this),u;return s==null?void this.removeAttributeNS(t.space,t.local):(i=this.getAttributeNS(t.space,t.local),u=s+"",i===u?null:i===r&&u===o?a:(o=u,a=e(r=i,s)))}}function bs(t,e){var n=ne(t),r=n==="transform"?No:Tr;return this.attrTween(t,typeof e=="function"?(n.local?sm:im)(n,r,Je(this,"attr."+t,e)):e==null?(n.local?rm:nm)(n):(n.local?am:om)(n,r,e))}function lm(t,e){return function(n){this.setAttribute(t,e.call(this,n))}}function um(t,e){return function(n){this.setAttributeNS(t.space,t.local,e.call(this,n))}}function cm(t,e){var n,r;function o(){var a=e.apply(this,arguments);return a!==r&&(n=(r=a)&&um(t,a)),n}return o._value=e,o}function fm(t,e){var n,r;function o(){var a=e.apply(this,arguments);return a!==r&&(n=(r=a)&&lm(t,a)),n}return o._value=e,o}function vs(t,e){var n="attr."+t;if(arguments.length<2)return(n=this.tween(n))&&n._value;if(e==null)return this.tween(n,null);if(typeof e!="function")throw new Error;var r=ne(t);return this.tween(n,(r.local?cm:fm)(r,e))}function mm(t,e){return function(){Un(this,t).delay=+e.apply(this,arguments)}}function pm(t,e){return e=+e,function(){Un(this,t).delay=e}}function ws(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?mm:pm)(e,t)):_t(this.node(),e).delay}function dm(t,e){return function(){It(this,t).duration=+e.apply(this,arguments)}}function hm(t,e){return e=+e,function(){It(this,t).duration=e}}function Ss(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?dm:hm)(e,t)):_t(this.node(),e).duration}function gm(t,e){if(typeof e!="function")throw new Error;return function(){It(this,t).ease=e}}function Ms(t){var e=this._id;return arguments.length?this.each(gm(e,t)):_t(this.node(),e).ease}function ym(t,e){return function(){var n=e.apply(this,arguments);if(typeof n!="function")throw new Error;It(this,t).ease=n}}function Cs(t){if(typeof t!="function")throw new Error;return this.each(ym(this._id,t))}function _s(t){typeof t!="function"&&(t=Sn(t));for(var e=this._groups,n=e.length,r=new Array(n),o=0;o<n;++o)for(var a=e[o],i=a.length,s=r[o]=[],u,l=0;l<i;++l)(u=a[l])&&t.call(u,u.__data__,l,a)&&s.push(u);return new Ut(r,this._parents,this._name,this._id)}function Ts(t){if(t._id!==this._id)throw new Error;for(var e=this._groups,n=t._groups,r=e.length,o=n.length,a=Math.min(r,o),i=new Array(r),s=0;s<a;++s)for(var u=e[s],l=n[s],f=u.length,c=i[s]=new Array(f),m,d=0;d<f;++d)(m=u[d]||l[d])&&(c[d]=m);for(;s<r;++s)i[s]=e[s];return new Ut(i,this._parents,this._name,this._id)}function xm(t){return(t+"").trim().split(/^|\s+/).every(function(e){var n=e.indexOf(".");return n>=0&&(e=e.slice(0,n)),!e||e==="start"})}function bm(t,e,n){var r,o,a=xm(e)?Un:It;return function(){var i=a(this,t),s=i.on;s!==r&&(o=(r=s).copy()).on(e,n),i.on=o}}function ks(t,e){var n=this._id;return arguments.length<2?_t(this.node(),n).on.on(t):this.each(bm(n,t,e))}function vm(t){return function(){var e=this.parentNode;for(var n in this.__transition)if(+n!==t)return;e&&e.removeChild(this)}}function Ds(){return this.on("end.remove",vm(this._id))}function Fs(t){var e=this._name,n=this._id;typeof t!="function"&&(t=_e(t));for(var r=this._groups,o=r.length,a=new Array(o),i=0;i<o;++i)for(var s=r[i],u=s.length,l=a[i]=new Array(u),f,c,m=0;m<u;++m)(f=s[m])&&(c=t.call(f,f.__data__,m,s))&&("__data__"in f&&(c.__data__=f.__data__),l[m]=c,pe(l[m],e,n,m,l,_t(f,n)));return new Ut(a,this._parents,e,n)}function As(t){var e=this._name,n=this._id;typeof t!="function"&&(t=wn(t));for(var r=this._groups,o=r.length,a=[],i=[],s=0;s<o;++s)for(var u=r[s],l=u.length,f,c=0;c<l;++c)if(f=u[c]){for(var m=t.call(f,f.__data__,c,u),d,b=_t(f,n),M=0,h=m.length;M<h;++M)(d=m[M])&&pe(d,e,n,M,m,b);a.push(m),i.push(f)}return new Ut(a,i,e,n)}var wm=re.prototype.constructor;function Es(){return new wm(this._groups,this._parents)}function Sm(t,e){var n,r,o;return function(){var a=fe(this,t),i=(this.style.removeProperty(t),fe(this,t));return a===i?null:a===n&&i===r?o:o=e(n=a,r=i)}}function Ys(t){return function(){this.style.removeProperty(t)}}function Mm(t,e,n){var r,o=n+"",a;return function(){var i=fe(this,t);return i===o?null:i===r?a:a=e(r=i,n)}}function Cm(t,e,n){var r,o,a;return function(){var i=fe(this,t),s=n(this),u=s+"";return s==null&&(u=s=(this.style.removeProperty(t),fe(this,t))),i===u?null:i===r&&u===o?a:(o=u,a=e(r=i,s))}}function _m(t,e){var n,r,o,a="style."+e,i="end."+a,s;return function(){var u=It(this,t),l=u.on,f=u.value[a]==null?s||(s=Ys(e)):void 0;(l!==n||o!==f)&&(r=(n=l).copy()).on(i,o=f),u.on=r}}function Is(t,e,n){var r=(t+="")=="transform"?Io:Tr;return e==null?this.styleTween(t,Sm(t,r)).on("end.style."+t,Ys(t)):typeof e=="function"?this.styleTween(t,Cm(t,r,Je(this,"style."+t,e))).each(_m(this._id,t)):this.styleTween(t,Mm(t,r,e),n).on("end.style."+t,null)}function Tm(t,e,n){return function(r){this.style.setProperty(t,e.call(this,r),n)}}function km(t,e,n){var r,o;function a(){var i=e.apply(this,arguments);return i!==o&&(r=(o=i)&&Tm(t,i,n)),r}return a._value=e,a}function Ns(t,e,n){var r="style."+(t+="");if(arguments.length<2)return(r=this.tween(r))&&r._value;if(e==null)return this.tween(r,null);if(typeof e!="function")throw new Error;return this.tween(r,km(t,e,n??""))}function Dm(t){return function(){this.textContent=t}}function Fm(t){return function(){var e=t(this);this.textContent=e??""}}function Os(t){return this.tween("text",typeof t=="function"?Fm(Je(this,"text",t)):Dm(t==null?"":t+""))}function Am(t){return function(e){this.textContent=t.call(this,e)}}function Em(t){var e,n;function r(){var o=t.apply(this,arguments);return o!==n&&(e=(n=o)&&Am(o)),e}return r._value=t,r}function Us(t){var e="text";if(arguments.length<1)return(e=this.tween(e))&&e._value;if(t==null)return this.tween(e,null);if(typeof t!="function")throw new Error;return this.tween(e,Em(t))}function Rs(){for(var t=this._name,e=this._id,n=kr(),r=this._groups,o=r.length,a=0;a<o;++a)for(var i=r[a],s=i.length,u,l=0;l<s;++l)if(u=i[l]){var f=_t(u,e);pe(u,t,n,l,i,{time:f.time+f.delay+f.duration,delay:0,duration:f.duration,ease:f.ease})}return new Ut(r,this._parents,t,n)}function Bs(){var t,e,n=this,r=n._id,o=n.size();return new Promise(function(a,i){var s={value:i},u={value:function(){--o===0&&a()}};n.each(function(){var l=It(this,r),f=l.on;f!==t&&(e=(t=f).copy(),e._.cancel.push(s),e._.interrupt.push(s),e._.end.push(u)),l.on=e}),o===0&&a()})}var Ym=0;function Ut(t,e,n,r){this._groups=t,this._parents=e,this._name=n,this._id=r}function $s(t){return re().transition(t)}function kr(){return++Ym}var ae=re.prototype;Ut.prototype=$s.prototype={constructor:Ut,select:Fs,selectAll:As,selectChild:ae.selectChild,selectChildren:ae.selectChildren,filter:_s,merge:Ts,selection:Es,transition:Rs,call:ae.call,nodes:ae.nodes,node:ae.node,size:ae.size,empty:ae.empty,each:ae.each,on:ks,attr:bs,attrTween:vs,style:Is,styleTween:Ns,text:Os,textTween:Us,remove:Ds,tween:xs,delay:ws,duration:Ss,ease:Ms,easeVarying:Cs,end:Bs,[Symbol.iterator]:ae[Symbol.iterator]};function Dr(t){return((t*=2)<=1?t*t*t:(t-=2)*t*t+2)/2}var Im={time:null,delay:0,duration:250,ease:Dr};function Nm(t,e){for(var n;!(n=t.__transition)||!(n=n[e]);)if(!(t=t.parentNode))throw new Error(`transition ${e} not found`);return n}function zs(t){var e,n;t instanceof Ut?(e=t._id,t=t._name):(e=kr(),(n=Im).time=Nn(),t=t==null?null:t+"");for(var r=this._groups,o=r.length,a=0;a<o;++a)for(var i=r[a],s=i.length,u,l=0;l<s;++l)(u=i[l])&&pe(u,t,e,l,i,n||Nm(u,e));return new Ut(r,this._parents,t,e)}re.prototype.interrupt=ys;re.prototype.transition=zs;var Fr=t=>()=>t;function Uo(t,{sourceEvent:e,target:n,selection:r,mode:o,dispatch:a}){Object.defineProperties(this,{type:{value:t,enumerable:!0,configurable:!0},sourceEvent:{value:e,enumerable:!0,configurable:!0},target:{value:n,enumerable:!0,configurable:!0},selection:{value:r,enumerable:!0,configurable:!0},mode:{value:o,enumerable:!0,configurable:!0},_:{value:a}})}function Ls(t){t.stopImmediatePropagation()}function Ar(t){t.preventDefault(),t.stopImmediatePropagation()}var Hs={name:"drag"},Ro={name:"space"},Ke={name:"handle"},je={name:"center"},{abs:qs,max:Nt,min:Ot}=Math;function Ps(t){return[+t[0],+t[1]]}function zo(t){return[Ps(t[0]),Ps(t[1])]}var Er={name:"x",handles:["w","e"].map(Rn),input:function(t,e){return t==null?null:[[+t[0],e[0][1]],[+t[1],e[1][1]]]},output:function(t){return t&&[t[0][0],t[1][0]]}},Bo={name:"y",handles:["n","s"].map(Rn),input:function(t,e){return t==null?null:[[e[0][0],+t[0]],[e[1][0],+t[1]]]},output:function(t){return t&&[t[0][1],t[1][1]]}},hw={name:"xy",handles:["n","w","e","s","nw","ne","sw","se"].map(Rn),input:function(t){return t==null?null:zo(t)},output:function(t){return t}},ie={overlay:"crosshair",selection:"move",n:"ns-resize",e:"ew-resize",s:"ns-resize",w:"ew-resize",nw:"nwse-resize",ne:"nesw-resize",se:"nwse-resize",sw:"nesw-resize"},Vs={e:"w",w:"e",nw:"ne",ne:"nw",se:"sw",sw:"se"},Ws={n:"s",s:"n",nw:"sw",ne:"se",se:"ne",sw:"nw"},Om={overlay:1,selection:1,n:null,e:1,s:null,w:-1,nw:-1,ne:1,se:1,sw:-1},Um={overlay:1,selection:1,n:-1,e:null,s:1,w:null,nw:-1,ne:-1,se:1,sw:1};function Rn(t){return{type:t}}function Rm(t){return!t.ctrlKey&&!t.button}function Bm(){var t=this.ownerSVGElement||this;return t.hasAttribute("viewBox")?(t=t.viewBox.baseVal,[[t.x,t.y],[t.x+t.width,t.y+t.height]]):[[0,0],[t.width.baseVal.value,t.height.baseVal.value]]}function $m(){return navigator.maxTouchPoints||"ontouchstart"in this}function $o(t){for(;!t.__brush;)if(!(t=t.parentNode))return;return t.__brush}function zm(t){return t[0][0]===t[1][0]||t[0][1]===t[1][1]}function Lo(){return Lm(Er)}function Lm(t){var e=Bm,n=Rm,r=$m,o=!0,a=vn("start","brush","end"),i=6,s;function u(h){var g=h.property("__brush",M).selectAll(".overlay").data([Rn("overlay")]);g.enter().append("rect").attr("class","overlay").attr("pointer-events","all").attr("cursor",ie.overlay).merge(g).each(function(){var x=$o(this).extent;et(this).attr("x",x[0][0]).attr("y",x[0][1]).attr("width",x[1][0]-x[0][0]).attr("height",x[1][1]-x[0][1])}),h.selectAll(".selection").data([Rn("selection")]).enter().append("rect").attr("class","selection").attr("cursor",ie.selection).attr("fill","#777").attr("fill-opacity",.3).attr("stroke","#fff").attr("shape-rendering","crispEdges");var T=h.selectAll(".handle").data(t.handles,function(x){return x.type});T.exit().remove(),T.enter().append("rect").attr("class",function(x){return"handle handle--"+x.type}).attr("cursor",function(x){return ie[x.type]}),h.each(l).attr("fill","none").attr("pointer-events","all").on("mousedown.brush",m).filter(r).on("touchstart.brush",m).on("touchmove.brush",d).on("touchend.brush touchcancel.brush",b).style("touch-action","none").style("-webkit-tap-highlight-color","rgba(0,0,0,0)")}u.move=function(h,g,T){h.tween?h.on("start.brush",function(x){f(this,arguments).beforestart().start(x)}).on("interrupt.brush end.brush",function(x){f(this,arguments).end(x)}).tween("brush",function(){var x=this,_=x.__brush,v=f(x,arguments),w=_.selection,O=t.input(typeof g=="function"?g.apply(this,arguments):g,_.extent),R=oe(w,O);function st(q){_.selection=q===1&&O===null?null:R(q),l.call(x),v.brush()}return w!==null&&O!==null?st:st(1)}):h.each(function(){var x=this,_=arguments,v=x.__brush,w=t.input(typeof g=="function"?g.apply(x,_):g,v.extent),O=f(x,_).beforestart();Fe(x),v.selection=w===null?null:w,l.call(x),O.start(T).brush(T).end(T)})},u.clear=function(h,g){u.move(h,null,g)};function l(){var h=et(this),g=$o(this).selection;g?(h.selectAll(".selection").style("display",null).attr("x",g[0][0]).attr("y",g[0][1]).attr("width",g[1][0]-g[0][0]).attr("height",g[1][1]-g[0][1]),h.selectAll(".handle").style("display",null).attr("x",function(T){return T.type[T.type.length-1]==="e"?g[1][0]-i/2:g[0][0]-i/2}).attr("y",function(T){return T.type[0]==="s"?g[1][1]-i/2:g[0][1]-i/2}).attr("width",function(T){return T.type==="n"||T.type==="s"?g[1][0]-g[0][0]+i:i}).attr("height",function(T){return T.type==="e"||T.type==="w"?g[1][1]-g[0][1]+i:i})):h.selectAll(".selection,.handle").style("display","none").attr("x",null).attr("y",null).attr("width",null).attr("height",null)}function f(h,g,T){var x=h.__brush.emitter;return x&&(!T||!x.clean)?x:new c(h,g,T)}function c(h,g,T){this.that=h,this.args=g,this.state=h.__brush,this.active=0,this.clean=T}c.prototype={beforestart:function(){return++this.active===1&&(this.state.emitter=this,this.starting=!0),this},start:function(h,g){return this.starting?(this.starting=!1,this.emit("start",h,g)):this.emit("brush",h),this},brush:function(h,g){return this.emit("brush",h,g),this},end:function(h,g){return--this.active===0&&(delete this.state.emitter,this.emit("end",h,g)),this},emit:function(h,g,T){var x=et(this.that).datum();a.call(h,this.that,new Uo(h,{sourceEvent:g,target:u,selection:t.output(this.state.selection),mode:T,dispatch:a}),x)}};function m(h){if(s&&!h.touches||!n.apply(this,arguments))return;var g=this,T=h.target.__data__.type,x=(o&&h.metaKey?T="overlay":T)==="selection"?Hs:o&&h.altKey?je:Ke,_=t===Bo?null:Om[T],v=t===Er?null:Um[T],w=$o(g),O=w.extent,R=w.selection,st=O[0][0],q,S,H=O[0][1],Y,Z,gt=O[1][0],G,K,ht=O[1][1],B,ft,mt=0,pt=0,Pt,Vt=_&&v&&o&&h.shiftKey,E,j,X=Array.from(h.touches||[h],D=>{let U=D.identifier;return D=me(D,g),D.point0=D.slice(),D.identifier=U,D});Fe(g);var P=f(g,arguments,!0).beforestart();if(T==="overlay"){R&&(Pt=!0);let D=[X[0],X[1]||X[0]];w.selection=R=[[q=t===Bo?st:Ot(D[0][0],D[1][0]),Y=t===Er?H:Ot(D[0][1],D[1][1])],[G=t===Bo?gt:Nt(D[0][0],D[1][0]),B=t===Er?ht:Nt(D[0][1],D[1][1])]],X.length>1&&L(h)}else q=R[0][0],Y=R[0][1],G=R[1][0],B=R[1][1];S=q,Z=Y,K=G,ft=B;var y=et(g).attr("pointer-events","none"),C=y.selectAll(".overlay").attr("cursor",ie[T]);if(h.touches)P.moved=p,P.ended=A;else{var k=et(h.view).on("mousemove.brush",p,!0).on("mouseup.brush",A,!0);o&&k.on("keydown.brush",V,!0).on("keyup.brush",I,!0),Co(h.view)}l.call(g),P.start(h,x.name);function p(D){for(let U of D.changedTouches||[D])for(let Wt of X)Wt.identifier===U.identifier&&(Wt.cur=me(U,g));if(Vt&&!E&&!j&&X.length===1){let U=X[0];qs(U.cur[0]-U[0])>qs(U.cur[1]-U[1])?j=!0:E=!0}for(let U of X)U.cur&&(U[0]=U.cur[0],U[1]=U.cur[1]);Pt=!0,Ar(D),L(D)}function L(D){let U=X[0],Wt=U.point0;var dt;switch(mt=U[0]-Wt[0],pt=U[1]-Wt[1],x){case Ro:case Hs:{_&&(mt=Nt(st-q,Ot(gt-G,mt)),S=q+mt,K=G+mt),v&&(pt=Nt(H-Y,Ot(ht-B,pt)),Z=Y+pt,ft=B+pt);break}case Ke:{X[1]?(_&&(S=Nt(st,Ot(gt,X[0][0])),K=Nt(st,Ot(gt,X[1][0])),_=1),v&&(Z=Nt(H,Ot(ht,X[0][1])),ft=Nt(H,Ot(ht,X[1][1])),v=1)):(_<0?(mt=Nt(st-q,Ot(gt-q,mt)),S=q+mt,K=G):_>0&&(mt=Nt(st-G,Ot(gt-G,mt)),S=q,K=G+mt),v<0?(pt=Nt(H-Y,Ot(ht-Y,pt)),Z=Y+pt,ft=B):v>0&&(pt=Nt(H-B,Ot(ht-B,pt)),Z=Y,ft=B+pt));break}case je:{_&&(S=Nt(st,Ot(gt,q-mt*_)),K=Nt(st,Ot(gt,G+mt*_))),v&&(Z=Nt(H,Ot(ht,Y-pt*v)),ft=Nt(H,Ot(ht,B+pt*v)));break}}K<S&&(_*=-1,dt=q,q=G,G=dt,dt=S,S=K,K=dt,T in Vs&&C.attr("cursor",ie[T=Vs[T]])),ft<Z&&(v*=-1,dt=Y,Y=B,B=dt,dt=Z,Z=ft,ft=dt,T in Ws&&C.attr("cursor",ie[T=Ws[T]])),w.selection&&(R=w.selection),E&&(S=R[0][0],K=R[1][0]),j&&(Z=R[0][1],ft=R[1][1]),(R[0][0]!==S||R[0][1]!==Z||R[1][0]!==K||R[1][1]!==ft)&&(w.selection=[[S,Z],[K,ft]],l.call(g),P.brush(D,x.name))}function A(D){if(Ls(D),D.touches){if(D.touches.length)return;s&&clearTimeout(s),s=setTimeout(function(){s=null},500)}else _o(D.view,Pt),k.on("keydown.brush keyup.brush mousemove.brush mouseup.brush",null);y.attr("pointer-events","all"),C.attr("cursor",ie.overlay),w.selection&&(R=w.selection),zm(R)&&(w.selection=null,l.call(g)),P.end(D,x.name)}function V(D){switch(D.keyCode){case 16:{Vt=_&&v;break}case 18:{x===Ke&&(_&&(G=K-mt*_,q=S+mt*_),v&&(B=ft-pt*v,Y=Z+pt*v),x=je,L(D));break}case 32:{(x===Ke||x===je)&&(_<0?G=K-mt:_>0&&(q=S-mt),v<0?B=ft-pt:v>0&&(Y=Z-pt),x=Ro,C.attr("cursor",ie.selection),L(D));break}default:return}Ar(D)}function I(D){switch(D.keyCode){case 16:{Vt&&(E=j=Vt=!1,L(D));break}case 18:{x===je&&(_<0?G=K:_>0&&(q=S),v<0?B=ft:v>0&&(Y=Z),x=Ke,L(D));break}case 32:{x===Ro&&(D.altKey?(_&&(G=K-mt*_,q=S+mt*_),v&&(B=ft-pt*v,Y=Z+pt*v),x=je):(_<0?G=K:_>0&&(q=S),v<0?B=ft:v>0&&(Y=Z),x=Ke),C.attr("cursor",ie[T]),L(D));break}default:return}Ar(D)}}function d(h){f(this,arguments).moved(h)}function b(h){f(this,arguments).ended(h)}function M(){var h=this.__brush||{selection:null};return h.extent=zo(e.apply(this,arguments)),h.dim=t,h}return u.extent=function(h){return arguments.length?(e=typeof h=="function"?h:Fr(zo(h)),u):e},u.filter=function(h){return arguments.length?(n=typeof h=="function"?h:Fr(!!h),u):n},u.touchable=function(h){return arguments.length?(r=typeof h=="function"?h:Fr(!!h),u):r},u.handleSize=function(h){return arguments.length?(i=+h,u):i},u.keyModifiers=function(h){return arguments.length?(o=!!h,u):o},u.on=function(){var h=a.on.apply(a,arguments);return h===a?u:h},u}var Ho=Math.PI,qo=2*Ho,Ae=1e-6,Hm=qo-Ae;function Gs(t){this._+=t[0];for(let e=1,n=t.length;e<n;++e)this._+=arguments[e]+t[e]}function qm(t){let e=Math.floor(t);if(!(e>=0))throw new Error(`invalid digits: ${t}`);if(e>15)return Gs;let n=10**e;return function(r){this._+=r[0];for(let o=1,a=r.length;o<a;++o)this._+=Math.round(arguments[o]*n)/n+r[o]}}var Ee=class{constructor(e){this._x0=this._y0=this._x1=this._y1=null,this._="",this._append=e==null?Gs:qm(e)}moveTo(e,n){this._append`M${this._x0=this._x1=+e},${this._y0=this._y1=+n}`}closePath(){this._x1!==null&&(this._x1=this._x0,this._y1=this._y0,this._append`Z`)}lineTo(e,n){this._append`L${this._x1=+e},${this._y1=+n}`}quadraticCurveTo(e,n,r,o){this._append`Q${+e},${+n},${this._x1=+r},${this._y1=+o}`}bezierCurveTo(e,n,r,o,a,i){this._append`C${+e},${+n},${+r},${+o},${this._x1=+a},${this._y1=+i}`}arcTo(e,n,r,o,a){if(e=+e,n=+n,r=+r,o=+o,a=+a,a<0)throw new Error(`negative radius: ${a}`);let i=this._x1,s=this._y1,u=r-e,l=o-n,f=i-e,c=s-n,m=f*f+c*c;if(this._x1===null)this._append`M${this._x1=e},${this._y1=n}`;else if(m>Ae)if(!(Math.abs(c*u-l*f)>Ae)||!a)this._append`L${this._x1=e},${this._y1=n}`;else{let d=r-i,b=o-s,M=u*u+l*l,h=d*d+b*b,g=Math.sqrt(M),T=Math.sqrt(m),x=a*Math.tan((Ho-Math.acos((M+m-h)/(2*g*T)))/2),_=x/T,v=x/g;Math.abs(_-1)>Ae&&this._append`L${e+_*f},${n+_*c}`,this._append`A${a},${a},0,0,${+(c*d>f*b)},${this._x1=e+v*u},${this._y1=n+v*l}`}}arc(e,n,r,o,a,i){if(e=+e,n=+n,r=+r,i=!!i,r<0)throw new Error(`negative radius: ${r}`);let s=r*Math.cos(o),u=r*Math.sin(o),l=e+s,f=n+u,c=1^i,m=i?o-a:a-o;this._x1===null?this._append`M${l},${f}`:(Math.abs(this._x1-l)>Ae||Math.abs(this._y1-f)>Ae)&&this._append`L${l},${f}`,r&&(m<0&&(m=m%qo+qo),m>Hm?this._append`A${r},${r},0,1,${c},${e-s},${n-u}A${r},${r},0,1,${c},${this._x1=l},${this._y1=f}`:m>Ae&&this._append`A${r},${r},0,${+(m>=Ho)},${c},${this._x1=e+r*Math.cos(a)},${this._y1=n+r*Math.sin(a)}`)}rect(e,n,r,o){this._append`M${this._x0=this._x1=+e},${this._y0=this._y1=+n}h${r=+r}v${+o}h${-r}Z`}toString(){return this._}};function Xs(){return new Ee}Xs.prototype=Ee.prototype;function Qs(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function Ye(t,e){if((n=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var n,r=t.slice(0,n);return[r.length>1?r[0]+r.slice(2):r,+t.slice(n+1)]}function Jt(t){return t=Ye(Math.abs(t)),t?t[1]:NaN}function Zs(t,e){return function(n,r){for(var o=n.length,a=[],i=0,s=t[0],u=0;o>0&&s>0&&(u+s+1>r&&(s=Math.max(1,r-u)),a.push(n.substring(o-=s,o+s)),!((u+=s+1)>r));)s=t[i=(i+1)%t.length];return a.reverse().join(e)}}function Js(t){return function(e){return e.replace(/[0-9]/g,function(n){return t[+n]})}}var Pm=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function de(t){if(!(e=Pm.exec(t)))throw new Error("invalid format: "+t);var e;return new Yr({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}de.prototype=Yr.prototype;function Yr(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}Yr.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function Ks(t){t:for(var e=t.length,n=1,r=-1,o;n<e;++n)switch(t[n]){case".":r=o=n;break;case"0":r===0&&(r=n),o=n;break;default:if(!+t[n])break t;r>0&&(r=0);break}return r>0?t.slice(0,r)+t.slice(o+1):t}var Po;function js(t,e){var n=Ye(t,e);if(!n)return t+"";var r=n[0],o=n[1],a=o-(Po=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,i=r.length;return a===i?r:a>i?r+new Array(a-i+1).join("0"):a>0?r.slice(0,a)+"."+r.slice(a):"0."+new Array(1-a).join("0")+Ye(t,Math.max(0,e+a-1))[0]}function Vo(t,e){var n=Ye(t,e);if(!n)return t+"";var r=n[0],o=n[1];return o<0?"0."+new Array(-o).join("0")+r:r.length>o+1?r.slice(0,o+1)+"."+r.slice(o+1):r+new Array(o-r.length+2).join("0")}var Wo={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:Qs,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>Vo(t*100,e),r:Vo,s:js,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function Go(t){return t}var tl=Array.prototype.map,el=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function nl(t){var e=t.grouping===void 0||t.thousands===void 0?Go:Zs(tl.call(t.grouping,Number),t.thousands+""),n=t.currency===void 0?"":t.currency[0]+"",r=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",a=t.numerals===void 0?Go:Js(tl.call(t.numerals,String)),i=t.percent===void 0?"%":t.percent+"",s=t.minus===void 0?"\u2212":t.minus+"",u=t.nan===void 0?"NaN":t.nan+"";function l(c){c=de(c);var m=c.fill,d=c.align,b=c.sign,M=c.symbol,h=c.zero,g=c.width,T=c.comma,x=c.precision,_=c.trim,v=c.type;v==="n"?(T=!0,v="g"):Wo[v]||(x===void 0&&(x=12),_=!0,v="g"),(h||m==="0"&&d==="=")&&(h=!0,m="0",d="=");var w=M==="$"?n:M==="#"&&/[boxX]/.test(v)?"0"+v.toLowerCase():"",O=M==="$"?r:/[%p]/.test(v)?i:"",R=Wo[v],st=/[defgprs%]/.test(v);x=x===void 0?6:/[gprs]/.test(v)?Math.max(1,Math.min(21,x)):Math.max(0,Math.min(20,x));function q(S){var H=w,Y=O,Z,gt,G;if(v==="c")Y=R(S)+Y,S="";else{S=+S;var K=S<0||1/S<0;if(S=isNaN(S)?u:R(Math.abs(S),x),_&&(S=Ks(S)),K&&+S==0&&b!=="+"&&(K=!1),H=(K?b==="("?b:s:b==="-"||b==="("?"":b)+H,Y=(v==="s"?el[8+Po/3]:"")+Y+(K&&b==="("?")":""),st){for(Z=-1,gt=S.length;++Z<gt;)if(G=S.charCodeAt(Z),48>G||G>57){Y=(G===46?o+S.slice(Z+1):S.slice(Z))+Y,S=S.slice(0,Z);break}}}T&&!h&&(S=e(S,1/0));var ht=H.length+S.length+Y.length,B=ht<g?new Array(g-ht+1).join(m):"";switch(T&&h&&(S=e(B+S,B.length?g-Y.length:1/0),B=""),d){case"<":S=H+S+Y+B;break;case"=":S=H+B+S+Y;break;case"^":S=B.slice(0,ht=B.length>>1)+H+S+Y+B.slice(ht);break;default:S=B+H+S+Y;break}return a(S)}return q.toString=function(){return c+""},q}function f(c,m){var d=l((c=de(c),c.type="f",c)),b=Math.max(-8,Math.min(8,Math.floor(Jt(m)/3)))*3,M=Math.pow(10,-b),h=el[8+b/3];return function(g){return d(M*g)+h}}return{format:l,formatPrefix:f}}var Ir,Nr,Or;Xo({thousands:",",grouping:[3],currency:["$",""]});function Xo(t){return Ir=nl(t),Nr=Ir.format,Or=Ir.formatPrefix,Ir}function Qo(t){return Math.max(0,-Jt(Math.abs(t)))}function Zo(t,e){return Math.max(0,Math.max(-8,Math.min(8,Math.floor(Jt(e)/3)))*3-Jt(Math.abs(t)))}function Jo(t,e){return t=Math.abs(t),e=Math.abs(e)-t,Math.max(0,Jt(e)-Jt(t))+1}function he(t,e){switch(arguments.length){case 0:break;case 1:this.range(t);break;default:this.range(e).domain(t);break}return this}var rl=Symbol("implicit");function Ur(){var t=new Ge,e=[],n=[],r=rl;function o(a){let i=t.get(a);if(i===void 0){if(r!==rl)return r;t.set(a,i=e.push(a)-1)}return n[i%n.length]}return o.domain=function(a){if(!arguments.length)return e.slice();e=[],t=new Ge;for(let i of a)t.has(i)||t.set(i,e.push(i)-1);return o},o.range=function(a){return arguments.length?(n=Array.from(a),o):n.slice()},o.unknown=function(a){return arguments.length?(r=a,o):r},o.copy=function(){return Ur(e,n).unknown(r)},he.apply(o,arguments),o}function Ie(){var t=Ur().unknown(void 0),e=t.domain,n=t.range,r=0,o=1,a,i,s=!1,u=0,l=0,f=.5;delete t.unknown;function c(){var m=e().length,d=o<r,b=d?o:r,M=d?r:o;a=(M-b)/Math.max(1,m-u+l*2),s&&(a=Math.floor(a)),b+=(M-b-a*(m-u))*f,i=a*(1-u),s&&(b=Math.round(b),i=Math.round(i));var h=er(m).map(function(g){return b+a*g});return n(d?h.reverse():h)}return t.domain=function(m){return arguments.length?(e(m),c()):e()},t.range=function(m){return arguments.length?([r,o]=m,r=+r,o=+o,c()):[r,o]},t.rangeRound=function(m){return[r,o]=m,r=+r,o=+o,s=!0,c()},t.bandwidth=function(){return i},t.step=function(){return a},t.round=function(m){return arguments.length?(s=!!m,c()):s},t.padding=function(m){return arguments.length?(u=Math.min(1,l=+m),c()):u},t.paddingInner=function(m){return arguments.length?(u=Math.min(1,m),c()):u},t.paddingOuter=function(m){return arguments.length?(l=+m,c()):l},t.align=function(m){return arguments.length?(f=Math.max(0,Math.min(1,m)),c()):f},t.copy=function(){return Ie(e(),[r,o]).round(s).paddingInner(u).paddingOuter(l).align(f)},he.apply(c(),arguments)}function ol(t){var e=t.copy;return t.padding=t.paddingOuter,delete t.paddingInner,delete t.paddingOuter,t.copy=function(){return ol(e())},t}function Ko(){return ol(Ie.apply(null,arguments).paddingInner(1))}function jo(t){return function(){return t}}function ta(t){return+t}var al=[0,1];function tn(t){return t}function ea(t,e){return(e-=t=+t)?function(n){return(n-t)/e}:jo(isNaN(e)?NaN:.5)}function Vm(t,e){var n;return t>e&&(n=t,t=e,e=n),function(r){return Math.max(t,Math.min(e,r))}}function Wm(t,e,n){var r=t[0],o=t[1],a=e[0],i=e[1];return o<r?(r=ea(o,r),a=n(i,a)):(r=ea(r,o),a=n(a,i)),function(s){return a(r(s))}}function Gm(t,e,n){var r=Math.min(t.length,e.length)-1,o=new Array(r),a=new Array(r),i=-1;for(t[r]<t[0]&&(t=t.slice().reverse(),e=e.slice().reverse());++i<r;)o[i]=ea(t[i],t[i+1]),a[i]=n(e[i],e[i+1]);return function(s){var u=ho(t,s,1,r)-1;return a[u](o[u](s))}}function Rr(t,e){return e.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown())}function Xm(){var t=al,e=al,n=oe,r,o,a,i=tn,s,u,l;function f(){var m=Math.min(t.length,e.length);return i!==tn&&(i=Vm(t[0],t[m-1])),s=m>2?Gm:Wm,u=l=null,c}function c(m){return m==null||isNaN(m=+m)?a:(u||(u=s(t.map(r),e,n)))(r(i(m)))}return c.invert=function(m){return i(o((l||(l=s(e,t.map(r),Yt)))(m)))},c.domain=function(m){return arguments.length?(t=Array.from(m,ta),f()):t.slice()},c.range=function(m){return arguments.length?(e=Array.from(m),f()):e.slice()},c.rangeRound=function(m){return e=Array.from(m),n=Eo,f()},c.clamp=function(m){return arguments.length?(i=m?!0:tn,f()):i!==tn},c.interpolate=function(m){return arguments.length?(n=m,f()):n},c.unknown=function(m){return arguments.length?(a=m,c):a},function(m,d){return r=m,o=d,f()}}function Bn(){return Xm()(tn,tn)}function na(t,e,n,r){var o=Xe(t,e,n),a;switch(r=de(r??",f"),r.type){case"s":{var i=Math.max(Math.abs(t),Math.abs(e));return r.precision==null&&!isNaN(a=Zo(o,i))&&(r.precision=a),Or(r,i)}case"":case"e":case"g":case"p":case"r":{r.precision==null&&!isNaN(a=Jo(o,Math.max(Math.abs(t),Math.abs(e))))&&(r.precision=a-(r.type==="e"));break}case"f":case"%":{r.precision==null&&!isNaN(a=Qo(o))&&(r.precision=a-(r.type==="%")*2);break}}return Nr(r)}function Qm(t){var e=t.domain;return t.ticks=function(n){var r=e();return Kn(r[0],r[r.length-1],n??10)},t.tickFormat=function(n,r){var o=e();return na(o[0],o[o.length-1],n??10,r)},t.nice=function(n){n==null&&(n=10);var r=e(),o=0,a=r.length-1,i=r[o],s=r[a],u,l,f=10;for(s<i&&(l=i,i=s,s=l,l=o,o=a,a=l);f-- >0;){if(l=yn(i,s,n),l===u)return r[o]=i,r[a]=s,e(r);if(l>0)i=Math.floor(i/l)*l,s=Math.ceil(s/l)*l;else if(l<0)i=Math.ceil(i*l)/l,s=Math.floor(s*l)/l;else break;u=l}return t},t}function $n(){var t=Bn();return t.copy=function(){return Rr(t,$n())},he.apply(t,arguments),Qm(t)}function ra(t,e){t=t.slice();var n=0,r=t.length-1,o=t[n],a=t[r],i;return a<o&&(i=n,n=r,r=i,i=o,o=a,a=i),t[n]=e.floor(o),t[r]=e.ceil(a),t}var oa=new Date,aa=new Date;function ct(t,e,n,r){function o(a){return t(a=arguments.length===0?new Date:new Date(+a)),a}return o.floor=a=>(t(a=new Date(+a)),a),o.ceil=a=>(t(a=new Date(a-1)),e(a,1),t(a),a),o.round=a=>{let i=o(a),s=o.ceil(a);return a-i<s-a?i:s},o.offset=(a,i)=>(e(a=new Date(+a),i==null?1:Math.floor(i)),a),o.range=(a,i,s)=>{let u=[];if(a=o.ceil(a),s=s==null?1:Math.floor(s),!(a<i)||!(s>0))return u;let l;do u.push(l=new Date(+a)),e(a,s),t(a);while(l<a&&a<i);return u},o.filter=a=>ct(i=>{if(i>=i)for(;t(i),!a(i);)i.setTime(i-1)},(i,s)=>{if(i>=i)if(s<0)for(;++s<=0;)for(;e(i,-1),!a(i););else for(;--s>=0;)for(;e(i,1),!a(i););}),n&&(o.count=(a,i)=>(oa.setTime(+a),aa.setTime(+i),t(oa),t(aa),Math.floor(n(oa,aa))),o.every=a=>(a=Math.floor(a),!isFinite(a)||!(a>0)?null:a>1?o.filter(r?i=>r(i)%a===0:i=>o.count(0,i)%a===0):o)),o}var zn=ct(()=>{},(t,e)=>{t.setTime(+t+e)},(t,e)=>e-t);zn.every=t=>(t=Math.floor(t),!isFinite(t)||!(t>0)?null:t>1?ct(e=>{e.setTime(Math.floor(e/t)*t)},(e,n)=>{e.setTime(+e+n*t)},(e,n)=>(n-e)/t):zn);var RS=zn.range;var Kt=ct(t=>{t.setTime(t-t.getMilliseconds())},(t,e)=>{t.setTime(+t+e*1e3)},(t,e)=>(e-t)/1e3,t=>t.getUTCSeconds()),il=Kt.range;var Br=ct(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*1e3)},(t,e)=>{t.setTime(+t+e*6e4)},(t,e)=>(e-t)/6e4,t=>t.getMinutes()),Zm=Br.range,en=ct(t=>{t.setUTCSeconds(0,0)},(t,e)=>{t.setTime(+t+e*6e4)},(t,e)=>(e-t)/6e4,t=>t.getUTCMinutes()),Jm=en.range;var $r=ct(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*1e3-t.getMinutes()*6e4)},(t,e)=>{t.setTime(+t+e*36e5)},(t,e)=>(e-t)/36e5,t=>t.getHours()),Km=$r.range,nn=ct(t=>{t.setUTCMinutes(0,0,0)},(t,e)=>{t.setTime(+t+e*36e5)},(t,e)=>(e-t)/36e5,t=>t.getUTCHours()),jm=nn.range;var Ue=ct(t=>t.setHours(0,0,0,0),(t,e)=>t.setDate(t.getDate()+e),(t,e)=>(e-t-(e.getTimezoneOffset()-t.getTimezoneOffset())*6e4)/864e5,t=>t.getDate()-1),tp=Ue.range,Re=ct(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/864e5,t=>t.getUTCDate()-1),ep=Re.range,zr=ct(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/864e5,t=>Math.floor(t/864e5)),np=zr.range;function Be(t){return ct(e=>{e.setDate(e.getDate()-(e.getDay()+7-t)%7),e.setHours(0,0,0,0)},(e,n)=>{e.setDate(e.getDate()+n*7)},(e,n)=>(n-e-(n.getTimezoneOffset()-e.getTimezoneOffset())*6e4)/6048e5)}var $e=Be(0),rn=Be(1),ll=Be(2),ul=Be(3),ge=Be(4),cl=Be(5),fl=Be(6),ml=$e.range,rp=rn.range,op=ll.range,ap=ul.range,ip=ge.range,sp=cl.range,lp=fl.range;function ze(t){return ct(e=>{e.setUTCDate(e.getUTCDate()-(e.getUTCDay()+7-t)%7),e.setUTCHours(0,0,0,0)},(e,n)=>{e.setUTCDate(e.getUTCDate()+n*7)},(e,n)=>(n-e)/6048e5)}var se=ze(0),on=ze(1),pl=ze(2),dl=ze(3),ye=ze(4),hl=ze(5),gl=ze(6),yl=se.range,up=on.range,cp=pl.range,fp=dl.range,mp=ye.range,pp=hl.range,dp=gl.range;var Lr=ct(t=>{t.setDate(1),t.setHours(0,0,0,0)},(t,e)=>{t.setMonth(t.getMonth()+e)},(t,e)=>e.getMonth()-t.getMonth()+(e.getFullYear()-t.getFullYear())*12,t=>t.getMonth()),hp=Lr.range,an=ct(t=>{t.setUTCDate(1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCMonth(t.getUTCMonth()+e)},(t,e)=>e.getUTCMonth()-t.getUTCMonth()+(e.getUTCFullYear()-t.getUTCFullYear())*12,t=>t.getUTCMonth()),gp=an.range;var qt=ct(t=>{t.setMonth(0,1),t.setHours(0,0,0,0)},(t,e)=>{t.setFullYear(t.getFullYear()+e)},(t,e)=>e.getFullYear()-t.getFullYear(),t=>t.getFullYear());qt.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:ct(e=>{e.setFullYear(Math.floor(e.getFullYear()/t)*t),e.setMonth(0,1),e.setHours(0,0,0,0)},(e,n)=>{e.setFullYear(e.getFullYear()+n*t)});var yp=qt.range,$t=ct(t=>{t.setUTCMonth(0,1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCFullYear(t.getUTCFullYear()+e)},(t,e)=>e.getUTCFullYear()-t.getUTCFullYear(),t=>t.getUTCFullYear());$t.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:ct(e=>{e.setUTCFullYear(Math.floor(e.getUTCFullYear()/t)*t),e.setUTCMonth(0,1),e.setUTCHours(0,0,0,0)},(e,n)=>{e.setUTCFullYear(e.getUTCFullYear()+n*t)});var xp=$t.range;function bl(t,e,n,r,o,a){let i=[[Kt,1,1e3],[Kt,5,5*1e3],[Kt,15,15*1e3],[Kt,30,30*1e3],[a,1,6e4],[a,5,5*6e4],[a,15,15*6e4],[a,30,30*6e4],[o,1,36e5],[o,3,3*36e5],[o,6,6*36e5],[o,12,12*36e5],[r,1,864e5],[r,2,2*864e5],[n,1,6048e5],[e,1,2592e6],[e,3,3*2592e6],[t,1,31536e6]];function s(l,f,c){let m=f<l;m&&([l,f]=[f,l]);let d=c&&typeof c.range=="function"?c:u(l,f,c),b=d?d.range(l,+f+1):[];return m?b.reverse():b}function u(l,f,c){let m=Math.abs(f-l)/c,d=Ce(([,,h])=>h).right(i,m);if(d===i.length)return t.every(Xe(l/31536e6,f/31536e6,c));if(d===0)return zn.every(Math.max(Xe(l,f,c),1));let[b,M]=i[m/i[d-1][2]<i[d][2]/m?d-1:d];return b.every(M)}return[s,u]}var[ia,sa]=bl($t,an,se,zr,nn,en),[vp,wp]=bl(qt,Lr,$e,Ue,$r,Br);function la(t){if(0<=t.y&&t.y<100){var e=new Date(-1,t.m,t.d,t.H,t.M,t.S,t.L);return e.setFullYear(t.y),e}return new Date(t.y,t.m,t.d,t.H,t.M,t.S,t.L)}function ua(t){if(0<=t.y&&t.y<100){var e=new Date(Date.UTC(-1,t.m,t.d,t.H,t.M,t.S,t.L));return e.setUTCFullYear(t.y),e}return new Date(Date.UTC(t.y,t.m,t.d,t.H,t.M,t.S,t.L))}function Hn(t,e,n){return{y:t,m:e,d:n,H:0,M:0,S:0,L:0}}function ca(t){var e=t.dateTime,n=t.date,r=t.time,o=t.periods,a=t.days,i=t.shortDays,s=t.months,u=t.shortMonths,l=qn(o),f=Pn(o),c=qn(a),m=Pn(a),d=qn(i),b=Pn(i),M=qn(s),h=Pn(s),g=qn(u),T=Pn(u),x={a:K,A:ht,b:B,B:ft,c:null,d:_l,e:_l,f:Pp,g:td,G:nd,H:Lp,I:Hp,j:qp,L:Al,m:Vp,M:Wp,p:mt,q:pt,Q:Dl,s:Fl,S:Gp,u:Xp,U:Qp,V:Zp,w:Jp,W:Kp,x:null,X:null,y:jp,Y:ed,Z:rd,"%":kl},_={a:Pt,A:Vt,b:E,B:j,c:null,d:Tl,e:Tl,f:sd,g:yd,G:bd,H:od,I:ad,j:id,L:Yl,m:ld,M:ud,p:X,q:P,Q:Dl,s:Fl,S:cd,u:fd,U:md,V:pd,w:dd,W:hd,x:null,X:null,y:gd,Y:xd,Z:vd,"%":kl},v={a:q,A:S,b:H,B:Y,c:Z,d:Ml,e:Ml,f:Rp,g:Sl,G:wl,H:Cl,I:Cl,j:Ip,L:Up,m:Yp,M:Np,p:st,q:Ep,Q:$p,s:zp,S:Op,u:Tp,U:kp,V:Dp,w:_p,W:Fp,x:gt,X:G,y:Sl,Y:wl,Z:Ap,"%":Bp};x.x=w(n,x),x.X=w(r,x),x.c=w(e,x),_.x=w(n,_),_.X=w(r,_),_.c=w(e,_);function w(y,C){return function(k){var p=[],L=-1,A=0,V=y.length,I,D,U;for(k instanceof Date||(k=new Date(+k));++L<V;)y.charCodeAt(L)===37&&(p.push(y.slice(A,L)),(D=vl[I=y.charAt(++L)])!=null?I=y.charAt(++L):D=I==="e"?" ":"0",(U=C[I])&&(I=U(k,D)),p.push(I),A=L+1);return p.push(y.slice(A,L)),p.join("")}}function O(y,C){return function(k){var p=Hn(1900,void 0,1),L=R(p,y,k+="",0),A,V;if(L!=k.length)return null;if("Q"in p)return new Date(p.Q);if("s"in p)return new Date(p.s*1e3+("L"in p?p.L:0));if(C&&!("Z"in p)&&(p.Z=0),"p"in p&&(p.H=p.H%12+p.p*12),p.m===void 0&&(p.m="q"in p?p.q:0),"V"in p){if(p.V<1||p.V>53)return null;"w"in p||(p.w=1),"Z"in p?(A=ua(Hn(p.y,0,1)),V=A.getUTCDay(),A=V>4||V===0?on.ceil(A):on(A),A=Re.offset(A,(p.V-1)*7),p.y=A.getUTCFullYear(),p.m=A.getUTCMonth(),p.d=A.getUTCDate()+(p.w+6)%7):(A=la(Hn(p.y,0,1)),V=A.getDay(),A=V>4||V===0?rn.ceil(A):rn(A),A=Ue.offset(A,(p.V-1)*7),p.y=A.getFullYear(),p.m=A.getMonth(),p.d=A.getDate()+(p.w+6)%7)}else("W"in p||"U"in p)&&("w"in p||(p.w="u"in p?p.u%7:"W"in p?1:0),V="Z"in p?ua(Hn(p.y,0,1)).getUTCDay():la(Hn(p.y,0,1)).getDay(),p.m=0,p.d="W"in p?(p.w+6)%7+p.W*7-(V+5)%7:p.w+p.U*7-(V+6)%7);return"Z"in p?(p.H+=p.Z/100|0,p.M+=p.Z%100,ua(p)):la(p)}}function R(y,C,k,p){for(var L=0,A=C.length,V=k.length,I,D;L<A;){if(p>=V)return-1;if(I=C.charCodeAt(L++),I===37){if(I=C.charAt(L++),D=v[I in vl?C.charAt(L++):I],!D||(p=D(y,k,p))<0)return-1}else if(I!=k.charCodeAt(p++))return-1}return p}function st(y,C,k){var p=l.exec(C.slice(k));return p?(y.p=f.get(p[0].toLowerCase()),k+p[0].length):-1}function q(y,C,k){var p=d.exec(C.slice(k));return p?(y.w=b.get(p[0].toLowerCase()),k+p[0].length):-1}function S(y,C,k){var p=c.exec(C.slice(k));return p?(y.w=m.get(p[0].toLowerCase()),k+p[0].length):-1}function H(y,C,k){var p=g.exec(C.slice(k));return p?(y.m=T.get(p[0].toLowerCase()),k+p[0].length):-1}function Y(y,C,k){var p=M.exec(C.slice(k));return p?(y.m=h.get(p[0].toLowerCase()),k+p[0].length):-1}function Z(y,C,k){return R(y,e,C,k)}function gt(y,C,k){return R(y,n,C,k)}function G(y,C,k){return R(y,r,C,k)}function K(y){return i[y.getDay()]}function ht(y){return a[y.getDay()]}function B(y){return u[y.getMonth()]}function ft(y){return s[y.getMonth()]}function mt(y){return o[+(y.getHours()>=12)]}function pt(y){return 1+~~(y.getMonth()/3)}function Pt(y){return i[y.getUTCDay()]}function Vt(y){return a[y.getUTCDay()]}function E(y){return u[y.getUTCMonth()]}function j(y){return s[y.getUTCMonth()]}function X(y){return o[+(y.getUTCHours()>=12)]}function P(y){return 1+~~(y.getUTCMonth()/3)}return{format:function(y){var C=w(y+="",x);return C.toString=function(){return y},C},parse:function(y){var C=O(y+="",!1);return C.toString=function(){return y},C},utcFormat:function(y){var C=w(y+="",_);return C.toString=function(){return y},C},utcParse:function(y){var C=O(y+="",!0);return C.toString=function(){return y},C}}}var vl={"-":"",_:" ",0:"0"},Dt=/^\s*\d+/,Sp=/^%/,Mp=/[\\^$*+?|[\]().{}]/g;function at(t,e,n){var r=t<0?"-":"",o=(r?-t:t)+"",a=o.length;return r+(a<n?new Array(n-a+1).join(e)+o:o)}function Cp(t){return t.replace(Mp,"\\$&")}function qn(t){return new RegExp("^(?:"+t.map(Cp).join("|")+")","i")}function Pn(t){return new Map(t.map((e,n)=>[e.toLowerCase(),n]))}function _p(t,e,n){var r=Dt.exec(e.slice(n,n+1));return r?(t.w=+r[0],n+r[0].length):-1}function Tp(t,e,n){var r=Dt.exec(e.slice(n,n+1));return r?(t.u=+r[0],n+r[0].length):-1}function kp(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.U=+r[0],n+r[0].length):-1}function Dp(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.V=+r[0],n+r[0].length):-1}function Fp(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.W=+r[0],n+r[0].length):-1}function wl(t,e,n){var r=Dt.exec(e.slice(n,n+4));return r?(t.y=+r[0],n+r[0].length):-1}function Sl(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.y=+r[0]+(+r[0]>68?1900:2e3),n+r[0].length):-1}function Ap(t,e,n){var r=/^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(n,n+6));return r?(t.Z=r[1]?0:-(r[2]+(r[3]||"00")),n+r[0].length):-1}function Ep(t,e,n){var r=Dt.exec(e.slice(n,n+1));return r?(t.q=r[0]*3-3,n+r[0].length):-1}function Yp(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.m=r[0]-1,n+r[0].length):-1}function Ml(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.d=+r[0],n+r[0].length):-1}function Ip(t,e,n){var r=Dt.exec(e.slice(n,n+3));return r?(t.m=0,t.d=+r[0],n+r[0].length):-1}function Cl(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.H=+r[0],n+r[0].length):-1}function Np(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.M=+r[0],n+r[0].length):-1}function Op(t,e,n){var r=Dt.exec(e.slice(n,n+2));return r?(t.S=+r[0],n+r[0].length):-1}function Up(t,e,n){var r=Dt.exec(e.slice(n,n+3));return r?(t.L=+r[0],n+r[0].length):-1}function Rp(t,e,n){var r=Dt.exec(e.slice(n,n+6));return r?(t.L=Math.floor(r[0]/1e3),n+r[0].length):-1}function Bp(t,e,n){var r=Sp.exec(e.slice(n,n+1));return r?n+r[0].length:-1}function $p(t,e,n){var r=Dt.exec(e.slice(n));return r?(t.Q=+r[0],n+r[0].length):-1}function zp(t,e,n){var r=Dt.exec(e.slice(n));return r?(t.s=+r[0],n+r[0].length):-1}function _l(t,e){return at(t.getDate(),e,2)}function Lp(t,e){return at(t.getHours(),e,2)}function Hp(t,e){return at(t.getHours()%12||12,e,2)}function qp(t,e){return at(1+Ue.count(qt(t),t),e,3)}function Al(t,e){return at(t.getMilliseconds(),e,3)}function Pp(t,e){return Al(t,e)+"000"}function Vp(t,e){return at(t.getMonth()+1,e,2)}function Wp(t,e){return at(t.getMinutes(),e,2)}function Gp(t,e){return at(t.getSeconds(),e,2)}function Xp(t){var e=t.getDay();return e===0?7:e}function Qp(t,e){return at($e.count(qt(t)-1,t),e,2)}function El(t){var e=t.getDay();return e>=4||e===0?ge(t):ge.ceil(t)}function Zp(t,e){return t=El(t),at(ge.count(qt(t),t)+(qt(t).getDay()===4),e,2)}function Jp(t){return t.getDay()}function Kp(t,e){return at(rn.count(qt(t)-1,t),e,2)}function jp(t,e){return at(t.getFullYear()%100,e,2)}function td(t,e){return t=El(t),at(t.getFullYear()%100,e,2)}function ed(t,e){return at(t.getFullYear()%1e4,e,4)}function nd(t,e){var n=t.getDay();return t=n>=4||n===0?ge(t):ge.ceil(t),at(t.getFullYear()%1e4,e,4)}function rd(t){var e=t.getTimezoneOffset();return(e>0?"-":(e*=-1,"+"))+at(e/60|0,"0",2)+at(e%60,"0",2)}function Tl(t,e){return at(t.getUTCDate(),e,2)}function od(t,e){return at(t.getUTCHours(),e,2)}function ad(t,e){return at(t.getUTCHours()%12||12,e,2)}function id(t,e){return at(1+Re.count($t(t),t),e,3)}function Yl(t,e){return at(t.getUTCMilliseconds(),e,3)}function sd(t,e){return Yl(t,e)+"000"}function ld(t,e){return at(t.getUTCMonth()+1,e,2)}function ud(t,e){return at(t.getUTCMinutes(),e,2)}function cd(t,e){return at(t.getUTCSeconds(),e,2)}function fd(t){var e=t.getUTCDay();return e===0?7:e}function md(t,e){return at(se.count($t(t)-1,t),e,2)}function Il(t){var e=t.getUTCDay();return e>=4||e===0?ye(t):ye.ceil(t)}function pd(t,e){return t=Il(t),at(ye.count($t(t),t)+($t(t).getUTCDay()===4),e,2)}function dd(t){return t.getUTCDay()}function hd(t,e){return at(on.count($t(t)-1,t),e,2)}function gd(t,e){return at(t.getUTCFullYear()%100,e,2)}function yd(t,e){return t=Il(t),at(t.getUTCFullYear()%100,e,2)}function xd(t,e){return at(t.getUTCFullYear()%1e4,e,4)}function bd(t,e){var n=t.getUTCDay();return t=n>=4||n===0?ye(t):ye.ceil(t),at(t.getUTCFullYear()%1e4,e,4)}function vd(){return"+0000"}function kl(){return"%"}function Dl(t){return+t}function Fl(t){return Math.floor(+t/1e3)}var sn,Nl,Ol,Hr,Ul;fa({dateTime:"%x, %X",date:"%-m/%-d/%Y",time:"%-I:%M:%S %p",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]});function fa(t){return sn=ca(t),Nl=sn.format,Ol=sn.parse,Hr=sn.utcFormat,Ul=sn.utcParse,sn}function wd(t){return new Date(t)}function Sd(t){return t instanceof Date?+t:+new Date(+t)}function ma(t,e,n,r,o,a,i,s,u,l){var f=Bn(),c=f.invert,m=f.domain,d=l(".%L"),b=l(":%S"),M=l("%I:%M"),h=l("%I %p"),g=l("%a %d"),T=l("%b %d"),x=l("%B"),_=l("%Y");function v(w){return(u(w)<w?d:s(w)<w?b:i(w)<w?M:a(w)<w?h:r(w)<w?o(w)<w?g:T:n(w)<w?x:_)(w)}return f.invert=function(w){return new Date(c(w))},f.domain=function(w){return arguments.length?m(Array.from(w,Sd)):m().map(wd)},f.ticks=function(w){var O=m();return t(O[0],O[O.length-1],w??10)},f.tickFormat=function(w,O){return O==null?v:l(O)},f.nice=function(w){var O=m();return(!w||typeof w.range!="function")&&(w=e(O[0],O[O.length-1],w??10)),w?m(ra(O,w)):f},f.copy=function(){return Rr(f,ma(t,e,n,r,o,a,i,s,u,l))},f}function qr(){return he.apply(ma(ia,sa,$t,an,se,Re,nn,en,Kt,Hr).domain([Date.UTC(2e3,0,1),Date.UTC(2e3,0,2)]),arguments)}function vt(t){return function(){return t}}function Pr(t){let e=3;return t.digits=function(n){if(!arguments.length)return e;if(n==null)e=null;else{let r=Math.floor(n);if(!(r>=0))throw new RangeError(`invalid digits: ${n}`);e=r}return t},()=>new Ee(e)}var $M=Array.prototype.slice;function Vr(t){return typeof t=="object"&&"length"in t?t:Array.from(t)}function Rl(t){this._context=t}Rl.prototype={areaStart:function(){this._line=0},areaEnd:function(){this._line=NaN},lineStart:function(){this._point=0},lineEnd:function(){(this._line||this._line!==0&&this._point===1)&&this._context.closePath(),this._line=1-this._line},point:function(t,e){switch(t=+t,e=+e,this._point){case 0:this._point=1,this._line?this._context.lineTo(t,e):this._context.moveTo(t,e);break;case 1:this._point=2;default:this._context.lineTo(t,e);break}}};function Wr(t){return new Rl(t)}function Gr(t){return t[0]}function Xr(t){return t[1]}function ln(t,e){var n=vt(!0),r=null,o=Wr,a=null,i=Pr(s);t=typeof t=="function"?t:t===void 0?Gr:vt(t),e=typeof e=="function"?e:e===void 0?Xr:vt(e);function s(u){var l,f=(u=Vr(u)).length,c,m=!1,d;for(r==null&&(a=o(d=i())),l=0;l<=f;++l)!(l<f&&n(c=u[l],l,u))===m&&((m=!m)?a.lineStart():a.lineEnd()),m&&a.point(+t(c,l,u),+e(c,l,u));if(d)return a=null,d+""||null}return s.x=function(u){return arguments.length?(t=typeof u=="function"?u:vt(+u),s):t},s.y=function(u){return arguments.length?(e=typeof u=="function"?u:vt(+u),s):e},s.defined=function(u){return arguments.length?(n=typeof u=="function"?u:vt(!!u),s):n},s.curve=function(u){return arguments.length?(o=u,r!=null&&(a=o(r)),s):o},s.context=function(u){return arguments.length?(u==null?r=a=null:a=o(r=u),s):r},s}function Qr(t,e,n){var r=null,o=vt(!0),a=null,i=Wr,s=null,u=Pr(l);t=typeof t=="function"?t:t===void 0?Gr:vt(+t),e=typeof e=="function"?e:e===void 0?vt(0):vt(+e),n=typeof n=="function"?n:n===void 0?Xr:vt(+n);function l(c){var m,d,b,M=(c=Vr(c)).length,h,g=!1,T,x=new Array(M),_=new Array(M);for(a==null&&(s=i(T=u())),m=0;m<=M;++m){if(!(m<M&&o(h=c[m],m,c))===g)if(g=!g)d=m,s.areaStart(),s.lineStart();else{for(s.lineEnd(),s.lineStart(),b=m-1;b>=d;--b)s.point(x[b],_[b]);s.lineEnd(),s.areaEnd()}g&&(x[m]=+t(h,m,c),_[m]=+e(h,m,c),s.point(r?+r(h,m,c):x[m],n?+n(h,m,c):_[m]))}if(T)return s=null,T+""||null}function f(){return ln().defined(o).curve(i).context(a)}return l.x=function(c){return arguments.length?(t=typeof c=="function"?c:vt(+c),r=null,l):t},l.x0=function(c){return arguments.length?(t=typeof c=="function"?c:vt(+c),l):t},l.x1=function(c){return arguments.length?(r=c==null?null:typeof c=="function"?c:vt(+c),l):r},l.y=function(c){return arguments.length?(e=typeof c=="function"?c:vt(+c),n=null,l):e},l.y0=function(c){return arguments.length?(e=typeof c=="function"?c:vt(+c),l):e},l.y1=function(c){return arguments.length?(n=c==null?null:typeof c=="function"?c:vt(+c),l):n},l.lineX0=l.lineY0=function(){return f().x(t).y(e)},l.lineY1=function(){return f().x(t).y(n)},l.lineX1=function(){return f().x(r).y(e)},l.defined=function(c){return arguments.length?(o=typeof c=="function"?c:vt(!!c),l):o},l.curve=function(c){return arguments.length?(i=c,a!=null&&(s=i(a)),l):i},l.context=function(c){return arguments.length?(c==null?a=s=null:s=i(a=c),l):a},l}function xe(t,e,n){this.k=t,this.x=e,this.y=n}xe.prototype={constructor:xe,scale:function(t){return t===1?this:new xe(this.k*t,this.x,this.y)},translate:function(t,e){return t===0&e===0?this:new xe(this.k,this.x+this.k*t,this.y+this.k*e)},apply:function(t){return[t[0]*this.k+this.x,t[1]*this.k+this.y]},applyX:function(t){return t*this.k+this.x},applyY:function(t){return t*this.k+this.y},invert:function(t){return[(t[0]-this.x)/this.k,(t[1]-this.y)/this.k]},invertX:function(t){return(t-this.x)/this.k},invertY:function(t){return(t-this.y)/this.k},rescaleX:function(t){return t.copy().domain(t.range().map(this.invertX,this).map(t.invert,t))},rescaleY:function(t){return t.copy().domain(t.range().map(this.invertY,this).map(t.invert,t))},toString:function(){return"translate("+this.x+","+this.y+") scale("+this.k+")"}};var pa=new xe(1,0,0);da.prototype=xe.prototype;function da(t){for(;!t.__zoom;)if(!(t=t.parentNode))return pa;return t.__zoom}var F={selectedAxisValues:new Set,chartType:"column"};function Bl(t,e="#ffffff"){let n=Et(t??e)??Et(e);return Lt(n?.toString()??e)}function Cd(t){let e=n=>{let r=n/255;return r<=.03928?r/12.92:Math.pow((r+.055)/1.055,2.4)};return .2126*e(t.r)+.7152*e(t.g)+.0722*e(t.b)}function un(t,e=.2){let n=Et(t);return n?Zt(n,"#ffffff")(Math.min(1,Math.max(0,e))):t}function Le(t,e=.2){let n=Et(t);return n?Zt(n,"#000000")(Math.min(1,Math.max(0,e))):t}function ha(t){let e=t?.itemsBackground||"#ffffff",n=Bl(e),r=Cd(n),o=r<.45?"#f8fafc":"#1f2937",a=r<.45?un(e,.25):Le(e,.15),i=Et(a)?.formatHex()??"#d1d5db",s=t||{},u=(s.colors??[]).filter(Boolean),l=s.mainColor||u[0]||"#6366f1",f='-apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif',c=Math.max(2,Math.min(16,s.itemSpecific?.rounding??8)),m=s.itemSpecific?.padding,d=typeof m=="number"?Math.max(.05,Math.min(.35,m/100)):.18,b=Lt(Le(l,.55)),M=Lt(l),h=`rgba(${b.r}, ${b.g}, ${b.b}, ${r<.45?.55:.25})`,g=`rgba(${M.r}, ${M.g}, ${M.b}, ${r<.45?.55:.35})`,T=s.tooltip?.background||(r<.45?un(e,.18):Le(e,.35)),x=Bl(T),_=`rgba(${x.r}, ${x.g}, ${x.b}, 0.70)`,v=r<.45?"#0f172a":"#f8fafc",w=r<.45?un(e,.22):Le(e,.08),O=w,R=r<.45?un(w,.12):Le(w,.12),st=r<.45?un(w,.18):Le(w,.18);return{backgroundColor:e,axisTextColor:o,axisLineColor:i,fontFamily:f,basePalette:u,mainColor:l,barRounding:c,barPadding:d,hoverShadow:h,selectedShadow:g,tooltipBackground:_,tooltipColor:v,controlBackground:O,controlBorder:R,controlText:o,controlHoverBackground:st}}function _d(t){let e={type:"customEvent",data:t};window.parent.postMessage(e,"*")}function He(t){let e;if(t.length>0&&Array.isArray(t[0])){let r=t;r.length===1?e=r[0]:e=r.map(o=>({or:o}))}else e=t;console.log("filterData",e);let n={type:"setFilter",filters:e};window.parent.postMessage(n,"*")}function Zr(t){return(t?.content?.[0]?.type??"")==="datetime"}var Jr=({container:t,data:e=[],slots:n=[],slotConfigurations:r=[],options:o={},language:a="en",dimensions:{width:i,height:s}={width:0,height:0}})=>{let u=ha(o.theme);t.__themeContext=u,t.__lastParams={data:e,slots:n,slotConfigurations:r,options:o,language:a,dimensions:{width:i,height:s}},F.facetSlot=n.find(g=>g.name==="category"),F.axisSlot=n.find(g=>g.name==="time"),F.measureSlot=n.find(g=>g.name==="measure");let l=Zr(F.axisSlot)?"line":"column";F.chartType=F.chartType||l;let f=F.measureSlot?.content?.[0]?Xt(F.measureSlot.content[0]):g=>new Intl.NumberFormat(a).format(g),c=!!F.facetSlot?.content?.length,m=!!F.axisSlot?.content?.length,d=!!F.measureSlot?.content?.length,b=c&&m&&d,M=zl(t,u);Ll(M,u,l,b,g=>{F.chartType=g,F.selectedAxisValues.clear(),F.selectedFacet=void 0,F.selectionByFacet=new Map,He([]);let T=t.__lastParams;Jr({...T,container:t})});let h=[];if(!e.length||!c||!m||!d){let g=["Alpha","Beta","Gamma","Delta","Epsilon","Zeta"],T=Zr(F.axisSlot)?Array.from({length:12},(_,v)=>{let w=new Date;return w.setMonth(w.getMonth()-(11-v)),w}):["A","B","C","D","E","F","G","H"],x=[];g.forEach(_=>{T.forEach((v,w)=>{let O=Math.abs(Math.sin(w/2+Math.random()*.3))*100,R=Math.round(O+Math.random()*40);x.push({facet:_,axis:v,axisRaw:v,valueFormatted:f(R),valueRaw:R})})}),h=x}else h=Dd(e,F.measureSlot,F.facetSlot,F.axisSlot,f);t.__chartData=h,$l({chartContainer:M,data:h,width:i,height:s,theme:u,measureFormatter:f,axisIsDatetime:Zr(F.axisSlot),chartType:F.chartType,language:a})},Td=({container:t,slots:e=[],slotConfigurations:n=[],options:r={},language:o="en",dimensions:{width:a,height:i}={width:0,height:0}})=>{let s=t.__chartData||[],u=t.__themeContext,l=r.theme?ha(r.theme):u??ha(void 0);t.__themeContext=l;let f=F.measureSlot?.content?.[0]?Xt(F.measureSlot.content[0]):h=>new Intl.NumberFormat(o).format(h),c=!!F.facetSlot?.content?.length,m=!!F.axisSlot?.content?.length,d=!!F.measureSlot?.content?.length,b=c&&m&&d,M=zl(t,l);Ll(M,l,F.chartType,b,h=>{F.chartType=h,F.selectedAxisValues.clear(),F.selectedFacet=void 0,F.selectionByFacet=new Map,He([]);let g=t.__lastParams;Jr({...g,container:t})}),$l({chartContainer:M,data:s,width:a,height:i,theme:l,measureFormatter:f,axisIsDatetime:Zr(F.axisSlot),chartType:F.chartType,language:o}),t.__chartData=s},kd=({slots:t=[],slotConfigurations:e=[]})=>{let n=t.find(c=>c.name==="category"),r=t.find(c=>c.name==="time"),o=t.find(c=>c.name==="measure"),a=[],i=[],s=n?.content?.[0],u=r?.content?.[0],l=o?.content?.[0];s&&a.push({dataset_id:s.datasetId||s.set,column_id:s.columnId||s.column,level:s.level||1}),u&&a.push({dataset_id:u.datasetId||u.set,column_id:u.columnId||u.column,level:u.level||1}),l&&(l.aggregationFunc&&["sum","average","min","max","count"].includes(l.aggregationFunc)?i.push({dataset_id:l.datasetId||l.set,column_id:l.columnId||l.column,aggregation:{type:l.aggregationFunc}}):i.push({dataset_id:l.datasetId||l.set,column_id:l.columnId||l.column}));let f=[];return s&&f.push({dataset_id:s.datasetId||s.set,column_id:s.columnId||s.column,order:"asc"}),u&&f.push({dataset_id:u.datasetId||u.set,column_id:u.columnId||u.column,order:"asc"}),{dimensions:a,measures:i,order:f,limit:{by:1e4,offset:0}}};function $l({chartContainer:t,data:e,width:n,height:r,theme:o,measureFormatter:a,axisIsDatetime:i,chartType:s,language:u}){t.style.width=`${n}px`,t.style.height=`${r}px`,t.style.position="relative",t.style.overflow="hidden";let l={top:10,right:24,bottom:40,left:24},f=Math.max(0,n-l.left-l.right),c=Math.max(0,r-l.top-l.bottom),m=et(t).append("div").style("position","absolute").style("inset","0 0 0 0").style("pointer-events","none"),d=Array.from(new Set(e.map(E=>E.facet))).sort((E,j)=>E.localeCompare(j,void 0,{numeric:!0,sensitivity:"base"})),b=200,M=180,h=Math.max(1,Math.min(d.length,Math.floor(f/b))),g=Math.ceil(d.length/h),x=Math.max(0,c-40),_=Math.max(b,f/h),v=Math.max(M,x/Math.max(1,g)),w=h*_+l.left+l.right,O=g*v+l.top+l.bottom,R=w>n,st=O>r,q=R?w:n,S=st?O:r,H=et(t).append("svg").attr("width",q).attr("height",S).attr("class","sm-svg").style("display","block").style("width",`${q}px`).style("height",`${S}px`).style("min-width",`${q}px`).style("min-height",`${S}px`);o.fontFamily&&H.style("font-family",o.fontFamily),R||st?(t.style.overflow="auto",t.style.overflowX=R?"auto":"hidden",t.style.overflowY=st?"auto":"hidden"):t.style.overflow="hidden";let Y=o.mainColor||o.basePalette[0]||"#6366f1",Z=H.append("g").attr("transform",`translate(${l.left},${l.top})`),gt=new Map,G=E=>E instanceof Date?String(E.getTime()):String(E),K=()=>{let E=F.selectionByFacet&&F.selectionByFacet.size>0;et(t).selectAll("rect.bar").classed("bar-selected",function(){let j=this.getAttribute("data-axis-key"),X=this.getAttribute("data-facet");if(!X||!j)return!1;let P=F.selectionByFacet?.get(X);return P?P.has(String(j)):!1}).classed("bar-dimmed",function(){let j=this.getAttribute("data-axis-key"),X=this.getAttribute("data-facet");if(!E||!X||!j)return!1;let P=F.selectionByFacet?.get(X);return P?!P.has(String(j)):!0}),et(t).selectAll("circle.point").classed("bar-dimmed",function(){if(!E)return!1;let j=this.getAttribute("data-axis-key"),X=this.getAttribute("data-facet");if(!X||!j)return!1;let P=F.selectionByFacet?.get(X);return P?!P.has(String(j)):!0})},ht=E=>{let j=m.select(`.tooltip[data-facet="${E}"]`);return j.empty()?m.append("div").attr("class","tooltip").attr("data-facet",E).style("opacity",0).style("position","absolute").style("background-color",o.tooltipBackground).style("color",o.tooltipColor).style("box-shadow",`0 12px 24px ${o.hoverShadow}`).style("padding","8px 12px").style("font-size","11px").style("min-width","140px"):j},B=(E,j,X,P)=>{let y=G(j),C=F.axisSlot?.content?.[0],k=F.facetSlot?.content?.[0],p=F.measureSlot?.content?.[0],L=C?Xt(C,{level:C.level||9}):I=>String(I),A=k?Xt(k,{level:k.level||9}):I=>String(I);et(t).selectAll(".hover-highlight").classed("hover-highlight",!1),m.selectAll(".value-label").remove();let V=et(t).selectAll(`[data-axis-key="${y}"]`).classed("hover-highlight",!0);V.filter("circle.point").attr("r",6).attr("stroke",o.backgroundColor).attr("stroke-width",2).each(function(){this.parentNode?.appendChild(this)}),V.filter("rect.bar").attr("stroke",o.mainColor).attr("stroke-width",3).classed("hover-highlight",!0).each(function(){this.parentNode?.appendChild(this)}),et(t).selectAll("rect.bar").filter(function(){let I=et(this).classed("hover-highlight"),D=et(this).classed("bar-selected");return!I&&!D}).classed("bar-hover-dimmed",!0),et(t).selectAll("circle.point").classed("point-hidden",function(){return!et(this).classed("hover-highlight")}).classed("point-visible",function(){return et(this).classed("hover-highlight")}),et(t).selectAll("path.line-path, path.line-area").classed("line-dimmed",function(){return this.getAttribute("data-facet")!==X}),V.filter("rect.bar").filter(function(){return et(this).classed("bar-selected")}).attr("stroke",Le(o.mainColor,.3)).attr("stroke-width",4),d.forEach(I=>{let D=gt.get(I),U=e.find(dt=>dt.facet===I&&(dt.axis instanceof Date?String(dt.axis.getTime()):String(dt.axis))===y);if(!D||!U)return;if(X===I){let dt=ht(I),wt=i?L(U.axis):String(U.axis),xt=A(I),be=F.axisSlot?.content?.[0]?.label?.[u]||"Axis",te=F.facetSlot?.content?.[0]?.label?.[u]||"Facet",Tt=F.measureSlot?.content?.[0]?.label?.[u]||"Measure";dt.interrupt().style("opacity",1).html(`
            <div class="tooltip-title">${xt}</div>
            <div class="tooltip-row"><span>${be}</span><span>${wt}</span></div>
            <div class="tooltip-row"><span>${Tt}</span><span>${U.valueFormatted}</span></div>
          `).style("z-index","1001").style("box-shadow",`0 16px 32px ${o.hoverShadow}`).style("padding","8px 12px").style("font-size","11px").style("min-width","140px");let le=l.left+D.col*_+D.margin.left,J=l.top+D.row*v+D.margin.top,lt=0,Q=D.xScale;if(typeof Q.bandwidth=="function"){let Rt=U.axis instanceof Date?String(U.axis.getTime()):String(U.axis);lt=(Q(String(Rt))??0)+Q.bandwidth()/2}else{let Rt=Q(i?U.axis:String(U.axis));lt=Number.isFinite(Rt)?Rt:0}let St=D.yScale(U.valueRaw),bt=dt.node(),N=typeof P=="number"?P:St,nt=lt>D.w/2,tt=16,$=le+lt+(nt?-tt:tt),it=J+N;dt.style("left",`${$}px`).style("top",`${Math.max(0,it)}px`);let{width:z,height:rt}=bt.getBoundingClientRect();it=J+N-rt/2;let W=m.node().getBoundingClientRect(),ut=W.width-z-8,Mt=8;!nt&&$+z>ut?$=le+lt-z-tt:nt&&$<Mt&&($=le+lt+tt),$=Math.max(Mt,Math.min(ut,$));let Ct=W.height-rt-8;it=Math.max(8,Math.min(Ct,it)),dt.style("left",`${$}px`).style("top",`${it}px`).raise(),et(t).selectAll(`circle.point[data-facet="${X}"][data-axis-key="${y}"]`).attr("r",6).attr("stroke",o.backgroundColor).attr("stroke-width",2).each(function(){this.parentNode?.appendChild(this)})}else{let dt=l.left+D.col*_+D.margin.left,wt=l.top+D.row*v+D.margin.top,xt=0,be=D.xScale;if(typeof be.bandwidth=="function"){let Q=U.axis instanceof Date?String(U.axis.getTime()):String(U.axis);xt=(be(String(Q))??0)+be.bandwidth()/2}else{let Q=be(i?U.axis:String(U.axis));xt=Number.isFinite(Q)?Q:0}let te=D.yScale(U.valueRaw),Tt=m.select(`.value-label[data-facet="${I}"][data-axis-key="${y}"]`);Tt.empty()&&(Tt=m.append("div").attr("class","value-label").attr("data-facet",I).attr("data-axis-key",y));let J=(s==="column"?Math.abs(te-D.yScale(0)):0)<30,lt=te;s==="column"&&!J?lt=U.valueRaw>=0?te+18:te-8:s==="column"?lt=te+4:lt=te+10,Tt.style("opacity",1).style("position","absolute").style("left",`${dt+xt}px`).style("top",`${wt+lt}px`).style("transform","translate(-50%, 50%)").style("background-color","rgba(0, 0, 0, 0.75)").style("color","#fff").style("padding","4px 8px").style("border-radius","4px").style("font-size","11px").style("font-weight","600").style("white-space","nowrap").style("pointer-events","none").style("z-index","400").text(U.valueFormatted)}})},ft=()=>{m.selectAll(".tooltip").transition().duration(120).style("opacity",0),m.selectAll(".value-label").remove(),et(t).selectAll(".hover-highlight").classed("hover-highlight",!1);let E=et(t);E.selectAll(".point").attr("r",3).attr("stroke",null).attr("stroke-width",null).classed("point-hidden",!1).classed("point-visible",!1),E.selectAll("rect.bar").attr("stroke",null).attr("stroke-width",null).classed("hover-highlight",!1).classed("bar-hover-dimmed",!1),E.selectAll("path.line-path, path.line-area").classed("line-dimmed",!1)},mt=new Map,pt=new Map,Pt=new Map;d.forEach(E=>{let j=e.filter(P=>P.facet===E),X=i?Array.from(new Set(j.map(P=>P.axis.getTime()))).sort((P,y)=>P-y).map(P=>new Date(P)):Array.from(new Set(j.map(P=>String(P.axis))));mt.set(E,X),pt.set(E,jn(j,P=>P.valueRaw)||0),Pt.set(E,tr(j,P=>P.valueRaw)||0)});let Vt=(E,j)=>{let X=Math.floor(j/h),P=j%h,y=Z.append("g").attr("transform",`translate(${P*_}, ${X*v})`),C={top:18,right:10,bottom:22,left:40},k=_-C.left-C.right,p=v-C.top-C.bottom,L=e.filter(J=>J.facet===E),A=mt.get(E)||[],V=pt.get(E)||0,I=Pt.get(E)||0,D=i?qr().domain(Zn(A)).range([0,k]):Ie().domain(A).range([0,k]).padding(.2),U;if(s==="column"&&i){let J=A.map(lt=>String(lt.getTime()));U=Ie().domain(J).range([0,k]).padding(.2)}let Wt=I<0?I*1.15:0,dt=V>0?V*1.15:0;I===0&&V===0?dt=1:I===V&&(I>0?(Wt=0,dt=V*1.15):I<0&&(Wt=I*1.15,dt=0));let wt=$n().domain([Wt,dt]).nice().range([p,0]),xt=y.append("g").attr("transform",`translate(${C.left}, ${C.top})`),te=`${F.facetSlot?.content?.[0]?.label?.[u]||F.facetSlot?.content?.[0]?.label||"Facet"}: ${E}`;y.append("text").attr("x",40).attr("y",14).style("font-weight",600).style("font-size","12px").style("fill",o.axisTextColor).text(te);let Tt=xt.append("g").attr("class","axis x-axis").attr("transform",`translate(0,${p})`);if(s==="column"&&i&&U){let J=F.axisSlot?.content?.[0],lt=J?Xt(J,{level:J.level||9}):nt=>String(nt),Q=bn(U).tickSizeOuter(0).tickFormat(nt=>lt(new Date(Number(String(nt)))));Tt.call(Q);let St=A,bt=Tt.selectAll(".tick"),N=bt.nodes();if(N.length>2){let tt=[];N.forEach((z,rt)=>{let ut=z.getAttribute("transform")?.match(/translate\(([^,]+),/),Mt=ut?parseFloat(ut[1]):0,Ft=z.querySelector("text")?.getBBox();tt.push({index:rt,position:Mt,width:Ft?.width||40})});let $=new Set;$.add(0),$.add(tt.length-1);let it=tt[0].position;for(let z=1;z<tt.length-1;z++){let rt=tt[z];rt.position-it>=50&&($.add(z),it=rt.position)}bt.each(function(z,rt){$.has(rt)||et(this).remove()})}}else if(i){let lt=Math.max(4,Math.floor(k/55)),Q=D,St=F.axisSlot?.content?.[0],bt=St?Xt(St,{level:St.level||9}):void 0,N=bn(Q).ticks(lt).tickSizeOuter(0);bt&&N.tickFormat(W=>bt(W)),Tt.call(N);let nt=Q.domain(),tt=Tt.selectAll(".tick"),$=tt.data().map(W=>W.getTime()),it=(nt[1].getTime()-nt[0].getTime())*.02,z=$.some(W=>Math.abs(W-nt[0].getTime())<it),rt=$.some(W=>Math.abs(W-nt[1].getTime())<it);if(!z&&k>120){let W=Q(nt[0]);if(!tt.nodes().some(Mt=>{let Ft=Mt.getAttribute("transform")?.match(/translate\(([^,]+),/),Rt=Ft?parseFloat(Ft[1]):0;return Math.abs(Rt-W)<45})){let Mt=Tt.insert("g",":first-child").attr("class","tick").attr("opacity",1).attr("transform",`translate(${W},0)`);Mt.append("line").attr("y2",6).attr("stroke",o.axisLineColor),Mt.append("text").attr("y",9).attr("dy","0.71em").style("fill",o.axisTextColor).style("font-size","10px").text(bt?bt(nt[0]):nt[0].toLocaleDateString())}}if(!rt&&k>120){let W=Q(nt[1]);if(!tt.nodes().some(Mt=>{let Ft=Mt.getAttribute("transform")?.match(/translate\(([^,]+),/),Rt=Ft?parseFloat(Ft[1]):0;return Math.abs(Rt-W)<45})){let Mt=Tt.append("g").attr("class","tick").attr("opacity",1).attr("transform",`translate(${W},0)`);Mt.append("line").attr("y2",6).attr("stroke",o.axisLineColor),Mt.append("text").attr("y",9).attr("dy","0.71em").style("fill",o.axisTextColor).style("font-size","10px").text(bt?bt(nt[1]):nt[1].toLocaleDateString())}}}else Tt.call(bn(D).tickSizeOuter(0));if(Tt.selectAll("text").style("fill",o.axisTextColor).style("font-size","10px"),Tt.selectAll("line").attr("stroke",o.axisLineColor),Tt.selectAll("path").attr("stroke",o.axisLineColor),!i){let J=A,lt=D.bandwidth(),Q=J.reduce(($,it)=>$+String(it).length,0)/J.length,St=Math.max(...J.map($=>String($).length)),bt=lt<50||Q>8&&lt<80,N=bt?St*4:St*6,tt=Math.max(3,Math.floor(k/Math.max(N,bt?40:50)));if(J.length>tt){let $=Tt.selectAll("g.tick"),it=$.size(),z=Math.ceil((it-2)/(tt-2)),rt=new Set;rt.add(0),rt.add(it-1);for(let W=z;W<it-1;W+=z)rt.add(W);$.each(function(W,ut){rt.has(ut)||et(this).remove()})}if(bt){let $=St<=10?-45:-35;Tt.selectAll("text").attr("text-anchor","end").attr("transform",`rotate(${$})`).attr("dx","-0.5em").attr("dy","0.15em")}}let le=xt.append("g").attr("class","axis y-axis").call(bo(wt).ticks(3).tickSize(-k).tickFormat(J=>a(Number(J))));if(le.selectAll("text").style("fill",o.axisTextColor).style("font-size","10px"),le.selectAll("line").attr("stroke",o.axisLineColor).attr("stroke-dasharray","2,4"),le.selectAll("path").attr("stroke",o.axisLineColor),s==="column"){let J=Y,lt=i?U:D;gt.set(E,{row:X,col:P,margin:C,w:k,h:p,xScale:lt,yScale:wt}),L.forEach(Q=>{let St=G(Q.axis),bt=lt(String(St))??0,N=lt.bandwidth(),nt=wt(0),tt=wt(Q.valueRaw),$=Q.valueRaw>=0?tt:nt,it=Math.abs(tt-nt),z=xt.append("rect").attr("class","bar").attr("x",bt).attr("y",$).attr("width",N).attr("height",it).attr("fill",J).attr("rx",4).attr("ry",4).style("filter","none").attr("data-axis-key",G(Q.axis)).attr("data-facet",E).on("mousemove",function(W){let[ut,Mt]=me(W,xt.node()),Ct=un(J,.18);et(this).raise().attr("fill",Ct).style("filter",`drop-shadow(0 10px 18px ${o.hoverShadow})`),B(W,Q.axis,E,Mt)}).on("mouseout",function(){et(this).attr("fill",J).style("filter","none"),ft()}).on("click",function(){let W=G(Q.axis);F.selectionByFacet||(F.selectionByFacet=new Map);let ut=F.selectionByFacet.get(E)||new Set;ut.has(W)?ut.delete(W):ut.add(W),ut.size>0?F.selectionByFacet.set(E,ut):F.selectionByFacet.delete(E),F.selectedAxisValues=new Set(ut),F.selectedFacet=F.selectedAxisValues.size?E:void 0,et(t).select(".clear-filter-btn").classed("visible",F.selectionByFacet&&F.selectionByFacet.size>0);let Ct=F.axisSlot?.content?.[0],Ft=F.facetSlot?.content?.[0];if(!Ct){K();return}let Rt=[];if(F.selectionByFacet&&F.selectionByFacet.size)for(let[ga,ya]of F.selectionByFacet.entries()){if(!ya.size)continue;let Kr=[];Ft&&Kr.push({expression:"? = ?",parameters:[{column_id:Ft.columnId||Ft.column,dataset_id:Ft.datasetId||Ft.set,level:Ft.level||void 0},ga],properties:{origin:"filterFromVizItem",type:"where"}});let Vn=Array.from(ya).map(xa=>i?new Date(Number(xa)).toISOString():xa);Kr.push({expression:Vn.length>1?"? in ?":"? = ?",parameters:[{column_id:Ct.columnId||Ct.column,dataset_id:Ct.datasetId||Ct.set,level:Ct.level||void 0},Vn.length>1?Vn:Vn[0]],properties:{origin:"filterFromVizItem",type:"where"}}),Rt.push(Kr)}Rt.length>1?He(Rt):Rt.length===1?He(Rt[0]):He([]),_d({facet:E,axis:Q.axis,value:Q.valueFormatted,rawValue:Q.valueRaw}),K()}),rt=wt(0);z.attr("height",0).attr("y",rt).transition().duration(300).attr("y",$).attr("height",it)}),K()}else{let J=Y;if(i){let lt=ln().x(N=>D(N.axis)).y(N=>wt(N.valueRaw)).defined(N=>Number.isFinite(N.valueRaw)),Q=[...L].sort((N,nt)=>N.axis.getTime()-nt.axis.getTime());if(gt.set(E,{row:X,col:P,margin:C,w:k,h:p,xScale:D,yScale:wt}),s==="area"){let N=`area-gradient-${E.replace(/[^a-zA-Z0-9]/g,"-")}-${Math.random().toString(36).substr(2,9)}`,tt=H.append("defs").append("linearGradient").attr("id",N).attr("x1","0%").attr("y1","0%").attr("x2","0%").attr("y2","100%"),$=Lt(J);tt.append("stop").attr("offset","0%").attr("stop-color",J).attr("stop-opacity",.6),tt.append("stop").attr("offset","50%").attr("stop-color",J).attr("stop-opacity",.3),tt.append("stop").attr("offset","100%").attr("stop-color",J).attr("stop-opacity",.05);let it=Qr().x(z=>D(z.axis)).y0(wt(0)).y1(z=>wt(z.valueRaw)).defined(z=>Number.isFinite(z.valueRaw));xt.append("path").attr("class","line-area").attr("data-facet",E).attr("fill",`url(#${N})`).attr("d",it(Q))}xt.append("path").attr("class","line-path").attr("data-facet",E).attr("fill","none").attr("stroke",J).attr("stroke-width",2).attr("d",lt(Q)).style("filter",`drop-shadow(0 6px 12px ${o.hoverShadow})`);let St=Lo().extent([[0,0],[k,p]]).on("start",function(){ft()}).on("end",({selection:N})=>{if(!N)return;let[nt,tt]=N,$=D.invert(nt),it=D.invert(tt),z=F.axisSlot?.content?.[0],rt=F.facetSlot?.content?.[0];if(!z)return;let W=[];W.push({expression:"? between ?",parameters:[{column_id:z.columnId||z.column,dataset_id:z.datasetId||z.set,level:z.level||void 0},[$.toISOString(),it.toISOString()]],properties:{origin:"filterFromVizItem",type:"where"}}),rt&&W.push({expression:"? = ?",parameters:[{column_id:rt.columnId||rt.column,dataset_id:rt.datasetId||rt.set,level:rt.level||void 0},E],properties:{origin:"filterFromVizItem",type:"where"}}),et(t).select(".clear-filter-btn").classed("visible",!0),He(W)}),bt=xt.append("g").attr("class","brush").call(St);xt.append("rect").attr("class","hover-overlay-datetime").attr("x",0).attr("y",0).attr("width",k).attr("height",p).attr("fill","transparent").style("pointer-events","all").on("mousemove",N=>{let[nt,tt]=me(N,xt.node()),$=A;if(!$.length)return;let it=D.invert(nt),z=0,rt=$.length-1,W=it.getTime();for(;z<rt;){let Ct=Math.floor((z+rt)/2);$[Ct].getTime()<W?z=Ct+1:rt=Ct}let ut=z;if(ut>0){let Ct=$[ut-1].getTime(),Ft=$[ut].getTime();Math.abs(Ct-W)<Math.abs(Ft-W)&&(ut=ut-1)}let Mt=$[Math.max(0,Math.min($.length-1,ut))];B(N,Mt,E,tt)}).on("mouseleave",()=>ft()),xt.selectAll("circle.point").data(Q).enter().append("circle").attr("class","point").attr("cx",N=>D(N.axis)).attr("cy",N=>wt(N.valueRaw)).attr("r",3).attr("fill",J).attr("data-axis-key",N=>G(N.axis)).attr("data-facet",E).style("pointer-events","none")}else{let lt=A,Q=Ko().domain(lt).range([0,k]);gt.set(E,{row:X,col:P,margin:C,w:k,h:p,xScale:Q,yScale:wt});let St=[...L];if(s==="area"){let N=`area-gradient-${E.replace(/[^a-zA-Z0-9]/g,"-")}-${Math.random().toString(36).substr(2,9)}`,tt=H.append("defs").append("linearGradient").attr("id",N).attr("x1","0%").attr("y1","0%").attr("x2","0%").attr("y2","100%"),$=Lt(J);tt.append("stop").attr("offset","0%").attr("stop-color",J).attr("stop-opacity",.6),tt.append("stop").attr("offset","50%").attr("stop-color",J).attr("stop-opacity",.3),tt.append("stop").attr("offset","100%").attr("stop-color",J).attr("stop-opacity",.05);let it=Qr().x(z=>Q(String(z.axis))||0).y0(wt(0)).y1(z=>wt(z.valueRaw));xt.append("path").attr("class","line-area").attr("data-facet",E).attr("fill",`url(#${N})`).attr("d",it(St))}let bt=ln().x(N=>Q(String(N.axis))||0).y(N=>wt(N.valueRaw));xt.append("path").attr("class","line-path").attr("data-facet",E).attr("fill","none").attr("stroke",J).attr("stroke-width",2).attr("d",bt(St)).style("filter",`drop-shadow(0 6px 12px ${o.hoverShadow})`),xt.selectAll("circle.point").data(St).enter().append("circle").attr("class","point").attr("cx",N=>Q(String(N.axis))||0).attr("cy",N=>wt(N.valueRaw)).attr("r",3).attr("fill",J).attr("data-axis-key",N=>G(N.axis)).attr("data-facet",E).style("pointer-events","none"),xt.append("rect").attr("class","hover-overlay").attr("x",0).attr("y",0).attr("width",k).attr("height",p).attr("fill","transparent").style("pointer-events","all").on("mousemove",N=>{let[nt,tt]=me(N,xt.node()),$=lt;if(!$.length)return;let it=$[0],z=1/0;$.forEach(rt=>{let W=Q(rt)||0,ut=Math.abs(W-nt);ut<z&&(z=ut,it=rt)}),B(N,it,E,tt)}).on("mouseleave",()=>ft())}}};d.forEach((E,j)=>Vt(E,j))}function zl(t,e){t.innerHTML="",t.style.background=e.backgroundColor;let n=document.createElement("div");n.className="bar-chart-container",n.style.background=e.backgroundColor,n.style.setProperty("--chart-background",e.backgroundColor),n.style.setProperty("--axis-text-color",e.axisTextColor),n.style.setProperty("--axis-line-color",e.axisLineColor),n.style.setProperty("--main-color",e.mainColor),n.style.setProperty("--control-bg",e.controlBackground),n.style.setProperty("--control-border",e.controlBorder),n.style.setProperty("--control-text",e.controlText),n.style.setProperty("--control-hover-bg",e.controlHoverBackground),n.style.setProperty("--hover-shadow",e.hoverShadow),n.style.setProperty("--selected-shadow",e.selectedShadow),n.style.setProperty("--tooltip-bg",e.tooltipBackground),n.style.setProperty("--tooltip-color",e.tooltipColor),n.style.setProperty("--bar-radius",`${e.barRounding}px`),n.style.setProperty("--chart-font-family",e.fontFamily),e.fontFamily&&(n.style.fontFamily=e.fontFamily);let r=document.createElement("div");r.className="sticky-header",n.appendChild(r);let o=document.createElement("div");o.className="controls-bar",r.appendChild(o);let a=document.createElement("button");return a.className="clear-filter-btn",a.textContent="Clear Filters",a.onclick=()=>{F.selectedAxisValues.clear(),F.selectedFacet=void 0,F.selectionByFacet=new Map,a.classList.remove("visible"),He([]);let i=t.__lastParams;i&&Jr({...i,container:t})},r.appendChild(a),t.appendChild(n),n}function Ll(t,e,n,r,o){let a=t.querySelector(".sticky-header");if(!a)return;if(!r){a.style.display="none";return}a.style.display="";let i=t.querySelector(".controls-bar");if(!i)return;i.innerHTML="";let s=document.createElement("select");s.className="chart-type-select",[{label:"Column",value:"column"},{label:"Line",value:"line"},{label:"Area",value:"area"}].forEach(l=>{let f=document.createElement("option");f.value=l.value,f.textContent=l.label,s.appendChild(f)}),s.value=F.chartType||n,s.onchange=()=>o(s.value),i.appendChild(s)}function Dd(t,e,n,r,o){let a=n?.content[0]?Xt(n.content[0],{level:n.content[0].level||9}):s=>String(s),i=r?.content[0]?Xt(r.content[0],{level:r.content[0].level||9}):s=>String(s);return(t??[]).map(s=>{let u=s[0]?.name?.en||s[0]||"Unknown",l=s[1]?.name?.en||s[1]||"",f=r.content[0].type==="datetime",c=f?new Date(l):l,m=Number(s[2])||0;return{facet:String(a(n.content[0].type==="datetime"?new Date(u):u)),axis:f?c:String(i(l)),axisRaw:l,valueFormatted:o(m),valueRaw:m}})}export{kd as buildQuery,Jr as render,Td as resize};
/*! Bundled license information:

@luzmo/analytics-components-kit/components/decompose-numeric-format-BuZcjH2k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/localize-BX7q0S0M.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/formatter-CQDms6fU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/area-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bar-chart-slots.config-MQAjNXqV.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/box-plot-slots.config-BRhnF2FE.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bubble-chart-slots.config-Bbh94VgZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bullet-chart-slots.config-BlWTleBt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/choropleth-map-slots.config-B-uJTj4q.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circle-pack-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circular-gauge-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/column-chart-slots.config-DAdAk17k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/combination-chart-slots.config-CqKLFKCZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/conditional-number-slots.config-L3t5pb1-.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/date-filter-slots.config-CxB8IF5B.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/donut-chart-slots.config-BEwhfq27.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/dropdown-filter-slots.config-B8J6ftCh.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/evolution-number-slots.config-CW21b2ua.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/funnel-chart-slots.config-BBhMS2qi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-table-slots.config-DJkP72oT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/hexbin-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/image-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/line-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/marker-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/ohlc-chart-slots.config-Cvy5n1xv.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/parallel-coordinates-plot-slots.config-CQW2CJW6.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pivot-table-slots.config-BH5fOJre.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pyramid-chart-slots.config-Cm9bQsXT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/radar-chart-slots.config-Dpmytmc3.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/regular-table-slots.config-EUS-V9lL.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/route-map-slots.config-DYCcaQZi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sankey-diagram-slots.config-BSTBEZDe.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/scatter-plot-slots.config-BuWYqDWK.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/search-filter-slots.config-DmiVXOva.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slicer-filter-slots.config-CHQ0ZXga.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slider-filter-slots.config-BN3K1rnl.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/speedometer-chart-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/spike-map-slots.config-CuqpgkvN.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/strip-plot-slots.config-Co8ghEv8.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sunburst-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/symbol-map-slots.config-C5CKaVED.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/text-slots.config-Hy5yNIAX.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/treemap-chart-slots.config-xLD22K9V.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/venn-diagram-slots.config-DPmj71cR.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/video-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/wordcloud-chart-slots.config-BS4sOOHt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/index-BEAYzHcY.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/utils.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)
*/
