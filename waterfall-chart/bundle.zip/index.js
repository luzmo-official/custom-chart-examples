function er(t){let e=/(?:([^{])?([<>=^]))?([+\- \()])?([$#])?(0)?(\d+)?([,_])?(\.-?\d+)?([a-z%]{1,2})?/i.exec(t)??[];return{fill:e[1]||" ",align:e[2]||">",sign:e[3]||"-",symbol:e[4]||"",zfill:e[5],width:+e[6],comma:e[7],precision:e[8],typeFormat:e[9]}}function rt(t){return t==null}function rr(t){return typeof t=="string"||t instanceof String}function $t(t){return!Number.isNaN(t)&&Number.isFinite(t)}function ai(t){return typeof t=="boolean"}function ii(t){return t!==null&&typeof t=="object"&&!Array.isArray(t)}function li(t){return t!==null&&typeof t=="object"&&Object.keys(t).length===0}function nr(t,e,r){if(rr(t)||$t(t)||ai(t))return t.toString();if(rt(t)||!ii(t)||li(t))return"";let n="",o=Object.keys(t);return r!=null&&r.allowEmpty?(e&&t[e]!==void 0&&(n=t[e]),n===void 0&&(n="")):(e&&t[e]&&(n=t[e]),(rt(n)||n==="")&&o!=null&&o.length&&(n=t[o[0]])),n}function si(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function ge(t,e){if((r=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var r,n=t.slice(0,r);return[n.length>1?n[0]+n.slice(2):n,+t.slice(r+1)]}function ui(t){return t=ge(Math.abs(t)),t?t[1]:NaN}function ci(t,e){return function(r,n){for(var o=r.length,a=[],i=0,l=t[0],s=0;o>0&&l>0&&(s+l+1>n&&(l=Math.max(1,n-s)),a.push(r.substring(o-=l,o+l)),!((s+=l+1)>n));)l=t[i=(i+1)%t.length];return a.reverse().join(e)}}function fi(t){return function(e){return e.replace(/[0-9]/g,function(r){return t[+r]})}}var mi=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function sr(t){if(!(e=mi.exec(t)))throw new Error("invalid format: "+t);var e;return new fr({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}sr.prototype=fr.prototype;function fr(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}fr.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function pi(t){t:for(var e=t.length,r=1,n=-1,o;r<e;++r)switch(t[r]){case".":n=o=r;break;case"0":n===0&&(n=r),o=r;break;default:if(!+t[r])break t;n>0&&(n=0);break}return n>0?t.slice(0,n)+t.slice(o+1):t}var wn;function di(t,e){var r=ge(t,e);if(!r)return t+"";var n=r[0],o=r[1],a=o-(wn=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,i=n.length;return a===i?n:a>i?n+new Array(a-i+1).join("0"):a>0?n.slice(0,a)+"."+n.slice(a):"0."+new Array(1-a).join("0")+ge(t,Math.max(0,e+a-1))[0]}function an(t,e){var r=ge(t,e);if(!r)return t+"";var n=r[0],o=r[1];return o<0?"0."+new Array(-o).join("0")+n:n.length>o+1?n.slice(0,o+1)+"."+n.slice(o+1):n+new Array(o-n.length+2).join("0")}var ln={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:si,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>an(t*100,e),r:an,s:di,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function sn(t){return t}var un=Array.prototype.map,cn=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function hi(t){var e=t.grouping===void 0||t.thousands===void 0?sn:ci(un.call(t.grouping,Number),t.thousands+""),r=t.currency===void 0?"":t.currency[0]+"",n=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",a=t.numerals===void 0?sn:fi(un.call(t.numerals,String)),i=t.percent===void 0?"%":t.percent+"",l=t.minus===void 0?"\u2212":t.minus+"",s=t.nan===void 0?"NaN":t.nan+"";function u(c){c=sr(c);var p=c.fill,m=c.align,g=c.sign,h=c.symbol,b=c.zero,x=c.width,M=c.comma,C=c.precision,k=c.trim,w=c.type;w==="n"?(M=!0,w="g"):ln[w]||(C===void 0&&(C=12),k=!0,w="g"),(b||p==="0"&&m==="=")&&(b=!0,p="0",m="=");var S=h==="$"?r:h==="#"&&/[boxX]/.test(w)?"0"+w.toLowerCase():"",I=h==="$"?n:/[%p]/.test(w)?i:"",q=ln[w],Q=/[defgprs%]/.test(w);C=C===void 0?6:/[gprs]/.test(w)?Math.max(1,Math.min(21,C)):Math.max(0,Math.min(20,C));function R(y){var E=S,D=I,P,tt,K;if(w==="c")D=q(y)+D,y="";else{y=+y;var W=y<0||1/y<0;if(y=isNaN(y)?s:q(Math.abs(y),C),k&&(y=pi(y)),W&&+y==0&&g!=="+"&&(W=!1),E=(W?g==="("?g:l:g==="-"||g==="("?"":g)+E,D=(w==="s"?cn[8+wn/3]:"")+D+(W&&g==="("?")":""),Q){for(P=-1,tt=y.length;++P<tt;)if(K=y.charCodeAt(P),48>K||K>57){D=(K===46?o+y.slice(P+1):y.slice(P))+D,y=y.slice(0,P);break}}}M&&!b&&(y=e(y,1/0));var _=E.length+y.length+D.length,O=_<x?new Array(x-_+1).join(p):"";switch(M&&b&&(y=e(O+y,O.length?x-D.length:1/0),O=""),m){case"<":y=E+y+D+O;break;case"=":y=E+O+y+D;break;case"^":y=O.slice(0,_=O.length>>1)+E+y+D+O.slice(_);break;default:y=O+E+y+D;break}return a(y)}return R.toString=function(){return c+""},R}function f(c,p){var m=u((c=sr(c),c.type="f",c)),g=Math.max(-8,Math.min(8,Math.floor(ui(p)/3)))*3,h=Math.pow(10,-g),b=cn[8+g/3];return function(x){return m(h*x)+b}}return{format:u,formatPrefix:f}}var or=new Date,ar=new Date;function L(t,e,r,n){function o(a){return t(a=arguments.length===0?new Date:new Date(+a)),a}return o.floor=a=>(t(a=new Date(+a)),a),o.ceil=a=>(t(a=new Date(a-1)),e(a,1),t(a),a),o.round=a=>{let i=o(a),l=o.ceil(a);return a-i<l-a?i:l},o.offset=(a,i)=>(e(a=new Date(+a),i==null?1:Math.floor(i)),a),o.range=(a,i,l)=>{let s=[];if(a=o.ceil(a),l=l==null?1:Math.floor(l),!(a<i)||!(l>0))return s;let u;do s.push(u=new Date(+a)),e(a,l),t(a);while(u<a&&a<i);return s},o.filter=a=>L(i=>{if(i>=i)for(;t(i),!a(i);)i.setTime(i-1)},(i,l)=>{if(i>=i)if(l<0)for(;++l<=0;)for(;e(i,-1),!a(i););else for(;--l>=0;)for(;e(i,1),!a(i););}),r&&(o.count=(a,i)=>(or.setTime(+a),ar.setTime(+i),t(or),t(ar),Math.floor(r(or,ar))),o.every=a=>(a=Math.floor(a),!isFinite(a)||!(a>0)?null:a>1?o.filter(n?i=>n(i)%a===0:i=>o.count(0,i)%a===0):o)),o}var Wt=1e3,ut=Wt*60,Ut=ut*60,Gt=Ut*24,_n=Gt*7,Cn=L(t=>{t.setTime(t-t.getMilliseconds())},(t,e)=>{t.setTime(+t+e*Wt)},(t,e)=>(e-t)/Wt,t=>t.getUTCSeconds());Cn.range;var Sn=L(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*Wt)},(t,e)=>{t.setTime(+t+e*ut)},(t,e)=>(e-t)/ut,t=>t.getMinutes());Sn.range;var gi=L(t=>{t.setUTCSeconds(0,0)},(t,e)=>{t.setTime(+t+e*ut)},(t,e)=>(e-t)/ut,t=>t.getUTCMinutes());gi.range;var Mn=L(t=>{t.setTime(t-t.getMilliseconds()-t.getSeconds()*Wt-t.getMinutes()*ut)},(t,e)=>{t.setTime(+t+e*Ut)},(t,e)=>(e-t)/Ut,t=>t.getHours());Mn.range;var yi=L(t=>{t.setUTCMinutes(0,0,0)},(t,e)=>{t.setTime(+t+e*Ut)},(t,e)=>(e-t)/Ut,t=>t.getUTCHours());yi.range;var be=L(t=>t.setHours(0,0,0,0),(t,e)=>t.setDate(t.getDate()+e),(t,e)=>(e-t-(e.getTimezoneOffset()-t.getTimezoneOffset())*ut)/Gt,t=>t.getDate()-1);be.range;var mr=L(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/Gt,t=>t.getUTCDate()-1);mr.range;var xi=L(t=>{t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCDate(t.getUTCDate()+e)},(t,e)=>(e-t)/Gt,t=>Math.floor(t/Gt));xi.range;function yt(t){return L(e=>{e.setDate(e.getDate()-(e.getDay()+7-t)%7),e.setHours(0,0,0,0)},(e,r)=>{e.setDate(e.getDate()+r*7)},(e,r)=>(r-e-(r.getTimezoneOffset()-e.getTimezoneOffset())*ut)/_n)}var pr=yt(0),ye=yt(1),bi=yt(2),vi=yt(3),Tt=yt(4),wi=yt(5),_i=yt(6);pr.range;ye.range;bi.range;vi.range;Tt.range;wi.range;_i.range;function xt(t){return L(e=>{e.setUTCDate(e.getUTCDate()-(e.getUTCDay()+7-t)%7),e.setUTCHours(0,0,0,0)},(e,r)=>{e.setUTCDate(e.getUTCDate()+r*7)},(e,r)=>(r-e)/_n)}var kn=xt(0),xe=xt(1),Ci=xt(2),Si=xt(3),Ft=xt(4),Mi=xt(5),ki=xt(6);kn.range;xe.range;Ci.range;Si.range;Ft.range;Mi.range;ki.range;var An=L(t=>{t.setDate(1),t.setHours(0,0,0,0)},(t,e)=>{t.setMonth(t.getMonth()+e)},(t,e)=>e.getMonth()-t.getMonth()+(e.getFullYear()-t.getFullYear())*12,t=>t.getMonth());An.range;var Ai=L(t=>{t.setUTCDate(1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCMonth(t.getUTCMonth()+e)},(t,e)=>e.getUTCMonth()-t.getUTCMonth()+(e.getUTCFullYear()-t.getUTCFullYear())*12,t=>t.getUTCMonth());Ai.range;var ct=L(t=>{t.setMonth(0,1),t.setHours(0,0,0,0)},(t,e)=>{t.setFullYear(t.getFullYear()+e)},(t,e)=>e.getFullYear()-t.getFullYear(),t=>t.getFullYear());ct.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:L(e=>{e.setFullYear(Math.floor(e.getFullYear()/t)*t),e.setMonth(0,1),e.setHours(0,0,0,0)},(e,r)=>{e.setFullYear(e.getFullYear()+r*t)});ct.range;var gt=L(t=>{t.setUTCMonth(0,1),t.setUTCHours(0,0,0,0)},(t,e)=>{t.setUTCFullYear(t.getUTCFullYear()+e)},(t,e)=>e.getUTCFullYear()-t.getUTCFullYear(),t=>t.getUTCFullYear());gt.every=t=>!isFinite(t=Math.floor(t))||!(t>0)?null:L(e=>{e.setUTCFullYear(Math.floor(e.getUTCFullYear()/t)*t),e.setUTCMonth(0,1),e.setUTCHours(0,0,0,0)},(e,r)=>{e.setUTCFullYear(e.getUTCFullYear()+r*t)});gt.range;function ir(t){if(0<=t.y&&t.y<100){var e=new Date(-1,t.m,t.d,t.H,t.M,t.S,t.L);return e.setFullYear(t.y),e}return new Date(t.y,t.m,t.d,t.H,t.M,t.S,t.L)}function lr(t){if(0<=t.y&&t.y<100){var e=new Date(Date.UTC(-1,t.m,t.d,t.H,t.M,t.S,t.L));return e.setUTCFullYear(t.y),e}return new Date(Date.UTC(t.y,t.m,t.d,t.H,t.M,t.S,t.L))}function Ht(t,e,r){return{y:t,m:e,d:r,H:0,M:0,S:0,L:0}}function ur(t){var e=t.dateTime,r=t.date,n=t.time,o=t.periods,a=t.days,i=t.shortDays,l=t.months,s=t.shortMonths,u=Pt(o),f=Vt(o),c=Pt(a),p=Vt(a),m=Pt(i),g=Vt(i),h=Pt(l),b=Vt(l),x=Pt(s),M=Vt(s),C={a:W,A:_,b:O,B:Za,c:null,d:gn,e:gn,f:Zi,g:il,G:sl,H:Gi,I:Xi,j:Qi,L:Dn,m:Ji,M:Ki,p:Ja,q:Ka,Q:bn,s:vn,S:ji,u:tl,U:el,V:rl,w:nl,W:ol,x:null,X:null,y:al,Y:ll,Z:ul,"%":xn},k={a:ja,A:ti,b:ei,B:ri,c:null,d:yn,e:yn,f:pl,g:Cl,G:Ml,H:cl,I:fl,j:ml,L:Fn,m:dl,M:hl,p:ni,q:oi,Q:bn,s:vn,S:gl,u:yl,U:xl,V:bl,w:vl,W:wl,x:null,X:null,y:_l,Y:Sl,Z:kl,"%":xn},w={a:R,A:y,b:E,B:D,c:P,d:dn,e:dn,f:Pi,g:pn,G:mn,H:hn,I:hn,j:Bi,L:Hi,m:qi,M:Li,p:Q,q:zi,Q:Wi,s:Ui,S:$i,u:Oi,U:Ni,V:Yi,w:Ei,W:Ri,x:tt,X:K,y:pn,Y:mn,Z:Ii,"%":Vi};C.x=S(r,C),C.X=S(n,C),C.c=S(e,C),k.x=S(r,k),k.X=S(n,k),k.c=S(e,k);function S(v,A){return function(T){var d=[],U=-1,N=0,Z=v.length,J,ht,on;for(T instanceof Date||(T=new Date(+T));++U<Z;)v.charCodeAt(U)===37&&(d.push(v.slice(N,U)),(ht=fn[J=v.charAt(++U)])!=null?J=v.charAt(++U):ht=J==="e"?" ":"0",(on=A[J])&&(J=on(T,ht)),d.push(J),N=U+1);return d.push(v.slice(N,U)),d.join("")}}function I(v,A){return function(T){var d=Ht(1900,void 0,1),U=q(d,v,T+="",0),N,Z;if(U!=T.length)return null;if("Q"in d)return new Date(d.Q);if("s"in d)return new Date(d.s*1e3+("L"in d?d.L:0));if(A&&!("Z"in d)&&(d.Z=0),"p"in d&&(d.H=d.H%12+d.p*12),d.m===void 0&&(d.m="q"in d?d.q:0),"V"in d){if(d.V<1||d.V>53)return null;"w"in d||(d.w=1),"Z"in d?(N=lr(Ht(d.y,0,1)),Z=N.getUTCDay(),N=Z>4||Z===0?xe.ceil(N):xe(N),N=mr.offset(N,(d.V-1)*7),d.y=N.getUTCFullYear(),d.m=N.getUTCMonth(),d.d=N.getUTCDate()+(d.w+6)%7):(N=ir(Ht(d.y,0,1)),Z=N.getDay(),N=Z>4||Z===0?ye.ceil(N):ye(N),N=be.offset(N,(d.V-1)*7),d.y=N.getFullYear(),d.m=N.getMonth(),d.d=N.getDate()+(d.w+6)%7)}else("W"in d||"U"in d)&&("w"in d||(d.w="u"in d?d.u%7:"W"in d?1:0),Z="Z"in d?lr(Ht(d.y,0,1)).getUTCDay():ir(Ht(d.y,0,1)).getDay(),d.m=0,d.d="W"in d?(d.w+6)%7+d.W*7-(Z+5)%7:d.w+d.U*7-(Z+6)%7);return"Z"in d?(d.H+=d.Z/100|0,d.M+=d.Z%100,lr(d)):ir(d)}}function q(v,A,T,d){for(var U=0,N=A.length,Z=T.length,J,ht;U<N;){if(d>=Z)return-1;if(J=A.charCodeAt(U++),J===37){if(J=A.charAt(U++),ht=w[J in fn?A.charAt(U++):J],!ht||(d=ht(v,T,d))<0)return-1}else if(J!=T.charCodeAt(d++))return-1}return d}function Q(v,A,T){var d=u.exec(A.slice(T));return d?(v.p=f.get(d[0].toLowerCase()),T+d[0].length):-1}function R(v,A,T){var d=m.exec(A.slice(T));return d?(v.w=g.get(d[0].toLowerCase()),T+d[0].length):-1}function y(v,A,T){var d=c.exec(A.slice(T));return d?(v.w=p.get(d[0].toLowerCase()),T+d[0].length):-1}function E(v,A,T){var d=x.exec(A.slice(T));return d?(v.m=M.get(d[0].toLowerCase()),T+d[0].length):-1}function D(v,A,T){var d=h.exec(A.slice(T));return d?(v.m=b.get(d[0].toLowerCase()),T+d[0].length):-1}function P(v,A,T){return q(v,e,A,T)}function tt(v,A,T){return q(v,r,A,T)}function K(v,A,T){return q(v,n,A,T)}function W(v){return i[v.getDay()]}function _(v){return a[v.getDay()]}function O(v){return s[v.getMonth()]}function Za(v){return l[v.getMonth()]}function Ja(v){return o[+(v.getHours()>=12)]}function Ka(v){return 1+~~(v.getMonth()/3)}function ja(v){return i[v.getUTCDay()]}function ti(v){return a[v.getUTCDay()]}function ei(v){return s[v.getUTCMonth()]}function ri(v){return l[v.getUTCMonth()]}function ni(v){return o[+(v.getUTCHours()>=12)]}function oi(v){return 1+~~(v.getUTCMonth()/3)}return{format:function(v){var A=S(v+="",C);return A.toString=function(){return v},A},parse:function(v){var A=I(v+="",!1);return A.toString=function(){return v},A},utcFormat:function(v){var A=S(v+="",k);return A.toString=function(){return v},A},utcParse:function(v){var A=I(v+="",!0);return A.toString=function(){return v},A}}}var fn={"-":"",_:" ",0:"0"},B=/^\s*\d+/,Di=/^%/,Ti=/[\\^$*+?|[\]().{}]/g;function F(t,e,r){var n=t<0?"-":"",o=(n?-t:t)+"",a=o.length;return n+(a<r?new Array(r-a+1).join(e)+o:o)}function Fi(t){return t.replace(Ti,"\\$&")}function Pt(t){return new RegExp("^(?:"+t.map(Fi).join("|")+")","i")}function Vt(t){return new Map(t.map((e,r)=>[e.toLowerCase(),r]))}function Ei(t,e,r){var n=B.exec(e.slice(r,r+1));return n?(t.w=+n[0],r+n[0].length):-1}function Oi(t,e,r){var n=B.exec(e.slice(r,r+1));return n?(t.u=+n[0],r+n[0].length):-1}function Ni(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.U=+n[0],r+n[0].length):-1}function Yi(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.V=+n[0],r+n[0].length):-1}function Ri(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.W=+n[0],r+n[0].length):-1}function mn(t,e,r){var n=B.exec(e.slice(r,r+4));return n?(t.y=+n[0],r+n[0].length):-1}function pn(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.y=+n[0]+(+n[0]>68?1900:2e3),r+n[0].length):-1}function Ii(t,e,r){var n=/^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(r,r+6));return n?(t.Z=n[1]?0:-(n[2]+(n[3]||"00")),r+n[0].length):-1}function zi(t,e,r){var n=B.exec(e.slice(r,r+1));return n?(t.q=n[0]*3-3,r+n[0].length):-1}function qi(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.m=n[0]-1,r+n[0].length):-1}function dn(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.d=+n[0],r+n[0].length):-1}function Bi(t,e,r){var n=B.exec(e.slice(r,r+3));return n?(t.m=0,t.d=+n[0],r+n[0].length):-1}function hn(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.H=+n[0],r+n[0].length):-1}function Li(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.M=+n[0],r+n[0].length):-1}function $i(t,e,r){var n=B.exec(e.slice(r,r+2));return n?(t.S=+n[0],r+n[0].length):-1}function Hi(t,e,r){var n=B.exec(e.slice(r,r+3));return n?(t.L=+n[0],r+n[0].length):-1}function Pi(t,e,r){var n=B.exec(e.slice(r,r+6));return n?(t.L=Math.floor(n[0]/1e3),r+n[0].length):-1}function Vi(t,e,r){var n=Di.exec(e.slice(r,r+1));return n?r+n[0].length:-1}function Wi(t,e,r){var n=B.exec(e.slice(r));return n?(t.Q=+n[0],r+n[0].length):-1}function Ui(t,e,r){var n=B.exec(e.slice(r));return n?(t.s=+n[0],r+n[0].length):-1}function gn(t,e){return F(t.getDate(),e,2)}function Gi(t,e){return F(t.getHours(),e,2)}function Xi(t,e){return F(t.getHours()%12||12,e,2)}function Qi(t,e){return F(1+be.count(ct(t),t),e,3)}function Dn(t,e){return F(t.getMilliseconds(),e,3)}function Zi(t,e){return Dn(t,e)+"000"}function Ji(t,e){return F(t.getMonth()+1,e,2)}function Ki(t,e){return F(t.getMinutes(),e,2)}function ji(t,e){return F(t.getSeconds(),e,2)}function tl(t){var e=t.getDay();return e===0?7:e}function el(t,e){return F(pr.count(ct(t)-1,t),e,2)}function Tn(t){var e=t.getDay();return e>=4||e===0?Tt(t):Tt.ceil(t)}function rl(t,e){return t=Tn(t),F(Tt.count(ct(t),t)+(ct(t).getDay()===4),e,2)}function nl(t){return t.getDay()}function ol(t,e){return F(ye.count(ct(t)-1,t),e,2)}function al(t,e){return F(t.getFullYear()%100,e,2)}function il(t,e){return t=Tn(t),F(t.getFullYear()%100,e,2)}function ll(t,e){return F(t.getFullYear()%1e4,e,4)}function sl(t,e){var r=t.getDay();return t=r>=4||r===0?Tt(t):Tt.ceil(t),F(t.getFullYear()%1e4,e,4)}function ul(t){var e=t.getTimezoneOffset();return(e>0?"-":(e*=-1,"+"))+F(e/60|0,"0",2)+F(e%60,"0",2)}function yn(t,e){return F(t.getUTCDate(),e,2)}function cl(t,e){return F(t.getUTCHours(),e,2)}function fl(t,e){return F(t.getUTCHours()%12||12,e,2)}function ml(t,e){return F(1+mr.count(gt(t),t),e,3)}function Fn(t,e){return F(t.getUTCMilliseconds(),e,3)}function pl(t,e){return Fn(t,e)+"000"}function dl(t,e){return F(t.getUTCMonth()+1,e,2)}function hl(t,e){return F(t.getUTCMinutes(),e,2)}function gl(t,e){return F(t.getUTCSeconds(),e,2)}function yl(t){var e=t.getUTCDay();return e===0?7:e}function xl(t,e){return F(kn.count(gt(t)-1,t),e,2)}function En(t){var e=t.getUTCDay();return e>=4||e===0?Ft(t):Ft.ceil(t)}function bl(t,e){return t=En(t),F(Ft.count(gt(t),t)+(gt(t).getUTCDay()===4),e,2)}function vl(t){return t.getUTCDay()}function wl(t,e){return F(xe.count(gt(t)-1,t),e,2)}function _l(t,e){return F(t.getUTCFullYear()%100,e,2)}function Cl(t,e){return t=En(t),F(t.getUTCFullYear()%100,e,2)}function Sl(t,e){return F(t.getUTCFullYear()%1e4,e,4)}function Ml(t,e){var r=t.getUTCDay();return t=r>=4||r===0?Ft(t):Ft.ceil(t),F(t.getUTCFullYear()%1e4,e,4)}function kl(){return"+0000"}function xn(){return"%"}function bn(t){return+t}function vn(t){return Math.floor(+t/1e3)}var Dt,at;Al({dateTime:"%x, %X",date:"%-m/%-d/%Y",time:"%-I:%M:%S %p",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]});function Al(t){return Dt=ur(t),at=Dt.format,Dt.parse,Dt.utcFormat,Dt.utcParse,Dt}var cr=[[1,4,12,52,365,365*24,365*24*60,365*24*60*60,365*24*60*60*1e3],[1/4,1,3,13,91,91*24,91*24*60,91*24*60*60,91*24*60*60*1e3],[1/12,1/3,1,4,30,30*24,30*24*60,30*24*60*60,30*24*60*60*1e3],[1/52,1/13,1/4,1,7,7*24,7*24*60,7*24*60*60,7*24*60*60*1e3],[1/365,1/91,1/30,1/7,1,24,24*60,24*60*60,24*60*60*1e3],[1/(365*24),1/(91*24),1/(30*24),1/(7*24),1/24,1,60,60*60,60*60*1e3],[1/(365*24*60),1/(91*24*60),1/(30*24*60),1/(7*24*60),1/(24*60),1/60,1,60,60*1e3],[1/(365*24*60*60),1/(91*24*60*60),1/(30*24*60*60),1/(7*24*60*60),1/(24*60*60),1/(60*60),1/60,1,1e3],[1/(365*24*60*60*1e3),1/(91*24*60*60*1e3),1/(30*24*60*60*1e3),1/(7*24*60*60*1e3),1/(24*60*60*1e3),1/(60*60*1e3),1/(60*1e3),1/1e3,1]];function Dl(t,e,r){if(rt(t))return;if(!e||!r||e===r)return t;let n=cr[e-1][r-1];if(n)return t*n}function Tl(t,e,r,n){if(rt(t)||!e.lowestLevel||r.length===0)return"";let o=[],a=0,i=Math.round(t*cr[e.lowestLevel-1][8]),l=9;for(let[,u]of r.entries())if(t){i=i-a;let f=cr[u-1][l-1],c=Math.floor(i/f);a=c*f,o.push({level:u,value:c})}else o.push({level:u,value:0});let s="";for(let[u,f]of o.entries())if(e.duration.format==="time"){let c=f.value;[6,7,8].includes(f.level)&&f.value<10?c="0"+f.value.toString():f.level===9&&f.value<10?c="00"+f.value.toString():f.level===9&&f.value<100&&(c="0"+f.value.toString()),s+=(u===0?"":f.level===9?".":":")+c}else if(e.duration.format==="long"){let c=n.durationLongSuffix;s+=f.value+" "+c[f.level]+(u===o.length-1?"":" ")}else{let c=n.durationShortSuffix;s+=f.value+""+c[f.level]+(u===o.length-1?"":" ")}return s}var Fl={decimal:".",thousands:",",grouping:[3],currency:["$",""],dateTime:"%a %b %e %X %Y",date:"%m/%d/%Y",dateSeparator:"/",time:"%H:%M:%S",periods:["AM","PM"],days:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],shortDays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],months:["January","February","March","April","May","June","July","August","September","October","November","December"],shortMonths:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],levels:["All","Year","Quarter","Month","Week","Date","Hour","Minute","Second","Millisecond"],shortLevels:["All","Yr","Qtr","Mth","Wk","Date","Hr","Min","Sec","Msec"],durationLongSuffix:["","years","quarters","months","weeks","days","hours","minutes","seconds","milliseconds"],durationShortSuffix:["","y","q","mo","w","d","h","m","s","ms"],multi:[".%L",":%S","%I:%M","%I %p","%a %d","W%G","%b %d","%B","%Y"]},El="%d-%m-%Y",Ol=[{key:"%a %e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%a %e %b %Y",monthType:"name",longText:!1,weekday:!0},{key:"%e %b %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%b %Y",lev4:"Wk %V-%G",lev5:"%e %b %Y",monthType:"name",longText:!1,weekday:!1},{key:"%a %e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%a %e %B %Y",monthType:"name",longText:!0,weekday:!0},{key:"%e %B %Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%B %Y",lev4:"Week %V, %G",lev5:"%e %B %Y",monthType:"name",longText:!0,weekday:!1},{key:"%d/%m/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"W%V/%G",lev5:"%d/%m/%Y",monthType:"number",mmdd:!1,separator:"/"},{key:"%d-%m-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"W%V-%G",lev5:"%d-%m-%Y",monthType:"number",mmdd:!1,separator:"-"},{key:"%d.%m.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"W%V.%G",lev5:"%d.%m.%Y",monthType:"number",mmdd:!1,separator:"."},{key:"%d~%m~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"W%V~%G",lev5:"%d~%m~%Y",monthType:"number",mmdd:!1,separator:"~"},{key:"%m/%d/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%m/%d/%Y",monthType:"number",mmdd:!0,separator:"/"},{key:"%m-%d-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%m-%d-%Y",monthType:"number",mmdd:!0,separator:"-"},{key:"%m.%d.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%m.%d.%Y",monthType:"number",mmdd:!0,separator:"."},{key:"%m~%d~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%m~%d~%Y",monthType:"number",mmdd:!0,separator:"~"},{key:"%amd/%Y",lev1:"%Y",lev2:"Q%q/%Y",lev3:"%m/%Y",lev4:"%G/W%V",lev5:"%amd/%Y",monthType:"number",mmdd:null,separator:"/"},{key:"%amd-%Y",lev1:"%Y",lev2:"Q%q-%Y",lev3:"%m-%Y",lev4:"%G-W%V",lev5:"%amd-%Y",monthType:"number",mmdd:null,separator:"-"},{key:"%amd.%Y",lev1:"%Y",lev2:"Q%q.%Y",lev3:"%m.%Y",lev4:"%G.W%V",lev5:"%amd.%Y",monthType:"number",mmdd:null,separator:"."},{key:"%amd~%Y",lev1:"%Y",lev2:"Q%q~%Y",lev3:"%m~%Y",lev4:"%G~W%V",lev5:"%amd~%Y",monthType:"number",mmdd:null,separator:"~"}],Nl=[{key:"%H:%M:%S.%L",lev6:"%H:00",lev7:"%H:%M",lev8:"%H:%M:%S",lev9:"%H:%M:%S.%L",ampm:!1},{key:"%I:%M:%S.%L %p",lev6:"%I:00 %p",lev7:"%I:%M %p",lev8:"%I:%M:%S %p",lev9:"%I:%M:%S.%L %p",ampm:!0}];function ve(t,e){var r,n;e=e||{};let o=e.localFormats||Fl,a,i,l,s=[],u=[],f="datetime",c;e&&e.multi&&(f="datetime"),(!t||!t.format)&&(f="hierarchy"),t&&t.type&&(f=t.type),t&&t.format?c=t.format:f==="numeric"?c=",.0f":f==="datetime"?c=El:c="";let p=er(c);switch(p.precision&&p.typeFormat&&(f="numeric"),f){case"numeric":{if(t.subtype==="duration"&&t.duration&&t.duration.levels&&t.duration.levels.length>1&&!e.hideDuration)a=m=>rt(m)?"":Tl(m,t,t.duration.levels,o);else{let m={...o},g=p.typeFormat,h=!1;switch(g.length===2&&g.startsWith("a")&&(h=!0,g=g.slice(1,2),c=c.replace(/a/,"")),h?(m.decimal=o.decimal,m.thousands=o.thousands):["z","y","w"].includes(g)?(m.decimal=",",m.thousands="."):(m.decimal=".",m.thousands=","),g){case"z":{c=c.replace("z","f");break}case"y":{c=c.replace("y","%");break}case"w":{c=c.replace("w","s");break}}if(t?.subtype==="currency"&&t.currency){let x="\xA0",M=m.currency.findIndex(S=>S.length>0),C=m.currency[M].startsWith(x),k=m.currency[M].endsWith(x),w=`${C?x:""}${t.currency}${k?x:""}`;m.currency[M]=w}let b=hi(m);g!=="%"&&t?.subtype==="currency"&&t.currency&&m.currency&&!(e!=null&&e.hideCurrency)&&!["count","distinctcount"].includes(t.aggregationFunc)&&!(t.aggregationFunc==="rate"&&((r=t.aggregationWeight)==null?void 0:r.columnSubType)==="currency")&&((n=t.periodOverPeriod)==null?void 0:n.type)!=="percentageChange"&&(c="$"+c),e!=null&&e.trimZero&&["y","%"].includes(g)&&m.decimal===","?i=x=>b.format(c)(x).replace(/(,\d*?)0+%$/,"$1%").replace(/,%$/,"%"):e!=null&&e.trimZero&&["y","%"].includes(g)&&m.decimal==="."?i=x=>b.format(c)(x).replace(/(\.\d*?)0+%$/,"$1%").replace(/\.%$/,"%"):e!=null&&e.trimZero&&["z","f"].includes(g)&&m.decimal===","?i=x=>b.format(c)(x).replace(/(,\d*?)0+$/,"$1").replace(/,$/,""):e!=null&&e.trimZero&&["z","f"].includes(g)&&m.decimal==="."?i=x=>b.format(c)(x).replace(/(\.\d*?)0+$/,"$1").replace(/\.$/,""):t?.subtype==="currency"&&t.currency&&m.currency&&g==="s"?i=x=>b.format(c)(x).replace(/G/,"B"):i=rt(p.precision)?b.format(",.0f"):b.format(c),a=x=>{var M;if(rt(x))return"";if(t.subtype==="duration"&&t.duration&&!e.hideDuration){let C=t.duration.levels?t.duration.levels[0]:t.lowestLevel;return C!==t.lowestLevel&&(x=Dl(x,t.lowestLevel,C)),i(x)+((M=o?.durationShortSuffix)==null?void 0:M[C])}return i(x)}}break}case"datetime":{if(s=o?.smartDateFormats??Ol,u=o?.smartTimeFormats??Nl,rt(t.datetimeDisplayMode)){if(e!=null&&e.level){let m=e.level,g=s.find(k=>c.includes(k.key)),h=u.find(k=>c.includes(k.key)),b=g?g["lev"+Math.min(m,5)]:s[0]["lev"+Math.min(m,5)],x=m>5?h?h["lev"+m]:u[0]["lev"+m]:"";c=m>5?b+", "+x:b;let M=c.includes("%amd")&&e.level>=5,C=g?e.level>=2&&g.separator==="~":!1;M?c=C?c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8)):c.replaceAll(new RegExp(/%amd[.~\/-]%Y/g),o.date.slice(0,8).replaceAll(new RegExp(/[.~\/-]/g),g.separator)):c=C?c.replaceAll(new RegExp(/[~]/g),o.dateSeparator):c}if(e!=null&&e.multi){let m=at(o.multi[0]),g=at(o.multi[1]),h=at(o.multi[2]),b=at(o.multi[3]),x=at(o.multi[4]),M=at(o.multi[6]),C=at(o.multi[7]),k=at(o.multi[8]);l=w=>{let S;return Cn(w)<w?S=m:Sn(w)<w?S=g:Mn(w)<w?S=h:be(w)<w?S=b:An(w)<w?S=pr(w)<w?x:M:ct(w)<w?S=C:S=k,S(w)}}else l=ur(o).format(c)}else{let m={quarter_number:{min:1,max:4},month_name:{min:1,max:12},month_number:{min:1,max:12},week_number:{min:1,max:53},day_in_month:{min:1,max:31},day_in_year:{min:1,max:366},weekday_name:{min:0,max:7},weekday_number:{min:0,max:7},hour_in_day:{min:0,max:23},minute_in_hour:{min:0,max:59},second_in_minute:{min:0,max:59}},g=(h,b,x)=>{var M,C,k,w,S;return b==="letter"?((M=h.shortNames)==null?void 0:M.length)>0&&((C=h.shortNames[x])==null?void 0:C.length)>0?(k=h.shortNames[x])==null?void 0:k.charAt(0):"N/A":b==="short"?((w=h.shortNames)==null?void 0:w.length)>0&&h.shortNames[x]?h.shortNames[x]:"N/A":((S=h.longNames)==null?void 0:S.length)>0&&h.longNames[x]?h.longNames[x]:"N/A"};["quarter_number","month_number","week_number","day_in_month","day_in_year","weekday_number","hour_in_day","minute_in_hour","second_in_minute"].includes(t.datetimeDisplayMode)?l=h=>$t(h)&&h>=m[t.datetimeDisplayMode].min&&h<=m[t.datetimeDisplayMode].max?h:"N/A":t.datetimeDisplayMode==="month_name"?l=h=>{let b=[...o.shortMonths],x=[...o.months];return $t(h)&&h>=m[t.datetimeDisplayMode].min&&h<=m[t.datetimeDisplayMode].max?g({shortNames:b,longNames:x},t.monthNameFormat,h-1):"N/A"}:t.datetimeDisplayMode==="weekday_name"?l=h=>{let b=[...o.shortDays],x=[...o.days];return t.weekStart==="monday"&&(b.push(b.shift()??""),x.push(x.shift()??"")),$t(h)&&h>=m[t.datetimeDisplayMode].min&&h<=m[t.datetimeDisplayMode].max?g({shortNames:b,longNames:x},t.weekDayNameFormat,h-1):"N/A"}:l=ur(o).format(c)}a=m=>{if(rt(m))return"";let g=l(m);return rr(g)?g.trim():g};break}case"hierarchy":{a=m=>nr(m,e?e.locale:void 0);break}default:{a=m=>m;break}}return a}var j={type:"platform",background:"rgb(245,245,245)",itemsBackground:"rgb(255,255,255)",boxShadow:{size:"none",color:"rgb(0, 0, 0)"},title:{align:"left",bold:!1,italic:!1,underline:!1,border:!1},font:{fontFamily:"Lato","font-style":"normal","font-weight":400,fontSize:15},colors:["rgb(68,52,255)","rgb(143,133,255)","rgb(218,214,255)","rgb(191,5,184)","rgb(217,105,212)","rgb(242,205,241)","rgb(248,194,12)","rgb(251,218,109)","rgb(254,243,206)","rgb(9,203,120)","rgb(107,224,174)","rgb(206,245,228)","rgb(122,112,112)","rgb(175,169,169)","rgb(228,226,226)"],borders:{"border-color":"rgba(216,216,216,1)","border-style":"none","border-radius":"12px","border-top-width":"0px","border-left-width":"0px","border-right-width":"0px","border-bottom-width":"0px"},margins:[16,16],mainColor:"rgb(68,52,255)",axis:{},legend:{type:"circle"},tooltip:{background:"rgb(38,38,38)"},itemSpecific:{rounding:8,padding:4}},Et=(t,e)=>({"border-color":t,"border-style":"none","border-radius":e,"border-top-width":"1px","border-left-width":"1px","border-right-width":"1px","border-bottom-width":"1px"}),op={default:{...j,name:"Default (light)"},default_dark:{...j,name:"Default (dark)",background:"rgb(61,61,61)",itemsBackground:"rgb(38,38,38)",colors:["rgb(48,36,179)","rgb(105,93,255)","rgb(199,194,255)","rgb(134,4,129)","rgb(204,55,198)","rgb(236,180,234)","rgb(220,141,0)","rgb(249,206,61)","rgb(253,237,182)","rgb(6,142,84)","rgb(58,213,147)","rgb(181,239,215)","rgb(85,78,78)","rgb(149,141,141)","rgb(215,212,212)"],mainColor:"rgb(123,144,255)",tooltip:{background:"rgb(248,248,248)"}},vivid:{...j,name:"Vivid",background:"#eef3f6",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[12,12],mainColor:"#5867C3",legend:{type:"normal"},tooltip:{},colors:["#5867C3","#00C5DC","#FF525E","#FFAA00","#FFDB03","#86de40","#59b339","#cc27bc","#ff4aed","#bfbfbf","#737373"],font:{fontFamily:"Open Sans",fontSize:13}},seasonal:{...j,name:"Seasonal",background:"#ffffff",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:Et("rgba(0,0,0,.1)","8px"),margins:[10,10],mainColor:"#009788",tooltip:{},colors:["#009788","#60cc64","#CDDC39","#FFEB3C","#FEC107","#FF9700","#FE5722","#EA1E63","#9C28B1","#673BB7","#3F51B5","#2196F3","#03A9F5","#00BCD5"],font:{fontFamily:"Open Sans",fontSize:13}},orion:{...j,name:"Orion's Belt",background:"#00062d",itemsBackground:"#00062d",boxShadow:{size:"L",color:"#64046f"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:Et("rgba(0, 0, 0, .1)","8px"),mainColor:"#d62750",legend:{type:"normal"},colors:["#880065","#b3005e","#d62750","#ef513e","#fd7b27","#ffa600","#fdae6b"],font:{fontFamily:"Electrolize",fontSize:15}},royale:{...j,name:"Royale",background:"#0A2747",itemsBackground:"#111e2f",boxShadow:{size:"S",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{"border-radius":"3px"},margins:[10,10],mainColor:"#f4a92c",legend:{type:"circle"},tooltip:{},colors:["#feeaa1","#e6cc85","#ceaf6a","#b79350","#9f7738","#885d20","#704308"],font:{fontFamily:"Exo",fontSize:13}},urban:{...j,name:"Urban",background:"#42403c",itemsBackground:"#e4dbcd",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},margins:[5,5],mainColor:"#33b59e",legend:{type:"circle"},colors:["#33b59e","#453d30","#ffffff","#237869","#165e4e","#b89f76","#7a6138","#543c13","#8a9c98","#44524f"],font:{fontFamily:"Open Sans",fontSize:13}},pinky:{...j,name:"Pinky Brains",background:"#0F1E43",itemsBackground:"#1B2A4D",title:{align:"center",bold:!0,italic:!1,underline:!1,border:!0},borders:Et("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#e84281",legend:{type:"normal"},tooltip:{},colors:["#e84281","#d464c2","#a089f2","#46a8ff","#00c0ff","#00d0e8","#49dcc9"],font:{fontFamily:"Capriola",fontSize:15}},bliss:{...j,name:"Bliss",background:"#ffffff",itemsBackground:"#ffffff",boxShadow:{size:"none",color:"rgb(0,0,0)"},title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#eeeeee",borders:Et("rgba(0, 0, 0, .1)","8px"),margins:[10,10],mainColor:"#0578ff",axis:{},legend:{type:"normal"},tooltip:{},colors:["#b8d8ff","#3ba0ff","#0044f2","#1b00ca","#9114de","#ce42ff","#ff19f6","#ed2bab","#d8175c","#ff303d","#ff6130","#ff9f30","#15BF49","#95E88C"],font:{fontFamily:"Open Sans",fontSize:13}},radiant:{...j,name:"Radiant",background:"rgba(43,43,56,1)",itemsBackground:"rgba(52,52,69,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:Et("rgba(255, 255, 255, .08)","8px"),margins:[14,14],mainColor:"#00a4eb",legend:{type:"line"},tooltip:{},colors:["#a6e1ff","#00a4eb","#3f3af0","#9300c7","#f72f5f","#f29b50","#f2d566","#3ae086","#c9c9c9","#7a7a7a"],font:{fontFamily:"Open Sans",fontSize:13}},classic:{...j,name:"Classic (light)",background:"#F2F2F2",itemsBackground:"#ffffff",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},editModeBackground:"#ececec",borders:Et("rgba(0, 0, 0, .1)","3px"),margins:[10,10],mainColor:"#009dff",legend:{type:"normal"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}},classic_dark:{...j,name:"Classic (dark)",background:"rgb(38,39,50)",itemsBackground:"rgba(52,53,68,1)",title:{align:"center",bold:!1,italic:!1,underline:!1,border:!0},borders:{},margins:[10,10],mainColor:"#0E89E0",legend:{type:"line"},tooltip:{},colors:["#0E89E0","#52B6F0","#8FD0F1","#BDDCF9","#F45000","#FF8E3B","#FFB069","#FFCFA1","#15BF49","#60D863","#95E88C","#C1F3B7","#685AC2","#958FD3","#B4B6E4","#D7D7EF","#636363","#969696","#BDBDBD","#D9D9D9"],font:{fontFamily:"Open Sans",fontSize:13}}};function bt(t,e){return t==null||e==null?NaN:t<e?-1:t>e?1:t>=e?0:NaN}function dr(t,e){return t==null||e==null?NaN:e<t?-1:e>t?1:e>=t?0:NaN}function we(t){let e,r,n;t.length!==2?(e=bt,r=(l,s)=>bt(t(l),s),n=(l,s)=>t(l)-s):(e=t===bt||t===dr?t:Yl,r=t,n=t);function o(l,s,u=0,f=l.length){if(u<f){if(e(s,s)!==0)return f;do{let c=u+f>>>1;r(l[c],s)<0?u=c+1:f=c}while(u<f)}return u}function a(l,s,u=0,f=l.length){if(u<f){if(e(s,s)!==0)return f;do{let c=u+f>>>1;r(l[c],s)<=0?u=c+1:f=c}while(u<f)}return u}function i(l,s,u=0,f=l.length){let c=o(l,s,u,f-1);return c>u&&n(l[c-1],s)>-n(l[c],s)?c-1:c}return{left:o,center:i,right:a}}function Yl(){return 0}function hr(t){return t===null?NaN:+t}var On=we(bt),Nn=On.right,Rl=On.left,Il=we(hr).center,gr=Nn;var Ot=class extends Map{constructor(e,r=Bl){if(super(),Object.defineProperties(this,{_intern:{value:new Map},_key:{value:r}}),e!=null)for(let[n,o]of e)this.set(n,o)}get(e){return super.get(Yn(this,e))}has(e){return super.has(Yn(this,e))}set(e,r){return super.set(zl(this,e),r)}delete(e){return super.delete(ql(this,e))}};function Yn({_intern:t,_key:e},r){let n=e(r);return t.has(n)?t.get(n):r}function zl({_intern:t,_key:e},r){let n=e(r);return t.has(n)?t.get(n):(t.set(n,r),r)}function ql({_intern:t,_key:e},r){let n=e(r);return t.has(n)&&(r=t.get(n),t.delete(n)),r}function Bl(t){return t!==null&&typeof t=="object"?t.valueOf():t}var Ll=Math.sqrt(50),$l=Math.sqrt(10),Hl=Math.sqrt(2);function _e(t,e,r){let n=(e-t)/Math.max(0,r),o=Math.floor(Math.log10(n)),a=n/Math.pow(10,o),i=a>=Ll?10:a>=$l?5:a>=Hl?2:1,l,s,u;return o<0?(u=Math.pow(10,-o)/i,l=Math.round(t*u),s=Math.round(e*u),l/u<t&&++l,s/u>e&&--s,u=-u):(u=Math.pow(10,o)*i,l=Math.round(t/u),s=Math.round(e/u),l*u<t&&++l,s*u>e&&--s),s<l&&.5<=r&&r<2?_e(t,e,r*2):[l,s,u]}function Ce(t,e,r){if(e=+e,t=+t,r=+r,!(r>0))return[];if(t===e)return[t];let n=e<t,[o,a,i]=n?_e(e,t,r):_e(t,e,r);if(!(a>=o))return[];let l=a-o+1,s=new Array(l);if(n)if(i<0)for(let u=0;u<l;++u)s[u]=(a-u)/-i;else for(let u=0;u<l;++u)s[u]=(a-u)*i;else if(i<0)for(let u=0;u<l;++u)s[u]=(o+u)/-i;else for(let u=0;u<l;++u)s[u]=(o+u)*i;return s}function Xt(t,e,r){return e=+e,t=+t,r=+r,_e(t,e,r)[2]}function yr(t,e,r){e=+e,t=+t,r=+r;let n=e<t,o=n?Xt(e,t,r):Xt(t,e,r);return(n?-1:1)*(o<0?1/-o:o)}function Se(t,e,r){t=+t,e=+e,r=(o=arguments.length)<2?(e=t,t=0,1):o<3?1:+r;for(var n=-1,o=Math.max(0,Math.ceil((e-t)/r))|0,a=new Array(o);++n<o;)a[n]=t+n*r;return a}function Rn(t){return t}var xr=1,br=2,vr=3,Qt=4,In=1e-6;function Pl(t){return"translate("+t+",0)"}function Vl(t){return"translate(0,"+t+")"}function Wl(t){return e=>+t(e)}function Ul(t,e){return e=Math.max(0,t.bandwidth()-e*2)/2,t.round()&&(e=Math.round(e)),r=>+t(r)+e}function Gl(){return!this.__axis}function zn(t,e){var r=[],n=null,o=null,a=6,i=6,l=3,s=typeof window<"u"&&window.devicePixelRatio>1?0:.5,u=t===xr||t===Qt?-1:1,f=t===Qt||t===br?"x":"y",c=t===xr||t===vr?Pl:Vl;function p(m){var g=n??(e.ticks?e.ticks.apply(e,r):e.domain()),h=o??(e.tickFormat?e.tickFormat.apply(e,r):Rn),b=Math.max(a,0)+l,x=e.range(),M=+x[0]+s,C=+x[x.length-1]+s,k=(e.bandwidth?Ul:Wl)(e.copy(),s),w=m.selection?m.selection():m,S=w.selectAll(".domain").data([null]),I=w.selectAll(".tick").data(g,e).order(),q=I.exit(),Q=I.enter().append("g").attr("class","tick"),R=I.select("line"),y=I.select("text");S=S.merge(S.enter().insert("path",".tick").attr("class","domain").attr("stroke","currentColor")),I=I.merge(Q),R=R.merge(Q.append("line").attr("stroke","currentColor").attr(f+"2",u*a)),y=y.merge(Q.append("text").attr("fill","currentColor").attr(f,u*b).attr("dy",t===xr?"0em":t===vr?"0.71em":"0.32em")),m!==w&&(S=S.transition(m),I=I.transition(m),R=R.transition(m),y=y.transition(m),q=q.transition(m).attr("opacity",In).attr("transform",function(E){return isFinite(E=k(E))?c(E+s):this.getAttribute("transform")}),Q.attr("opacity",In).attr("transform",function(E){var D=this.parentNode.__axis;return c((D&&isFinite(D=D(E))?D:k(E))+s)})),q.remove(),S.attr("d",t===Qt||t===br?i?"M"+u*i+","+M+"H"+s+"V"+C+"H"+u*i:"M"+s+","+M+"V"+C:i?"M"+M+","+u*i+"V"+s+"H"+C+"V"+u*i:"M"+M+","+s+"H"+C),I.attr("opacity",1).attr("transform",function(E){return c(k(E)+s)}),R.attr(f+"2",u*a),y.attr(f,u*b).text(h),w.filter(Gl).attr("fill","none").attr("font-size",10).attr("font-family","sans-serif").attr("text-anchor",t===br?"start":t===Qt?"end":"middle"),w.each(function(){this.__axis=k})}return p.scale=function(m){return arguments.length?(e=m,p):e},p.ticks=function(){return r=Array.from(arguments),p},p.tickArguments=function(m){return arguments.length?(r=m==null?[]:Array.from(m),p):r.slice()},p.tickValues=function(m){return arguments.length?(n=m==null?null:Array.from(m),p):n&&n.slice()},p.tickFormat=function(m){return arguments.length?(o=m,p):o},p.tickSize=function(m){return arguments.length?(a=i=+m,p):a},p.tickSizeInner=function(m){return arguments.length?(a=+m,p):a},p.tickSizeOuter=function(m){return arguments.length?(i=+m,p):i},p.tickPadding=function(m){return arguments.length?(l=+m,p):l},p.offset=function(m){return arguments.length?(s=+m,p):s},p}function wr(t){return zn(vr,t)}function _r(t){return zn(Qt,t)}var Xl={value:()=>{}};function Bn(){for(var t=0,e=arguments.length,r={},n;t<e;++t){if(!(n=arguments[t]+"")||n in r||/[\s.]/.test(n))throw new Error("illegal type: "+n);r[n]=[]}return new Me(r)}function Me(t){this._=t}function Ql(t,e){return t.trim().split(/^|\s+/).map(function(r){var n="",o=r.indexOf(".");if(o>=0&&(n=r.slice(o+1),r=r.slice(0,o)),r&&!e.hasOwnProperty(r))throw new Error("unknown type: "+r);return{type:r,name:n}})}Me.prototype=Bn.prototype={constructor:Me,on:function(t,e){var r=this._,n=Ql(t+"",r),o,a=-1,i=n.length;if(arguments.length<2){for(;++a<i;)if((o=(t=n[a]).type)&&(o=Zl(r[o],t.name)))return o;return}if(e!=null&&typeof e!="function")throw new Error("invalid callback: "+e);for(;++a<i;)if(o=(t=n[a]).type)r[o]=qn(r[o],t.name,e);else if(e==null)for(o in r)r[o]=qn(r[o],t.name,null);return this},copy:function(){var t={},e=this._;for(var r in e)t[r]=e[r].slice();return new Me(t)},call:function(t,e){if((o=arguments.length-2)>0)for(var r=new Array(o),n=0,o,a;n<o;++n)r[n]=arguments[n+2];if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(a=this._[t],n=0,o=a.length;n<o;++n)a[n].value.apply(e,r)},apply:function(t,e,r){if(!this._.hasOwnProperty(t))throw new Error("unknown type: "+t);for(var n=this._[t],o=0,a=n.length;o<a;++o)n[o].value.apply(e,r)}};function Zl(t,e){for(var r=0,n=t.length,o;r<n;++r)if((o=t[r]).name===e)return o.value}function qn(t,e,r){for(var n=0,o=t.length;n<o;++n)if(t[n].name===e){t[n]=Xl,t=t.slice(0,n).concat(t.slice(n+1));break}return r!=null&&t.push({name:e,value:r}),t}var Cr=Bn;var ke="http://www.w3.org/1999/xhtml",Sr={svg:"http://www.w3.org/2000/svg",xhtml:ke,xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace",xmlns:"http://www.w3.org/2000/xmlns/"};function it(t){var e=t+="",r=e.indexOf(":");return r>=0&&(e=t.slice(0,r))!=="xmlns"&&(t=t.slice(r+1)),Sr.hasOwnProperty(e)?{space:Sr[e],local:t}:t}function Jl(t){return function(){var e=this.ownerDocument,r=this.namespaceURI;return r===ke&&e.documentElement.namespaceURI===ke?e.createElement(t):e.createElementNS(r,t)}}function Kl(t){return function(){return this.ownerDocument.createElementNS(t.space,t.local)}}function Ae(t){var e=it(t);return(e.local?Kl:Jl)(e)}function jl(){}function vt(t){return t==null?jl:function(){return this.querySelector(t)}}function Ln(t){typeof t!="function"&&(t=vt(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var a=e[o],i=a.length,l=n[o]=new Array(i),s,u,f=0;f<i;++f)(s=a[f])&&(u=t.call(s,s.__data__,f,a))&&("__data__"in s&&(u.__data__=s.__data__),l[f]=u);return new Y(n,this._parents)}function Mr(t){return t==null?[]:Array.isArray(t)?t:Array.from(t)}function ts(){return[]}function Zt(t){return t==null?ts:function(){return this.querySelectorAll(t)}}function es(t){return function(){return Mr(t.apply(this,arguments))}}function $n(t){typeof t=="function"?t=es(t):t=Zt(t);for(var e=this._groups,r=e.length,n=[],o=[],a=0;a<r;++a)for(var i=e[a],l=i.length,s,u=0;u<l;++u)(s=i[u])&&(n.push(t.call(s,s.__data__,u,i)),o.push(s));return new Y(n,o)}function Jt(t){return function(){return this.matches(t)}}function De(t){return function(e){return e.matches(t)}}var rs=Array.prototype.find;function ns(t){return function(){return rs.call(this.children,t)}}function os(){return this.firstElementChild}function Hn(t){return this.select(t==null?os:ns(typeof t=="function"?t:De(t)))}var as=Array.prototype.filter;function is(){return Array.from(this.children)}function ls(t){return function(){return as.call(this.children,t)}}function Pn(t){return this.selectAll(t==null?is:ls(typeof t=="function"?t:De(t)))}function Vn(t){typeof t!="function"&&(t=Jt(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var a=e[o],i=a.length,l=n[o]=[],s,u=0;u<i;++u)(s=a[u])&&t.call(s,s.__data__,u,a)&&l.push(s);return new Y(n,this._parents)}function Te(t){return new Array(t.length)}function Wn(){return new Y(this._enter||this._groups.map(Te),this._parents)}function Kt(t,e){this.ownerDocument=t.ownerDocument,this.namespaceURI=t.namespaceURI,this._next=null,this._parent=t,this.__data__=e}Kt.prototype={constructor:Kt,appendChild:function(t){return this._parent.insertBefore(t,this._next)},insertBefore:function(t,e){return this._parent.insertBefore(t,e)},querySelector:function(t){return this._parent.querySelector(t)},querySelectorAll:function(t){return this._parent.querySelectorAll(t)}};function Un(t){return function(){return t}}function ss(t,e,r,n,o,a){for(var i=0,l,s=e.length,u=a.length;i<u;++i)(l=e[i])?(l.__data__=a[i],n[i]=l):r[i]=new Kt(t,a[i]);for(;i<s;++i)(l=e[i])&&(o[i]=l)}function us(t,e,r,n,o,a,i){var l,s,u=new Map,f=e.length,c=a.length,p=new Array(f),m;for(l=0;l<f;++l)(s=e[l])&&(p[l]=m=i.call(s,s.__data__,l,e)+"",u.has(m)?o[l]=s:u.set(m,s));for(l=0;l<c;++l)m=i.call(t,a[l],l,a)+"",(s=u.get(m))?(n[l]=s,s.__data__=a[l],u.delete(m)):r[l]=new Kt(t,a[l]);for(l=0;l<f;++l)(s=e[l])&&u.get(p[l])===s&&(o[l]=s)}function cs(t){return t.__data__}function Gn(t,e){if(!arguments.length)return Array.from(this,cs);var r=e?us:ss,n=this._parents,o=this._groups;typeof t!="function"&&(t=Un(t));for(var a=o.length,i=new Array(a),l=new Array(a),s=new Array(a),u=0;u<a;++u){var f=n[u],c=o[u],p=c.length,m=fs(t.call(f,f&&f.__data__,u,n)),g=m.length,h=l[u]=new Array(g),b=i[u]=new Array(g),x=s[u]=new Array(p);r(f,c,h,b,x,m,e);for(var M=0,C=0,k,w;M<g;++M)if(k=h[M]){for(M>=C&&(C=M+1);!(w=b[C])&&++C<g;);k._next=w||null}}return i=new Y(i,n),i._enter=l,i._exit=s,i}function fs(t){return typeof t=="object"&&"length"in t?t:Array.from(t)}function Xn(){return new Y(this._exit||this._groups.map(Te),this._parents)}function Qn(t,e,r){var n=this.enter(),o=this,a=this.exit();return typeof t=="function"?(n=t(n),n&&(n=n.selection())):n=n.append(t+""),e!=null&&(o=e(o),o&&(o=o.selection())),r==null?a.remove():r(a),n&&o?n.merge(o).order():o}function Zn(t){for(var e=t.selection?t.selection():t,r=this._groups,n=e._groups,o=r.length,a=n.length,i=Math.min(o,a),l=new Array(o),s=0;s<i;++s)for(var u=r[s],f=n[s],c=u.length,p=l[s]=new Array(c),m,g=0;g<c;++g)(m=u[g]||f[g])&&(p[g]=m);for(;s<o;++s)l[s]=r[s];return new Y(l,this._parents)}function Jn(){for(var t=this._groups,e=-1,r=t.length;++e<r;)for(var n=t[e],o=n.length-1,a=n[o],i;--o>=0;)(i=n[o])&&(a&&i.compareDocumentPosition(a)^4&&a.parentNode.insertBefore(i,a),a=i);return this}function Kn(t){t||(t=ms);function e(c,p){return c&&p?t(c.__data__,p.__data__):!c-!p}for(var r=this._groups,n=r.length,o=new Array(n),a=0;a<n;++a){for(var i=r[a],l=i.length,s=o[a]=new Array(l),u,f=0;f<l;++f)(u=i[f])&&(s[f]=u);s.sort(e)}return new Y(o,this._parents).order()}function ms(t,e){return t<e?-1:t>e?1:t>=e?0:NaN}function jn(){var t=arguments[0];return arguments[0]=this,t.apply(null,arguments),this}function to(){return Array.from(this)}function eo(){for(var t=this._groups,e=0,r=t.length;e<r;++e)for(var n=t[e],o=0,a=n.length;o<a;++o){var i=n[o];if(i)return i}return null}function ro(){let t=0;for(let e of this)++t;return t}function no(){return!this.node()}function oo(t){for(var e=this._groups,r=0,n=e.length;r<n;++r)for(var o=e[r],a=0,i=o.length,l;a<i;++a)(l=o[a])&&t.call(l,l.__data__,a,o);return this}function ps(t){return function(){this.removeAttribute(t)}}function ds(t){return function(){this.removeAttributeNS(t.space,t.local)}}function hs(t,e){return function(){this.setAttribute(t,e)}}function gs(t,e){return function(){this.setAttributeNS(t.space,t.local,e)}}function ys(t,e){return function(){var r=e.apply(this,arguments);r==null?this.removeAttribute(t):this.setAttribute(t,r)}}function xs(t,e){return function(){var r=e.apply(this,arguments);r==null?this.removeAttributeNS(t.space,t.local):this.setAttributeNS(t.space,t.local,r)}}function ao(t,e){var r=it(t);if(arguments.length<2){var n=this.node();return r.local?n.getAttributeNS(r.space,r.local):n.getAttribute(r)}return this.each((e==null?r.local?ds:ps:typeof e=="function"?r.local?xs:ys:r.local?gs:hs)(r,e))}function Fe(t){return t.ownerDocument&&t.ownerDocument.defaultView||t.document&&t||t.defaultView}function bs(t){return function(){this.style.removeProperty(t)}}function vs(t,e,r){return function(){this.style.setProperty(t,e,r)}}function ws(t,e,r){return function(){var n=e.apply(this,arguments);n==null?this.style.removeProperty(t):this.style.setProperty(t,n,r)}}function io(t,e,r){return arguments.length>1?this.each((e==null?bs:typeof e=="function"?ws:vs)(t,e,r??"")):ft(this.node(),t)}function ft(t,e){return t.style.getPropertyValue(e)||Fe(t).getComputedStyle(t,null).getPropertyValue(e)}function _s(t){return function(){delete this[t]}}function Cs(t,e){return function(){this[t]=e}}function Ss(t,e){return function(){var r=e.apply(this,arguments);r==null?delete this[t]:this[t]=r}}function lo(t,e){return arguments.length>1?this.each((e==null?_s:typeof e=="function"?Ss:Cs)(t,e)):this.node()[t]}function so(t){return t.trim().split(/^|\s+/)}function kr(t){return t.classList||new uo(t)}function uo(t){this._node=t,this._names=so(t.getAttribute("class")||"")}uo.prototype={add:function(t){var e=this._names.indexOf(t);e<0&&(this._names.push(t),this._node.setAttribute("class",this._names.join(" ")))},remove:function(t){var e=this._names.indexOf(t);e>=0&&(this._names.splice(e,1),this._node.setAttribute("class",this._names.join(" ")))},contains:function(t){return this._names.indexOf(t)>=0}};function co(t,e){for(var r=kr(t),n=-1,o=e.length;++n<o;)r.add(e[n])}function fo(t,e){for(var r=kr(t),n=-1,o=e.length;++n<o;)r.remove(e[n])}function Ms(t){return function(){co(this,t)}}function ks(t){return function(){fo(this,t)}}function As(t,e){return function(){(e.apply(this,arguments)?co:fo)(this,t)}}function mo(t,e){var r=so(t+"");if(arguments.length<2){for(var n=kr(this.node()),o=-1,a=r.length;++o<a;)if(!n.contains(r[o]))return!1;return!0}return this.each((typeof e=="function"?As:e?Ms:ks)(r,e))}function Ds(){this.textContent=""}function Ts(t){return function(){this.textContent=t}}function Fs(t){return function(){var e=t.apply(this,arguments);this.textContent=e??""}}function po(t){return arguments.length?this.each(t==null?Ds:(typeof t=="function"?Fs:Ts)(t)):this.node().textContent}function Es(){this.innerHTML=""}function Os(t){return function(){this.innerHTML=t}}function Ns(t){return function(){var e=t.apply(this,arguments);this.innerHTML=e??""}}function ho(t){return arguments.length?this.each(t==null?Es:(typeof t=="function"?Ns:Os)(t)):this.node().innerHTML}function Ys(){this.nextSibling&&this.parentNode.appendChild(this)}function go(){return this.each(Ys)}function Rs(){this.previousSibling&&this.parentNode.insertBefore(this,this.parentNode.firstChild)}function yo(){return this.each(Rs)}function xo(t){var e=typeof t=="function"?t:Ae(t);return this.select(function(){return this.appendChild(e.apply(this,arguments))})}function Is(){return null}function bo(t,e){var r=typeof t=="function"?t:Ae(t),n=e==null?Is:typeof e=="function"?e:vt(e);return this.select(function(){return this.insertBefore(r.apply(this,arguments),n.apply(this,arguments)||null)})}function zs(){var t=this.parentNode;t&&t.removeChild(this)}function vo(){return this.each(zs)}function qs(){var t=this.cloneNode(!1),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function Bs(){var t=this.cloneNode(!0),e=this.parentNode;return e?e.insertBefore(t,this.nextSibling):t}function wo(t){return this.select(t?Bs:qs)}function _o(t){return arguments.length?this.property("__data__",t):this.node().__data__}function Ls(t){return function(e){t.call(this,e,this.__data__)}}function $s(t){return t.trim().split(/^|\s+/).map(function(e){var r="",n=e.indexOf(".");return n>=0&&(r=e.slice(n+1),e=e.slice(0,n)),{type:e,name:r}})}function Hs(t){return function(){var e=this.__on;if(e){for(var r=0,n=-1,o=e.length,a;r<o;++r)a=e[r],(!t.type||a.type===t.type)&&a.name===t.name?this.removeEventListener(a.type,a.listener,a.options):e[++n]=a;++n?e.length=n:delete this.__on}}}function Ps(t,e,r){return function(){var n=this.__on,o,a=Ls(e);if(n){for(var i=0,l=n.length;i<l;++i)if((o=n[i]).type===t.type&&o.name===t.name){this.removeEventListener(o.type,o.listener,o.options),this.addEventListener(o.type,o.listener=a,o.options=r),o.value=e;return}}this.addEventListener(t.type,a,r),o={type:t.type,name:t.name,value:e,listener:a,options:r},n?n.push(o):this.__on=[o]}}function Co(t,e,r){var n=$s(t+""),o,a=n.length,i;if(arguments.length<2){var l=this.node().__on;if(l){for(var s=0,u=l.length,f;s<u;++s)for(o=0,f=l[s];o<a;++o)if((i=n[o]).type===f.type&&i.name===f.name)return f.value}return}for(l=e?Ps:Hs,o=0;o<a;++o)this.each(l(n[o],e,r));return this}function So(t,e,r){var n=Fe(t),o=n.CustomEvent;typeof o=="function"?o=new o(e,r):(o=n.document.createEvent("Event"),r?(o.initEvent(e,r.bubbles,r.cancelable),o.detail=r.detail):o.initEvent(e,!1,!1)),t.dispatchEvent(o)}function Vs(t,e){return function(){return So(this,t,e)}}function Ws(t,e){return function(){return So(this,t,e.apply(this,arguments))}}function Mo(t,e){return this.each((typeof e=="function"?Ws:Vs)(t,e))}function*ko(){for(var t=this._groups,e=0,r=t.length;e<r;++e)for(var n=t[e],o=0,a=n.length,i;o<a;++o)(i=n[o])&&(yield i)}var Ar=[null];function Y(t,e){this._groups=t,this._parents=e}function Ao(){return new Y([[document.documentElement]],Ar)}function Us(){return this}Y.prototype=Ao.prototype={constructor:Y,select:Ln,selectAll:$n,selectChild:Hn,selectChildren:Pn,filter:Vn,data:Gn,enter:Wn,exit:Xn,join:Qn,merge:Zn,selection:Us,order:Jn,sort:Kn,call:jn,nodes:to,node:eo,size:ro,empty:no,each:oo,attr:ao,style:io,property:lo,classed:mo,text:po,html:ho,raise:go,lower:yo,append:xo,insert:bo,remove:vo,clone:wo,datum:_o,on:Co,dispatch:Mo,[Symbol.iterator]:ko};var lt=Ao;function Nt(t){return typeof t=="string"?new Y([[document.querySelector(t)]],[document.documentElement]):new Y([[t]],Ar)}function Do(t){let e;for(;e=t.sourceEvent;)t=e;return t}function Dr(t,e){if(t=Do(t),e===void 0&&(e=t.currentTarget),e){var r=e.ownerSVGElement||e;if(r.createSVGPoint){var n=r.createSVGPoint();return n.x=t.clientX,n.y=t.clientY,n=n.matrixTransform(e.getScreenCTM().inverse()),[n.x,n.y]}if(e.getBoundingClientRect){var o=e.getBoundingClientRect();return[t.clientX-o.left-e.clientLeft,t.clientY-o.top-e.clientTop]}}return[t.pageX,t.pageY]}function Ee(t,e,r){t.prototype=e.prototype=r,r.constructor=t}function Tr(t,e){var r=Object.create(t.prototype);for(var n in e)r[n]=e[n];return r}function ee(){}var jt=.7,Ye=1/jt,Yt="\\s*([+-]?\\d+)\\s*",te="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*",nt="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*",Gs=/^#([0-9a-f]{3,8})$/,Xs=new RegExp(`^rgb\\(${Yt},${Yt},${Yt}\\)$`),Qs=new RegExp(`^rgb\\(${nt},${nt},${nt}\\)$`),Zs=new RegExp(`^rgba\\(${Yt},${Yt},${Yt},${te}\\)$`),Js=new RegExp(`^rgba\\(${nt},${nt},${nt},${te}\\)$`),Ks=new RegExp(`^hsl\\(${te},${nt},${nt}\\)$`),js=new RegExp(`^hsla\\(${te},${nt},${nt},${te}\\)$`),To={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074};Ee(ee,X,{copy(t){return Object.assign(new this.constructor,this,t)},displayable(){return this.rgb().displayable()},hex:Fo,formatHex:Fo,formatHex8:tu,formatHsl:eu,formatRgb:Eo,toString:Eo});function Fo(){return this.rgb().formatHex()}function tu(){return this.rgb().formatHex8()}function eu(){return zo(this).formatHsl()}function Eo(){return this.rgb().formatRgb()}function X(t){var e,r;return t=(t+"").trim().toLowerCase(),(e=Gs.exec(t))?(r=e[1].length,e=parseInt(e[1],16),r===6?Oo(e):r===3?new G(e>>8&15|e>>4&240,e>>4&15|e&240,(e&15)<<4|e&15,1):r===8?Oe(e>>24&255,e>>16&255,e>>8&255,(e&255)/255):r===4?Oe(e>>12&15|e>>8&240,e>>8&15|e>>4&240,e>>4&15|e&240,((e&15)<<4|e&15)/255):null):(e=Xs.exec(t))?new G(e[1],e[2],e[3],1):(e=Qs.exec(t))?new G(e[1]*255/100,e[2]*255/100,e[3]*255/100,1):(e=Zs.exec(t))?Oe(e[1],e[2],e[3],e[4]):(e=Js.exec(t))?Oe(e[1]*255/100,e[2]*255/100,e[3]*255/100,e[4]):(e=Ks.exec(t))?Ro(e[1],e[2]/100,e[3]/100,1):(e=js.exec(t))?Ro(e[1],e[2]/100,e[3]/100,e[4]):To.hasOwnProperty(t)?Oo(To[t]):t==="transparent"?new G(NaN,NaN,NaN,0):null}function Oo(t){return new G(t>>16&255,t>>8&255,t&255,1)}function Oe(t,e,r,n){return n<=0&&(t=e=r=NaN),new G(t,e,r,n)}function ru(t){return t instanceof ee||(t=X(t)),t?(t=t.rgb(),new G(t.r,t.g,t.b,t.opacity)):new G}function Rt(t,e,r,n){return arguments.length===1?ru(t):new G(t,e,r,n??1)}function G(t,e,r,n){this.r=+t,this.g=+e,this.b=+r,this.opacity=+n}Ee(G,Rt,Tr(ee,{brighter(t){return t=t==null?Ye:Math.pow(Ye,t),new G(this.r*t,this.g*t,this.b*t,this.opacity)},darker(t){return t=t==null?jt:Math.pow(jt,t),new G(this.r*t,this.g*t,this.b*t,this.opacity)},rgb(){return this},clamp(){return new G(_t(this.r),_t(this.g),_t(this.b),Re(this.opacity))},displayable(){return-.5<=this.r&&this.r<255.5&&-.5<=this.g&&this.g<255.5&&-.5<=this.b&&this.b<255.5&&0<=this.opacity&&this.opacity<=1},hex:No,formatHex:No,formatHex8:nu,formatRgb:Yo,toString:Yo}));function No(){return`#${wt(this.r)}${wt(this.g)}${wt(this.b)}`}function nu(){return`#${wt(this.r)}${wt(this.g)}${wt(this.b)}${wt((isNaN(this.opacity)?1:this.opacity)*255)}`}function Yo(){let t=Re(this.opacity);return`${t===1?"rgb(":"rgba("}${_t(this.r)}, ${_t(this.g)}, ${_t(this.b)}${t===1?")":`, ${t})`}`}function Re(t){return isNaN(t)?1:Math.max(0,Math.min(1,t))}function _t(t){return Math.max(0,Math.min(255,Math.round(t)||0))}function wt(t){return t=_t(t),(t<16?"0":"")+t.toString(16)}function Ro(t,e,r,n){return n<=0?t=e=r=NaN:r<=0||r>=1?t=e=NaN:e<=0&&(t=NaN),new et(t,e,r,n)}function zo(t){if(t instanceof et)return new et(t.h,t.s,t.l,t.opacity);if(t instanceof ee||(t=X(t)),!t)return new et;if(t instanceof et)return t;t=t.rgb();var e=t.r/255,r=t.g/255,n=t.b/255,o=Math.min(e,r,n),a=Math.max(e,r,n),i=NaN,l=a-o,s=(a+o)/2;return l?(e===a?i=(r-n)/l+(r<n)*6:r===a?i=(n-e)/l+2:i=(e-r)/l+4,l/=s<.5?a+o:2-a-o,i*=60):l=s>0&&s<1?0:i,new et(i,l,s,t.opacity)}function qo(t,e,r,n){return arguments.length===1?zo(t):new et(t,e,r,n??1)}function et(t,e,r,n){this.h=+t,this.s=+e,this.l=+r,this.opacity=+n}Ee(et,qo,Tr(ee,{brighter(t){return t=t==null?Ye:Math.pow(Ye,t),new et(this.h,this.s,this.l*t,this.opacity)},darker(t){return t=t==null?jt:Math.pow(jt,t),new et(this.h,this.s,this.l*t,this.opacity)},rgb(){var t=this.h%360+(this.h<0)*360,e=isNaN(t)||isNaN(this.s)?0:this.s,r=this.l,n=r+(r<.5?r:1-r)*e,o=2*r-n;return new G(Fr(t>=240?t-240:t+120,o,n),Fr(t,o,n),Fr(t<120?t+240:t-120,o,n),this.opacity)},clamp(){return new et(Io(this.h),Ne(this.s),Ne(this.l),Re(this.opacity))},displayable(){return(0<=this.s&&this.s<=1||isNaN(this.s))&&0<=this.l&&this.l<=1&&0<=this.opacity&&this.opacity<=1},formatHsl(){let t=Re(this.opacity);return`${t===1?"hsl(":"hsla("}${Io(this.h)}, ${Ne(this.s)*100}%, ${Ne(this.l)*100}%${t===1?")":`, ${t})`}`}}));function Io(t){return t=(t||0)%360,t<0?t+360:t}function Ne(t){return Math.max(0,Math.min(1,t||0))}function Fr(t,e,r){return(t<60?e+(r-e)*t/60:t<180?r:t<240?e+(r-e)*(240-t)/60:e)*255}function Er(t,e,r,n,o){var a=t*t,i=a*t;return((1-3*t+3*a-i)*e+(4-6*a+3*i)*r+(1+3*t+3*a-3*i)*n+i*o)/6}function Bo(t){var e=t.length-1;return function(r){var n=r<=0?r=0:r>=1?(r=1,e-1):Math.floor(r*e),o=t[n],a=t[n+1],i=n>0?t[n-1]:2*o-a,l=n<e-1?t[n+2]:2*a-o;return Er((r-n/e)*e,i,o,a,l)}}function Lo(t){var e=t.length;return function(r){var n=Math.floor(((r%=1)<0?++r:r)*e),o=t[(n+e-1)%e],a=t[n%e],i=t[(n+1)%e],l=t[(n+2)%e];return Er((r-n/e)*e,o,a,i,l)}}var re=t=>()=>t;function ou(t,e){return function(r){return t+r*e}}function au(t,e,r){return t=Math.pow(t,r),e=Math.pow(e,r)-t,r=1/r,function(n){return Math.pow(t+n*e,r)}}function $o(t){return(t=+t)==1?Ie:function(e,r){return r-e?au(e,r,t):re(isNaN(e)?r:e)}}function Ie(t,e){var r=e-t;return r?ou(t,r):re(isNaN(t)?e:t)}var Ct=function t(e){var r=$o(e);function n(o,a){var i=r((o=Rt(o)).r,(a=Rt(a)).r),l=r(o.g,a.g),s=r(o.b,a.b),u=Ie(o.opacity,a.opacity);return function(f){return o.r=i(f),o.g=l(f),o.b=s(f),o.opacity=u(f),o+""}}return n.gamma=t,n}(1);function Ho(t){return function(e){var r=e.length,n=new Array(r),o=new Array(r),a=new Array(r),i,l;for(i=0;i<r;++i)l=Rt(e[i]),n[i]=l.r||0,o[i]=l.g||0,a[i]=l.b||0;return n=t(n),o=t(o),a=t(a),l.opacity=1,function(s){return l.r=n(s),l.g=o(s),l.b=a(s),l+""}}}var iu=Ho(Bo),lu=Ho(Lo);function Po(t,e){e||(e=[]);var r=t?Math.min(e.length,t.length):0,n=e.slice(),o;return function(a){for(o=0;o<r;++o)n[o]=t[o]*(1-a)+e[o]*a;return n}}function Vo(t){return ArrayBuffer.isView(t)&&!(t instanceof DataView)}function Wo(t,e){var r=e?e.length:0,n=t?Math.min(r,t.length):0,o=new Array(n),a=new Array(r),i;for(i=0;i<n;++i)o[i]=St(t[i],e[i]);for(;i<r;++i)a[i]=e[i];return function(l){for(i=0;i<n;++i)a[i]=o[i](l);return a}}function Uo(t,e){var r=new Date;return t=+t,e=+e,function(n){return r.setTime(t*(1-n)+e*n),r}}function $(t,e){return t=+t,e=+e,function(r){return t*(1-r)+e*r}}function Go(t,e){var r={},n={},o;(t===null||typeof t!="object")&&(t={}),(e===null||typeof e!="object")&&(e={});for(o in e)o in t?r[o]=St(t[o],e[o]):n[o]=e[o];return function(a){for(o in r)n[o]=r[o](a);return n}}var Nr=/[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,Or=new RegExp(Nr.source,"g");function su(t){return function(){return t}}function uu(t){return function(e){return t(e)+""}}function ne(t,e){var r=Nr.lastIndex=Or.lastIndex=0,n,o,a,i=-1,l=[],s=[];for(t=t+"",e=e+"";(n=Nr.exec(t))&&(o=Or.exec(e));)(a=o.index)>r&&(a=e.slice(r,a),l[i]?l[i]+=a:l[++i]=a),(n=n[0])===(o=o[0])?l[i]?l[i]+=o:l[++i]=o:(l[++i]=null,s.push({i,x:$(n,o)})),r=Or.lastIndex;return r<e.length&&(a=e.slice(r),l[i]?l[i]+=a:l[++i]=a),l.length<2?s[0]?uu(s[0].x):su(e):(e=s.length,function(u){for(var f=0,c;f<e;++f)l[(c=s[f]).i]=c.x(u);return l.join("")})}function St(t,e){var r=typeof e,n;return e==null||r==="boolean"?re(e):(r==="number"?$:r==="string"?(n=X(e))?(e=n,Ct):ne:e instanceof X?Ct:e instanceof Date?Uo:Vo(e)?Po:Array.isArray(e)?Wo:typeof e.valueOf!="function"&&typeof e.toString!="function"||isNaN(e)?Go:$)(t,e)}function Yr(t,e){return t=+t,e=+e,function(r){return Math.round(t*(1-r)+e*r)}}var Xo=180/Math.PI,ze={translateX:0,translateY:0,rotate:0,skewX:0,scaleX:1,scaleY:1};function Rr(t,e,r,n,o,a){var i,l,s;return(i=Math.sqrt(t*t+e*e))&&(t/=i,e/=i),(s=t*r+e*n)&&(r-=t*s,n-=e*s),(l=Math.sqrt(r*r+n*n))&&(r/=l,n/=l,s/=l),t*n<e*r&&(t=-t,e=-e,s=-s,i=-i),{translateX:o,translateY:a,rotate:Math.atan2(e,t)*Xo,skewX:Math.atan(s)*Xo,scaleX:i,scaleY:l}}var qe;function Qo(t){let e=new(typeof DOMMatrix=="function"?DOMMatrix:WebKitCSSMatrix)(t+"");return e.isIdentity?ze:Rr(e.a,e.b,e.c,e.d,e.e,e.f)}function Zo(t){return t==null?ze:(qe||(qe=document.createElementNS("http://www.w3.org/2000/svg","g")),qe.setAttribute("transform",t),(t=qe.transform.baseVal.consolidate())?(t=t.matrix,Rr(t.a,t.b,t.c,t.d,t.e,t.f)):ze)}function Jo(t,e,r,n){function o(u){return u.length?u.pop()+" ":""}function a(u,f,c,p,m,g){if(u!==c||f!==p){var h=m.push("translate(",null,e,null,r);g.push({i:h-4,x:$(u,c)},{i:h-2,x:$(f,p)})}else(c||p)&&m.push("translate("+c+e+p+r)}function i(u,f,c,p){u!==f?(u-f>180?f+=360:f-u>180&&(u+=360),p.push({i:c.push(o(c)+"rotate(",null,n)-2,x:$(u,f)})):f&&c.push(o(c)+"rotate("+f+n)}function l(u,f,c,p){u!==f?p.push({i:c.push(o(c)+"skewX(",null,n)-2,x:$(u,f)}):f&&c.push(o(c)+"skewX("+f+n)}function s(u,f,c,p,m,g){if(u!==c||f!==p){var h=m.push(o(m)+"scale(",null,",",null,")");g.push({i:h-4,x:$(u,c)},{i:h-2,x:$(f,p)})}else(c!==1||p!==1)&&m.push(o(m)+"scale("+c+","+p+")")}return function(u,f){var c=[],p=[];return u=t(u),f=t(f),a(u.translateX,u.translateY,f.translateX,f.translateY,c,p),i(u.rotate,f.rotate,c,p),l(u.skewX,f.skewX,c,p),s(u.scaleX,u.scaleY,f.scaleX,f.scaleY,c,p),u=f=null,function(m){for(var g=-1,h=p.length,b;++g<h;)c[(b=p[g]).i]=b.x(m);return c.join("")}}}var Ir=Jo(Qo,"px, ","px)","deg)"),zr=Jo(Zo,", ",")",")");var It=0,ae=0,oe=0,jo=1e3,Be,ie,Le=0,Mt=0,$e=0,le=typeof performance=="object"&&performance.now?performance:Date,ta=typeof window=="object"&&window.requestAnimationFrame?window.requestAnimationFrame.bind(window):function(t){setTimeout(t,17)};function ue(){return Mt||(ta(cu),Mt=le.now()+$e)}function cu(){Mt=0}function se(){this._call=this._time=this._next=null}se.prototype=He.prototype={constructor:se,restart:function(t,e,r){if(typeof t!="function")throw new TypeError("callback is not a function");r=(r==null?ue():+r)+(e==null?0:+e),!this._next&&ie!==this&&(ie?ie._next=this:Be=this,ie=this),this._call=t,this._time=r,qr()},stop:function(){this._call&&(this._call=null,this._time=1/0,qr())}};function He(t,e,r){var n=new se;return n.restart(t,e,r),n}function ea(){ue(),++It;for(var t=Be,e;t;)(e=Mt-t._time)>=0&&t._call.call(void 0,e),t=t._next;--It}function Ko(){Mt=(Le=le.now())+$e,It=ae=0;try{ea()}finally{It=0,mu(),Mt=0}}function fu(){var t=le.now(),e=t-Le;e>jo&&($e-=e,Le=t)}function mu(){for(var t,e=Be,r,n=1/0;e;)e._call?(n>e._time&&(n=e._time),t=e,e=e._next):(r=e._next,e._next=null,e=t?t._next=r:Be=r);ie=t,qr(n)}function qr(t){if(!It){ae&&(ae=clearTimeout(ae));var e=t-Mt;e>24?(t<1/0&&(ae=setTimeout(Ko,t-le.now()-$e)),oe&&(oe=clearInterval(oe))):(oe||(Le=le.now(),oe=setInterval(fu,jo)),It=1,ta(Ko))}}function Pe(t,e,r){var n=new se;return e=e==null?0:+e,n.restart(o=>{n.stop(),t(o+e)},e,r),n}var pu=Cr("start","end","cancel","interrupt"),du=[],oa=0,ra=1,We=2,Ve=3,na=4,Ue=5,ce=6;function mt(t,e,r,n,o,a){var i=t.__transition;if(!i)t.__transition={};else if(r in i)return;hu(t,r,{name:e,index:n,group:o,on:pu,tween:du,time:a.time,delay:a.delay,duration:a.duration,ease:a.ease,timer:null,state:oa})}function fe(t,e){var r=z(t,e);if(r.state>oa)throw new Error("too late; already scheduled");return r}function H(t,e){var r=z(t,e);if(r.state>Ve)throw new Error("too late; already running");return r}function z(t,e){var r=t.__transition;if(!r||!(r=r[e]))throw new Error("transition not found");return r}function hu(t,e,r){var n=t.__transition,o;n[e]=r,r.timer=He(a,0,r.time);function a(u){r.state=ra,r.timer.restart(i,r.delay,r.time),r.delay<=u&&i(u-r.delay)}function i(u){var f,c,p,m;if(r.state!==ra)return s();for(f in n)if(m=n[f],m.name===r.name){if(m.state===Ve)return Pe(i);m.state===na?(m.state=ce,m.timer.stop(),m.on.call("interrupt",t,t.__data__,m.index,m.group),delete n[f]):+f<e&&(m.state=ce,m.timer.stop(),m.on.call("cancel",t,t.__data__,m.index,m.group),delete n[f])}if(Pe(function(){r.state===Ve&&(r.state=na,r.timer.restart(l,r.delay,r.time),l(u))}),r.state=We,r.on.call("start",t,t.__data__,r.index,r.group),r.state===We){for(r.state=Ve,o=new Array(p=r.tween.length),f=0,c=-1;f<p;++f)(m=r.tween[f].value.call(t,t.__data__,r.index,r.group))&&(o[++c]=m);o.length=c+1}}function l(u){for(var f=u<r.duration?r.ease.call(null,u/r.duration):(r.timer.restart(s),r.state=Ue,1),c=-1,p=o.length;++c<p;)o[c].call(t,f);r.state===Ue&&(r.on.call("end",t,t.__data__,r.index,r.group),s())}function s(){r.state=ce,r.timer.stop(),delete n[e];for(var u in n)return;delete t.__transition}}function Ge(t,e){var r=t.__transition,n,o,a=!0,i;if(r){e=e==null?null:e+"";for(i in r){if((n=r[i]).name!==e){a=!1;continue}o=n.state>We&&n.state<Ue,n.state=ce,n.timer.stop(),n.on.call(o?"interrupt":"cancel",t,t.__data__,n.index,n.group),delete r[i]}a&&delete t.__transition}}function aa(t){return this.each(function(){Ge(this,t)})}function gu(t,e){var r,n;return function(){var o=H(this,t),a=o.tween;if(a!==r){n=r=a;for(var i=0,l=n.length;i<l;++i)if(n[i].name===e){n=n.slice(),n.splice(i,1);break}}o.tween=n}}function yu(t,e,r){var n,o;if(typeof r!="function")throw new Error;return function(){var a=H(this,t),i=a.tween;if(i!==n){o=(n=i).slice();for(var l={name:e,value:r},s=0,u=o.length;s<u;++s)if(o[s].name===e){o[s]=l;break}s===u&&o.push(l)}a.tween=o}}function ia(t,e){var r=this._id;if(t+="",arguments.length<2){for(var n=z(this.node(),r).tween,o=0,a=n.length,i;o<a;++o)if((i=n[o]).name===t)return i.value;return null}return this.each((e==null?gu:yu)(r,t,e))}function zt(t,e,r){var n=t._id;return t.each(function(){var o=H(this,n);(o.value||(o.value={}))[e]=r.apply(this,arguments)}),function(o){return z(o,n).value[e]}}function Xe(t,e){var r;return(typeof e=="number"?$:e instanceof X?Ct:(r=X(e))?(e=r,Ct):ne)(t,e)}function xu(t){return function(){this.removeAttribute(t)}}function bu(t){return function(){this.removeAttributeNS(t.space,t.local)}}function vu(t,e,r){var n,o=r+"",a;return function(){var i=this.getAttribute(t);return i===o?null:i===n?a:a=e(n=i,r)}}function wu(t,e,r){var n,o=r+"",a;return function(){var i=this.getAttributeNS(t.space,t.local);return i===o?null:i===n?a:a=e(n=i,r)}}function _u(t,e,r){var n,o,a;return function(){var i,l=r(this),s;return l==null?void this.removeAttribute(t):(i=this.getAttribute(t),s=l+"",i===s?null:i===n&&s===o?a:(o=s,a=e(n=i,l)))}}function Cu(t,e,r){var n,o,a;return function(){var i,l=r(this),s;return l==null?void this.removeAttributeNS(t.space,t.local):(i=this.getAttributeNS(t.space,t.local),s=l+"",i===s?null:i===n&&s===o?a:(o=s,a=e(n=i,l)))}}function la(t,e){var r=it(t),n=r==="transform"?zr:Xe;return this.attrTween(t,typeof e=="function"?(r.local?Cu:_u)(r,n,zt(this,"attr."+t,e)):e==null?(r.local?bu:xu)(r):(r.local?wu:vu)(r,n,e))}function Su(t,e){return function(r){this.setAttribute(t,e.call(this,r))}}function Mu(t,e){return function(r){this.setAttributeNS(t.space,t.local,e.call(this,r))}}function ku(t,e){var r,n;function o(){var a=e.apply(this,arguments);return a!==n&&(r=(n=a)&&Mu(t,a)),r}return o._value=e,o}function Au(t,e){var r,n;function o(){var a=e.apply(this,arguments);return a!==n&&(r=(n=a)&&Su(t,a)),r}return o._value=e,o}function sa(t,e){var r="attr."+t;if(arguments.length<2)return(r=this.tween(r))&&r._value;if(e==null)return this.tween(r,null);if(typeof e!="function")throw new Error;var n=it(t);return this.tween(r,(n.local?ku:Au)(n,e))}function Du(t,e){return function(){fe(this,t).delay=+e.apply(this,arguments)}}function Tu(t,e){return e=+e,function(){fe(this,t).delay=e}}function ua(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?Du:Tu)(e,t)):z(this.node(),e).delay}function Fu(t,e){return function(){H(this,t).duration=+e.apply(this,arguments)}}function Eu(t,e){return e=+e,function(){H(this,t).duration=e}}function ca(t){var e=this._id;return arguments.length?this.each((typeof t=="function"?Fu:Eu)(e,t)):z(this.node(),e).duration}function Ou(t,e){if(typeof e!="function")throw new Error;return function(){H(this,t).ease=e}}function fa(t){var e=this._id;return arguments.length?this.each(Ou(e,t)):z(this.node(),e).ease}function Nu(t,e){return function(){var r=e.apply(this,arguments);if(typeof r!="function")throw new Error;H(this,t).ease=r}}function ma(t){if(typeof t!="function")throw new Error;return this.each(Nu(this._id,t))}function pa(t){typeof t!="function"&&(t=Jt(t));for(var e=this._groups,r=e.length,n=new Array(r),o=0;o<r;++o)for(var a=e[o],i=a.length,l=n[o]=[],s,u=0;u<i;++u)(s=a[u])&&t.call(s,s.__data__,u,a)&&l.push(s);return new V(n,this._parents,this._name,this._id)}function da(t){if(t._id!==this._id)throw new Error;for(var e=this._groups,r=t._groups,n=e.length,o=r.length,a=Math.min(n,o),i=new Array(n),l=0;l<a;++l)for(var s=e[l],u=r[l],f=s.length,c=i[l]=new Array(f),p,m=0;m<f;++m)(p=s[m]||u[m])&&(c[m]=p);for(;l<n;++l)i[l]=e[l];return new V(i,this._parents,this._name,this._id)}function Yu(t){return(t+"").trim().split(/^|\s+/).every(function(e){var r=e.indexOf(".");return r>=0&&(e=e.slice(0,r)),!e||e==="start"})}function Ru(t,e,r){var n,o,a=Yu(e)?fe:H;return function(){var i=a(this,t),l=i.on;l!==n&&(o=(n=l).copy()).on(e,r),i.on=o}}function ha(t,e){var r=this._id;return arguments.length<2?z(this.node(),r).on.on(t):this.each(Ru(r,t,e))}function Iu(t){return function(){var e=this.parentNode;for(var r in this.__transition)if(+r!==t)return;e&&e.removeChild(this)}}function ga(){return this.on("end.remove",Iu(this._id))}function ya(t){var e=this._name,r=this._id;typeof t!="function"&&(t=vt(t));for(var n=this._groups,o=n.length,a=new Array(o),i=0;i<o;++i)for(var l=n[i],s=l.length,u=a[i]=new Array(s),f,c,p=0;p<s;++p)(f=l[p])&&(c=t.call(f,f.__data__,p,l))&&("__data__"in f&&(c.__data__=f.__data__),u[p]=c,mt(u[p],e,r,p,u,z(f,r)));return new V(a,this._parents,e,r)}function xa(t){var e=this._name,r=this._id;typeof t!="function"&&(t=Zt(t));for(var n=this._groups,o=n.length,a=[],i=[],l=0;l<o;++l)for(var s=n[l],u=s.length,f,c=0;c<u;++c)if(f=s[c]){for(var p=t.call(f,f.__data__,c,s),m,g=z(f,r),h=0,b=p.length;h<b;++h)(m=p[h])&&mt(m,e,r,h,p,g);a.push(p),i.push(f)}return new V(a,i,e,r)}var zu=lt.prototype.constructor;function ba(){return new zu(this._groups,this._parents)}function qu(t,e){var r,n,o;return function(){var a=ft(this,t),i=(this.style.removeProperty(t),ft(this,t));return a===i?null:a===r&&i===n?o:o=e(r=a,n=i)}}function va(t){return function(){this.style.removeProperty(t)}}function Bu(t,e,r){var n,o=r+"",a;return function(){var i=ft(this,t);return i===o?null:i===n?a:a=e(n=i,r)}}function Lu(t,e,r){var n,o,a;return function(){var i=ft(this,t),l=r(this),s=l+"";return l==null&&(s=l=(this.style.removeProperty(t),ft(this,t))),i===s?null:i===n&&s===o?a:(o=s,a=e(n=i,l))}}function $u(t,e){var r,n,o,a="style."+e,i="end."+a,l;return function(){var s=H(this,t),u=s.on,f=s.value[a]==null?l||(l=va(e)):void 0;(u!==r||o!==f)&&(n=(r=u).copy()).on(i,o=f),s.on=n}}function wa(t,e,r){var n=(t+="")=="transform"?Ir:Xe;return e==null?this.styleTween(t,qu(t,n)).on("end.style."+t,va(t)):typeof e=="function"?this.styleTween(t,Lu(t,n,zt(this,"style."+t,e))).each($u(this._id,t)):this.styleTween(t,Bu(t,n,e),r).on("end.style."+t,null)}function Hu(t,e,r){return function(n){this.style.setProperty(t,e.call(this,n),r)}}function Pu(t,e,r){var n,o;function a(){var i=e.apply(this,arguments);return i!==o&&(n=(o=i)&&Hu(t,i,r)),n}return a._value=e,a}function _a(t,e,r){var n="style."+(t+="");if(arguments.length<2)return(n=this.tween(n))&&n._value;if(e==null)return this.tween(n,null);if(typeof e!="function")throw new Error;return this.tween(n,Pu(t,e,r??""))}function Vu(t){return function(){this.textContent=t}}function Wu(t){return function(){var e=t(this);this.textContent=e??""}}function Ca(t){return this.tween("text",typeof t=="function"?Wu(zt(this,"text",t)):Vu(t==null?"":t+""))}function Uu(t){return function(e){this.textContent=t.call(this,e)}}function Gu(t){var e,r;function n(){var o=t.apply(this,arguments);return o!==r&&(e=(r=o)&&Uu(o)),e}return n._value=t,n}function Sa(t){var e="text";if(arguments.length<1)return(e=this.tween(e))&&e._value;if(t==null)return this.tween(e,null);if(typeof t!="function")throw new Error;return this.tween(e,Gu(t))}function Ma(){for(var t=this._name,e=this._id,r=Qe(),n=this._groups,o=n.length,a=0;a<o;++a)for(var i=n[a],l=i.length,s,u=0;u<l;++u)if(s=i[u]){var f=z(s,e);mt(s,t,r,u,i,{time:f.time+f.delay+f.duration,delay:0,duration:f.duration,ease:f.ease})}return new V(n,this._parents,t,r)}function ka(){var t,e,r=this,n=r._id,o=r.size();return new Promise(function(a,i){var l={value:i},s={value:function(){--o===0&&a()}};r.each(function(){var u=H(this,n),f=u.on;f!==t&&(e=(t=f).copy(),e._.cancel.push(l),e._.interrupt.push(l),e._.end.push(s)),u.on=e}),o===0&&a()})}var Xu=0;function V(t,e,r,n){this._groups=t,this._parents=e,this._name=r,this._id=n}function me(t){return lt().transition(t)}function Qe(){return++Xu}var st=lt.prototype;V.prototype=me.prototype={constructor:V,select:ya,selectAll:xa,selectChild:st.selectChild,selectChildren:st.selectChildren,filter:pa,merge:da,selection:ba,transition:Ma,call:st.call,nodes:st.nodes,node:st.node,size:st.size,empty:st.empty,each:st.each,on:ha,attr:la,attrTween:sa,style:wa,styleTween:_a,text:Ca,textTween:Sa,remove:ga,tween:ia,delay:ua,duration:ca,ease:fa,easeVarying:ma,end:ka,[Symbol.iterator]:st[Symbol.iterator]};function Br(t){return--t*t*t+1}function Ze(t){return((t*=2)<=1?t*t*t:(t-=2)*t*t+2)/2}var Qu={time:null,delay:0,duration:250,ease:Ze};function Zu(t,e){for(var r;!(r=t.__transition)||!(r=r[e]);)if(!(t=t.parentNode))throw new Error(`transition ${e} not found`);return r}function Aa(t){var e,r;t instanceof V?(e=t._id,t=t._name):(e=Qe(),(r=Qu).time=ue(),t=t==null?null:t+"");for(var n=this._groups,o=n.length,a=0;a<o;++a)for(var i=n[a],l=i.length,s,u=0;u<l;++u)(s=i[u])&&mt(s,t,e,u,i,r||Zu(s,e));return new V(n,this._parents,t,e)}lt.prototype.interrupt=aa;lt.prototype.transition=Aa;var{abs:Xy,max:Qy,min:Zy}=Math;function Da(t){return[+t[0],+t[1]]}function Ju(t){return[Da(t[0]),Da(t[1])]}var Jy={name:"x",handles:["w","e"].map(Lr),input:function(t,e){return t==null?null:[[+t[0],e[0][1]],[+t[1],e[1][1]]]},output:function(t){return t&&[t[0][0],t[1][0]]}},Ky={name:"y",handles:["n","s"].map(Lr),input:function(t,e){return t==null?null:[[e[0][0],+t[0]],[e[1][0],+t[1]]]},output:function(t){return t&&[t[0][1],t[1][1]]}},jy={name:"xy",handles:["n","w","e","s","nw","ne","sw","se"].map(Lr),input:function(t){return t==null?null:Ju(t)},output:function(t){return t}};function Lr(t){return{type:t}}function Ta(t){return Math.abs(t=Math.round(t))>=1e21?t.toLocaleString("en").replace(/,/g,""):t.toString(10)}function kt(t,e){if((r=(t=e?t.toExponential(e-1):t.toExponential()).indexOf("e"))<0)return null;var r,n=t.slice(0,r);return[n.length>1?n[0]+n.slice(2):n,+t.slice(r+1)]}function ot(t){return t=kt(Math.abs(t)),t?t[1]:NaN}function Fa(t,e){return function(r,n){for(var o=r.length,a=[],i=0,l=t[0],s=0;o>0&&l>0&&(s+l+1>n&&(l=Math.max(1,n-s)),a.push(r.substring(o-=l,o+l)),!((s+=l+1)>n));)l=t[i=(i+1)%t.length];return a.reverse().join(e)}}function Ea(t){return function(e){return e.replace(/[0-9]/g,function(r){return t[+r]})}}var Ku=/^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;function pt(t){if(!(e=Ku.exec(t)))throw new Error("invalid format: "+t);var e;return new Je({fill:e[1],align:e[2],sign:e[3],symbol:e[4],zero:e[5],width:e[6],comma:e[7],precision:e[8]&&e[8].slice(1),trim:e[9],type:e[10]})}pt.prototype=Je.prototype;function Je(t){this.fill=t.fill===void 0?" ":t.fill+"",this.align=t.align===void 0?">":t.align+"",this.sign=t.sign===void 0?"-":t.sign+"",this.symbol=t.symbol===void 0?"":t.symbol+"",this.zero=!!t.zero,this.width=t.width===void 0?void 0:+t.width,this.comma=!!t.comma,this.precision=t.precision===void 0?void 0:+t.precision,this.trim=!!t.trim,this.type=t.type===void 0?"":t.type+""}Je.prototype.toString=function(){return this.fill+this.align+this.sign+this.symbol+(this.zero?"0":"")+(this.width===void 0?"":Math.max(1,this.width|0))+(this.comma?",":"")+(this.precision===void 0?"":"."+Math.max(0,this.precision|0))+(this.trim?"~":"")+this.type};function Oa(t){t:for(var e=t.length,r=1,n=-1,o;r<e;++r)switch(t[r]){case".":n=o=r;break;case"0":n===0&&(n=r),o=r;break;default:if(!+t[r])break t;n>0&&(n=0);break}return n>0?t.slice(0,n)+t.slice(o+1):t}var $r;function Na(t,e){var r=kt(t,e);if(!r)return t+"";var n=r[0],o=r[1],a=o-($r=Math.max(-8,Math.min(8,Math.floor(o/3)))*3)+1,i=n.length;return a===i?n:a>i?n+new Array(a-i+1).join("0"):a>0?n.slice(0,a)+"."+n.slice(a):"0."+new Array(1-a).join("0")+kt(t,Math.max(0,e+a-1))[0]}function Hr(t,e){var r=kt(t,e);if(!r)return t+"";var n=r[0],o=r[1];return o<0?"0."+new Array(-o).join("0")+n:n.length>o+1?n.slice(0,o+1)+"."+n.slice(o+1):n+new Array(o-n.length+2).join("0")}var Pr={"%":(t,e)=>(t*100).toFixed(e),b:t=>Math.round(t).toString(2),c:t=>t+"",d:Ta,e:(t,e)=>t.toExponential(e),f:(t,e)=>t.toFixed(e),g:(t,e)=>t.toPrecision(e),o:t=>Math.round(t).toString(8),p:(t,e)=>Hr(t*100,e),r:Hr,s:Na,X:t=>Math.round(t).toString(16).toUpperCase(),x:t=>Math.round(t).toString(16)};function Vr(t){return t}var Ya=Array.prototype.map,Ra=["y","z","a","f","p","n","\xB5","m","","k","M","G","T","P","E","Z","Y"];function Ia(t){var e=t.grouping===void 0||t.thousands===void 0?Vr:Fa(Ya.call(t.grouping,Number),t.thousands+""),r=t.currency===void 0?"":t.currency[0]+"",n=t.currency===void 0?"":t.currency[1]+"",o=t.decimal===void 0?".":t.decimal+"",a=t.numerals===void 0?Vr:Ea(Ya.call(t.numerals,String)),i=t.percent===void 0?"%":t.percent+"",l=t.minus===void 0?"\u2212":t.minus+"",s=t.nan===void 0?"NaN":t.nan+"";function u(c){c=pt(c);var p=c.fill,m=c.align,g=c.sign,h=c.symbol,b=c.zero,x=c.width,M=c.comma,C=c.precision,k=c.trim,w=c.type;w==="n"?(M=!0,w="g"):Pr[w]||(C===void 0&&(C=12),k=!0,w="g"),(b||p==="0"&&m==="=")&&(b=!0,p="0",m="=");var S=h==="$"?r:h==="#"&&/[boxX]/.test(w)?"0"+w.toLowerCase():"",I=h==="$"?n:/[%p]/.test(w)?i:"",q=Pr[w],Q=/[defgprs%]/.test(w);C=C===void 0?6:/[gprs]/.test(w)?Math.max(1,Math.min(21,C)):Math.max(0,Math.min(20,C));function R(y){var E=S,D=I,P,tt,K;if(w==="c")D=q(y)+D,y="";else{y=+y;var W=y<0||1/y<0;if(y=isNaN(y)?s:q(Math.abs(y),C),k&&(y=Oa(y)),W&&+y==0&&g!=="+"&&(W=!1),E=(W?g==="("?g:l:g==="-"||g==="("?"":g)+E,D=(w==="s"?Ra[8+$r/3]:"")+D+(W&&g==="("?")":""),Q){for(P=-1,tt=y.length;++P<tt;)if(K=y.charCodeAt(P),48>K||K>57){D=(K===46?o+y.slice(P+1):y.slice(P))+D,y=y.slice(0,P);break}}}M&&!b&&(y=e(y,1/0));var _=E.length+y.length+D.length,O=_<x?new Array(x-_+1).join(p):"";switch(M&&b&&(y=e(O+y,O.length?x-D.length:1/0),O=""),m){case"<":y=E+y+D+O;break;case"=":y=E+O+y+D;break;case"^":y=O.slice(0,_=O.length>>1)+E+y+D+O.slice(_);break;default:y=O+E+y+D;break}return a(y)}return R.toString=function(){return c+""},R}function f(c,p){var m=u((c=pt(c),c.type="f",c)),g=Math.max(-8,Math.min(8,Math.floor(ot(p)/3)))*3,h=Math.pow(10,-g),b=Ra[8+g/3];return function(x){return m(h*x)+b}}return{format:u,formatPrefix:f}}var Ke,qt,je;Wr({thousands:",",grouping:[3],currency:["$",""]});function Wr(t){return Ke=Ia(t),qt=Ke.format,je=Ke.formatPrefix,Ke}function Ur(t){return Math.max(0,-ot(Math.abs(t)))}function Gr(t,e){return Math.max(0,Math.max(-8,Math.min(8,Math.floor(ot(e)/3)))*3-ot(Math.abs(t)))}function Xr(t,e){return t=Math.abs(t),e=Math.abs(e)-t,Math.max(0,ot(e)-ot(t))+1}function Bt(t,e){switch(arguments.length){case 0:break;case 1:this.range(t);break;default:this.range(e).domain(t);break}return this}var za=Symbol("implicit");function tr(){var t=new Ot,e=[],r=[],n=za;function o(a){let i=t.get(a);if(i===void 0){if(n!==za)return n;t.set(a,i=e.push(a)-1)}return r[i%r.length]}return o.domain=function(a){if(!arguments.length)return e.slice();e=[],t=new Ot;for(let i of a)t.has(i)||t.set(i,e.push(i)-1);return o},o.range=function(a){return arguments.length?(r=Array.from(a),o):r.slice()},o.unknown=function(a){return arguments.length?(n=a,o):n},o.copy=function(){return tr(e,r).unknown(n)},Bt.apply(o,arguments),o}function pe(){var t=tr().unknown(void 0),e=t.domain,r=t.range,n=0,o=1,a,i,l=!1,s=0,u=0,f=.5;delete t.unknown;function c(){var p=e().length,m=o<n,g=m?o:n,h=m?n:o;a=(h-g)/Math.max(1,p-s+u*2),l&&(a=Math.floor(a)),g+=(h-g-a*(p-s))*f,i=a*(1-s),l&&(g=Math.round(g),i=Math.round(i));var b=Se(p).map(function(x){return g+a*x});return r(m?b.reverse():b)}return t.domain=function(p){return arguments.length?(e(p),c()):e()},t.range=function(p){return arguments.length?([n,o]=p,n=+n,o=+o,c()):[n,o]},t.rangeRound=function(p){return[n,o]=p,n=+n,o=+o,l=!0,c()},t.bandwidth=function(){return i},t.step=function(){return a},t.round=function(p){return arguments.length?(l=!!p,c()):l},t.padding=function(p){return arguments.length?(s=Math.min(1,u=+p),c()):s},t.paddingInner=function(p){return arguments.length?(s=Math.min(1,p),c()):s},t.paddingOuter=function(p){return arguments.length?(u=+p,c()):u},t.align=function(p){return arguments.length?(f=Math.max(0,Math.min(1,p)),c()):f},t.copy=function(){return pe(e(),[n,o]).round(l).paddingInner(s).paddingOuter(u).align(f)},Bt.apply(c(),arguments)}function Qr(t){return function(){return t}}function Zr(t){return+t}var qa=[0,1];function Lt(t){return t}function Jr(t,e){return(e-=t=+t)?function(r){return(r-t)/e}:Qr(isNaN(e)?NaN:.5)}function ju(t,e){var r;return t>e&&(r=t,t=e,e=r),function(n){return Math.max(t,Math.min(e,n))}}function tc(t,e,r){var n=t[0],o=t[1],a=e[0],i=e[1];return o<n?(n=Jr(o,n),a=r(i,a)):(n=Jr(n,o),a=r(a,i)),function(l){return a(n(l))}}function ec(t,e,r){var n=Math.min(t.length,e.length)-1,o=new Array(n),a=new Array(n),i=-1;for(t[n]<t[0]&&(t=t.slice().reverse(),e=e.slice().reverse());++i<n;)o[i]=Jr(t[i],t[i+1]),a[i]=r(e[i],e[i+1]);return function(l){var s=gr(t,l,1,n)-1;return a[s](o[s](l))}}function Ba(t,e){return e.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown())}function rc(){var t=qa,e=qa,r=St,n,o,a,i=Lt,l,s,u;function f(){var p=Math.min(t.length,e.length);return i!==Lt&&(i=ju(t[0],t[p-1])),l=p>2?ec:tc,s=u=null,c}function c(p){return p==null||isNaN(p=+p)?a:(s||(s=l(t.map(n),e,r)))(n(i(p)))}return c.invert=function(p){return i(o((u||(u=l(e,t.map(n),$)))(p)))},c.domain=function(p){return arguments.length?(t=Array.from(p,Zr),f()):t.slice()},c.range=function(p){return arguments.length?(e=Array.from(p),f()):e.slice()},c.rangeRound=function(p){return e=Array.from(p),r=Yr,f()},c.clamp=function(p){return arguments.length?(i=p?!0:Lt,f()):i!==Lt},c.interpolate=function(p){return arguments.length?(r=p,f()):r},c.unknown=function(p){return arguments.length?(a=p,c):a},function(p,m){return n=p,o=m,f()}}function Kr(){return rc()(Lt,Lt)}function jr(t,e,r,n){var o=yr(t,e,r),a;switch(n=pt(n??",f"),n.type){case"s":{var i=Math.max(Math.abs(t),Math.abs(e));return n.precision==null&&!isNaN(a=Gr(o,i))&&(n.precision=a),je(n,i)}case"":case"e":case"g":case"p":case"r":{n.precision==null&&!isNaN(a=Xr(o,Math.max(Math.abs(t),Math.abs(e))))&&(n.precision=a-(n.type==="e"));break}case"f":case"%":{n.precision==null&&!isNaN(a=Ur(o))&&(n.precision=a-(n.type==="%")*2);break}}return qt(n)}function nc(t){var e=t.domain;return t.ticks=function(r){var n=e();return Ce(n[0],n[n.length-1],r??10)},t.tickFormat=function(r,n){var o=e();return jr(o[0],o[o.length-1],r??10,n)},t.nice=function(r){r==null&&(r=10);var n=e(),o=0,a=n.length-1,i=n[o],l=n[a],s,u,f=10;for(l<i&&(u=i,i=l,l=u,u=o,o=a,a=u);f-- >0;){if(u=Xt(i,l,r),u===s)return n[o]=i,n[a]=l,e(n);if(u>0)i=Math.floor(i/u)*u,l=Math.ceil(l/u)*u;else if(u<0)i=Math.ceil(i*u)/u,l=Math.floor(l*u)/u;else break;s=u}return t},t}function de(){var t=Kr();return t.copy=function(){return Ba(t,de())},Bt.apply(t,arguments),nc(t)}function dt(t,e,r){this.k=t,this.x=e,this.y=r}dt.prototype={constructor:dt,scale:function(t){return t===1?this:new dt(this.k*t,this.x,this.y)},translate:function(t,e){return t===0&e===0?this:new dt(this.k,this.x+this.k*t,this.y+this.k*e)},apply:function(t){return[t[0]*this.k+this.x,t[1]*this.k+this.y]},applyX:function(t){return t*this.k+this.x},applyY:function(t){return t*this.k+this.y},invert:function(t){return[(t[0]-this.x)/this.k,(t[1]-this.y)/this.k]},invertX:function(t){return(t-this.x)/this.k},invertY:function(t){return(t-this.y)/this.k},rescaleX:function(t){return t.copy().domain(t.range().map(this.invertX,this).map(t.invert,t))},rescaleY:function(t){return t.copy().domain(t.range().map(this.invertY,this).map(t.invert,t))},toString:function(){return"translate("+this.x+","+this.y+") scale("+this.k+")"}};var tn=new dt(1,0,0);en.prototype=dt.prototype;function en(t){for(;!t.__zoom;)if(!(t=t.parentNode))return tn;return t.__zoom}var he="__waterfallChartState",La=320,$a=260,Va=({container:t,data:e=[],slots:r=[],options:n={},language:o="en",dimensions:{width:a=0,height:i=0}={}})=>{let l=n??{},{root:s,tooltip:u}=Wa(t),f=ic({data:e,slots:r,options:l,language:o});if(!f.steps.length){Ua(s),t[he]=f;return}Ga({root:s,tooltip:u,steps:f.steps,config:f.config,formatValue:f.formatValue,formatLabel:f.formatLabel,dimensions:{width:a,height:i},container:t,theme:f.theme}),t[he]=f},ac=({container:t,data:e=[],slots:r=[],options:n={},language:o="en",dimensions:{width:a=0,height:i=0}={}})=>{let l=t[he]??null;if(!l){Va({container:t,data:e,slots:r,options:n,language:o,dimensions:{width:a,height:i}});return}let{root:s,tooltip:u}=Wa(t);if(!l.steps.length){Ua(s),t[he]=l;return}Ga({root:s,tooltip:u,steps:l.steps,config:l.config,formatValue:l.formatValue,formatLabel:l.formatLabel,dimensions:{width:a,height:i},container:t,theme:l.theme}),t[he]=l};function ic({data:t,slots:e,options:r,language:n}){let o=e?.find(c=>c.name==="category"),a=e?.find(c=>c.name==="measure"),i=uc(a,r,n),l=(c,p)=>yc(c,p,i),s=sc({data:t,categorySlot:o,measureSlot:a,options:r,language:n}),u=lc(s),f={colors:cc(r,r.theme),animationDuration:Math.max(0,Number(r.animationDuration)||700)};return{steps:u,formatValue:i,formatLabel:l,config:f,language:n,theme:r.theme}}function Wa(t){t.innerHTML="";let e=document.createElement("div");e.className="waterfall-chart-container",t.appendChild(e);let r=Nt(e),n=r.append("div").attr("class","waterfall-tooltip").style("opacity","0");return{root:r,tooltip:n}}function Ua(t){let e=t.append("div").attr("class","empty-state");e.append("div").attr("class","empty-state-title").text("Waterfall chart"),e.append("div").attr("class","empty-state-message").text("Assign a category and a measure to render the waterfall chart.")}function Ga({root:t,tooltip:e,steps:r,config:n,formatValue:o,formatLabel:a,dimensions:i,container:l,theme:s}){let{width:u=0,height:f=0}=i,c=Math.max(u||l.clientWidth||La,La),p=Math.max(f||l.clientHeight||$a,$a),m={top:48,right:48,bottom:110,left:92},g=Math.max(c-m.left-m.right,80),h=Math.max(p-m.top-m.bottom,80);s?.itemsBackground?t.style("background",s.itemsBackground):t.style("background","transparent");let b=fc(s?.itemsBackground),x=t.append("svg").attr("class","waterfall-svg").attr("viewBox",`0 0 ${c} ${p}`).attr("preserveAspectRatio","xMidYMid meet");x.style("width","100%").style("height","100%");let M=x.append("g").attr("class","waterfall-chart").attr("transform",`translate(${m.left}, ${m.top})`),C=pe().domain(r.map(_=>_.label)).range([0,g]).paddingInner(.4).paddingOuter(.25),k=Math.min(0,...r.map(_=>Math.min(_.start,_.end))),w=Math.max(0,...r.map(_=>Math.max(_.start,_.end))),S=de().domain([k,w]).nice().range([h,0]);M.append("line").attr("class","waterfall-baseline").attr("x1",0).attr("x2",g).attr("y1",S(0)).attr("y2",S(0)).attr("stroke",b.baseline);let I=_r(S).ticks(6).tickFormat(_=>o(Number(_)));M.append("g").attr("class","waterfall-axis waterfall-axis--y").call(I);let q=wr(C);if(M.append("g").attr("class","waterfall-axis waterfall-axis--x").attr("transform",`translate(0, ${h})`).call(q).selectAll("text").attr("transform","rotate(-30)").attr("text-anchor","end").attr("dx","-0.6em").attr("dy","0.9em"),s?.axis?.fontSize){let _=`${s.axis.fontSize}px`;x.selectAll(".waterfall-axis text").style("font-size",_)}x.selectAll(".waterfall-axis line, .waterfall-axis path").attr("stroke",b.line),x.selectAll(".waterfall-axis text").style("fill",b.text),M.select(".waterfall-baseline").attr("stroke",b.baseline);let R=me("waterfall-bars").duration(n.animationDuration).ease(Br),y=M.append("g").attr("class","waterfall-connectors"),E=[];for(let _=1;_<r.length;_+=1)E.push({from:r[_-1],to:r[_]});y.selectAll("path").data(E).enter().append("path").attr("class",_=>`waterfall-connector connector-from-${_.from.index} connector-to-${_.to.index}`).attr("d",_=>gc(_,C,S)).attr("stroke",n.colors.connector).attr("stroke-width",1.5).attr("stroke-linecap","round").attr("fill","none").attr("opacity",0).attr("pointer-events","none").transition(R).delay(n.animationDuration/3).attr("opacity",1);let tt=M.append("g").attr("class","waterfall-bars").selectAll("g").data(r).enter().append("g").attr("class",_=>`waterfall-bar waterfall-bar--${_.type}`).attr("transform",_=>`translate(${C(_.label)??0}, 0)`);tt.append("rect").attr("class","waterfall-bar-rect").attr("x",0).attr("width",C.bandwidth()).attr("y",_=>S(_.start)).attr("height",0).attr("fill",_=>Xa(_,n.colors)).attr("rx",3).attr("ry",3).transition(R).attr("y",_=>S(Math.max(_.start,_.end))).attr("height",_=>{let O=Math.abs(S(_.start)-S(_.end));return O<1?1:O});let W=tt.append("text").attr("class","waterfall-bar-label").attr("x",C.bandwidth()/2).attr("text-anchor","middle").attr("y",_=>nn(_,S)).text(_=>a(_.labelValue,_.type)).style("opacity",0);mc(W,S,n.colors,b.text),W.transition(R.delay(n.animationDuration/4)).style("opacity",1).attr("y",_=>nn(_,S)),tt.on("mouseenter",function(_,O){Nt(this).classed("is-active",!0),Ha(y,O.index,!0),e.html(hc(O,a,o)).style("opacity","1").classed("is-visible",!0),Pa(_,e,t)}).on("mousemove",function(_){Pa(_,e,t)}).on("mouseleave",function(_,O){Nt(this).classed("is-active",!1),Ha(y,O.index,!1),e.style("opacity","0").classed("is-visible",!1)})}function lc(t){let e=0,r=!1;return t.map((n,o)=>{let a=n.type,i,l,s,u=n.value;if(a==="start")i=0,l=n.value,e=l,r=!0,s=e;else if(a==="total"){let f=r?e:n.value;i=0,l=f,e=f,s=f,u=f}else i=r||o>0?e:0,l=i+n.value,e=l,s=n.value;return{index:o,label:n.label,type:a,value:u,start:i,end:l,runningTotal:e,labelValue:s}})}function sc({data:t,categorySlot:e,measureSlot:r,options:n,language:o}){if(Array.isArray(n.data)&&n.data.length)return n.data.map((h,b,x)=>({label:String(h.label??`Step ${b+1}`),value:Number(h.value)||0,type:At(h.type,b,x.length)}));let a=e?.content?.[0],i=r?.content?.[0];if(!(!!a&&!!i)||!t?.length)return rn();let s=a?ve(a,{level:a.level??9}):h=>String(h??""),u=n.typeMapping??{},f=a?.type,c=t.map((h,b,x)=>{let M=h[0],C=xc(M,o),k=s(f==="datetime"?new Date(C):C),w=h[1],S=bc(w),I=wc(h[2]),q=u[String(k)],Q=At(q??I,b,x.length),R=null;return f==="datetime"?R=vc(C):f==="hierarchy"&&(R=String(k).toLocaleLowerCase()),{label:String(k),value:S,type:Q,sortValue:R,order:b}});if(!c.length)return rn();let m=c.map(h=>({label:h.label,value:h.value,type:h.type}));if(!m.length)return rn();m.some(h=>h.type==="start")||(m[0].type="start");let g=m.length-1;return!m.some(h=>h.type==="total")&&g>=0&&(m[g].type="total"),m}function uc(t,e,r){if(t?.content?.[0]){let o=ve(t.content[0]);return a=>o(a)}if(e?.numberFormat)try{let o=qt(e.numberFormat);return a=>o(a)}catch{}let n=new Intl.NumberFormat(r||"en");return o=>n.format(o)}function cc(t,e){let r=Array.isArray(e?.colors)?e?.colors??[]:[],n=t.increaseColor||r[0]||"#2e7d32",o=t.decreaseColor||r[1]||"#c62828",a=t.totalColor||r[2]||"#455a64",i=t.connectorColor||"#9e9e9e";return{increase:String(n),decrease:String(o),total:String(a),connector:String(i)}}function fc(t){let e={text:"#555555",line:"#d0d0d0",baseline:"#9e9e9e"};return!t||!X(t)?e:Qa(t)?{text:"#f5f5f5",line:"rgba(255, 255, 255, 0.35)",baseline:"rgba(255, 255, 255, 0.55)"}:e}function Xa(t,e){return t.type==="change"?t.labelValue<0?e.decrease:t.labelValue>0?e.increase:e.total:e.total}function mc(t,e,r,n){let o=n??"#212121";t.each(function(a){let i=Xa(a,r),l=Qa(i),s=pc(a,e);Nt(this).classed("is-invert",l&&s).style("fill",s&&l?"#ffffff":o)})}function pc(t,e){let r=e(t.start),n=e(t.end),o=nn(t,e),a=Math.min(r,n),i=Math.max(r,n),l=1;return o>=a-l&&o<=i+l}function Qa(t){let e=X(t);if(!e)return!1;let r=e.rgb();return(.2126*r.r+.7152*r.g+.0722*r.b)/255<=.55}function dc(t,e){return t.type==="change"&&t.labelValue<0?Math.abs(e(t.start)-e(t.end))>=22:!1}function nn(t,e){let r=e(Math.max(t.start,t.end)),n=e(Math.min(t.start,t.end)),o=Math.abs(e(t.start)-e(t.end));return dc(t,e)?r+o-8:t.type==="change"&&t.labelValue<0?r+o+14:n-8}function Ha(t,e,r){t.selectAll(`.connector-to-${e}, .connector-from-${e}`).classed("is-active",r)}function hc(t,e,r){let n=e(t.labelValue,t.type),o=r(t.runningTotal);return`
    <div class="waterfall-tooltip__title">${t.label}</div>
    <div class="waterfall-tooltip__row"><span>Value</span><span>${n}</span></div>
    <div class="waterfall-tooltip__row"><span>Running total</span><span>${o}</span></div>
  `}function Pa(t,e,r){let n=r.node(),o=e.node();if(!n||!o)return;let a=Dr(t,n),i=o.offsetWidth,l=o.offsetHeight,s=n.clientWidth,u=n.clientHeight,f=a[0]+16,c=a[1]-l-16;f+i>s&&(f=Math.max(8,s-i-8)),c<0&&(c=a[1]+16),c+l>u&&(c=Math.max(8,u-l-8)),e.style("transform",`translate(${f}px, ${c}px)`)}function gc(t,e,r){let n=(e(t.from.label)??0)+e.bandwidth(),o=e(t.to.label)??0,a=r(t.from.end),i=r(t.to.start);if(Math.abs(a-i)<1)return`M${n},${a}H${o}`;let l=n+(o-n)/2;return`M${n},${a}H${l}V${i}H${o}`}function yc(t,e,r){if(e==="change"){if(t<0)return`(${r(Math.abs(t))})`;if(t>0)return`+${r(t)}`}return r(t)}function rn(){let t=[{label:"Opening Balance",value:12e4,type:"start"},{label:"Sales Growth",value:85e3,type:"change"},{label:"Cost of Goods Sold",value:-45e3,type:"change"},{label:"Operating Expenses",value:-32e3,type:"change"},{label:"Marketing Investment",value:-15e3,type:"change"},{label:"Other Income",value:12e3,type:"change"}],e=0;return t.forEach((r,n)=>{n===0?e=r.value:e+=r.value}),t.push({label:"Net Result",value:e,type:"total"}),t}function xc(t,e){if(t==null)return"";if(typeof t=="object"){let r=t;if(typeof r.raw<"u")return r.raw;if(typeof r.value<"u")return r.value;if(typeof r.name=="object"&&r.name!==null){let n=r.name;return n[e]??n.en??Object.values(n)[0]}}return t}function bc(t){if(t==null)return 0;if(typeof t=="number")return t;if(typeof t=="string"){let e=Number(t);return Number.isFinite(e)?e:0}if(typeof t=="object"){let e=t;if(typeof e.raw=="number")return e.raw;if(typeof e.value=="number")return e.value;if(typeof e.value=="string"){let r=Number(e.value);return Number.isFinite(r)?r:0}}return 0}function vc(t){if(t instanceof Date){let e=t.getTime();return Number.isNaN(e)?null:e}if(typeof t=="number")return Number.isFinite(t)?t:null;if(typeof t=="string"){let e=Date.parse(t);return Number.isFinite(e)?e:null}return null}function At(t,e,r){if(typeof t=="string"){let n=t.toLowerCase();if(["start","begin","baseline","opening"].includes(n))return"start";if(["total","end","closing","net","result"].includes(n))return"total";if(["change","delta","increase","decrease","diff","adjustment"].includes(n))return"change"}return e===0?"start":typeof r=="number"&&e===r-1?"total":"change"}function wc(t){if(t!=null){if(typeof t=="string")return At(t);if(typeof t=="object"){let e=t;if(typeof e.type=="string")return At(e.type);if(typeof e.label=="string")return At(e.label);if(typeof e.value=="string")return At(e.value);if(typeof e.name=="object"&&e.name!==null){let r=e.name,n=r.en??Object.values(r)[0];return At(n)}}}}export{Va as render,ac as resize};
/*! Bundled license information:

@luzmo/analytics-components-kit/components/decompose-numeric-format-BuZcjH2k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/localize-BX7q0S0M.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/formatter-CQDms6fU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/area-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bar-chart-slots.config-MQAjNXqV.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/box-plot-slots.config-BRhnF2FE.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bubble-chart-slots.config-Bbh94VgZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/bullet-chart-slots.config-BlWTleBt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/choropleth-map-slots.config-B-uJTj4q.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circle-pack-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/circular-gauge-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/column-chart-slots.config-DAdAk17k.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/combination-chart-slots.config-CqKLFKCZ.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/conditional-number-slots.config-L3t5pb1-.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/date-filter-slots.config-CxB8IF5B.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/donut-chart-slots.config-BEwhfq27.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/dropdown-filter-slots.config-B8J6ftCh.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/evolution-number-slots.config-CW21b2ua.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/funnel-chart-slots.config-BBhMS2qi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/heat-table-slots.config-DJkP72oT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/hexbin-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/image-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/line-chart-slots.config-P7xa-pHi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/marker-map-slots.config-cdD8XTmI.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/ohlc-chart-slots.config-Cvy5n1xv.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/parallel-coordinates-plot-slots.config-CQW2CJW6.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pivot-table-slots.config-BH5fOJre.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/pyramid-chart-slots.config-Cm9bQsXT.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/radar-chart-slots.config-Dpmytmc3.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/regular-table-slots.config-EUS-V9lL.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/route-map-slots.config-DYCcaQZi.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sankey-diagram-slots.config-BSTBEZDe.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/scatter-plot-slots.config-BuWYqDWK.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/search-filter-slots.config-DmiVXOva.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slicer-filter-slots.config-CHQ0ZXga.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/slider-filter-slots.config-BN3K1rnl.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/speedometer-chart-slots.config-DA-ZAc5d.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/spike-map-slots.config-CuqpgkvN.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/strip-plot-slots.config-Co8ghEv8.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/sunburst-chart-slots.config-xwVdRiwS.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/symbol-map-slots.config-C5CKaVED.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/text-slots.config-Hy5yNIAX.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/treemap-chart-slots.config-xLD22K9V.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/venn-diagram-slots.config-DPmj71cR.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/video-slots.config-IpwUxDyU.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/wordcloud-chart-slots.config-BS4sOOHt.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/index-BEAYzHcY.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)

@luzmo/analytics-components-kit/components/utils.js:
  (*! * A kit of modern Luzmo Web Components for analytics in your web application.
   * 
   * Copyright © 2025 Luzmo
   * All rights reserved.
   * Luzmo web components (“Luzmo Web Components”)
   * must be used according to the Luzmo Terms of Service.
   * This license allows users with a current active Luzmo account
   * to use the Luzmo Web Components. This license terminates
   * automatically if a user no longer has an active Luzmo account.
   * Please view the Luzmo Terms of Service at: https://www.luzmo.com/information-pages/terms-of-use.
   * 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
   * *)
*/
